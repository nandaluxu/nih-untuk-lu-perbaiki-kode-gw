/**
 * plugins/owner/amexport.js — Render & kirim hasil AM ke chat.
 *
 * Adaptasi case 'amexport' dari AMRenderKit/bot-plugin/am-plugin.mjs.
 *
 * Pemakaian: .amexport [res] [fps] [quality]
 *   res:     360 / 540 / 720 / 1080
 *   fps:     30 / 60
 *   quality: low / medium / high
 *   Urutan argumen bebas; argumen tidak dikenali diabaikan.
 *
 * Perilaku:
 *   1. Validasi ada sesi + tidak ada render jalan.
 *   2. Parse argumen (res/fps/quality) — pakai default kalau tidak ada.
 *   3. startRender → renderId, simpan ke state.rendering.
 *   4. Kirim pesan "Render mulai ... 0%" sebagai anchor progress.
 *   5. waitForRender + onProgress → update progress tiap
 *      cfg.progressUpdateEveryPct%.
 *   6. downloadRender → Buffer MP4.
 *   7. Kirim MP4 ke chat pakai sendVideoSmart (lib/messaging/video-send.js)
 *      — punya fallback chain + anti-hang timeout, cocok untuk file render
 *      yang ukurannya gak tentu (360p kecil, 1080p bisa puluhan MB).
 *   8. Bersihkan state.rendering.
 *
 * Watchdog: plugin ini masuk category 'amrender' yang punya timeout 25
 * menit (handler.js — EXEC_TIMEOUT_CATEGORY_MS.amrender). Render 1080p
 * bisa makan 15-20 menit di server Playwright segede itu — watchdog harus
 * longgar. Default 3 menit tidak cukup.
 *
 * Catatan: plugin asli langsung pakai sock.sendMessage untuk video.
 * Di bot-gw kita pakai sendVideoSmart karena ada bug vendor starcore
 * ("err is not defined") di jalur video bubble — sendVideoSmart punya
 * fallback document yang terbukti jalan di server user. Lihat docstring
 * lib/messaging/video-send.js untuk detail.
 */

import { sendVideoSmart } from '../../lib/messaging/video-send.js'
import {
    getClient,
    getState,
    touch,
    cleanupExpired,
    apiErrText,
    parseExportArgs,
    fmtSize,
    cfg,
    logger,
} from '../../lib/amrender/index.js'

export default {
    name: 'amexport',
    aliases: ['amrender-export'],
    description: 'Render & kirim hasil AM ke chat',
    category: 'amrender',
    owner: true,
    usage: '.amexport [res] [fps] [quality]',
    example: ['.amexport', '.amexport 720', '.amexport 1080 60 high', '.amexport 360 30 low'],
    limit: true,
    limitType: 'group',
    limitGroup: 'amrender',
    cooldownMs: 60_000,

    async execute(ctx) {
        const { args, reply, chat, prefix, sock, message: m } = ctx
        const pfx = prefix ?? '.'

        cleanupExpired()

        const st = getState(chat)
        if (!st) {
            return reply(`Belum ada sesi. Mulai dengan ${pfx}amrender <link>`)
        }
        if (st.rendering) {
            return reply(`Masih ada render jalan (${st.rendering}). Cek ${pfx}amstatus atau ${pfx}amcancel`)
        }
        touch(chat)

        const { resolution, fps, quality } = parseExportArgs(args)

        let renderId
        try {
            const r = await getClient().startRender(st.sessionId, { resolution, fps, quality })
            renderId = r.renderId
        } catch (e) {
            const msg = apiErrText(e)
            logger.error('[amexport] startRender gagal: %s', msg)
            return reply('❌ Gagal mulai render:\n' + msg)
        }

        st.rendering = renderId

        // Kirim anchor progress — update tiap progressUpdateEveryPct%.
        const progressMsg = await sock
            .sendMessage(chat, { text: `🔄 Render mulai (${resolution}p ${fps}fps ${quality})...\n0%` }, { quoted: m })
            .catch(() => null)

        let lastSent = 0
        try {
            const info = await getClient().waitForRender(renderId, {
                onProgress: (p) => {
                    const pct = p.progressPct ?? 0
                    if (p.status === 'rendering' && pct - lastSent >= cfg.progressUpdateEveryPct) {
                        lastSent = pct
                        sock
                            .sendMessage(chat, { text: `⏳ ${pct}% (frame ${p.currentFrame}/${p.totalFrames})` })
                            .catch(() => {})
                    }
                },
            })

            if (info.status === 'error') {
                st.rendering = null
                return reply('❌ Render gagal: ' + (info.error || 'tidak diketahui'))
            }
            if (info.status === 'cancelled') {
                st.rendering = null
                return reply('🚫 Render dibatalkan.')
            }

            // Download hasil MP4 → kirim pakai sendVideoSmart (fallback chain).
            const mp4 = await getClient().downloadRender(renderId)
            st.rendering = null

            const caption =
                `✅ *Selesai!* ${info.durationSec ? info.durationSec.toFixed(1) + 's' : ''} | ` +
                `${fmtSize(mp4.length)} | ${resolution}p ${fps}fps (${quality})`

            try {
                await sendVideoSmart(sock, {
                    chat,
                    buffer: mp4,
                    mimetype: 'video/mp4',
                    fileName: 'am-render.mp4',
                    caption,
                    quoted: m,
                })
            } catch (sendErr) {
                // sendVideoSmart throw dengan .attempts berisi detail semua strategi
                // yang gagal. Kalau semua jalur gagal, kasih user hint download manual.
                logger.error('[amexport] semua jalur kirim video gagal: %s', sendErr?.message || sendErr)
                const fallbackText =
                    `⚠️ Gagal kirim MP4 lewat WhatsApp (semua jalur gagal). ` +
                    `File tetap ada di render server sebentar.\n\n` +
                    `Detail error: ${String(sendErr?.message || sendErr).slice(0, 300)}`
                await reply(fallbackText).catch(() => {})
            }
        } catch (e) {
            st.rendering = null
            const msg = apiErrText(e)
            logger.error('[amexport] waitForRender/download gagal: %s', msg)
            return reply('❌ ' + msg)
        }
    },
}
