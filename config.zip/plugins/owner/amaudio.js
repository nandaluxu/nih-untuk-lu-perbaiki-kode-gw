/**
 * plugins/owner/amaudio.js — Pasang audio ke sesi AM (reply audio atau URL).
 *
 * Adaptasi case 'amaudio' dari AMRenderKit/bot-plugin/am-plugin.mjs.
 *
 * Pemakaian:
 *   .amaudio <url>            URL mp3 / TikTok / Drive berisi audio
 *   .amaudio (reply audio)    reply pesan audio + ketik .amaudio
 *
 * Perilaku:
 *   1. Validasi ada sesi.
 *   2. Kalau ada reply → download audio, base64, kirim ke render-server.
 *      Tolak reply yang bukan audio.
 *   3. Kalau gak ada reply tapi ada URL → kirim sebagai { audioUrl }.
 *   4. Kalau gak ada keduanya → hint cara pakai.
 *
 * Catatan: AMRenderKit asli validasi reply dengan `media.mimetype?.startsWith('video')`
 * (video bisa dipakai sebagai audio source). Pola yang sama dipertahankan di sini.
 */

import {
    getClient,
    getState,
    touch,
    cleanupExpired,
    apiErrText,
    getQuotedMedia,
    logger,
} from '../../lib/amrender/index.js'

export default {
    name: 'amaudio',
    description: 'Pasang audio ke sesi AM (reply audio / URL mp3/tiktok/drive)',
    category: 'amrender',
    owner: true,
    usage: '.amaudio <url>  |  .amaudio (reply audio)',
    example: ['.amaudio https://example.com/song.mp3'],
    cooldownMs: 5_000,

    async execute(ctx) {
        const { args, reply, chat, prefix, message: m, quoted } = ctx
        const pfx = prefix ?? '.'

        cleanupExpired()

        const st = getState(chat)
        if (!st) {
            return reply(`Belum ada sesi. Mulai dengan ${pfx}amrender <link>`)
        }
        touch(chat)

        try {
            if (quoted) {
                const media = await getQuotedMedia(m, quoted)
                if (!media || !media.buffer?.length) {
                    return reply(`Reply-nya harus file audio (mp3/dll) atau ketik ${pfx}amaudio <url>`)
                }
                // Validasi: harus audio atau video (video bisa jadi sumber audio).
                const isAudioLike =
                    media.kind === 'audio' ||
                    (media.mimetype?.startsWith('audio')) ||
                    (media.mimetype?.startsWith('video'))
                if (!isAudioLike) {
                    return reply(`Reply-nya harus file audio (mp3/dll) atau ketik ${pfx}amaudio <url>`)
                }
                await getClient().setAudio(st.sessionId, {
                    audioBase64: media.buffer.toString('base64'),
                    audioMime: media.mimetype,
                })
            } else if (Array.isArray(args) && args[0] && /^https?:\/\//i.test(args[0])) {
                await getClient().setAudio(st.sessionId, { audioUrl: args[0] })
            } else {
                return reply(`Reply audio, atau ketik ${pfx}amaudio <url mp3/tiktok/drive>`)
            }

            return reply(`✅ Audio terpasang. Render dengan ${pfx}amexport`)
        } catch (e) {
            const msg = apiErrText(e)
            logger.error('[amaudio] setAudio gagal: %s', msg)
            return reply('❌ Gagal pasang audio:\n' + msg)
        }
    },
}
