/**
 * plugins/owner/amslots.js — Lihat daftar slot media sesi AM yang aktif.
 *
 * Adaptasi case 'amslots' dari AMRenderKit/bot-plugin/am-plugin.mjs.
 *
 * Pemakaian: .amslots
 *
 * Perilaku: tampilkan slot yang bisa diganti (isReplaceable=true) dengan
 * aliasnya (pict1, video1, ...) + marker [SUDAH DIGANTI] kalau sudah
 * di-replace sebelumnya.
 *
 * Gagal kalau belum ada sesi → kasih hint .amrender.
 */

import {
    getState,
    touch,
    cleanupExpired,
    slotListText,
} from '../../lib/amrender/index.js'

export default {
    name: 'amslots',
    description: 'Lihat daftar slot media sesi AM aktif',
    category: 'amrender',
    owner: true,
    usage: '.amslots',
    cooldownMs: 5_000,

    async execute(ctx) {
        const { reply, chat, prefix } = ctx
        const pfx = prefix ?? '.'

        cleanupExpired()

        const st = getState(chat)
        if (!st) {
            return reply(`Belum ada sesi. Mulai dengan ${pfx}amrender <link>`)
        }
        touch(chat)

        return reply('Slot sesi ini:\n' + slotListText(st))
    },
}
