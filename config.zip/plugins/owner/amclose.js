/**
 * plugins/owner/amclose.js — Tutup sesi AM di chat ini.
 *
 * Adaptasi case 'amclose' dari AMRenderKit/bot-plugin/am-plugin.mjs.
 *
 * Pemakaian: .amclose
 *
 * Perilaku:
 *   - Kalau gak ada sesi → kasih hint.
 *   - Kalau ada → kirim closeSession ke render-server (best-effort,
 *     error diabaikan), hapus state lokal.
 *
 * Catatan: tutup sesi juga melepaskan browser context di render-server
 * (Playwright context per sesi = RAM besar). Selalu panggil .amclose
 * kalau sudah selesai pakai preset biar render-server gak numpuk.
 */

import {
    getClient,
    getState,
    clearState,
    cleanupExpired,
    apiErrText,
    logger,
} from '../../lib/amrender/index.js'

export default {
    name: 'amclose',
    description: 'Tutup sesi AM aktif di chat ini',
    category: 'amrender',
    owner: true,
    usage: '.amclose',
    cooldownMs: 5_000,

    async execute(ctx) {
        const { reply, chat } = ctx

        cleanupExpired()

        const st = getState(chat)
        if (!st) {
            return reply('Tidak ada sesi aktif.')
        }

        // Tutup di sisi render-server — best-effort.
        try {
            await getClient().closeSession(st.sessionId)
        } catch (e) {
            // Tetap hapus state lokal biar user bisa buat sesi baru.
            // Error log di-debug supaya tidak spam owner kalau server mati.
            logger.debug('[amclose] closeSession gagal untuk %s: %s', st.sessionId, apiErrText(e))
        }

        clearState(chat)
        return reply('🔒 Sesi ditutup. Sampai jumpa!')
    },
}
