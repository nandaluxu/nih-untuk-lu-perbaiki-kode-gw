/**
 * plugins/owner/amrender.js — Mulai sesi render AM.
 *
 * Adaptasi case 'amrender' dari AMRenderKit/bot-plugin/am-plugin.mjs
 * jadi plugin file tunggal sesuai konvensi bot-gw (satu file = satu command).
 *
 * Pemakaian: .amrender <link>
 *   link = link share Alight Motion (alight.link/...) / Google Drive (.xml) /
 *          URL .xml publik.
 *
 * Perilaku:
 *   1. Validasi link (harus http(s)://...)
 *   2. Kalau ada sesi aktif di chat ini → tutup dulu (best-effort) supaya
 *      render-server tidak numpuk browser context.
 *   3. Reply "⏳ Memuat preset..." (preset load bisa lama — AM runtime
 *      kadang lagi down)
 *   4. createSession ke render-server → simpan state (sessionId, slots,
 *      replaced Set kosong) ke sessions Map (lib/amrender/index.js)
 *   5. Reply daftar slot media yang bisa diganti + hint cara pakai.
 *
 * Sumber daya: render server AM (Express + Playwright). Resource berat —
 * karena itu owner-only (metadata owner:true) + limit group 'amrender'
 * (limit harian per role — config/limits/group/amrender.json).
 */

import {
    getClient,
    getState,
    setState,
    clearState,
    cleanupExpired,
    slotListText,
    apiErrText,
    logger,
} from '../../lib/amrender/index.js'

export default {
    name: 'amrender',
    aliases: ['amload', 'amstart'],
    description: 'Mulai sesi render AM (link alight.link / gdrive / .xml)',
    category: 'amrender',
    owner: true,
    usage: '.amrender <link>',
    example: ['.amrender https://alight.link/xxxx'],
    limit: true,
    limitType: 'group',
    limitGroup: 'amrender',
    cooldownMs: 10_000,

    async execute(ctx) {
        const { args, reply, chat, prefix } = ctx
        const pfx = prefix ?? '.'

        const link = Array.isArray(args) ? args[0] : null
        if (!link || !/^https?:\/\//i.test(link)) {
            return reply(
                `Kirim link-nya:\n${pfx}amrender https://alight.link/xxxx\n\n` +
                `Link valid: alight.link share / Google Drive (.xml) / URL .xml publik.`
            )
        }

        cleanupExpired()

        // Kalau ada sesi aktif → tutup dulu, supaya render-server gak numpuk
        // browser context (Playwright context per sesi = RAM besar).
        const existing = getState(chat)
        if (existing) {
            try {
                await getClient().closeSession(existing.sessionId)
            } catch (e) {
                logger.warn('[amrender] gagal tutup sesi lama di %s: %s', chat, apiErrText(e))
            }
            clearState(chat)
        }

        await reply('⏳ Memuat preset... (kalau lama, host AM-nya lagi error, sabar ya)')

        let info
        try {
            info = await getClient().createSession({ source: link })
        } catch (e) {
            logger.error('[amrender] createSession gagal: %s', apiErrText(e))
            return reply('❌ Gagal memuat preset:\n' + apiErrText(e))
        }

        const state = {
            sessionId: info.id,
            slots: info.slots,
            replaced: new Set(),
            lastActivity: Date.now(),
            createdAt: Date.now(),
            rendering: null,
        }
        setState(chat, state)

        const lines = [
            '✅ *Sesi render dibuat!*',
            `Slot media (${info.totalSlots ?? (info.slots?.length ?? 0)}):`,
            slotListText(state),
            '',
            `Ganti slot: reply gambar/video + ketik ${pfx}amrep <slot>`,
            'Slot video boleh dibiarkan (pakai bawaan preset).',
            `Render: ${pfx}amexport`,
        ].join('\n')

        return reply(lines)
    },
}
