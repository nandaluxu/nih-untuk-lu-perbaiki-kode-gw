/**
 * plugins/owner/amstatus.js — Cek progres render AM yang sedang berjalan.
 *
 * Adaptasi case 'amstatus' dari AMRenderKit/bot-plugin/am-plugin.mjs.
 *
 * Pemakaian: .amstatus
 *
 * Perilaku:
 *   - Kalau gak ada sesi → hint .amrender.
 *   - Kalau ada sesi tapi gak ada render jalan → tampil daftar slot.
 *   - Kalau ada render jalan → tampil status + progres (% + frame X/Y).
 */

import {
    getClient,
    getState,
    touch,
    cleanupExpired,
    slotListText,
    apiErrText,
    logger,
} from '../../lib/amrender/index.js'

export default {
    name: 'amstatus',
    description: 'Cek progres render AM berjalan',
    category: 'amrender',
    owner: true,
    usage: '.amstatus',
    cooldownMs: 5_000,

    async execute(ctx) {
        const { reply, chat, prefix } = ctx
        const pfx = prefix ?? '.'

        cleanupExpired()

        const st = getState(chat)
        if (!st) {
            return reply(`Belum ada sesi. Mulai dengan ${pfx}amrender <link>`)
        }
        touch(chat)

        if (!st.rendering) {
            return reply('Tidak ada render berjalan. Slot:\n' + slotListText(st))
        }

        try {
            const info = await getClient().renderInfo(st.rendering)
            return reply(
                `Render: *${info.status}*\n` +
                `Progres: ${info.progressPct}% (frame ${info.currentFrame}/${info.totalFrames})`
            )
        } catch (e) {
            const msg = apiErrText(e)
            logger.error('[amstatus] renderInfo gagal: %s', msg)
            return reply('❌ Gagal ambil status render:\n' + msg)
        }
    },
}
