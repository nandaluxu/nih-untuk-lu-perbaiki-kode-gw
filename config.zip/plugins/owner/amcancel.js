/**
 * plugins/owner/amcancel.js — Batalkan render AM yang sedang berjalan.
 *
 * Adaptasi case 'amcancel' dari AMRenderKit/bot-plugin/am-plugin.mjs.
 *
 * Pemakaian: .amcancel
 *
 * Perilaku:
 *   - Kalau gak ada render jalan → kasih hint.
 *   - Kalau ada → kirim cancelRender ke render-server, hapus state.rendering.
 *
 * Catatan: render-server cuma set cancelRequested + panggil
 * window.AM.cancelRender (kalau ada). Render yang lagi jalan di Playwright
 * tetap harus selesai (atau timeout-nya) sebelum status jadi 'cancelled'.
 */

import {
    getClient,
    getState,
    touch,
    cleanupExpired,
    apiErrText,
    logger,
} from '../../lib/amrender/index.js'

export default {
    name: 'amcancel',
    description: 'Batalkan render AM yang sedang berjalan',
    category: 'amrender',
    owner: true,
    usage: '.amcancel',
    cooldownMs: 5_000,

    async execute(ctx) {
        const { reply, chat } = ctx

        cleanupExpired()

        const st = getState(chat)
        if (!st || !st.rendering) {
            return reply('Tidak ada render berjalan.')
        }
        touch(chat)

        const renderId = st.rendering
        try {
            await getClient().cancelRender(renderId)
        } catch (e) {
            // Best-effort — tetap reset state biar user bisa export ulang.
            const msg = apiErrText(e)
            logger.warn('[amcancel] cancelRender gagal untuk %s: %s', renderId, msg)
            // Gak return error — biarkan reset state terjadi.
        }

        st.rendering = null
        return reply('🚫 Render dibatalkan.')
    },
}
