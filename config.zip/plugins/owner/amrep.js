/**
 * plugins/owner/amrep.js — Ganti media slot sesi AM dengan gambar/video yang
 * di-reply.
 *
 * Adaptasi case 'amrep' dari AMRenderKit/bot-plugin/am-plugin.mjs.
 *
 * Pemakaian: .amrep <slot>  (sambil reply gambar/video)
 *   slot = alias (pict1, video1, ...) / id / index — apa pun yang diterima
 *   render-server.
 *
 * Perilaku:
 *   1. Validasi ada sesi + arg slot + ada reply media.
 *   2. Download media reply via lib/amrender/index.js#getQuotedMedia
 *      (yang di-dalami pake lib/media/media.js — kompatibel Baileys v7).
 *   3. Tolak audio (harus pakai .amaudio).
 *   4. applyMedia ke render-server dengan { mediaBase64, mediaMime }.
 *   5. Update state.replaced supaya .amslots nampil [SUDAH DIGANTI].
 *
 * Catatan: AMRenderKit asli pake `downloadMediaMessage` lazy import dari
 * `@whiskeysockets/baileys` v6. Bot-gw pake Baileys v7 via starcore, jadi
 * pakai helper lib/media/media.js — sama persis pola yang dipakai
 * plugins/owner/run.js buat download document reply.
 */

import {
    getClient,
    getState,
    touch,
    cleanupExpired,
    apiErrText,
    getQuotedMedia,
    fmtSize,
    logger,
} from '../../lib/amrender/index.js'

export default {
    name: 'amrep',
    description: 'Ganti media slot AM (reply gambar/video)',
    category: 'amrender',
    owner: true,
    usage: '.amrep <slot> (reply gambar/video)',
    example: ['.amrep pict1', '.amrep video1'],
    cooldownMs: 5_000,

    async execute(ctx) {
        const { args, reply, chat, prefix, message: m, quoted } = ctx
        const pfx = prefix ?? '.'

        cleanupExpired()

        const st = getState(chat)
        if (!st) {
            return reply(`Belum ada sesi. Mulai dengan ${pfx}amrender <link>`)
        }
        touch(chat)

        const slotArg = Array.isArray(args) ? args[0] : null
        if (!slotArg) {
            return reply(
                `Format: reply media + ketik ${pfx}amrep <slot>\n` +
                `Contoh: ${pfx}amrep pict1`
            )
        }

        if (!quoted) {
            return reply(
                `Reply gambar/video-nya dulu, lalu ketik ${pfx}amrep ${slotArg}`
            )
        }

        const media = await getQuotedMedia(m, quoted)
        if (!media || !media.buffer?.length) {
            return reply('Media di reply tidak bisa diunduh / bukan media.')
        }

        if (media.kind === 'audio') {
            return reply(`Itu audio - pakai ${pfx}amaudio ya.`)
        }

        await reply(`⏳ Mengunggah media (${fmtSize(media.buffer.length)})...`)

        try {
            const r = await getClient().applyMedia(st.sessionId, slotArg, {
                mediaBase64: media.buffer.toString('base64'),
                mediaMime: media.mimetype,
            })
            const key = r?.slot?.alias ?? slotArg
            st.replaced.add(key)
            return reply(`✅ ${key} diganti (${r?.slot?.mediaKind ?? '?'} - ${r?.slot?.name ?? '-'})`)
        } catch (e) {
            const msg = apiErrText(e)
            logger.error('[amrep] applyMedia gagal: %s', msg)
            const hint = /GAMBAR/i.test(msg) ? '\n💡 Slot ini butuh gambar, kirim gambar ya.' : ''
            return reply('❌ Gagal ganti slot:\n' + msg + hint)
        }
    },
}
