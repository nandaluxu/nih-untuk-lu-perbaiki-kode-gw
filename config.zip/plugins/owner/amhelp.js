/**
 * plugins/owner/amhelp.js — Bantuan daftar command AM Render.
 *
 * Adaptasi case 'amhelp' / 'am' dari AMRenderKit/bot-plugin/am-plugin.mjs.
 *
 * Pemakaian: .amhelp  atau  .am
 *
 * Perilaku: tampilkan teks HELP (semua command .am* + format argumen).
 * Prefix di-resolve runtime dari ctx.prefix supaya konsisten dengan
 * prefix yang aktif (default '.', tapi bisa per-group via prefixManager).
 */

import { helpText } from '../../lib/amrender/index.js'

export default {
    name: 'amhelp',
    aliases: ['am'],
    description: 'Bantuan AM Render (daftar command .am*)',
    category: 'amrender',
    owner: true,
    usage: '.amhelp',
    cooldownMs: 5_000,

    async execute(ctx) {
        const { reply, prefix } = ctx
        return reply(helpText(prefix ?? '.'))
    },
}
