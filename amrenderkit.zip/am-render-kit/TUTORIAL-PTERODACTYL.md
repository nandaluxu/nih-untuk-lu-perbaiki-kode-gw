# Tutorial Pemasangan AM Render di Pterodactyl (2 Server)

Panduan lengkap untuk admin Pterodactyl: server **#1 bot WhatsApp**, server
**#2 render AM** (Playwright + Chromium). Dikerjakan ±15 menit.

---

## 0. Arsitektur

```
┌─────────────────────────┐            ┌──────────────────────────────┐
│  SERVER #1: BOT         │            │  SERVER #2: RENDER           │
│  (Pterodactyl)          │  HTTP/fetch│  (Pterodactyl)               │
│                         │───────────▶│                              │
│  bot WhatsApp (Baileys) │            │  am-render-server            │
│   └ am-plugin.mjs       │  Bearer    │   └ Express (REST API)       │
│   └ am-client.mjs       │  token     │   └ Playwright + Chromium    │
└─────────────────────────┘            │      └ window.AM runtime    │
      kirim/terima WA                  │          (am.zervida.my.id)  │
                                       └──────────────────────────────┘
                                       Hasil render = file .mp4
                                       (diunduh bot, dikirim ke user)
```

Kenapa harus 2 server? Karena render AM **100% jalan di browser**
(WebCodecs `VideoEncoder`, `MediaRecorder`, WebGL, AudioContext — tidak ada
endpoint render server-side di web-nya). Playwright wajib, dan Chromium butuh
±1-2GB RAM saat render — jangan dicampur dengan proses bot di container yang
sama biar bot lu gak ikut mati kena OOM.

---

## 1. Buat Server Render (SERVER #2)

### 1.1 Pilih egg

Panel admin → **Eggs** → pakai egg **Node.js** standar
(mis. `Node.js Generic` dari [parkervcp/eggs](https://github.com/parkervcp/eggs)
— egg nodejs `generic`). Kalau udah punya egg Node.js apapun, itu cukup.

### 1.2 Buat servernya

Panel admin → **Servers** → **Create New**:

- Nest: *Node.js* — Egg: *generic* (atau nama serupa)
- Memory limit: **2048 MB** (minimum untuk 720p; 3072 MB kalau mau 1080p)
- Disk: **3000 MB** (browser udah ada di image, ini buat app + hasil render)
- CPU limit: **0** (unlimited) atau minimal **200%** (2 core)
- Allocation: 1 port (catat IP:PORT-nya, ini `AM_SERVER_URL` nanti)

### 1.3 GANTI DOCKER IMAGE (langkah paling penting!)

Egg Node.js biasanya pakai image `ghcr.io/parkervcp/yolks:nodejs_XX` — image ini
**TIDAK punya dependency browser** (libnss, libatk, dll), dan di Pterodactyl
kamu tidak punya akses root untuk `apt install`.

Solusinya: pakai **Docker image resmi Playwright** — sudah berisi
Node.js + Chromium + semua dependency sistem:

```
mcr.microsoft.com/playwright:v1.63.0-noble
```

Cara ganti (salah satu):

- **Per-server**: panel admin → *Servers* → pilih server → tab **Settings**
  (build?) — ubah **Docker Image**.
- **Atau via egg**: panel admin → *Eggs* → edit egg Node.js → bagian
  **Docker Images** → tambahkan image di atas, lalu pilih di server.

> ⚠️ **Versi image HARUS sama dengan versi playwright di package.json!**
> Package ini pakai `playwright@1.63.0` → image `v1.63.0-noble`.
> Kalau nanti mau upgrade, ubah keduanya barengan.
> Tag image ada di: https://mcr.microsoft.com/en-us/product/playwright/tags

### 1.4 Upload file

Via panel (Files → Upload) atau git. Upload isi folder `render-server/`:

```
index.js
package.json
src/
  app.js
  config.js
  engine.js
test/          (opsional, buat ngetes)
.env.example
```

**Jangan** upload `node_modules/` — nanti di-install otomatis.

### 1.5 Konfigurasi

Buat file `.env` di root container (Files → Create File → `.env`):

```env
AUTH_TOKEN=buat-token-acak-panjang-disini
# sisanya opsional, default-nya sudah masuk akal
```

Catatan port: Pterodactyl otomatis set env `SERVER_PORT` = port allocation,
dan `config.js` sudah membacanya — **kamu tidak perlu set PORT manual**.

Kalau mau link unduhan hasil render enak (untuk di-share manual), set juga:

```env
PUBLIC_BASE_URL=http://IP_PUBLIC_NODE:PORT_ALLOCATION
```

### 1.6 Startup command

Server → **Startup** → isi perintah:

```
npm install --omit=dev && node index.js
```

(`npm install` cuma jalan sekali — setelah `node_modules` ada, boot jadi cepat.)

### 1.7 Start & tes

Tekan **Start**. Log yang benar:

```
[am-render-server] listening di http://0.0.0.0:25565
[am-render-server] runtime target: https://am.zervida.my.id/runtime/preset.html
[am-render-server] auth: AKTIF (Bearer token)
[engine] chromium aktif via auto-detect (/home/container/pw-browsers/chromium-1243/chrome-linux64/chrome)
[engine] WebGL OK: WebGL 2.0 (OpenGL ES 3.0 Chromium) | ANGLE (Google, Vulkan 1.3.0 (SwiftShader Device (Subzero) ...), SwiftShader driver)
[am-render-server] chromium siap, engine mulai.
```

Baris `chromium aktif via ...` bisa beda (auto-detect / channel 'chromium') —
anggap normal. **Buka `http://IP:PORT/` di browser** → dashboard status
(uptime, sesi, antre, status WebGL, daftar endpoint). Kalau dashboard kebuka,
server lu hidup. 🎉

Tes dari luar (PC lu / server bot):

```bash
curl http://IP:PORT/api/health
# {"ok":true,"uptimeSec":12,"sessions":0,...,"chromium":"auto-detect (...)","webgl":{"ok":true,...}}

# tes render beneran (preset contoh dari web AM):
curl -X POST http://IP:PORT/api/sessions \
  -H 'Authorization: Bearer TOKENMU' -H 'Content-Type: application/json' \
  -d '{"source":"https://am.zervida.my.id/preset/TestVideo.xml"}'
```

Kalau itu balik JSON sesi dengan slot `pict1..pict3`, server render lu HIDUP.

### 1.8 Firewall (disarankan)

Di panel *Nest/Node* atau firewall host, batasi port allocation render server
hanya menerima koneksi dari **IP server bot** — biar orang gak bisa nyolong
CPU render lu. Minimal: **jangan pernah kosongin `AUTH_TOKEN`** kalau port-nya
public.

---

## 2. Pasang di Server Bot (SERVER #1)

### 2.1 Siapkan server bot

Server Pterodactyl biasa (egg Node.js apa pun, image standar boleh), dengan bot
WhatsApp Baileys lu yang udah jalan. Kalau mulai dari nol, lihat
`bot-plugin/index.js` — contoh bot minimal siap jalan.

### 2.2 Copy 2 file plugin

Dari folder `bot-plugin/`, copy ke project bot lu:

- `am-client.mjs`
- `am-plugin.mjs`

### 2.3 Install dependensi

```bash
npm install @whiskeysockets/baileys   # kalau belum ada di bot lu
```

### 2.4 Set environment

Di startup/`.env` server bot:

```env
AM_SERVER_URL=http://IP_RENDER_SERVER:PORT
AM_TOKEN=token-yang-sama-dengan-AUTH_TOKEN
```

### 2.5 Wiring ke handler pesan

Cari handler `messages.upsert` di bot lu, tambahkan:

```js
import { createAMPlugin } from './am-plugin.mjs';

const am = createAMPlugin({}); // baca dari env AM_SERVER_URL & AM_TOKEN

// di dalam handler messages.upsert, SEBELUM handler command lain:
const handled = await am.handleAMCommand({ sock, m });
if (handled) continue; // atau return — command .am* selesai di sini
```

Restart bot. Selesai.

---

## 3. Cara Pakai di WhatsApp

```
(dari grup/chat)

lu     : .amrender https://alight.link/xxxx
bot    : ✅ Sesi render dibuat!
        Slot media (3):
        • pict1 - image (12w4v1.jpg)
        • pict2 - image (13qsyx.jpg)
        • pict3 - image (e43rss.jpg)
        Ganti slot: reply gambar/video + ketik .amrep <slot>
        Render: .amexport

lu     : [kirim foto, reply] .amrep pict1
bot    : ✅ pict1 diganti (image - 12w4v1.jpg)

lu     : .amexport 720
bot    : 🔄 Render mulai (720p 30fps high)... 0%
bot    : ⏳ 25% (frame 465/1860)
bot    : ⏳ 55% (frame 1023/1860)
bot    : [video mp4] ✅ Selesai! 62.0s | 1.2MB | 720p 30fps (high)
```

Slot **video** boleh dibiarkan (pakai bawaan preset) — khas template AM
("video ny biarin aja, yang penting pict diganti").

---

## 4. Troubleshooting

| Gejala | Penyebab | Solusi |
| ------ | -------- | ------ |
| Buka `http://IP:PORT/` cuma keluar JSON error | versi lama (root belum punya halaman) / cache browser | update ke versi 1.1.0+ (root = dashboard), hard-refresh (Ctrl+Shift+R) |
| `chromium siap` gak muncul / crash saat start | image Docker bukan image Playwright | pastikan image = `mcr.microsoft.com/playwright:v1.63.0-noble` (lihat 1.3) |
| `Executable doesn't exist at .../chromium-XXXX` | versi playwright ≠ versi image | samakan: package.json `playwright` ↔ tag image |
| Dashboard bilang chromium `headless shell!` (merah) | launch jatuh ke fallback terakhir | set `PW_EXECUTABLE_PATH` ke chrome penuh (mis. `/home/container/pw-browsers/chromium-1243/chrome-linux64/chrome`) |
| Dashboard bilang WebGL `MATI` | box gak bisa software-GL default | coba `.env`: `PW_EXTRA_ARGS=--use-gl=angle,--use-angle=swiftshader` (tapi INGAT: render jadi ~30x lebih lambat — 4 fps) |
| Render kelamaan (menit2an buat video pendek) | ada flag `--use-gl=angle` / `--use-angle=swiftshader` aktif | hapus `PW_EXTRA_ARGS` itu — tanpa flag, 62s video 360p ≈ 17s render |
| Render lambat banget / CPU 100% | wajar — software rendering (SwiftShader) | 360p utk preview; 720p biasanya 1-3 menit per menit video |
| Server mati pas render 1080p | OOM (RAM limit) | naikkan memory limit ke 3GB+, atau batasi ke 720p |
| `Gagal memuat preset: ...` dari bot | host AM (Termux) lagi down | udah auto-retry 3x; tunggu sebentar trus `.amrender` ulang — sesi lama bisa ditutup paksa dengan `.amrender <link>` lagi |
| `Unauthorized` | token beda | `AM_TOKEN` (bot) harus = `AUTH_TOKEN` (render server) |
| Video keluar tanpa audio | preset-nya memang tanpa audio bawaan — runtime AM membuang audio saat export | pakai preset dengan audio sendiri, atau coba `.amaudio` (hasil bisa beda-beda tergantung preset) |
| `Slot "pict1" menerima GAMBAR, tapi media berupa VIDEO` | slot itu untuk gambar | kirim gambar; atau `force:true` dari API kalau yakin |
| Port gak bisa diakses dari bot | firewall / salah port | cek allocation IP:PORT, test `curl http://IP:PORT/api/health` dari server bot |

### Catatan teknis (buat yang penasaran)

- **Kenapa gak bisa fetch doang?** Render video AM jalan 100% di browser
  (`VideoEncoder`/WebCodecs, `MediaRecorder`, WebGL, `AudioContext`). Tidak ada
  endpoint server-side. Playwright = satu-satunya jalan (terverifikasi
  headless, tanpa GPU, via SwiftShader).
- **Slot media**: nama file slot (`.jpg`/`.mp4`) menentukan jenis loader,
  bukan field `type` dari API. Server udah otomatis deteksi (`mediaKind`) dan
  nolak media yang salah jenis.
- **Race scene**: server nunggu log `[SCENE] Siap` sebelum sesi dipakai —
  tanpa ini durasi render bisa kepotong.
- **File hasil render** otomatis dihapus setelah 3 jam (`RENDER_TTL_MIN`),
  sesi idle ditutup setelah 45 menit (`SESSION_TTL_MIN`).

---

## 5. Konfigurasi lanjutan (opsional)

Semua env render server (lihat `.env.example`):

| Env | Default | Fungsi |
| --- | ------- | ------ |
| `MAX_SESSIONS` | 3 | jumlah sesi (tab browser) bersamaan |
| `RENDER_CONCURRENCY` | 1 | render paralel — naikkan kalau CPU lega |
| `RENDER_TIMEOUT_MIN` | 20 | timeout satu render |
| `SESSION_TTL_MIN` | 45 | sesi idle ditutup otomatis |
| `RENDER_TTL_MIN` | 180 | file render dihapus otomatis |
| `FETCH_RETRIES` | 3 | retry saat host AM error |
| `RETRY_WAIT_MS` | 5000 | jeda awal retry (naik linear) |
| `AM_RUNTIME_URL` | URL resmi | kalau web AM pindah domain / self-host |
| `PW_EXECUTABLE_PATH` | (kosong) | path chromium eksplisit (auto-detect kalau kosong) |
| `PW_EXTRA_ARGS` | (kosong) | flag chromium ekstra — hanya kalau WebGL MATI, lihat warning di atas |
