/**
 * Halaman HTML untuk path "/" (dashboard status) dan 404 ramah browser.
 * Tanpa dependensi eksternal — biar bisa dibuka walau CDN mati.
 */

function esc(s) {
  return String(s ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;');
}

const CSS = `
  :root { color-scheme: dark; }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: ui-monospace, 'Cascadia Mono', 'JetBrains Mono', Menlo, Consolas, monospace;
    background: #0b0f14; color: #c9d4e0; min-height: 100vh; padding: 28px 20px 48px;
  }
  .wrap { max-width: 880px; margin: 0 auto; }
  h1 { font-size: 20px; color: #eaf2fb; letter-spacing: .5px; }
  h1 .dot { color: #38e07b; }
  .sub { color: #5c7086; font-size: 12px; margin-top: 6px; word-break: break-all; }
  .cards { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 10px; margin: 22px 0; }
  .card {
    background: #111823; border: 1px solid #1d2a3a; border-radius: 10px; padding: 14px 16px;
  }
  .card .k { font-size: 11px; color: #5c7086; text-transform: uppercase; letter-spacing: 1px; }
  .card .v { font-size: 22px; color: #eaf2fb; margin-top: 6px; }
  .card .v.ok { color: #38e07b; }
  .card .v.bad { color: #ff5d5d; }
  .card .v small { font-size: 11px; color: #5c7086; display: block; margin-top: 4px; word-break: break-all; }
  table { width: 100%; border-collapse: collapse; font-size: 12.5px; margin-top: 10px; }
  th, td { text-align: left; padding: 7px 10px; border-bottom: 1px solid #16212f; }
  th { color: #5c7086; font-size: 11px; text-transform: uppercase; letter-spacing: 1px; }
  td code, .mono { font-family: inherit; background: #16212f; border-radius: 4px; padding: 1px 6px; color: #7fd1ff; }
  td code.post { color: #ffcf7d; }
  td code.del { color: #ff8f8f; }
  td code.get { color: #8ef0a5; }
  .section { background: #111823; border: 1px solid #1d2a3a; border-radius: 10px; padding: 18px 20px; margin-top: 16px; }
  .section h2 { font-size: 13px; color: #9fb4cc; text-transform: uppercase; letter-spacing: 1.5px; margin-bottom: 4px; }
  .badge {
    display: inline-block; padding: 3px 10px; border-radius: 999px; font-size: 11px; margin-left: 8px;
    background: #0f2b1c; color: #38e07b; border: 1px solid #1c5c38; vertical-align: middle;
  }
  .badge.warn { background: #2b1f0f; color: #ffcf7d; border-color: #5c451c; }
  .note { font-size: 12px; color: #5c7086; margin-top: 10px; line-height: 1.7; }
  .note b { color: #c9d4e0; }
  footer { margin-top: 26px; font-size: 11px; color: #3d4f63; text-align: center; }
  a { color: #7fd1ff; }
  .center { text-align: center; padding-top: 60px; }
  .big404 { font-size: 64px; color: #1d2a3a; font-weight: bold; }
`;

const ENDPOINTS = [
  ['get', '/api/health', 'status server (publik, tanpa auth)'],
  ['post', '/api/sessions', 'buat sesi render — body: {"source":"<link AM>"}'],
  ['get', '/api/sessions/:id', 'info sesi + daftar slot (pict1, video1, ...)'],
  ['del', '/api/sessions/:id', 'tutup sesi'],
  ['post', '/api/sessions/:id/media', 'ganti media slot — body: {"slot":"pict1","mediaUrl":...}'],
  ['post', '/api/sessions/:id/audio', 'pasang audio — body: {"audioUrl":...}'],
  ['post', '/api/sessions/:id/render', 'mulai render — body: {"resolution":720,"fps":30,"quality":"high"}'],
  ['get', '/api/renders/:id', 'pantau progres render (status, %, frame)'],
  ['get', '/api/renders/:id/file', 'unduh MP4 hasil render'],
  ['post', '/api/renders/:id/cancel', 'batalkan render'],
  ['get', '/renders/&lt;file&gt;.mp4', 'unduhan langsung hasil render (tanpa auth)'],
];

function endpointsRows() {
  return ENDPOINTS.map(
    ([m, p, d]) =>
      '        <tr><td><code class="' + m + '">' + m.toUpperCase() + '</code></td><td><code>' + p + '</code></td><td>' + d + '</td></tr>'
  ).join('\n');
}

/** Dashboard utama untuk GET / */
export function dashboardHtml(cfg) {
  const authOn = !!cfg.authToken;
  return '<!doctype html>\n' +
'<html lang="id">\n' +
'<head>\n' +
'<meta charset="utf-8">\n' +
'<meta name="viewport" content="width=device-width, initial-scale=1">\n' +
'<title>AM Render Server — Status</title>\n' +
'<style>' + CSS + '</style>\n' +
'</head>\n' +
'<body>\n' +
'<div class="wrap">\n' +
'  <h1>AM Render Server <span class="dot">&#9679;</span> <span class="badge" id="badge">UP</span></h1>\n' +
'  <div class="sub">runtime target: ' + esc(cfg.amRuntimeUrl) + '</div>\n' +
'\n' +
'  <div class="cards">\n' +
'    <div class="card"><div class="k">Uptime</div><div class="v" id="uptime">—</div></div>\n' +
'    <div class="card"><div class="k">Sesi aktif</div><div class="v" id="sessions">—</div></div>\n' +
'    <div class="card"><div class="k">Render jalan</div><div class="v" id="active">—</div></div>\n' +
'    <div class="card"><div class="k">Antre render</div><div class="v" id="queue">—</div></div>\n' +
'    <div class="card"><div class="k">Chromium</div><div class="v" id="chromium">…</div></div>\n' +
'    <div class="card"><div class="k">WebGL</div><div class="v" id="webgl">…</div></div>\n' +
'  </div>\n' +
'\n' +
'  <div class="section">\n' +
'    <h2>REST API</h2>\n' +
'    <div class="note">' +
(authOn
  ? 'Auth <b>AKTIF</b> — semua route (kecuali <code>health</code> dan halaman ini) butuh header <code>Authorization: Bearer &lt;token&gt;</code>.'
  : 'Auth <b>NONAKTIF</b> — kalau port ini bisa diakses publik, isi <code>AUTH_TOKEN</code> di .env SEKARANG.') +
'    </div>\n' +
'    <table>\n' +
'      <tr><th>Method</th><th>Path</th><th>Fungsi</th></tr>\n' +
endpointsRows() +
'    </table>\n' +
'    <div class="note">Contoh cepat:\n' +
'    <span class="mono">curl -X POST ' + esc('/api/sessions') + ' -H \'Content-Type: application/json\' ' +
(authOn ? '-H \'Authorization: Bearer &lt;token&gt;\' ' : '') +
'-d \'{"source":"https://am.zervida.my.id/preset/TestVideo.xml"}\'</span></div>\n' +
'  </div>\n' +
'\n' +
'  <div class="section">\n' +
'    <h2>Catatan</h2>\n' +
'    <div class="note">Server ini meng-drive AM Web Runtime (am.zervida.my.id) lewat Playwright headless. ' +
'Host AM jalan di Termux dan kadang error — semua request otomatis di-retry. ' +
'File hasil render otomatis dihapus setelah ' + esc(cfg.renderTtlMin) + ' menit, sesi idle ditutup setelah ' +
esc(cfg.sessionTtlMin) + ' menit.</div>\n' +
'  </div>\n' +
'\n' +
'  <footer>am-render-server v' + esc(cfg.version) + '</footer>\n' +
'</div>\n' +
'<script>\n' +
"  var fmtUptime = function (s) {\n" +
"    if (s == null) return '—';\n" +
"    var h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), sec = s % 60;\n" +
"    return (h ? h + 'j ' : '') + (m ? m + 'm ' : '') + sec + 's';\n" +
"  };\n" +
"  var set = function (id, html) { var el = document.getElementById(id); if (el) el.innerHTML = html; };\n" +
"  var refresh = function () {\n" +
"    fetch('/api/health').then(function (r) { return r.json(); }).then(function (h) {\n" +
"      set('uptime', fmtUptime(h.uptimeSec));\n" +
"      set('sessions', String(h.sessions));\n" +
"      set('active', String(h.activeRenders));\n" +
"      set('queue', String(h.queueWaiting));\n" +
"      var cr = h.chromium ? String(h.chromium) : null;\n" +
"      if (cr && cr.indexOf('headless shell') >= 0) {\n" +
"        set('chromium', '<span class=\"bad\">headless shell!</span><small>' + cr + '</small>');\n" +
"      } else {\n" +
"        set('chromium', cr ? '<span class=\"ok\">OK</span><small>' + cr + '</small>' : '?');\n" +
"      }\n" +
"      var w = h.webgl;\n" +
"      if (w && w.ok) {\n" +
"        set('webgl', '<span class=\"ok\">OK</span><small>' + String(w.version || '') + ' — ' + String(w.renderer || '') + '</small>');\n" +
"      } else if (w) {\n" +
"        set('webgl', '<span class=\"bad\">MATI</span><small>' + String(w.error || '') + '</small>');\n" +
"      } else {\n" +
"        set('webgl', '…');\n" +
"      }\n" +
"    }).catch(function () {\n" +
"      var b = document.getElementById('badge');\n" +
"      if (b) { b.textContent = 'DOWN?'; b.className = 'badge warn'; }\n" +
"    });\n" +
"  };\n" +
"  refresh();\n" +
"  setInterval(refresh, 3000);\n" +
'</script>\n' +
'</body>\n' +
'</html>\n';
}

/** Halaman 404 ramah untuk path non-API. */
export function notFoundHtml(pathName, hasAuth) {
  return '<!doctype html>\n' +
'<html lang="id">\n' +
'<head>\n' +
'<meta charset="utf-8">\n' +
'<title>404 — AM Render Server</title>\n' +
'<style>' + CSS + '</style>\n' +
'</head>\n' +
'<body>\n' +
'<div class="wrap center">\n' +
'  <div class="big404">404</div>\n' +
'  <h1 style="margin-top:10px">Halaman tidak ditemukan</h1>\n' +
'  <div class="sub">' + esc(pathName) + '</div>\n' +
'  <div class="note">Ini server render AM — halaman web cuma ada di <a href="/">/</a> (status), ' +
'sisanya REST API di <code>/api/...</code>' + (hasAuth ? ' (butuh Bearer token)' : '') + '.</div>\n' +
'  <p style="margin-top:22px"><a href="">&#8592; kembali ke dashboard</a></p>\n' +
'</div>\n' +
'</body>\n' +
'</html>\n';
}
