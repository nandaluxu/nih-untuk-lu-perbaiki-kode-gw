// Diagnosa varian: kenapa render gagal setelah applyMedia?
// Varian A: tanpa applyMedia, tanpa setAudio (harusnya sukses seperti live-test)
// Varian B: applyMedia video kecil (5s) lalu render
import { spawn } from 'node:child_process';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import fs from 'node:fs/promises';

const execFileP = promisify(execFile);
const PORT = 3998;
const BASE = `http://127.0.0.1:${PORT}`;
const TOKEN = 'test123';
const HDRS = { 'Content-Type': 'application/json', Authorization: `Bearer ${TOKEN}` };
const PRESET = 'https://am.zervida.my.id/preset/TestVideo.xml';

const log = (...a) => console.log('[diag]', ...a);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function api(method, p, body) {
  const res = await fetch(BASE + p, { method, headers: HDRS, body: body === undefined ? undefined : JSON.stringify(body) });
  const text = await res.text();
  let json = null; try { json = JSON.parse(text); } catch {}
  return { status: res.status, json, text };
}

async function renderAndWait(sessionId, opts) {
  const rnd = await api('POST', `/api/sessions/${sessionId}/render`, opts);
  if (rnd.status !== 202) throw new Error('startRender: ' + rnd.text);
  const id = rnd.json.renderId;
  while (true) {
    await sleep(2000);
    const info = (await api('GET', `/api/renders/${id}`)).json;
    if (info.status !== 'queued' && info.status !== 'rendering') return info;
    process.stdout.write(`\r[diag] ${info.status} ${info.progressPct}%   `);
  }
}

// bikin video kecil 5 detik pakai ffmpeg bawaan playwright
const FFMPEG = "/home/z/my-project/scripts/amscrape/render-test/node_modules/ffmpeg-static/ffmpeg";
let smallVideo = null;
try {
  await execFileP(FFMPEG, ['-y', '-f', 'lavfi', '-i', 'testsrc=size=360x640:rate=30:duration=5', '-pix_fmt', 'yuv420p', '-c:v', 'libx264', '/tmp/small.mp4']);
  smallVideo = await fs.readFile('/tmp/small.mp4');
  log('video uji 5s dibuat:', smallVideo.length, 'bytes');
} catch (e) {
  log('ffmpeg gagal:', e.message);
}

const server = spawn('node', ['index.js'], {
  cwd: process.cwd(),
  env: { ...process.env, PORT: String(PORT), AUTH_TOKEN: TOKEN },
  stdio: ['ignore', 'pipe', 'pipe'],
});
server.stdout.on('data', (d) => process.stdout.write('[srv] ' + d));
server.stderr.on('data', (d) => process.stderr.write('[srv-err] ' + d));

try {
  for (let i = 0; i < 30; i++) {
    await sleep(1000);
    try { const r = await fetch(`${BASE}/api/health`); if (r.ok) break; } catch {}
  }
  log('server siap');

  // ===== Varian A: default =====
  {
    const ses = (await api('POST', '/api/sessions', { source: PRESET })).json;
    log(`\n== VARAN A (default, tanpa media/audio) sesi=${ses.id} ==`);
    const info = await renderAndWait(ses.id, { resolution: 360, fps: 30, quality: 'low' });
    log(`A hasil: ${info.status} ${info.error ?? ''} ${info.sizeBytes ?? 0} bytes`);
    await api('DELETE', `/api/sessions/${ses.id}`);
  }

  // ===== Varian B: apply video kecil =====
  if (smallVideo) {
    const ses = (await api('POST', '/api/sessions', { source: PRESET })).json;
    log(`\n== VARAN B (apply video 5s) sesi=${ses.id} ==`);
    const ap = await api('POST', `/api/sessions/${ses.id}/media`, {
      slot: 'video1', mediaBase64: smallVideo.toString('base64'), mediaMime: 'video/mp4',
    });
    log('applyMedia:', ap.status, ap.text);
    const info = await renderAndWait(ses.id, { resolution: 360, fps: 30, quality: 'low' });
    log(`B hasil: ${info.status} ${info.error ?? ''} ${info.sizeBytes ?? 0} bytes`);
    await api('DELETE', `/api/sessions/${ses.id}`);
  }
} finally {
  server.kill('SIGTERM');
  await sleep(1500);
  try { process.kill(server.pid, 0); server.kill('SIGKILL'); } catch {}
}
