// E2E test render-server: spawn server -> health -> session -> media -> render -> download -> cleanup
import { spawn } from 'node:child_process';
import fs from 'node:fs/promises';

const PORT = 3999;
const BASE = `http://127.0.0.1:${PORT}`;
const TOKEN = 'test123';
const HDRS = { 'Content-Type': 'application/json', Authorization: `Bearer ${TOKEN}` };
const PRESET = 'https://am.zervida.my.id/preset/TestVideo.xml';

const log = (...a) => console.log('[e2e]', ...a);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function api(method, p, body) {
  const res = await fetch(BASE + p, {
    method,
    headers: HDRS,
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const text = await res.text();
  let json = null;
  try { json = JSON.parse(text); } catch {}
  return { status: res.status, json, text };
}

// ---- 1. spawn server ----
log('spawn render-server...');
const server = spawn('node', ['index.js'], {
  cwd: process.cwd(),
  env: { ...process.env, PORT: String(PORT), AUTH_TOKEN: TOKEN },
  stdio: ['ignore', 'pipe', 'pipe'],
});
server.stdout.on('data', (d) => process.stdout.write('[srv] ' + d));
server.stderr.on('data', (d) => process.stderr.write('[srv-err] ' + d));

try {
  // ---- 2. tunggu health ----
  let health = null;
  for (let i = 0; i < 30; i++) {
    await sleep(1000);
    try {
      const r = await fetch(`${BASE}/api/health`);
      if (r.ok) { health = await r.json(); break; }
    } catch {}
  }
  if (!health) throw new Error('server gak kunjung sehat');
  log('health OK:', JSON.stringify(health));

  // ---- auth harus nolak tanpa token ----
  const noAuth = await fetch(`${BASE}/api/sessions`, { method: 'POST' });
  if (noAuth.status !== 401) throw new Error('auth lemah! status=' + noAuth.status);
  log('auth guard OK (401 tanpa token)');

  // ---- 3. bikin sesi ----
  const ses = await api('POST', '/api/sessions', { source: PRESET });
  if (ses.status !== 201) throw new Error('create session gagal: ' + ses.text);
  const session = ses.json;
  log('session:', session.id, '| slots:', session.totalSlots,
      '| image:', session.imageSlots, '| video:', session.videoSlots);
  log('aliases:', session.slots.map((s) => `${s.alias ?? '—'}(${s.type})`).join(', '));

  // ---- 4. ganti media slot pertama pakai gambar (picsum) ----
  const media = await api('POST', `/api/sessions/${session.id}/media`, {
    slot: session.slots[0].alias,
    mediaUrl: 'https://picsum.photos/800/1200',
  });
  if (media.status !== 200) throw new Error('applyMedia gagal: ' + media.text);
  log('applyMedia OK:', JSON.stringify(media.json));

  // ---- 4b. guard: apply video ke slot gambar harus DITOLAK ----
  const mp4 = await fs.readFile('/home/z/my-project/scripts/amscrape/render-test/output-test.mp4');
  const bad = await api('POST', `/api/sessions/${session.id}/media`, {
    slot: session.slots[0].alias,
    mediaBase64: mp4.toString('base64'),
    mediaMime: 'video/mp4',
  });
  if (bad.status !== 400) throw new Error('guard mediaKind bocor! status=' + bad.status);
  log('guard mediaKind OK (400 video->slot gambar)');

  // ---- 5. pasang audio ----
  const audio = await api('POST', `/api/sessions/${session.id}/audio`, {
    audioUrl: 'https://am.zervida.my.id/preset/Beraksi.mp3',
  });
  if (audio.status !== 200) throw new Error('setAudio gagal: ' + audio.text);
  log('setAudio OK');

  // ---- 6. render (360p low biar cepat) ----
  const rnd = await api('POST', `/api/sessions/${session.id}/render`, {
    resolution: 360, fps: 30, quality: 'low',
  });
  if (rnd.status !== 202) throw new Error('startRender gagal: ' + rnd.text);
  const renderId = rnd.json.renderId;
  log('render queued:', renderId);

  let info;
  const t0 = Date.now();
  while (true) {
    await sleep(2000);
    info = (await api('GET', `/api/renders/${renderId}`)).json;
    process.stdout.write(`\r[e2e] ${info.status} ${info.progressPct}% (frame ${info.currentFrame}/${info.totalFrames})   `);
    if (info.status === 'done' || info.status === 'error' || info.status === 'cancelled') break;
    if (Date.now() - t0 > 10 * 60_000) throw new Error('render timeout 10 menit');
  }
  console.log();
  if (info.status !== 'done') throw new Error('render gagal: ' + info.error);
  log(`render done: ${info.sizeBytes} bytes, durasi ${info.durationSec}s, ${((Date.now() - t0) / 1000).toFixed(0)}s`);

  // ---- 7. unduh via static path ----
  const dl = await fetch(BASE + info.downloadPath);
  if (!dl.ok) throw new Error('download gagal: HTTP ' + dl.status);
  const buf = Buffer.from(await dl.arrayBuffer());
  const magic = buf.subarray(4, 8).toString('latin1');
  if (magic !== 'ftyp') throw new Error('file hasil unduh bukan mp4 valid');
  log(`download OK: ${buf.length} bytes, magic ftyp OK`);
  await fs.writeFile('/tmp/e2e-output.mp4', buf);

  // ---- 8. unduh via /file (res.download) ----
  const dl2 = await fetch(`${BASE}/api/renders/${renderId}/file`, { headers: { Authorization: `Bearer ${TOKEN}` } });
  if (!dl2.ok) throw new Error('download /file gagal');
  const buf2 = Buffer.from(await dl2.arrayBuffer());
  if (buf2.length !== buf.length) throw new Error('ukuran beda antara static dan /file');
  log('download via /api/renders/:id/file OK, ukuran sama');

  // ---- 9. cleanup ----
  const closed = await api('DELETE', `/api/sessions/${session.id}`);
  log('close session:', closed.json.closed === true ? 'OK' : 'FAIL');

  log('\nE2E SEMUA LULUS');
} finally {
  server.kill('SIGTERM');
  await sleep(1500);
  try { process.kill(server.pid, 0); server.kill('SIGKILL'); } catch {}
}
