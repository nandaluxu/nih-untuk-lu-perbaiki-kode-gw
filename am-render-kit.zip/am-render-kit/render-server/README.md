# am-render-server

Render server untuk **AM Web Runtime** (`https://am.zervida.my.id/runtime/preset.html`) —
meng-drive `window.AM` (loadPreset / applyMedia / setAudio / renderVideo) lewat
Playwright headless, lalu memfasilitasi bot via REST API.

> Panduan pemasangan lengkap di Pterodactyl: lihat `../TUTORIAL-PTERODACTYL.md`

## Menjalankan lokal

```bash
npm install
cp .env.example .env       # edit AUTH_TOKEN dkk
node index.js              # listening di PORT/SERVER_PORT (default 3000)
```

Butuh: Node.js >= 18 dan browser Chromium yang cocok dengan versi `playwright`
di `package.json` (di Pterodactyl otomatis tersedia via Docker image resmi Playwright).

## REST API

Semua route JSON. Kalau `AUTH_TOKEN` diisi, semua route (kecuali health) butuh
header `Authorization: Bearer <token>`.

| Method | Path | Fungsi |
| ------ | ---- | ------ |
| GET  | `/api/health` | status server (sesi, antrean) |
| POST | `/api/sessions` | buat sesi render. Body: `{ "source": "<link>", "projectName?" }` |
| GET  | `/api/sessions/:id` | info sesi + daftar slot |
| DELETE | `/api/sessions/:id` | tutup sesi |
| POST | `/api/sessions/:id/media` | ganti media. Body: `{ "slot": "pict1", "mediaUrl" \| "mediaBase64"+"mediaMime", "force"? }` |
| POST | `/api/sessions/:id/audio` | pasang audio. Body: `{ "audioUrl" \| "audioBase64"+"audioMime" }` |
| POST | `/api/sessions/:id/render` | mulai render (async). Body: `{ "resolution": 720, "fps": 30, "quality": "high" }` → `{ "renderId" }` |
| GET  | `/api/renders/:id` | progres render (`queued/rendering/done/error/cancelled`, persen, frame) |
| GET  | `/api/renders/:id/file` | unduh MP4 hasil render |
| POST | `/api/renders/:id/cancel` | batalkan render |
| GET  | `/renders/<file>.mp4` | unduhan langsung (tanpa auth — untuk bot) |

### Contoh alur (curl)

```bash
BASE=http://IP:PORT; TOK=tokenmu; H="Authorization: Bearer $TOK"

# 1. buat sesi dari link share AM / gdrive / xml
SES=$(curl -s -X POST $BASE/api/sessions -H "$H" -H 'Content-Type: application/json' \
  -d '{"source":"https://alight.link/xxxx"}' | jq -r .id)

# 2. lihat slot (alias pict1, video1, ... dipakai untuk ganti media)
curl -s $BASE/api/sessions/$SES -H "$H | jq .slots

# 3. ganti slot pict1 dengan gambar
curl -s -X POST $BASE/api/sessions/$SES/media -H "$H" -H 'Content-Type: application/json' \
  -d '{"slot":"pict1","mediaUrl":"https://picsum.photos/800/1200"}'

# 4. render 720p
RID=$(curl -s -X POST $BASE/api/sessions/$SES/render -H "$H" -H 'Content-Type: application/json' \
  -d '{"resolution":720,"fps":30,"quality":"high"}' | jq -r .renderId)

# 5. pantau sampai done
curl -s $BASE/api/renders/$RID -H "$H" | jq '{status, progressPct}'

# 6. unduh
curl -s -o hasil.mp4 $BASE/api/renders/$RID/file -H "$H"
```

## Konfigurasi (env)

Lihat `.env.example`. Poin penting:

- `PORT` / `SERVER_PORT` — otomatis dari allocation Pterodactyl.
- `AUTH_TOKEN` — WAJIB kalau port bisa diakses publik.
- `MAX_SESSIONS` — jumlah tab browser bersamaan (default 3; tiap tab = RAM).
- `RENDER_CONCURRENCY` — render paralel (default 1, aman untuk CPU kecil).
- `SESSION_TTL_MIN` / `RENDER_TTL_MIN` — pembersihan otomatis sesi idle & file lama.
- `FETCH_RETRIES` / `RETRY_WAIT_MS` — retry otomatis saat host AM (Termux) error.
- `PW_EXECUTABLE_PATH` — override path chromium (jarang perlu).

## Perilaku penting (hasil reverse engineering)

1. **Slot media: `mediaKind` lebih benar daripada `type`.** Loader runtime AM
   menentukan gambar/video dari **ekstensi nama slot** (`12w4v1.jpg` = gambar),
   BUKAN field `type` (yang bisa `video`). Server menolak (HTTP 400) video yang
   dikirim ke slot gambar, kecuali `"force": true`.
2. **Race condition scene**: sesi hanya dianggap siap setelah log `[SCENE] Siap`
   muncul — sebelum itu, `setAudio`/render bisa memotong durasi project.
3. **Audio**: untuk preset TANPA audio bawaan (mis. `TestVideo.xml`), export
   runtime AM cenderung membuang audio (perilaku web-nya, bukan server ini).
   Preset dengan audio sendiri akan diekspor bersama audionya.
4. **Render 100% client-side** (WebCodecs/MediaRecorder + WebGL SwiftShader) —
   tidak butuh GPU, cukup CPU + RAM. 360p 62 detik ≈ 15-18 detik di 1 vCPU.

## Test

```bash
node test/e2e.mjs   # E2E penuh (butuh akses internet ke am.zervida.my.id)
```
