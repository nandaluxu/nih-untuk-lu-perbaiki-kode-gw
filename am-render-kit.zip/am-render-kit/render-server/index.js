/** Entry point render server AM. */
import { config } from './src/config.js';
import { AMEngine } from './src/engine.js';
import { buildApp } from './src/app.js';

const engine = new AMEngine();

const app = buildApp(engine);
const server = app.listen(config.port, config.host, async () => {
  console.log(`[am-render-server] listening di http://${config.host}:${config.port}`);
  console.log(`[am-render-server] runtime target: ${config.amRuntimeUrl}`);
  console.log(`[am-render-server] auth: ${config.authToken ? 'AKTIF (Bearer token)' : 'NONAKTIF (set AUTH_TOKEN!)'}`);
  try {
    await engine.start();
    console.log('[am-render-server] chromium siap, engine mulai.');
  } catch (e) {
    console.error('[am-render-server] GAGAL start engine:', e.message);
    process.exit(1);
  }
});

async function shutdown(signal) {
  console.log(`[am-render-server] ${signal}, matikan...`);
  server.close();
  await engine.stop().catch(() => {});
  process.exit(0);
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
