/**
 * AMEngine - wrapper Playwright untuk AM Web Runtime (window.AM).
 *
 * Satu sesi = 1 browser context + 1 tab (preset termuat di sana).
 * Render masuk antre global (default 1 bersamaan) karena berat CPU.
 * Semua aksi ke host AM (Termux, suka error) otomatis di-retry.
 */
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import { chromium } from 'playwright';
import { config } from './config.js';

const LAUNCH_ARGS = [
  '--no-sandbox',
  '--disable-dev-shm-usage',
  '--autoplay-policy=no-user-gesture-required',
  '--enable-unsafe-swiftshader',
  '--force-color-profile=srgb',
  '--mute-audio',
];

const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';

export class AMEngineError extends Error {
  constructor(message, status = 500, extra = {}) {
    super(message);
    this.name = 'AMEngineError';
    this.status = status;
    this.extra = extra;
  }
}

export class AMEngine {
  constructor() {
    this.browser = null;
    /** @type {Map<string, session>} */
    this.sessions = new Map();
    /** @type {Map<string, renderJob>} */
    this.jobs = new Map();
    this.renderQueue = [];
    this.activeRenders = 0;
    this._sweeper = null;
  }

  /* ============================ lifecycle ============================ */

  async start() {
    const opts = { headless: true, args: LAUNCH_ARGS };
    if (config.pwExecutablePath) {
      opts.executablePath = config.pwExecutablePath;
    } else {
      // channel 'chromium' = chrome penuh (bukan headless shell),
      // wajib biar WebCodecs/MediaRecorder jalan di headless.
      opts.channel = 'chromium';
    }
    try {
      this.browser = await chromium.launch(opts);
    } catch (e) {
      // Fallback: launch default bawaan playwright.
      delete opts.channel;
      this.browser = await chromium.launch(opts);
    }
    await fs.mkdir(config.rendersDir, { recursive: true });
    this._sweeper = setInterval(() => this.#sweep(), 60_000);
    if (typeof this._sweeper.unref === 'function') this._sweeper.unref();
  }

  async stop() {
    clearInterval(this._sweeper);
    for (const job of this.jobs.values()) this.#failJob(job, 'server shutdown');
    for (const s of this.sessions.values()) this.#closeSessionQuiet(s);
    this.sessions.clear();
    if (this.browser) await this.browser.close().catch(() => {});
  }

  stats() {
    return {
      sessions: this.sessions.size,
      queueWaiting: this.renderQueue.length,
      activeRenders: this.activeRenders,
      jobsTotal: this.jobs.size,
    };
  }

  /* ============================ sessions ============================ */

  async createSession({ source, projectName }) {
    if (this.sessions.size >= config.maxSessions) {
      throw new AMEngineError(
        `Jumlah sesi maksimum (${config.maxSessions}) tercapai. Tutup sesi lain dulu / tunggu.`,
        409
      );
    }
    if (!source || typeof source !== 'string') {
      throw new AMEngineError('Parameter "source" wajib (link share AM / URL XML)', 400);
    }

    const id = 's_' + crypto.randomBytes(6).toString('hex');

    // Satu attempt = buka context baru, muat preset, verifikasi bukan fallback.
    // Host AM (Termux) suka 502 sesaat -> runtime diam-diam fallback ke project
    // sample default, jadi seluruh attempt ini di-retry kalau ada indikasi itu.
    const attempt = async () => {
      const context = await this.browser.newContext({ userAgent: UA });
      const page = await context.newPage();
      page.setDefaultTimeout(45_000);

      // Log player -> stdout server + buffer (deteksi scene siap & fallback).
      const consoleBuffer = [];
      page.on('console', (m) => {
        const t = m.text();
        consoleBuffer.push(t);
        if (consoleBuffer.length > 300) consoleBuffer.shift();
        if (t.length < 300) console.log(`[AM ${id}] ${t}`);
      });
      page.on('pageerror', (e) => console.log(`[AM ${id}] PAGEERROR: ${e.message}`));

      try {
        await page.goto(config.amRuntimeUrl, { waitUntil: 'domcontentloaded', timeout: 45_000 });
        await page.waitForFunction(() => window.AM != null, null, { timeout: 30_000 });

        // Forward log internal player ke console (tertangkap handler di atas).
        await page.evaluate(() => {
          if (typeof window.AM?.onLog === 'function') {
            window.AM.onLog((msg) => console.log(String(msg)));
          }
        });

        // Catat judul scene sample default (kalau sempat muncul sebelum dibatalkan).
        await new Promise((r) => setTimeout(r, 1500));
        const sceneTitles = () =>
          consoleBuffer
            .filter((l) => l.includes('[SCENE]') && /\d+x\d+\s/.test(l))
            .map((l) => l.replace(/^\[SCENE\]\s*"?([^"]*?)"?\s*\d+x\d+.*$/, '$1').trim());
        const preTitles = sceneTitles();

        await page.evaluate(
          ({ src, name }) => window.AM.loadPreset(src, name),
          { src: source, name: projectName ?? undefined }
        );
        const projects = await page.evaluate(() => window.AM.getAvailableProjects?.() ?? []);

        // Tunggu scene benar2 siap ("[SCENE] Siap") — race: aksi terlalu dini
        // bisa memotong durasi project (terbukti: 18.48s padahal 61.97s).
        const sceneReady = () => consoleBuffer.some((l) => l.includes('[SCENE] Siap'));
        const t0 = Date.now();
        while (!sceneReady() && Date.now() - t0 < 20_000) {
          await new Promise((r) => setTimeout(r, 500));
        }
        if (!sceneReady()) console.log(`[AM ${id}] WARNING: "[SCENE] Siap" tidak terdeteksi dalam 20s, lanjut...`);

        // Tunggu nama slot stabil: media yang gagal dimuat (content://) diganti
        // "gambar contoh" (.jpg) secara ASYNC. Kalau keburu, nama tanpa ekstensi
        // -> mediaKind salah -> applyMedia bisa merusak render.
        const settled = (slots) =>
          !slots.some((x) => x.isReplaceable && String(x.name ?? '').startsWith('content://'));
        let rawSlots = await page.evaluate(() => window.AM.getMediaSlots());
        const t1 = Date.now();
        while (!settled(rawSlots) && Date.now() - t1 < 15_000) {
          await new Promise((r) => setTimeout(r, 500));
          rawSlots = await page.evaluate(() => window.AM.getMediaSlots());
        }
        if (!settled(rawSlots)) {
          console.log(`[AM ${id}] WARNING: nama slot masih content:// setelah 15s - lanjut...`);
        }

        // Deteksi fallback: judul scene terakhir == judul default sample
        // (berarti preset yang diminta gagal, mis. host 502, tapi runtime
        // lanjut dengan project contoh -> JANGAN diberikan ke user).
        const postTitles = sceneTitles();
        const lastTitle = postTitles[postTitles.length - 1];
        if (preTitles.length > 0 && lastTitle && preTitles.includes(lastTitle)) {
          throw new AMEngineError(
            `Preset gagal dimuat - host AM error (502) dan runtime fallback ke sample "${lastTitle}". Coba lagi sebentar lagi.`,
            502,
            { retriable: true }
          );
        }

        return { context, page, projects, rawSlots };
      } catch (e) {
        await context.close().catch(() => {});
        throw e;
      }
    };

    let result;
    try {
      result = await this.#retry('createSession', attempt, config.fetchRetries);
    } catch (e) {
      throw e instanceof AMEngineError ? e : new AMEngineError('Gagal memuat preset: ' + e.message, 502);
    }

    const session = {
      id,
      page: result.page,
      context: result.context,
      source,
      projectName: projectName ?? null,
      projects: result.projects,
      slots: this.#withAliases(result.rawSlots),
      createdAt: Date.now(),
      lastUsed: Date.now(),
    };
    this.sessions.set(id, session);
    return this.#sessionInfo(session);
  }

  getSession(id) {
    const s = this.sessions.get(id);
    if (!s) throw new AMEngineError(`Sesi ${id} tidak ditemukan / sudah ditutup`, 404);
    s.lastUsed = Date.now();
    return s;
  }

  sessionInfo(id) {
    return this.#sessionInfo(this.getSession(id));
  }

  closeSession(id) {
    const s = this.getSession(id); // 404 kalau udah gak ada
    this.sessions.delete(id);
    this.#closeSessionQuiet(s);
    return { id, closed: true };
  }

  /** Tambah slot alias ramah user + mediaKind dari ekstensi nama file.
   *
   * PENTING: loader media runtime AM menentukan image/video dari EKSTENSI
   * nama slot (mis. 12w4v1.jpg -> dimuat sebagai gambar), BUKAN dari field
   * `type` (terbukti lewat tes: apply mp4 ke slot bernama .jpg = render gagal,
   * apply jpg = sukses). Jadi mediaKind = kebenaran yang dipakai bot.
   */
  #withAliases(rawSlots) {
    let pict = 0, vid = 0, aud = 0;
    return (rawSlots ?? []).map((s) => {
      const slot = { ...s, alias: null, mediaKind: this.#mediaKind(s) };
      if (s.isReplaceable) {
        if (slot.mediaKind === 'image') slot.alias = `pict${++pict}`;
        else if (slot.mediaKind === 'video') slot.alias = `video${++vid}`;
        else if (slot.mediaKind === 'audio') slot.alias = `audio${++aud}`;
      }
      return slot;
    });
  }

  #mediaKind(slot) {
    const m = String(slot?.name ?? '').toLowerCase().match(/\.(jpe?g|png|webp|gif|bmp|avif)$/);
    if (m) return 'image';
    const v = String(slot?.name ?? '').toLowerCase().match(/\.(mp4|webm|mov|mkv|m4v)$/);
    if (v) return 'video';
    const a = String(slot?.name ?? '').toLowerCase().match(/\.(mp3|wav|ogg|m4a|aac|flac)$/);
    if (a) return 'audio';
    // fallback: pakai field type
    return ['image', 'video', 'audio'].includes(slot?.type) ? slot.type : null;
  }

  #sessionInfo(s) {
    return {
      id: s.id,
      source: s.source,
      projects: s.projects,
      createdAt: s.createdAt,
      lastUsed: s.lastUsed,
      slots: s.slots.map((x) => ({
        index: x.index,
        id: x.id,
        name: x.name,
        type: x.type,
        mediaKind: x.mediaKind,
        isReplaceable: !!x.isReplaceable,
        alias: x.alias,
      })),
      totalSlots: s.slots.length,
      imageSlots: s.slots.filter((x) => x.mediaKind === 'image' && x.isReplaceable).length,
      videoSlots: s.slots.filter((x) => x.mediaKind === 'video' && x.isReplaceable).length,
    };
  }

  #closeSessionQuiet(s) {
    s.context.close().catch(() => {});
  }

  /* ============================ media & audio ============================ */

  /** Cari slot berdasar alias (pict1) / id / index. */
  #findSlot(s, ref) {
    if (typeof ref === 'number' || /^\d+$/.test(String(ref))) {
      const idx = Number(ref);
      const slot = s.slots.find((x) => x.index === idx);
      if (slot) return slot;
    }
    const low = String(ref ?? '').toLowerCase().trim();
    const slot =
      s.slots.find((x) => (x.alias ?? '').toLowerCase() === low) ??
      s.slots.find((x) => String(x.id).toLowerCase() === low) ??
      s.slots.find((x) => String(x.name ?? '').toLowerCase() === low);
    if (!slot) {
      throw new AMEngineError(
        `Slot "${ref}" tidak ditemukan. Daftar: ` +
          s.slots.map((x) => x.alias || x.name || x.index).join(', '),
        404
      );
    }
    if (!slot.isReplaceable) {
      throw new AMEngineError(`Slot "${ref}" tidak bisa diganti (isReplaceable=false)`, 400);
    }
    return slot;
  }

  async applyMedia(sessionId, slotRef, { mediaUrl, mediaBase64, mediaMime, force } = {}) {
    const s = this.getSession(sessionId);
    const slot = this.#findSlot(s, slotRef);

    // Validasi kecocokan jenis media vs slot (berdasar mediaKind).
    const input = mediaUrl ?? this.#dataUrl(mediaBase64, mediaMime, 'image');
    if (!input) throw new AMEngineError('Sertakan mediaUrl ATAU mediaBase64(+mediaMime)', 400);
    if (!force) {
      const mediaIsVideo = this.#looksLikeVideo(mediaUrl, mediaMime);
      if (slot.mediaKind === 'image' && mediaIsVideo) {
        throw new AMEngineError(
          `Slot "${slot.alias || slot.name}" menerima GAMBAR (nama file: ${slot.name}), ` +
            'tapi media yang dikirim berupa VIDEO. Kirim gambar, atau pakai force:true untuk memaksa.',
          400
        );
      }
    }

    await this.#retry('applyMedia', () =>
      pageEval(s.page, ({ id, input }) => window.AM.applyMedia(id, input), {
        id: slot.id,
        input,
      })
    );
    return {
      sessionId,
      slot: { alias: slot.alias, id: slot.id, name: slot.name, mediaKind: slot.mediaKind },
    };
  }

  #looksLikeVideo(url, mime) {
    if (mime?.startsWith('video/')) return true;
    if (mime?.startsWith('image/')) return false;
    const u = String(url ?? '').toLowerCase();
    return /\.(mp4|webm|mov|mkv|m4v)(\?|$)/.test(u) || u.startsWith('data:video');
  }

  async setAudio(sessionId, { audioUrl, audioBase64, audioMime } = {}) {
    const s = this.getSession(sessionId);
    const input = audioUrl ?? this.#dataUrl(audioBase64, audioMime, 'audio');
    if (!input) throw new AMEngineError('Sertakan audioUrl ATAU audioBase64(+audioMime)', 400);
    await this.#retry('setAudio', () =>
      pageEval(s.page, (input) => window.AM.setAudio(input), input)
    );
    return { sessionId, audio: true };
  }

  #dataUrl(base64, mime, kind) {
    if (!base64) return null;
    const m = (mime || '').startsWith(kind + '/') ? mime : `${kind}/mp4`;
    const b64 = base64.includes(',') ? base64.split(',')[1] : base64; // terima data URL juga
    return `data:${m};base64,${b64}`;
  }

  /* ============================ render queue ============================ */

  startRender(sessionId, { resolution = 720, fps = 30, quality = 'high' } = {}) {
    const s = this.getSession(sessionId);
    if (![360, 540, 720, 1080].includes(Number(resolution))) {
      throw new AMEngineError('resolusi harus 360 | 540 | 720 | 1080', 400);
    }
    if (![30, 60].includes(Number(fps))) throw new AMEngineError('fps harus 30 | 60', 400);
    if (!['low', 'medium', 'high'].includes(String(quality))) {
      throw new AMEngineError("quality harus 'low' | 'medium' | 'high'", 400);
    }

    const job = {
      id: 'r_' + crypto.randomBytes(6).toString('hex'),
      sessionId,
      status: 'queued', // queued | rendering | done | error | cancelled
      resolution: Number(resolution),
      fps: Number(fps),
      quality: String(quality),
      progressPct: 0,
      currentFrame: 0,
      totalFrames: 0,
      sizeBytes: 0,
      durationSec: 0,
      file: null,
      error: null,
      createdAt: Date.now(),
      startedAt: null,
      finishedAt: null,
      cancelRequested: false,
    };
    this.jobs.set(job.id, job);
    this.renderQueue.push({ session: s, job });
    this.#pumpQueue();
    return { renderId: job.id, status: job.status };
  }

  getRenderInfo(jobId) {
    const j = this.jobs.get(jobId);
    if (!j) throw new AMEngineError(`Render ${jobId} tidak ditemukan`, 404);
    const out = {
      renderId: j.id,
      sessionId: j.sessionId,
      status: j.status,
      resolution: j.resolution,
      fps: j.fps,
      quality: j.quality,
      progressPct: j.progressPct,
      currentFrame: j.currentFrame,
      totalFrames: j.totalFrames,
      sizeBytes: j.sizeBytes,
      durationSec: j.durationSec,
      error: j.error,
      createdAt: j.createdAt,
      startedAt: j.startedAt,
      finishedAt: j.finishedAt,
    };
    if (j.status === 'done' && j.file) {
      out.file = path.basename(j.file);
      out.downloadPath = `/renders/${path.basename(j.file)}`;
    }
    return out;
  }

  renderFilePath(jobId) {
    const j = this.jobs.get(jobId);
    if (!j || j.status !== 'done' || !j.file) {
      throw new AMEngineError(`Render ${jobId} belum selesai / tidak ada`, 404);
    }
    return j.file;
  }

  async cancelRender(jobId) {
    const j = this.jobs.get(jobId);
    if (!j) throw new AMEngineError(`Render ${jobId} tidak ditemukan`, 404);
    if (j.status === 'done') return { renderId: j.id, status: j.status };
    j.cancelRequested = true;
    if (j.status === 'rendering') {
      const s = this.sessions.get(j.sessionId);
      if (s) await s.page.evaluate(() => window.AM.cancelRender?.()).catch(() => {});
      this.#failJob(j, 'dibatalkan pengguna', 'cancelled');
      this.#pumpQueue();
    }
    return { renderId: j.id, status: j.status };
  }

  #pumpQueue() {
    while (this.activeRenders < config.renderConcurrency && this.renderQueue.length) {
      const { session, job } = this.renderQueue.shift();
      if (!this.sessions.has(session.id) || job.cancelRequested) {
        this.#failJob(job, 'sesi sudah ditutup', 'cancelled');
        continue;
      }
      this.activeRenders++;
      this.#runRender(session, job)
        .catch((e) => this.#failJob(job, e.message))
        .finally(() => {
          this.activeRenders--;
          this.#pumpQueue();
        });
    }
  }

  async #runRender(session, job) {
    job.status = 'rendering';
    job.startedAt = Date.now();
    const timeout = setTimeout(
      () => this.#failJob(job, `timeout ${config.renderTimeoutMin} menit`),
      config.renderTimeoutMin * 60_000
    );
    if (typeof timeout.unref === 'function') timeout.unref();

    // Poll progress paralel (getRenderProgress) selama renderVideo jalan.
    const poller = setInterval(async () => {
      try {
        if (job.cancelRequested || job.status !== 'rendering') return;
        const p = await session.page
          .evaluate(() => window.AM.getRenderProgress?.() ?? null)
          .catch(() => null);
        if (p && typeof p.progressPct === 'number') {
          job.progressPct = Math.round(p.progressPct);
          job.currentFrame = p.currentFrame ?? job.currentFrame;
          job.totalFrames = p.totalFrames ?? job.totalFrames;
        }
      } catch {}
    }, 1500);
    if (typeof poller.unref === 'function') poller.unref();

    try {
      const result = await session.page.evaluate(
        ({ resolution, fps, quality }) =>
          window.AM.renderVideo({ resolution, fps, quality }),
        { resolution: job.resolution, fps: job.fps, quality: job.quality }
      );

      if (!result?.base64 || !String(result.base64).startsWith('data:video')) {
        throw new Error('hasil render bukan video (base64 kosong)');
      }
      const buf = Buffer.from(String(result.base64).split(',')[1], 'base64');
      const magic = buf.subarray(4, 8).toString('latin1');
      if (magic !== 'ftyp') throw new Error('hasil render bukan MP4 valid');

      const file = path.join(config.rendersDir, `${job.id}.mp4`);
      await fs.writeFile(file, buf);

      job.status = 'done';
      job.progressPct = 100;
      job.sizeBytes = buf.length;
      job.durationSec = result.durationSec ?? null;
      job.file = file;
      job.finishedAt = Date.now();
    } finally {
      clearInterval(poller);
      clearTimeout(timeout);
    }
  }

  #failJob(job, message, status = 'error') {
    if (job.status === 'done' || job.status === 'error') return;
    job.status = status;
    job.error = message;
    job.finishedAt = Date.now();
  }

  /* ============================ util ============================ */

  /** Retry helper - host AM jalan di Termux, suka down sesaat. */
  async #retry(label, fn, tries = config.fetchRetries) {
    let lastErr;
    for (let i = 1; i <= tries; i++) {
      try {
        return await fn();
      } catch (e) {
        lastErr = e;
        // Error validasi (4xx) = fatal, jangan di-retry. 5xx / retriable = ulang.
        const fatal = e instanceof AMEngineError && e.status < 500 && !e.extra?.retriable;
        if (fatal || i === tries) break;
        await new Promise((r) => setTimeout(r, config.retryWaitMs * i));
      }
    }
    throw lastErr;
  }

  #sweep() {
    const now = Date.now();
    // tutup sesi idle
    for (const s of this.sessions.values()) {
      if (now - s.lastUsed > config.sessionTtlMin * 60_000) {
        this.sessions.delete(s.id);
        this.#closeSessionQuiet(s);
      }
    }
    // hapus file render kedaluwarsa
    for (const [id, j] of this.jobs) {
      if (j.finishedAt && now - j.finishedAt > config.renderTtlMin * 60_000) {
        if (j.file) fs.unlink(j.file).catch(() => {});
        this.jobs.delete(id);
      }
    }
  }
}

/** page.evaluate dengan argumen ter-serialisasi (aman untuk string besar). */
function pageEval(page, fn, arg) {
  return page.evaluate(fn, arg);
}
