/**
 * Konfigurasi render server - semua lewat environment variable.
 * Di Pterodactyl, isi lewat file .env (buat via file manager) atau
 * variable startup egg (kalau egg-nya mengizinkan).
 */
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const int = (v, d) => {
  const n = Number.parseInt(v ?? '', 10);
  return Number.isFinite(n) ? n : d;
};

export const config = {
  // Port - Pterodactyl otomatis set SERVER_PORT sesuai allocation.
  port: int(process.env.PORT ?? process.env.SERVER_PORT, 3000),
  host: process.env.HOST ?? '0.0.0.0',

  // Token autentikasi (kosongkan = tanpa auth; WAJIB diisi kalau expose publik).
  authToken: process.env.AUTH_TOKEN ?? '',

  // URL runtime AM (bisa dioverride kalau mau self-host web-nya).
  amRuntimeUrl: process.env.AM_RUNTIME_URL ?? 'https://am.zervida.my.id/runtime/preset.html',

  // Base URL publik untuk link unduhan hasil render (dipakai bot).
  publicBaseUrl: process.env.PUBLIC_BASE_URL ?? '',

  // Limit sesi browser yang aktif bersamaan (tiap sesi = 1 tab).
  maxSessions: int(process.env.MAX_SESSIONS, 3),
  // Sesi idle lebih lama dari ini (menit) ditutup otomatis.
  sessionTtlMin: int(process.env.SESSION_TTL_MIN, 45),
  // File hasil render lebih lama dari ini (menit) dihapus otomatis.
  renderTtlMin: int(process.env.RENDER_TTL_MIN, 180),
  // Render dijalankan satu per satu (antre global) - biar CPU aman.
  renderConcurrency: int(process.env.RENDER_CONCURRENCY, 1),
  // Batas waktu satu proses render (menit).
  renderTimeoutMin: int(process.env.RENDER_TIMEOUT_MIN, 20),
  // Retry saat host AM (Termux) error / gangguan jaringan.
  fetchRetries: int(process.env.FETCH_RETRIES, 3),
  retryWaitMs: int(process.env.RETRY_WAIT_MS, 5000),

  // Path binary chromium kustom (kalau gak pakai channel bawaan playwright).
  pwExecutablePath: process.env.PW_EXECUTABLE_PATH || '',

  dataDir: process.env.DATA_DIR ?? path.join(__dirname, '..', 'data'),
  rendersDir: path.join(
    process.env.DATA_DIR ?? path.join(__dirname, '..', 'data'),
    'renders'
  ),
};
