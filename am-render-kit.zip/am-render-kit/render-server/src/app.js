/** REST API render server. Semua route di bawah /api (kecuali static /renders). */
import express from 'express';
import path from 'node:path';
import { config } from './config.js';
import { AMEngine, AMEngineError } from './engine.js';

export function buildApp(engine) {
  const app = express();
  app.disable('x-powered-by');
  app.use(express.json({ limit: '300mb' }));

  // ---- auth (opsional) ----
  app.use('/api', (req, res, next) => {
    if (!config.authToken) return next();
    if (req.path === '/health') return next(); // health tetap terbuka
    const auth = req.headers['authorization'] || '';
    if (auth !== `Bearer ${config.authToken}`) {
      return res.status(401).json({ error: 'Unauthorized: sertakan Authorization: Bearer <token>' });
    }
    next();
  });

  const wrap = (fn) => (req, res) => {
    Promise.resolve(fn(req, res)).catch((e) => {
      if (e instanceof AMEngineError) {
        return res.status(e.status).json({ error: e.message, ...e.extra });
      }
      console.error('[api] error:', e);
      res.status(500).json({ error: 'Kesalahan internal: ' + e.message });
    });
  };

  // ---- health ----
  app.get(
    '/api/health',
    wrap(async (req, res) => {
      res.json({
        ok: true,
        uptimeSec: Math.round(process.uptime()),
        ...engine.stats(),
      });
    })
  );

  // ---- sesi ----
  app.post(
    '/api/sessions',
    wrap(async (req, res) => {
      const { source, projectName } = req.body ?? {};
      const info = await engine.createSession({ source, projectName });
      res.status(201).json(info);
    })
  );

  app.get(
    '/api/sessions/:id',
    wrap(async (req, res) => {
      res.json(engine.sessionInfo(req.params.id));
    })
  );

  app.delete(
    '/api/sessions/:id',
    wrap(async (req, res) => {
      res.json(engine.closeSession(req.params.id));
    })
  );

  // ---- media & audio ----
  app.post(
    '/api/sessions/:id/media',
    wrap(async (req, res) => {
      const { slot, mediaUrl, mediaBase64, mediaMime, force } = req.body ?? {};
      if (slot === undefined) return res.status(400).json({ error: 'Parameter "slot" wajib (mis. "pict1", id, atau index)' });
      res.json(await engine.applyMedia(req.params.id, slot, { mediaUrl, mediaBase64, mediaMime, force }));
    })
  );

  app.post(
    '/api/sessions/:id/audio',
    wrap(async (req, res) => {
      const { audioUrl, audioBase64, audioMime } = req.body ?? {};
      res.json(await engine.setAudio(req.params.id, { audioUrl, audioBase64, audioMime }));
    })
  );

  // ---- render ----
  app.post(
    '/api/sessions/:id/render',
    wrap(async (req, res) => {
      const { resolution, fps, quality } = req.body ?? {};
      res.status(202).json(engine.startRender(req.params.id, { resolution, fps, quality }));
    })
  );

  app.get(
    '/api/renders/:id',
    wrap(async (req, res) => {
      res.json(engine.getRenderInfo(req.params.id));
    })
  );

  app.post(
    '/api/renders/:id/cancel',
    wrap(async (req, res) => {
      res.json(await engine.cancelRender(req.params.id));
    })
  );

  app.get(
    '/api/renders/:id/file',
    wrap(async (req, res) => {
      const file = engine.renderFilePath(req.params.id);
      res.download(file, `render-${req.params.id}.mp4`);
    })
  );

  // ---- unduhan statis hasil render ----
  app.use(
    '/renders',
    express.static(config.rendersDir, {
      setHeaders: (res, filePath) => {
        if (path.extname(filePath) === '.mp4') res.setHeader('content-type', 'video/mp4');
      },
    })
  );

  app.use((req, res) => res.status(404).json({ error: 'Tidak ditemukan: ' + req.path }));
  return app;
}
