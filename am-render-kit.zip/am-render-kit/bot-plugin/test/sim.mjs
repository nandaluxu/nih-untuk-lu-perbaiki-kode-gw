// Simulasi plugin bot: mock sock & pesan ala Baileys, tanpa WhatsApp.
// Butuh render server jalan di PORT (di-spawn sendiri di sini).
import { spawn } from 'node:child_process';
import { createAMPlugin } from '../am-plugin.mjs';

const PORT = 3997;
const BASE = `http://127.0.0.1:${PORT}`;
const TOKEN = 'test123';
const PRESET = 'https://am.zervida.my.id/preset/TestVideo.xml';
const CHAT = '6281234567890@s.whatsapp.net';

const log = (...a) => console.log('[sim]', ...a);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// "media" buat .amrep: gambar asli dari picsum (diunduh saat mulai)
let TINY_JPG = null;
try {
  const r = await fetch('https://picsum.photos/800/1200', { signal: AbortSignal.timeout(20000) });
  TINY_JPG = Buffer.from(await r.arrayBuffer());
  log('jpg uji diunduh:', TINY_JPG.length, 'bytes');
} catch {
  log('picsum gagal - pakai jpg lokal');
  TINY_JPG = await import('node:fs/promises').then((fs) =>
    fs.readFile('/tmp/uji.jpg').catch(() => null)
  );
}
if (!TINY_JPG) throw new Error('gak ada jpg uji');

// ---------- mock sock ----------
const sent = [];
const mockSock = {
  sendMessage: async (jid, content, opts) => {
    sent.push({ jid, content });
    const preview =
      content.video ? `[VIDEO ${(content.video.length || content.video.byteLength) / 1024 | 0}KB] ${content.caption ?? ''}` :
      content.text ? content.text.split('\n')[0].slice(0, 90) : '[?]';
    log('bot kirim:', preview);
    return { key: { id: 'msg' + sent.length, remoteJid: jid } };
  },
  updateMediaMessage: async () => {},
};

// ---------- mock pesan Baileys ----------
function textMsg(text) {
  return { key: { remoteJid: CHAT, id: 't' + Math.random(), fromMe: false }, message: { conversation: text } };
}
function replyMediaMsg(text) {
  return {
    key: { remoteJid: CHAT, id: 'm' + Math.random(), fromMe: false },
    message: {
      extendedTextMessage: {
        text,
        contextInfo: { stanzaId: 'quoted1', participant: CHAT, quotedMessage: { imageMessage: { mimetype: 'image/jpeg' } } },
      },
    },
  };
}

// ---------- downloader tiruan (injection) ----------
const fakeDownloader = async () => TINY_JPG;

const server = spawn('node', ['index.js'], {
  cwd: new URL('../../render-server/', import.meta.url).pathname,
  env: { ...process.env, PORT: String(PORT), AUTH_TOKEN: TOKEN },
  stdio: ['ignore', 'pipe', 'pipe'],
});
server.stdout.on('data', () => {});
server.stderr.on('data', (d) => process.stderr.write('[srv-err] ' + d));

const assertions = [];
const check = (name, cond) => {
  assertions.push([name, !!cond]);
  console.log(`${cond ? 'PASS' : 'FAIL'}  ${name}`);
};

try {
  for (let i = 0; i < 30; i++) {
    await sleep(1000);
    try { const r = await fetch(`${BASE}/api/health`); if (r.ok) break; } catch {}
  }
  log('render server siap');

  const am = createAMPlugin({
    serverUrl: BASE,
    token: TOKEN,
    prefix: '.',
    defaultResolution: 360,
    defaultQuality: 'low',
    downloadMediaMessage: fakeDownloader,
  });

  // 1. .amrender <link>
  let r = await am.handleAMCommand({ sock: mockSock, m: textMsg(`.amrender ${PRESET}`) });
  check('.amrender -> true', r === true);
  check('reply sukses sesi', sent.some((s) => /Sesi render dibuat/.test(s.content.text)));
  check('daftar slot muncul (pict1..pict3)', sent.some((s) => /pict1/.test(s.content.text) && /pict2/.test(s.content.text)));

  // 2. .amhelp
  r = await am.handleAMCommand({ sock: mockSock, m: textMsg('.amhelp') });
  check('.amhelp -> true + teks bantuan', r === true && sent.some((s) => /amexport/.test(s.content.text)));

  // 3. .amrep pict1 (reply gambar)
  r = await am.handleAMCommand({ sock: mockSock, m: replyMediaMsg('.amrep pict1') });
  check('.amrep pict1 -> true', r === true);
  check('konfirmasi ganti slot', sent.some((s) => /pict1 diganti/.test(s.content.text)));

  // 4. .amrep tanpa reply
  sent.length = 0;
  r = await am.handleAMCommand({ sock: mockSock, m: textMsg('.amrep pict2') });
  check('.amrep tanpa reply -> error ramah', r === true && sent.some((s) => /Reply gambar/i.test(s.content.text)));

  // 5. .amexport
  sent.length = 0;
  r = await am.handleAMCommand({ sock: mockSock, m: textMsg('.amexport') });
  check('.amexport -> true', r === true);
  const videoMsg = sent.find((s) => s.content.video);
  check('video final dikirim', !!videoMsg);
  check('video valid (ftyp)', videoMsg && videoMsg.content.video.subarray(4, 8).toString('latin1') === 'ftyp');
  check('ada caption selesai', videoMsg && /Selesai/.test(videoMsg.content.caption));

  // 6. .amclose
  sent.length = 0;
  r = await am.handleAMCommand({ sock: mockSock, m: textMsg('.amclose') });
  check('.amclose -> true + konfirmasi', r === true && sent.some((s) => /Sesi ditutup/.test(s.content.text)));

  // 7. command bukan .am* -> false (tidak dikonsumsi)
  r = await am.handleAMCommand({ sock: mockSock, m: textMsg('.menu') });
  check('command lain tidak dikonsumsi', r === false);

  const failed = assertions.filter(([, ok]) => !ok);
  console.log(failed.length ? `\n${failed.length} GAGAL` : '\nSIMULASI SEMUA LULUS');
  process.exitCode = failed.length ? 1 : 0;
} catch (e) {
  console.error('SIM GAGAL:', e);
  process.exitCode = 1;
} finally {
  server.kill('SIGTERM');
  await sleep(1500);
  try { process.kill(server.pid, 0); server.kill('SIGKILL'); } catch {}
}
