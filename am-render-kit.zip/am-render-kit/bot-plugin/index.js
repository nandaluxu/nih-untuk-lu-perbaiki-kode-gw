/**
 * index.js - Contoh MINIMAL bot WhatsApp Baileys dengan plugin AM Render.
 *
 * Kalau bot lu udah jalan, lihat bagian bertanda [INTEGRASI] aja -
 * sisanya cuma boilerplate Biailles standar.
 *
 * Env:
 *   AM_SERVER_URL  (wajib) URL render server, mis. http://103.x.x.x:25565
 *   AM_TOKEN        (sesuai AUTH_TOKEN di render server)
 */
import makeWASocket, { useMultiFileAuthState, DisconnectReason } from '@whiskeysockets/baileys';
import { Boom } from 'boom';
import pino from 'pino';
import qrcode from 'qrcode-terminal';
import { createAMPlugin } from './am-plugin.mjs';

const logger = pino({ level: 'silent' }); // ganti 'info' kalau mau verbose

/* ======================= [INTEGRASI] plugin AM ======================= */
const am = createAMPlugin({
  serverUrl: process.env.AM_SERVER_URL || 'http://127.0.0.1:3000',
  token: process.env.AM_TOKEN || '',
  prefix: '.',
  defaultResolution: 720,
  defaultFps: 30,
  defaultQuality: 'high',
  logger,
});
/* ==================================================================== */

async function start() {
  const { state, saveCreds } = await useMultiFileAuthState('./auth');
  const sock = makeWASocket({
    auth: state,
    logger,
    printQRInTerminal: false,
    markOnlineOnConnect: false,
  });

  sock.ev.on('creds.update', saveCreds);
  sock.ev.on('connection.update', ({ connection, qr, lastDisconnect }) => {
    if (qr) qrcode.generate(qr, { small: true });
    if (connection === 'close') {
      const code = new Boom(lastDisconnect?.error)?.output?.statusCode;
      if (code !== DisconnectReason.loggedOut) {
        console.log('[bot] reconnect...');
        start().catch(console.error);
      } else {
        console.log('[bot] logged out, hapus folder auth & scan ulang.');
      }
    } else if (connection === 'open') {
      console.log('[bot] terhubung!');
    }
  });

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return;
    for (const m of messages) {
      if (m.key.fromMe || m.key.remoteJid === 'status@broadcast') continue;

      /* ============ [INTEGRASI] cukup 3 baris ini di bot lu ============ */
      try {
        const handled = await am.handleAMCommand({ sock, m });
        if (handled) continue; // sudah diproses plugin AM
      } catch (e) {
        console.error('[am]', e);
      }
      /* ================================================================= */

      // ... handler command bot lainnya di sini
    }
  });
}

start().catch((e) => {
  console.error('bot mati:', e);
  process.exit(1);
});
