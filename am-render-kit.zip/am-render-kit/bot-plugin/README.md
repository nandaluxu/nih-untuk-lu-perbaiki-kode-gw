# am-bot-plugin (Baileys)

Plugin bot WhatsApp untuk AM Render — pasang di server bot (Pterodactyl #1).

## Command di chat

| Command | Fungsi |
| ------- | ------ |
| `.amrender <link>` | mulai sesi render (link alight.link / Google Drive / URL .xml) |
| `.amslots` | lihat daftar slot + alias (pict1, video1, ...) + status |
| `.amrep <slot>` | **reply** gambar/video → masuk slot (mis. reply foto + `.amrep pict1`) |
| `.amaudio <url\|reply>` | pasang musik (link mp3/tiktok/drive, atau reply file audio) |
| `.amexport [res] [fps] [quality]` | render & kirim hasil. Contoh: `.amexport 720 30 high`, `.amexport 360` |
| `.amstatus` | progres render berjalan |
| `.amcancel` | batalkan render |
| `.amclose` | tutup sesi |
| `.amhelp` | bantuan |

Slot video boleh dibiarkan (pakai media bawaan preset) — sesuai kebiasaan AM.

## Integrasi ke bot yang udah jalan

 cukup 2 file: `am-client.mjs` + `am-plugin.mjs` (copy ke folder bot).

```bash
npm install @whiskeysockets/baileys   # kalau belum ada
```

```js
// di file utama bot:
import { createAMPlugin } from './am-plugin.mjs';

const am = createAMPlugin({
  serverUrl: process.env.AM_SERVER_URL,   // http://IP_RENDER:PORT
  token: process.env.AM_TOKEN,             // sama dengan AUTH_TOKEN render server
  prefix: '.',
});

// di handler messages.upsert:
const handled = await am.handleAMCommand({ sock, m });
if (handled) return; // command .am* sudah diproses
```

Lihat `index.js` untuk contoh bot Baileys lengkap (QR login + wiring).

## Config

| Opsi | Default | Keterangan |
| ---- | ------- | ---------- |
| `serverUrl` | `AM_SERVER_URL` env / `http://127.0.0.1:3000` | URL render server |
| `token` | `AM_TOKEN` env | bearer token |
| `prefix` | `.` | awalan command |
| `defaultResolution` | 720 | resolusi default `.amexport` |
| `defaultFps` | 30 | fps default |
| `defaultQuality` | `high` | kualitas default |
| `sessionTtlMin` | 45 | sesi idle otomatis dilupakan |
| `progressUpdateEveryPct` | 25 | update progres tiap N% |

## Test (tanpa WhatsApp)

```bash
# butuh render server bisa di-spawn otomatis (test/sim.mjs yang urus)
node test/sim.mjs
```
