/**
 * am-plugin.mjs - Plugin bot WhatsApp (Baileys) untuk AM Render.
 *
 * Alur pemakaian di chat:
 *   .amrender <link>     mulai sesi render dari link (alight.link / drive / xml)
 *   .amslots             lihat daftar slot & alias (pict1, video1, ...)
 *   .amrep <slot>        reply media -> masuk ke slot tsb
 *   .amaudio <url|reply> pasang musik (reply audio, atau link mp3/tiktok/drive)
 *   .amexport [res|fps|quality]  render & kirim hasilnya
 *                        contoh: .amexport 360 30 low  |  .amexport 1080
 *   .amstatus            cek progres render berjalan
 *   .amcancel            batalkan render yang jalan
 *   .amclose             tutup sesi (selesai / mau ganti preset)
 *   .amhelp              bantuan
 *
 * Integrasi (di bot lu):
 *   import { createAMPlugin } from './am-plugin.mjs';
 *   const am = createAMPlugin({ serverUrl: 'http://IP_RENDER:PORT', token: 'xxx' });
 *   // di handler "messages.upsert":
 *   if (await am.handleAMCommand({ sock, m })) return; // command .am* kedaluwarsa
 *
 * Catatan: butuh @whiskeysockets/baileys terpasang di project bot lu
 * (di-import otomatis saat pertama kali download media; bisa juga di-inject
 *  lewat config.downloadMediaMessage untuk testing).
 */
import { AMRenderClient } from './am-client.mjs';

export function createAMPlugin(userConfig = {}) {
  const cfg = {
    serverUrl: userConfig.serverUrl || process.env.AM_SERVER_URL || 'http://127.0.0.1:3000',
    token: userConfig.token || process.env.AM_TOKEN || '',
    prefix: userConfig.prefix || '.',
    defaultResolution: userConfig.defaultResolution || 720,
    defaultFps: userConfig.defaultFps || 30,
    defaultQuality: userConfig.defaultQuality || 'high',
    sessionTtlMin: userConfig.sessionTtlMin || 45, // sesi idle dihapus dari memori bot
    progressUpdateEveryPct: userConfig.progressUpdateEveryPct ?? 25,
    logger: userConfig.logger || { info: () => {}, error: () => {} },
    ...userConfig,
  };

  const client = new AMRenderClient({ baseUrl: cfg.serverUrl, token: cfg.token });
  /** chatId -> state */
  const sessions = new Map();

  const HELP = `*AM RENDER* - fitur render video AM
${cfg.prefix}amrender <link> - mulai sesi (link alight.link / gdrive / .xml)
${cfg.prefix}amslots - daftar slot (pict1, video1, ...)
${cfg.prefix}amrep <slot> - reply gambar/video, ganti slot
${cfg.prefix}amaudio <url|reply audio> - pasang musik
${cfg.prefix}amexport [res] [fps] [quality] - render & kirim
  res: 360/540/720/1080 | fps: 30/60 | quality: low/medium/high
${cfg.prefix}amstatus - progres render
${cfg.prefix}amcancel - batalkan render
${cfg.prefix}amclose - tutup sesi`;

  /* ---------------- util ---------------- */

  const now = () => Date.now();

  function cleanupExpired() {
    for (const [chatId, st] of sessions) {
      if (now() - st.lastActivity > cfg.sessionTtlMin * 60_000) sessions.delete(chatId);
    }
  }

  function getBodyAndQuoted(m) {
    const msg = m.message ?? {};
    const text =
      msg.conversation ||
      msg.extendedTextMessage?.text ||
      msg.imageMessage?.caption ||
      msg.videoMessage?.caption ||
      '';
    const ctx = msg.extendedTextMessage?.contextInfo;
    return { text: String(text || '').trim(), ctx, hasQuoted: !!ctx?.quotedMessage };
  }

  function quotedMedia(ctx) {
    const q = ctx?.quotedMessage;
    if (!q) return null;
    if (q.imageMessage) return { kind: 'image', mimetype: q.imageMessage.mimetype || 'image/jpeg', msg: q };
    if (q.videoMessage) return { kind: 'video', mimetype: q.videoMessage.mimetype || 'video/mp4', msg: q };
    if (q.audioMessage) return { kind: 'audio', mimetype: q.audioMessage.mimetype || 'audio/mpeg', msg: q };
    if (q.documentMessage) {
      return {
        kind: 'document',
        mimetype: q.documentMessage.mimetype || 'application/octet-stream',
        fileName: q.documentMessage.fileName || 'file',
        msg: q,
      };
    }
    if (q.stickerMessage) return { kind: 'image', mimetype: 'image/webp', msg: q };
    return null;
  }

  async function downloadQuoted(sock, m, ctx) {
    const qm = quotedMedia(ctx);
    if (!qm) return null;
    const fakeMsg = {
      key: {
        remoteJid: m.key.remoteJid,
        id: ctx.stanzaId,
        participant: ctx.participant,
        fromMe: false,
      },
      message: qm.msg,
    };
    // Lazy import Baileys (atau pakai injection untuk testing).
    const downloader = cfg.downloadMediaMessage ?? (await importBaileys());
    const buffer = await downloader(fakeMsg, 'buffer', {}, {
      logger: cfg.logger,
      reuploadRequest: sock.updateMediaMessage?.bind(sock),
    });
    return { ...qm, buffer };
  }

  let _baileysDownloader = null;
  async function importBaileys() {
    if (_baileysDownloader) return _baileysDownloader;
    const mod = await import('@whiskeysockets/baileys');
    _baileysDownloader = mod.downloadMediaMessage;
    return _baileysDownloader;
  }

  const fmtSize = (b) => (b > 1048576 ? (b / 1048576).toFixed(1) + 'MB' : Math.round(b / 1024) + 'KB');

  function slotListText(st) {
    if (!st.slots.length) return '(preset ini tidak punya slot media yang bisa diganti)';
    return st.slots
      .filter((s) => s.isReplaceable)
      .map(
        (s) =>
          `• *${s.alias ?? s.index}* - ${s.mediaKind ?? s.type ?? '?'} (${s.name})` +
          (st.replaced.has(s.alias ?? String(s.index)) ? ' [SUDAH DIGANTI]' : '')
      )
      .join('\n');
  }

  const reply = (sock, m, text) => sock.sendMessage(m.key.remoteJid, { text }, { quoted: m });

  function apiErrText(e) {
    if (e.status === 0) return e.message; // koneksi/timeouts
    return e.body?.error || e.message;
  }

  /* ---------------- command handler ---------------- */

  /**
   * Panggil dari handler messages.upsert.
   * Return true kalau pesan TERSERAH sebagai command AM (biar handler lain skip).
   */
  async function handleAMCommand({ sock, m }) {
    const chatId = m.key.remoteJid;
    const { text, ctx, hasQuoted } = getBodyAndQuoted(m);
    if (!text.startsWith(cfg.prefix + 'am')) return false;

    const parts = text.slice(cfg.prefix.length).trim().split(/\s+/);
    const cmd = (parts[0] || '').toLowerCase();
    const args = parts.slice(1);

    cleanupExpired();
    const st = sessions.get(chatId);

    try {
      switch (cmd) {
        /* ============ mulai sesi ============ */
        case 'amrender': {
          const link = args[0];
          if (!link || !/^https?:\/\//i.test(link)) {
            return reply(sock, m, 'Kirim link-nya:\n' + cfg.prefix + 'amrender https://alight.link/xxxx'), true;
          }
          if (st) {
            await client.closeSession(st.sessionId).catch(() => {});
            sessions.delete(chatId);
          }
          await reply(sock, m, '⏳ Memuat preset... (kalau lama, host AM-nya lagi error, sabar ya)');
          let info;
          try {
            info = await client.createSession({ source: link });
          } catch (e) {
            return reply(sock, m, '❌ Gagal memuat preset:\n' + apiErrText(e)), true;
          }
          const state = {
            sessionId: info.id,
            slots: info.slots,
            replaced: new Set(),
            lastActivity: now(),
            createdAt: now(),
            rendering: null,
          };
          sessions.set(chatId, state);
          const lines = [
            '✅ *Sesi render dibuat!*',
            `Slot media (${info.totalSlots}):`,
            slotListText(state),
            '',
            'Ganti slot: reply gambar/video + ketik ' + cfg.prefix + 'amrep <slot>',
            'Slot video boleh dibiarkan (pakai bawaan preset).',
            'Render: ' + cfg.prefix + 'amexport',
          ].join('\n');
          return reply(sock, m, lines), true;
        }

        /* ============ daftar slot ============ */
        case 'amslots': {
          if (!st) return reply(sock, m, 'Belum ada sesi. Mulai dengan ' + cfg.prefix + 'amrender <link>'), true;
          st.lastActivity = now();
          return reply(sock, m, 'Slot sesi ini:\n' + slotListText(st)), true;
        }

        /* ============ ganti media ============ */
        case 'amrep': {
          if (!st) return reply(sock, m, 'Belum ada sesi. Mulai dengan ' + cfg.prefix + 'amrender <link>'), true;
          st.lastActivity = now();
          const slotArg = args[0];
          if (!slotArg) return reply(sock, m, 'Format: reply media + ketik ' + cfg.prefix + 'amrep <slot>\nContoh: ' + cfg.prefix + 'amrep pict1'), true;
          if (!hasQuoted) return reply(sock, m, 'Reply gambar/video-nya dulu, lalu ketik ' + cfg.prefix + 'amrep ' + slotArg), true;

          const media = await downloadQuoted(sock, m, ctx);
          if (!media || !media.buffer?.length) {
            return reply(sock, m, 'Media di reply tidak bisa diunduh / bukan media.'), true;
          }
          if (media.kind === 'audio') {
            return reply(sock, m, 'Itu audio - pakai ' + cfg.prefix + 'amaudio ya.'), true;
          }
          await reply(sock, m, `⏳ Mengunggah media (${fmtSize(media.buffer.length)})...`);
          try {
            const r = await client.applyMedia(st.sessionId, slotArg, {
              mediaBase64: media.buffer.toString('base64'),
              mediaMime: media.mimetype,
            });
            const key = r.slot.alias ?? slotArg;
            st.replaced.add(key);
            return reply(sock, m, `✅ ${key} diganti (${r.slot.mediaKind ?? '?'} - ${r.slot.name})`), true;
          } catch (e) {
            const msg = apiErrText(e);
            const hint = /GAMBAR/i.test(msg) ? '\n💡 Slot ini butuh gambar, kirim gambar ya.' : '';
            return reply(sock, m, '❌ Gagal ganti slot:\n' + msg + hint), true;
          }
        }

        /* ============ audio ============ */
        case 'amaudio': {
          if (!st) return reply(sock, m, 'Belum ada sesi. Mulai dengan ' + cfg.prefix + 'amrender <link>'), true;
          st.lastActivity = now();
          try {
            if (hasQuoted) {
              const media = await downloadQuoted(sock, m, ctx);
              if (!media || media.kind !== 'audio' && media.mimetype?.startsWith('video') === false && !media.mimetype?.startsWith('audio')) {
                return reply(sock, m, 'Reply-nya harus file audio (mp3/dll) atau ketik ' + cfg.prefix + 'amaudio <url>'), true;
              }
              await client.setAudio(st.sessionId, {
                audioBase64: media.buffer.toString('base64'),
                audioMime: media.mimetype,
              });
            } else if (args[0] && /^https?:\/\//i.test(args[0])) {
              await client.setAudio(st.sessionId, { audioUrl: args[0] });
            } else {
              return reply(sock, m, 'Reply audio, atau ketik ' + cfg.prefix + 'amaudio <url mp3/tiktok/drive>'), true;
            }
            return reply(sock, m, '✅ Audio terpasang. Render dengan ' + cfg.prefix + 'amexport'), true;
          } catch (e) {
            return reply(sock, m, '❌ Gagal pasang audio:\n' + apiErrText(e)), true;
          }
        }

        /* ============ export / render ============ */
        case 'amexport': {
          if (!st) return reply(sock, m, 'Belum ada sesi. Mulai dengan ' + cfg.prefix + 'amrender <link>'), true;
          if (st.rendering) return reply(sock, m, `Masih ada render jalan (${st.rendering}). Cek ${cfg.prefix}amstatus atau ${cfg.prefix}amcancel`), true;
          st.lastActivity = now();

          // parse opsi: [res] [fps] [quality]
          let resolution = cfg.defaultResolution, fps = cfg.defaultFps, quality = cfg.defaultQuality;
          for (const a of args) {
            const n = Number(a);
            if ([360, 540, 720, 1080].includes(n)) resolution = n;
            else if ([30, 60].includes(n)) fps = n;
            else if (['low', 'medium', 'high'].includes(a.toLowerCase())) quality = a.toLowerCase();
          }

          const { renderId } = await client.startRender(st.sessionId, { resolution, fps, quality });
          st.rendering = renderId;
          const progressMsg = await sock.sendMessage(chatId, { text: `🔄 Render mulai (${resolution}p ${fps}fps ${quality})...\n0%` }, { quoted: m });
          let lastSent = 0;

          try {
            const info = await client.waitForRender(renderId, {
              onProgress: (p) => {
                const pct = p.progressPct ?? 0;
                if (p.status === 'rendering' && pct - lastSent >= cfg.progressUpdateEveryPct) {
                  lastSent = pct;
                  sock
                    .sendMessage(chatId, { text: `⏳ ${pct}% (frame ${p.currentFrame}/${p.totalFrames})` })
                    .catch(() => {});
                }
              },
            });
            if (info.status === 'error') {
              st.rendering = null;
              return reply(sock, m, '❌ Render gagal: ' + (info.error || 'tidak diketahui')), true;
            }
            if (info.status === 'cancelled') {
              st.rendering = null;
              return reply(sock, m, '🚫 Render dibatalkan.'), true;
            }

            const mp4 = await client.downloadRender(renderId);
            st.rendering = null;
            await sock.sendMessage(
              chatId,
              {
                video: mp4,
                mimetype: 'video/mp4',
                fileName: 'am-render.mp4',
                caption:
                  `✅ *Selesai!* ${info.durationSec ? info.durationSec.toFixed(1) + 's' : ''} | ` +
                  `${fmtSize(mp4.length)} | ${resolution}p ${fps}fps (${quality})`,
              },
              { quoted: m }
            );
            return true;
          } catch (e) {
            st.rendering = null;
            return reply(sock, m, '❌ ' + apiErrText(e)), true;
          }
        }

        /* ============ status ============ */
        case 'amstatus': {
          if (!st) return reply(sock, m, 'Belum ada sesi.'), true;
          if (!st.rendering) {
            return reply(sock, m, 'Tidak ada render berjalan. Slot:\n' + slotListText(st)), true;
          }
          const info = await client.renderInfo(st.rendering);
          return reply(
            sock,
            m,
            `Render: *${info.status}*\nProgres: ${info.progressPct}% (frame ${info.currentFrame}/${info.totalFrames})`
          ), true;
        }

        /* ============ cancel ============ */
        case 'amcancel': {
          if (!st?.rendering) return reply(sock, m, 'Tidak ada render berjalan.'), true;
          await client.cancelRender(st.rendering);
          st.rendering = null;
          return reply(sock, m, '🚫 Render dibatalkan.'), true;
        }

        /* ============ tutup sesi ============ */
        case 'amclose': {
          if (!st) return reply(sock, m, 'Tidak ada sesi aktif.'), true;
          await client.closeSession(st.sessionId).catch(() => {});
          sessions.delete(chatId);
          return reply(sock, m, '🔒 Sesi ditutup. Sampai jumpa!'), true;
        }

        /* ============ bantuan ============ */
        case 'amhelp':
        case 'am':
          return reply(sock, m, HELP), true;

        default:
          return false; // bukan command AM -> biar handler lain proses
      }
    } catch (e) {
      cfg.logger.error?.('[am-plugin]', e);
      await reply(sock, m, '❌ Error tak terduga: ' + (e.message || e)).catch(() => {});
      return true;
    }
  }

  return {
    handleAMCommand,
    /** state internal (buat test / diagnostik) */
    _sessions: sessions,
    _client: client,
  };
}
