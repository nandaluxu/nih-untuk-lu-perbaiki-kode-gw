/**
 * am-client.mjs - Klien HTTP untuk am-render-server.
 *
 * Dipakai di server bot (Pterodactyl #1) untuk bicara ke render server
 * (Pterodactyl #2) lewat fetch biasa. Tanpa dependensi (Node >= 18).
 *
 * Contoh:
 *   import { AMRenderClient } from './am-client.mjs';
 *   const am = new AMRenderClient({ baseUrl: 'http://ip:port', token: 'xxx' });
 *   const ses = await am.createSession({ source: 'https://alight.link/xxx' });
 *   await am.applyMedia(ses.id, 'pict1', { mediaBase64, mediaMime: 'image/jpeg' });
 *   const { renderId } = await am.startRender(ses.id, { resolution: 720 });
 *   const info = await am.waitForRender(renderId, { onProgress: (p) => ... });
 *   const mp4 = await am.downloadRender(renderId); // Buffer
 */

export class AMClientError extends Error {
  constructor(message, status = 0, body = null) {
    super(message);
    this.name = 'AMClientError';
    this.status = status;
    this.body = body;
  }
}

export class AMRenderClient {
  /**
   * @param {object} opts
   * @param {string} opts.baseUrl  contoh: http://103.x.x.x:25565 (tanpa slash akhir)
   * @param {string} [opts.token]  bearer token (sama dengan AUTH_TOKEN render server)
   * @param {number} [opts.timeoutMs=60000] timeout per request
   */
  constructor({ baseUrl, token = '', timeoutMs = 60_000 } = {}) {
    if (!baseUrl) throw new Error('baseUrl wajib (URL render server)');
    this.baseUrl = String(baseUrl).replace(/\/+$/, '');
    this.token = token;
    this.timeoutMs = timeoutMs;
  }

  async #api(method, path, body, timeoutMs) {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), timeoutMs ?? this.timeoutMs);
    try {
      const res = await fetch(this.baseUrl + path, {
        method,
        headers: {
          'Content-Type': 'application/json',
          ...(this.token ? { Authorization: `Bearer ${this.token}` } : {}),
        },
        body: body === undefined ? undefined : JSON.stringify(body),
        signal: ctrl.signal,
      });
      const text = await res.text();
      let json = null;
      try { json = JSON.parse(text); } catch {}
      if (!res.ok) {
        const msg = json?.error || text || `HTTP ${res.status}`;
        throw new AMClientError(msg, res.status, json);
      }
      return json;
    } catch (e) {
      if (e instanceof AMClientError) throw e;
      if (e.name === 'AbortError') {
        throw new AMClientError(`Timeout ${timeoutMs ?? this.timeoutMs}ms ke ${this.baseUrl}${path}`, 0);
      }
      throw new AMClientError(
        `Gagal terhubung ke render server (${this.baseUrl}): ${e.message}. ` +
          'Cek servernya hidup / port benar / tidak diblokir firewall.',
        0
      );
    } finally {
      clearTimeout(t);
    }
  }

  /** Cek kesehatan render server. */
  async health() {
    return this.#api('GET', '/api/health', undefined, 10_000);
  }

  /** Buat sesi render dari link share AM / Google Drive / URL XML. */
  async createSession({ source, projectName } = {}) {
    return this.#api('POST', '/api/sessions', { source, projectName }, 120_000);
  }

  /** Info sesi (slot, alias, dll). */
  async getSession(sessionId) {
    return this.#api('GET', `/api/sessions/${sessionId}`);
  }

  /** Tutup sesi. */
  async closeSession(sessionId) {
    return this.#api('DELETE', `/api/sessions/${sessionId}`);
  }

  /**
   * Ganti media slot.
   * @param {string} sessionId
   * @param {string|number} slot alias ('pict1') / id / index
   * @param {object} media { mediaUrl } atau { mediaBase64, mediaMime }, opsi { force }
   */
  async applyMedia(sessionId, slot, media = {}) {
    return this.#api('POST', `/api/sessions/${sessionId}/media`, { slot, ...media }, 180_000);
  }

  /** Pasang audio: { audioUrl } atau { audioBase64, audioMime }. */
  async setAudio(sessionId, audio = {}) {
    return this.#api('POST', `/api/sessions/${sessionId}/audio`, audio, 180_000);
  }

  /** Mulai render (async). Return { renderId, status }. */
  async startRender(sessionId, { resolution = 720, fps = 30, quality = 'high' } = {}) {
    return this.#api('POST', `/api/sessions/${sessionId}/render`, { resolution, fps, quality }, 30_000);
  }

  /** Info progres render. */
  async renderInfo(renderId) {
    return this.#api('GET', `/api/renders/${renderId}`);
  }

  /** Batalkan render. */
  async cancelRender(renderId) {
    return this.#api('POST', `/api/renders/${renderId}/cancel`);
  }

  /** Unduh hasil render jadi Buffer. */
  async downloadRender(renderId, timeoutMs = 300_000) {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), timeoutMs);
    try {
      const res = await fetch(`${this.baseUrl}/api/renders/${renderId}/file`, {
        headers: this.token ? { Authorization: `Bearer ${this.token}` } : {},
        signal: ctrl.signal,
      });
      if (!res.ok) {
        const text = await res.text();
        throw new AMClientError(text || `HTTP ${res.status}`, res.status);
      }
      return Buffer.from(await res.arrayBuffer());
    } finally {
      clearTimeout(t);
    }
  }

  /**
   * Tunggu render selesai sambil poll progres.
   * @returns info render final (status 'done' | 'error' | 'cancelled')
   */
  async waitForRender(renderId, { onProgress = null, pollMs = 2500, timeoutMs = 25 * 60_000 } = {}) {
    const t0 = Date.now();
    let last = -1;
    while (true) {
      const info = await this.renderInfo(renderId);
      if (onProgress && (info.progressPct !== last || info.status !== 'rendering')) {
        onProgress(info);
        last = info.progressPct;
      }
      if (info.status !== 'queued' && info.status !== 'rendering') return info;
      if (Date.now() - t0 > timeoutMs) {
        throw new AMClientError(`Menunggu render timeout (${timeoutMs / 60000} menit)`, 0, info);
      }
      await new Promise((r) => setTimeout(r, pollMs));
    }
  }
}
