# AM Render Kit

Scrape + otomatisasi **AM Web Runtime** (`https://am.zervida.my.id`) jadi
fitur bot WhatsApp: `.amrender` → `.amrep` → `.amexport`.

## Isi paket

| Folder | Isi |
| ------ | --- |
| `render-server/` | Node.js + Express + Playwright — REST API render. Deploy di **Pterodactyl #2** dengan image Docker resmi Playwright |
| `bot-plugin/` | `am-client.mjs` + `am-plugin.mjs` (plugin Baileys) + contoh bot `index.js` + simulasi test |
| `TUTORIAL-PTERODACTYL.md` | Panduan pemasangan 2-server lengkap (egg, docker image, env, wiring bot, troubleshooting) |

## Status verifikasi (semua diuji live, headless)

- ✅ `loadPreset` dari URL XML (alight.link & Google Drive diproses server web AM)
- ✅ `getMediaSlots` → daftar slot + alias ramah user (`pict1`, `video1`, ...)
- ✅ `applyMedia` via URL / base64 (gambar)
- ✅ `setAudio` via URL / base64
- ✅ `renderVideo` → MP4 h264 valid (62 detik video ≈ 15-18s render di 1 vCPU, 360p)
- ✅ Progres real-time (persen + frame), cancel render
- ✅ E2E: REST API lengkap (health, auth bearer, sesi, media, audio, render, unduh)
- ✅ Simulasi bot: `.amrender` `.amrep` `.amexport` `.amclose` dst — semua lulus

## Kesimpulan reverse engineering (singkat)

1. Web AM = player preset **Alight Motion** di browser; API otomasi resminya
   `window.AM` (di `/runtime/preset.html`), dirancang untuk Puppeteer/Playwright.
2. **Render 100% client-side** — WebCodecs `VideoEncoder`, `MediaRecorder`,
   WebGL (jalan via SwiftShader tanpa GPU), `AudioContext`. **Fetch-only tidak
   mungkin** untuk render; Playwright itu satu-satunya jalan.
3. Slot media: jenis loader ditentukan **ekstensi nama file slot**, bukan
   field `type` (tes: mp4 ke slot `.jpg` = gagal; jpg = sukses).
4. Race condition: aksi sebelum `[SCENE] Siap` bisa memotong durasi project —
   render server sudah mengatasinya.
5. Preset tanpa audio bawaan: export membuang audio (perilaku web AM-nya).
6. Host web AM jalan di Termux — sering error sebentar; render server
   auto-retry 3x dengan backoff.
