import 'dotenv/config'

const ownerNumber = (process.env.OWNER_NUMBER || '').replace(/\D/g, '')
const pairingNumber = (process.env.PAIRING_NUMBER || '').replace(/\D/g, '')
const loginMethod = String(process.env.LOGIN_METHOD || 'qr').toLowerCase()

if (!['pairing', 'qr'].includes(loginMethod)) {
        throw new Error(`LOGIN_METHOD tidak valid: "${loginMethod}". Gunakan "qr" atau "pairing".`)
}

export default {
        ownerNumber,
        ownerName: process.env.OWNER_NAME || 'Owner',
        botName: process.env.BOT_NAME || 'Bot',
        sessionName: process.env.SESSION_DIR || './sessions',
        pairingNumber,
        loginMethod,
        usePairingCode: loginMethod === 'pairing' && Boolean(pairingNumber),
        // Task 18: selfMode env SISA SEJARAH — selfmode nyata kini runtime
        // persist di global_settings["selfmode_enabled"] (lib/selfmode.js;
        // gate di bot.js). Owner mengetik di akun bot tetap SELALU diproses
        // (echo-guard memilah kiriman bot).
        logLevel: process.env.LOG_LEVEL || 'silent',
        defaultPrefix: (process.env.PREFIX || '.')[0] || '.',
        // B3: ejaan disamakan ke THERESAV_API_KEY (underscore) — sejajar
        // lib/theresav.js + .env.example. Ejaan lama THERESAV_APIKEY tetap
        // dibaca sebagai legacy fallback agar .env operator lama tidak rusak.
        // TIDAK ada lagi fallback hardcoded — kosong = kosong (plugin
        // theresav-based sudah punya pesan "key belum dikonfigurasi").
        theresavApiKey: process.env.THERESAV_API_KEY || process.env.THERESAV_APIKEY || '',
        ai: {
                groqKeys: (process.env.GROQ_API_KEY || '').split(',').map(k => k.trim()).filter(Boolean),
                geminiKeys: (process.env.GEMINI_API_KEY || '').split(',').map(k => k.trim()).filter(Boolean),
                openrouterKeys: (process.env.OPENROUTER_API_KEY || '').split(',').map(k => k.trim()).filter(Boolean),
                defaultProvider: process.env.AI_PROVIDER || 'groq'
        }
}

/**
 * Cek apakah JID termasuk owner.
 * Mendukung format: '628xxx@s.whatsapp.net', '628xxx@lid', '628xxx'
 */
export function isOwner(jid) {
        if (!jid || !ownerNumber) return false
        const number = String(jid).split('@')[0].replace(/\D/g, '')
        return number === ownerNumber
}

// Re-export economy config
export { economy } from './economy.js'
export { default as economyConfig } from './economy.js'
export { protection, protection as protectionConfig } from './protection.js'
