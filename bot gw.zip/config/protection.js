/**
 * Protection configuration (rate limit + anti-spam).
 * Semua angka penting bisa di-override via .env
 *
 * Prinsip:
 *   - State rate-limit adalah ephemeral runtime state (in-memory), BUKAN database.
 *   - Nilai default ditentukan dari karakter bot existing:
 *       • Command umum cepat (lookup/menu/bal) → global burst bucket cukup.
 *       • Kategori berat (ai/search/downloader/economy/premium/nsfw) → policy per kategori.
 *       • Plugin bisa override via metadata rateLimit (ikut hot reload).
 */
import 'dotenv/config'

const env = (key, fallback) => {
        const v = process.env[key]
        if (v === undefined) return fallback
        return isNaN(Number(v)) ? v : Number(v)
}

export const protection = {
        // Master switch — false menonaktifkan seluruh protection layer
        enabled: /^true$/i.test(process.env.PROTECTION_ENABLED || 'true'),

        // ---- Global burst limit per user (token bucket) ----
        // capacity 6 = user boleh menembak ~6 command cepat,
        // lalu token kembali bertahap 1 token per 1.5s (~40 command/menit sustain).
        burst: {
                capacity: env('BURST_CAPACITY', 6),
                refill: env('BURST_REFILL', 1),          // token per interval
                interval: env('BURST_INTERVAL', 1500),   // ms
        },

        // ---- Flood detection COMMAND (spam req ke bot, sliding window per user) ----
        flood: {
                window: env('FLOOD_WINDOW', 10000),        // ms
                maxCommands: env('FLOOD_MAX_COMMANDS', 10), // total command dalam window
                maxSameCommand: env('FLOOD_MAX_SAME', 6),   // command sama dalam window
                windowSize: 16,                             // batas ring buffer (anti unbounded array)
        },

        // ---- Flood detection CHAT (spam pesan biasa/non-command) ----
        // Terpisah dari flood command: window, threshold, dan hitungan sendiri.
        chatFlood: {
                window: env('CHAT_FLOOD_WINDOW', 15000),      // ms
                maxMessages: env('CHAT_FLOOD_MAX', 20),       // pesan non-command per window → strike
                windowSize: 24,                                // batas ring buffer (anti unbounded array)
        },

        // ---- Switch anti-spam (flood + strike + penalty) TERPISAH dari rate limit ----
        // false = tidak ada strike/penalty (flood command & chat diabaikan),
        // tapi rate limit (burst, policy per command, bucket AI) tetap berjalan.
        antispam: {
                enabled: /^true$/i.test(process.env.ANTISPAM_ENABLED || 'true'),
        },

        // ---- Temporary penalty per strike (escalaning, decay otomatis) ----
        // strike 1 → 20s, strike 2 → 90s, strike 3 → 5m, strike 4+ → 15m (cap)
        penalties: [
                env('PENALTY_1', 20000),
                env('PENALTY_2', 90000),
                env('PENALTY_3', 300000),
                env('PENALTY_4', 900000),
        ],
        penaltyCap: env('PENALTY_CAP', 900000),
        strikeDecay: env('STRIKE_DECAY', 600000), // 1 strike memudar per 10 menit tanpa flood

        // ---- Jalur AI trigger (rik/rikka/reply-AI) — API call mahal ----
        ai: {
                capacity: env('AI_CAPACITY', 3),
                refill: env('AI_REFILL', 1),
                interval: env('AI_INTERVAL', 12000),      // ms
                window: env('AI_FLOOD_WINDOW', 30000),    // ms
                maxRequests: env('AI_FLOOD_MAX', 6),      // request AI dalam window → strike
        },

        // ---- Policy per kategori (default untuk plugin tanpa metadata rateLimit) ----
        // Kosong = hanya global burst yang berlaku (command ringan tidak diberi cooldown tambahan).
        // Audit fase-2: tools (91 cmd) dipecah → imagefilter/image/creator kini
        // berpolicy (semuanya API eksternal per-gambar); premium tetap (am*).
        categoryPolicies: {
                ai:          { capacity: 2, refill: 1, interval: 10000, concurrency: 1 },
                search:      { capacity: 2, refill: 1, interval: 8000,  concurrency: 1 },
                downloader:  { capacity: 1, refill: 1, interval: 15000, concurrency: 1 },
                economy:     { concurrency: 1 }, // mutasi user file — anti race condition
                premium:     { concurrency: 1 },
                nsfw:        { capacity: 2, refill: 1, interval: 8000,  concurrency: 1 },
                imagefilter: { capacity: 2, refill: 1, interval: 8000,  concurrency: 1 },
                image:       { capacity: 2, refill: 1, interval: 8000,  concurrency: 1 },
                creator:     { capacity: 2, refill: 1, interval: 10000, concurrency: 1 },
                // Task 24: submit JJ = upload foto + render upstream — 1 konkurensi,
                // jeda 20 dtk antar task per user (render bisa menit-menit).
                jjcapcut:    { capacity: 1, refill: 1, interval: 20000, concurrency: 1 },
        },

        // ---- Concurrency ----
        maxUserConcurrency: env('MAX_USER_CONCURRENCY', 3), // total command berjalan per user
        queueMaxWait: env('QUEUE_MAX_WAIT', 30000),         // ms — batas waktu antrian (queue TIDAK unlimited)

        // ---- Role integration ----
        // Kapasitas burst = capacity × multiplier (role lebih tinggi → bucket lebih besar,
        // BUKAN unlimited). owner punya bypass eksplisit (konsisten ROLE_CONFIG.bypassCooldown).
        roleBurstMultiplier: {
                'premium': 1.5,
                'vip': 2,
                'co-owner': 3,
        },
        exemptOwner: /^true$/i.test(process.env.PROTECTION_EXEMPT_OWNER || 'true'),

        // ---- Feedback suppression (anti bot-spam saat menolak request) ----
        feedbackCooldown: env('FEEDBACK_COOLDOWN', 8000), // ms — 1 reply per reason per user

        // ---- Memory lifecycle ----
        sweepInterval: env('PROTECTION_SWEEP_INTERVAL', 120000), // ms antar sweep
        stateTtl: env('PROTECTION_STATE_TTL', 900000),           // ms idle sebelum state dibuang
}

// Re-export dari config/index.js agar pola import konsisten dengan economy
export default protection
