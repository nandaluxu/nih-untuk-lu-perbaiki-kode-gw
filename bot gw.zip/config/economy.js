/**
 * Economy configuration.
 * Semua angka penting bisa di-override via .env
 *
 * Task 26 — Economy deepening:
 *   - job        : katalog pekerjaan + kurva EXP job + aturan ganti job
 *   - workEngine : mesin .work (progress dinamis, event, grade, scaling)
 *   - rob        : .rob @user
 *   - transfer   : fee transfer (money sink → World Bank)
 *   - sell       : aturan penjualan item
 * Item shop/inventory TIDAK diubah strukturnya (sellable ditambah per item).
 */
import 'dotenv/config'

const env = (key, fallback) => {
        const v = process.env[key]
        if (v === undefined) return fallback
        return isNaN(Number(v)) ? v : Number(v)
}

// ---------------------------------------------------------------------------
// Katalog job — configurable penuh. Tambah/ubah job di sini tanpa sentuh logic.
//   difficulty     : 1-5 (sudah tercermin di successBase & baseReward)
//   tags           : penentu pool event yang kompatibel ('*' = semua job)
//   unlock         : { cost, minPlayerLevel } — cost dibayar SEKALI (owned)
//   durationMs     : durasi dasar sesi kerja (progress dibagi jadi step 1-7 dtk)
//   expReward      : job EXP dasar per sesi sukses (dikali grade & bonus event)
// ---------------------------------------------------------------------------
const jobCatalog = [
        { id: 'barista', emoji: '☕', name: 'Barista', desc: 'Membuat kopi dan menyambut pelanggan di kafe.', tags: ['food_service', 'customer_service'], difficulty: 1, baseReward: 25, energyCost: 12, durationMs: 18000, expReward: 12, successBase: 0.68, maxLevel: 30, unlock: { cost: 0, minPlayerLevel: 1 } },
        { id: 'waiter', emoji: '🍽️', name: 'Waiter', desc: 'Melayani meja, mencatat pesanan, membawa piring.', tags: ['food_service', 'customer_service'], difficulty: 1, baseReward: 26, energyCost: 13, durationMs: 18000, expReward: 12, successBase: 0.66, maxLevel: 30, unlock: { cost: 0, minPlayerLevel: 1 } },
        { id: 'cashier', emoji: '🧾', name: 'Cashier', desc: 'Menghitung belanja dan menjaga kasir tetap lancar.', tags: ['customer_service', 'office'], difficulty: 1, baseReward: 28, energyCost: 12, durationMs: 19000, expReward: 12, successBase: 0.64, maxLevel: 30, unlock: { cost: 0, minPlayerLevel: 1 } },
        { id: 'gardener', emoji: '🌱', name: 'Gardener', desc: 'Menyiram tanaman dan merawat taman.', tags: ['outdoor', 'nature'], difficulty: 1, baseReward: 24, energyCost: 12, durationMs: 18000, expReward: 11, successBase: 0.7, maxLevel: 30, unlock: { cost: 0, minPlayerLevel: 1 } },
        { id: 'courier', emoji: '🚚', name: 'Courier', desc: 'Mengantar paket melintasi kota.', tags: ['delivery', 'outdoor'], difficulty: 2, baseReward: 34, energyCost: 15, durationMs: 20000, expReward: 14, successBase: 0.6, maxLevel: 30, unlock: { cost: 0, minPlayerLevel: 1 } },
        { id: 'driver', emoji: '🚕', name: 'Driver', desc: 'Mengantar penumpang ke tujuan dengan aman.', tags: ['delivery', 'outdoor'], difficulty: 2, baseReward: 33, energyCost: 15, durationMs: 20000, expReward: 13, successBase: 0.61, maxLevel: 30, unlock: { cost: 0, minPlayerLevel: 1 } },
        { id: 'farmer', emoji: '🌾', name: 'Farmer', desc: 'Menanam, memanen, dan menjaga lahan.', tags: ['outdoor', 'nature'], difficulty: 2, baseReward: 36, energyCost: 16, durationMs: 21000, expReward: 14, successBase: 0.58, maxLevel: 30, unlock: { cost: 0, minPlayerLevel: 1 } },
        { id: 'fisher', emoji: '🎣', name: 'Fisher', desc: 'Mencari ikan dengan kesabaran ekstra.', tags: ['outdoor', 'nature'], difficulty: 2, baseReward: 35, energyCost: 15, durationMs: 22000, expReward: 14, successBase: 0.56, maxLevel: 30, unlock: { cost: 0, minPlayerLevel: 1 } },
        { id: 'mechanic', emoji: '🔧', name: 'Mechanic', desc: 'Membongkar, memperbaiki, merakit kembali.', tags: ['technical'], difficulty: 3, baseReward: 46, energyCost: 18, durationMs: 22000, expReward: 16, successBase: 0.54, maxLevel: 30, unlock: { cost: env('JOB_UNLOCK_MECHANIC', 200), minPlayerLevel: 1 } },
        { id: 'technician', emoji: '🖥️', name: 'Technician', desc: 'Memelihara jaringan dan mesin-mesin kritis.', tags: ['technical', 'office'], difficulty: 3, baseReward: 44, energyCost: 17, durationMs: 22000, expReward: 16, successBase: 0.55, maxLevel: 30, unlock: { cost: env('JOB_UNLOCK_TECHNICIAN', 200), minPlayerLevel: 1 } },
        { id: 'miner', emoji: '⛏️', name: 'Miner', desc: 'Menggali kedalaman bumi mencari bijih.', tags: ['outdoor', 'technical'], difficulty: 3, baseReward: 48, energyCost: 20, durationMs: 24000, expReward: 17, successBase: 0.52, maxLevel: 30, unlock: { cost: env('JOB_UNLOCK_MINER', 150), minPlayerLevel: 1 } },
        { id: 'chef', emoji: '👨‍🍳', name: 'Chef', desc: 'Memasak hidangan dengan presisi tinggi.', tags: ['food_service', 'craft'], difficulty: 3, baseReward: 45, energyCost: 18, durationMs: 23000, expReward: 16, successBase: 0.55, maxLevel: 30, unlock: { cost: env('JOB_UNLOCK_CHEF', 250), minPlayerLevel: 1 } },
        { id: 'photographer', emoji: '📸', name: 'Photographer', desc: 'Membeku momen menjadi karya visual.', tags: ['craft', 'outdoor'], difficulty: 3, baseReward: 42, energyCost: 16, durationMs: 21000, expReward: 15, successBase: 0.56, maxLevel: 30, unlock: { cost: env('JOB_UNLOCK_PHOTOGRAPHER', 300), minPlayerLevel: 2 } },
        { id: 'designer', emoji: '🎨', name: 'Designer', desc: 'Merancang visual yang menjual.', tags: ['craft', 'office'], difficulty: 4, baseReward: 58, energyCost: 18, durationMs: 24000, expReward: 18, successBase: 0.5, maxLevel: 30, unlock: { cost: env('JOB_UNLOCK_DESIGNER', 350), minPlayerLevel: 3 } },
        { id: 'programmer', emoji: '💻', name: 'Programmer', desc: 'Menaklukkan bug dan shipping fitur.', tags: ['technical', 'office'], difficulty: 4, baseReward: 60, energyCost: 18, durationMs: 24000, expReward: 18, successBase: 0.5, maxLevel: 30, unlock: { cost: env('JOB_UNLOCK_PROGRAMMER', 400), minPlayerLevel: 3 } },
]

export const economy = {
        worldBank: {
                initialBalance: env('WB_INITIAL_BALANCE', 5000),
                maxBalance: env('WB_MAX_BALANCE', 50000),
                regenAmount: env('WB_REGEN_AMOUNT', 50),
                regenInterval: env('WB_REGEN_INTERVAL', 60000),
        },

        energy: {
                max: env('ENERGY_MAX', 100),
                initial: env('ENERGY_INITIAL', 100),
                regenAmount: env('ENERGY_REGEN_AMOUNT', 10),
                regenInterval: env('ENERGY_REGEN_INTERVAL', 300000),
        },

        // ---- WORK (legacy fallback values — engine baru pakai workEngine) ----
        work: {
                minReward: env('WORK_MIN_REWARD', 20),
                maxReward: env('WORK_MAX_REWARD', 120),
                cooldown: env('WORK_COOLDOWN', 25000),
                energyCost: env('WORK_ENERGY_COST', 15),
                thresholds: [
                        { percentage: 75, multiplier: 1.0 },
                        { percentage: 50, multiplier: 0.8 },
                        { percentage: 25, multiplier: 0.6 },
                        { percentage: 10, multiplier: 0.3 },
                        { percentage: 1,  multiplier: 0.1 },
                        { percentage: 0,  multiplier: 0.05 },
                ],
        },

        // ---- JOB SYSTEM ----
        job: {
                /** Kurva EXP job — terpisah dari player leveling (config/activity.js). */
                expBase: env('JOB_EXP_BASE', 40),
                expExponent: env('JOB_EXP_EXPONENT', 1.3),

                /** Biaya ganti job (dibayar tiap pindah, job pertama gratis) → World Bank. */
                changeFee: env('JOB_CHANGE_FEE', 50),

                /** Cooldown ganti job (ms) — job pertama bebas. */
                changeCooldown: env('JOB_CHANGE_COOLDOWN', 600000),

                /**
                 * EXP job per-job TIDAK pernah direset saat pindah — player bisa
                 * punya "Barista Lv. 8" + "Courier Lv. 4" sekaligus (rekomendasi spec).
                 */
                keepExp: env('JOB_KEEP_EXP', 1) === 1,

                catalog: jobCatalog,
        },

        // ---- WORK ENGINE ----
        workEngine: {
                /** Batas reward per sesi (safety clamp atas). */
                rewardCap: env('WORK_REWARD_CAP', 5000),

                /** Reward minimal saat sukses (sebelum multiplier World Bank). */
                rewardFloor: env('WORK_REWARD_FLOOR', 5),

                /** Variasi reward dasar ± (fraksi). */
                rewardVariance: env('WORK_REWARD_VARIANCE', 0.25),

                /** Bonus success rate per job level (0.01 = +1%/level). */
                successPerLevel: env('WORK_SUCCESS_PER_LEVEL', 0.01),
                successMin: env('WORK_SUCCESS_MIN', 0.15),
                successMax: env('WORK_SUCCESS_MAX', 0.97),

                /** Peluang PERFECT & GREAT saat roll sukses (naik dgn job level). */
                perfectChanceBase: env('WORK_PERFECT_BASE', 0.05),
                perfectChancePerLevel: env('WORK_PERFECT_PER_LEVEL', 0.004),
                perfectChanceMax: env('WORK_PERFECT_MAX', 0.25),
                greatChanceBase: env('WORK_GREAT_BASE', 0.18),
                greatChancePerLevel: env('WORK_GREAT_PER_LEVEL', 0.006),
                greatChanceMax: env('WORK_GREAT_MAX', 0.4),

                /** Dari seluruh kegagalan, porsi yang jadi CRITICAL FAILURE. */
                critFailShare: env('WORK_CRITFAIL_SHARE', 0.3),

                /** Multiplier reward & EXP per grade. */
                grades: {
                        perfect:      { mult: env('WORK_GRADE_PERFECT_MULT', 1.5),  expMult: env('WORK_GRADE_PERFECT_EXP', 1.5) },
                        great:        { mult: env('WORK_GRADE_GREAT_MULT', 1.25),   expMult: env('WORK_GRADE_GREAT_EXP', 1.25) },
                        success:      { mult: env('WORK_GRADE_SUCCESS_MULT', 1.0),  expMult: env('WORK_GRADE_SUCCESS_EXP', 1.0) },
                        failed:       { mult: env('WORK_FAIL_REWARD_PCT', 0),       expMult: env('WORK_FAIL_EXP_PCT', 0.25) },
                        crit_failed:  { mult: env('WORK_CRITFAIL_REWARD_PCT', 0),   expMult: env('WORK_CRITFAIL_EXP_PCT', 0.1) },
                },

                /** Tabel scaling reward per job level (threshold terbesar ≤ level yang dipakai). */
                rewardScaling: [
                        { level: 1, pct: 0 },
                        { level: 5, pct: 10 },
                        { level: 10, pct: 25 },
                        { level: 20, pct: 50 },
                        { level: 30, pct: 80 },
                ],

                /** Progress dinamis: jumlah step & jeda antar-update (ms) — random per sesi.
                 * Task 27: jeda 1-5 dtk per update (lebih cepat). */
                progress: {
                        minSteps: env('WORK_PROGRESS_MIN_STEPS', 5),
                        maxSteps: env('WORK_PROGRESS_MAX_STEPS', 8),
                        minDelayMs: env('WORK_PROGRESS_MIN_DELAY', 1000),
                        maxDelayMs: env('WORK_PROGRESS_MAX_DELAY', 5000),
                        /** Durasi sesi maksimum sebelum jeda diskalakan (kecuali lembur).
                         *  8 step × 5 dtk = 40 dtk — cap ini tidak memangkas jeda 1-5 dtk. */
                        maxSessionMs: env('WORK_MAX_SESSION_MS', 40000),
                },

                /** Momen menyelesaikan pekerjaan (step 99%):
                 *  kadang SIAL → lembur (progress mundur + durasi nambah) lalu selesai.
                 *  eventId menunjuk event di workEvents (chainOnly) sbg sumber efek. */
                finish: {
                        unluckyChance: env('WORK_FINISH_UNLUCKY', 0.18),
                        maxUnlucky: env('WORK_FINISH_UNLUCKY_MAX', 1),
                        eventId: 'finish_unlucky',
                },

                /** Peluang event muncul di tiap step + batas event per sesi. */
                eventChance: env('WORK_EVENT_CHANCE', 0.55),
                maxEventsPerSession: env('WORK_MAX_EVENTS', 4),

                /** Rare event hanya terbuka sejak job level ini. */
                rareMinLevel: env('WORK_RARE_MIN_LEVEL', 3),

                /** Peluang chain default bila event tidak mendefinisikan sendiri. */
                chainChance: env('WORK_CHAIN_CHANCE', 0.5),

                /** Event menggeser peluang sukses: rewardPct total × faktor ini (clamp ±0.05). */
                eventSuccessInfluence: env('WORK_EVENT_SUCCESS_INFLUENCE', 0.002),

                /** Perilaku World Bank kosong: 'block' (tolak) | 'partial' (bayar seadanya). */
                emptyBankBehavior: env('WORK_EMPTY_BANK', 'block'),
        },

        // ---- EVENT POOL (bertag — job memakai event sesuai tags-nya) ----
        // weight : bobot undian (makin besar makin sering). 0 + chainOnly = hanya via chain.
        // rare   : butuh job level ≥ workEngine.rareMinLevel
        // effect : reward (flat), rewardPct (% base+scaling), exp (flat), progress (%),
        //          durationMs (tambahan lembur di step berikutnya)
        // chain  : { id, chance } — peluang memicu event lanjutan setelah event ini
        workEvents: [
                // --- umum (semua job) ---
                { id: 'smooth', emoji: '✅', text: 'Semua berjalan lancar hari ini.', tags: ['*'], weight: 8, effect: { rewardPct: 5 } },
                // Sial di menit terakhir (.work Task 27) — TIDAK pernah keluar dari pool
                // (chainOnly), hanya diundi engine saat step "menyelesaikan pekerjaan":
                // kena lembur, progress mundur, durasi nambah, lalu menyelesaikan lagi.
                { id: 'finish_unlucky', emoji: '😵', text: 'Sial! Ada kendala di menit terakhir — kamu harus lembur.', tags: [], weight: 0, chainOnly: true, effect: { rewardPct: -10, progress: -15, durationMs: 5000 } },
                { id: 'rushed', emoji: '⏱️', text: 'Ada permintaan mendadak — kerja lebih cepat.', tags: ['*'], weight: 7, effect: { progress: 8 } },
                { id: 'overtime', emoji: '🌙', text: 'Permintaan tambahan datang — sedikit lembur.', tags: ['*'], weight: 6, effect: { durationMs: 4000, rewardPct: 12, progress: -5 } },
                { id: 'distraction', emoji: '😵‍💫', text: 'Fokus buyar sesaat, hasil sedikit tergerus.', tags: ['*'], weight: 6, effect: { rewardPct: -8, progress: -4 } },
                { id: 'major_fail', emoji: '💥', text: 'Kesalahan besar — sebagian hasil harus diulang.', tags: ['*'], weight: 2, rare: true, effect: { rewardPct: -25, progress: -14, durationMs: 5000 }, chain: { id: 'fix_mistake', chance: 0.5 } },
                { id: 'fix_mistake', emoji: '🧰', text: 'Kesalahan berhasil diperbaiki — bonus performance.', tags: [], weight: 0, chainOnly: true, effect: { rewardPct: 10, exp: 4 } },

                // --- customer service / food ---
                { id: 'busy_orders', emoji: '📣', text: 'Pesanan datang beruntun — ritme kerja meningkat.', tags: ['customer_service', 'food_service'], weight: 10, effect: { rewardPct: 8, exp: 2 } },
                { id: 'tip_small', emoji: '🪙', text: 'Pelanggan memberikan tip kecil.', tags: ['customer_service', 'food_service', 'delivery'], weight: 9, effect: { reward: 12 } },
                { id: 'spill', emoji: '💦', text: 'Kecelakaan kecil! Beberapa pesanan harus diulang.', tags: ['food_service', 'craft'], weight: 8, effect: { rewardPct: -10, progress: -6 } },
                { id: 'regular_customer', emoji: '🙂', text: 'Pelanggan langganan menyapa sambil senyum.', tags: ['customer_service', 'food_service'], weight: 7, effect: { exp: 3 } },
                { id: 'vip_customer', emoji: '🎩', text: 'Pelanggan VIP datang!', tags: ['customer_service', 'food_service'], weight: 2, rare: true, effect: { rewardPct: 25, exp: 5 }, chain: { id: 'vip_order', chance: 0.6 } },
                { id: 'vip_order', emoji: '📝', text: 'VIP memesan hidangan spesial.', tags: [], weight: 0, chainOnly: true, effect: { rewardPct: 15 }, chain: { id: 'vip_bonus', chance: 0.7 } },
                { id: 'vip_bonus', emoji: '💎', text: 'Pesanan VIP selesai sempurna — bonus besar!', tags: [], weight: 0, chainOnly: true, effect: { reward: 60, exp: 8 } },
                { id: 'big_tip', emoji: '💸', text: 'Tip besar dari pelanggan yang sangat puas.', tags: ['customer_service', 'food_service', 'delivery'], weight: 2, rare: true, effect: { reward: 45 } },

                // --- delivery / outdoor ---
                { id: 'wrong_address', emoji: '🗺️', text: 'Alamat sulit ditemukan, muter-muter dulu.', tags: ['delivery', 'outdoor'], weight: 8, effect: { rewardPct: -8, durationMs: 3000 } },
                { id: 'traffic', emoji: '🚦', text: 'Jalan macet total.', tags: ['delivery', 'outdoor'], weight: 7, effect: { progress: -6, durationMs: 3000 } },
                { id: 'extra_order', emoji: '📦', text: 'Order tambahan masuk di jalur yang sama.', tags: ['delivery'], weight: 7, effect: { rewardPct: 10 } },
                { id: 'lucky_shortcut', emoji: '🛣️', text: 'Nemu jalan tikus — nyampe duluan.', tags: ['delivery', 'outdoor'], weight: 6, effect: { progress: 7 } },

                // --- technical / office / craft ---
                { id: 'machine_issue', emoji: '🛠️', text: 'Peralatan bermasalah, perlu perbaikan cepat.', tags: ['technical', 'food_service', 'craft', 'office'], weight: 7, effect: { rewardPct: -8, durationMs: 3000 } },
                { id: 'build_fail', emoji: '🧨', text: 'Proses gagal di tengah jalan — harus ulang sebagian.', tags: ['technical', 'office', 'craft'], weight: 7, effect: { rewardPct: -12, progress: -8 } },
                { id: 'solved_bug', emoji: '🐞', text: 'Masalah tricky berhasil ditaklukkan.', tags: ['technical', 'office', 'craft'], weight: 8, effect: { rewardPct: 12, exp: 3 } },
                { id: 'fast_finish', emoji: '🚀', text: 'Selesai lebih cepat dari perkiraan.', tags: ['technical', 'office', 'craft'], weight: 7, effect: { progress: 10 } },
                { id: 'bonus_client', emoji: '🏆', text: 'Client memberi bonus atas kualitas kerja.', tags: ['technical', 'office', 'craft'], weight: 2, rare: true, effect: { reward: 50, exp: 6 } },

                // --- nature / outdoor ---
                { id: 'good_harvest', emoji: '🌻', text: 'Hasil panen/ikan hari ini melimpah.', tags: ['nature', 'outdoor'], weight: 8, effect: { rewardPct: 10 } },
                { id: 'bad_weather', emoji: '🌧️', text: 'Cuaca buruk mengganggu pekerjaan.', tags: ['nature', 'outdoor'], weight: 7, effect: { rewardPct: -10, durationMs: 3000 } },
                { id: 'rare_find', emoji: '🔮', text: 'Menemukan temuan langka di lokasi kerja!', tags: ['nature', 'outdoor'], weight: 2, rare: true, effect: { reward: 40, exp: 5 } },
        ],

        // ---- ROB ----
        rob: {
                cooldown: env('ROB_COOLDOWN', 300000),          // 5 menit (plugin cooldownMs)
                successChance: env('ROB_SUCCESS_CHANCE', 0.45),
                minTargetBalance: env('ROB_MIN_TARGET', 100),   // wallet target minimal
                maxStealPct: env('ROB_MAX_STEAL_PCT', 0.4),     // max 40% wallet target
                maxStealAmount: env('ROB_MAX_STEAL', 500),      // cap absolute
                failPenaltyPct: env('ROB_FAIL_PENALTY_PCT', 0.1),   // 10% wallet perampok
                failPenaltyMin: env('ROB_FAIL_PENALTY_MIN', 25),    // denda minimal
                penaltyToBank: true,                            // denda → World Bank (sink)
                /** Job dengan tag ini memberi bonus success per job level (pakai sistem job existing). */
                jobTagBonus: { tags: ['delivery', 'outdoor'], perLevel: env('ROB_JOB_BONUS_PER_LEVEL', 0.015), max: env('ROB_JOB_BONUS_MAX', 0.15) },
        },

        // ---- TRANSFER ----
        transfer: {
                feePct: env('TRANSFER_FEE_PCT', 2),
                feeMin: env('TRANSFER_FEE_MIN', 3),
                feeMax: env('TRANSFER_FEE_MAX', 500),
                feeTo: 'worldbank', // sink — tidak menciptakan uang
        },

        // ---- STORE statistik economy/job (debounced flush, pola activity) ----
        stats: {
                flushMs: env('ECONOMY_FLUSH_MS', 15000),
        },

        // ---- SELL ----
        sell: {
                /** Default jual; item individual bisa `sellable: false` di daftar shop. */
                defaultSellable: env('SELL_DEFAULT_SELLABLE', 1) === 1,
                /** Pembeli = World Bank (dana WB harus cukup — behavior existing). */
                buyer: 'worldbank',
        },

        shop: {
                items: [
                        {
                                id: 'bread',
                                name: '🍞 Bread',
                                price: env('SHOP_BREAD_PRICE', 15),
                                sellPrice: env('SHOP_BREAD_SELL', 6),
                                energyRestore: env('SHOP_BREAD_ENERGY', 15),
                                description: 'Roti sederhana, memulihkan energi sedikit.',
                        },
                        {
                                id: 'chicken',
                                name: '🍗 Chicken',
                                price: env('SHOP_CHICKEN_PRICE', 30),
                                sellPrice: env('SHOP_CHICKEN_SELL', 12),
                                energyRestore: env('SHOP_CHICKEN_ENERGY', 30),
                                description: 'Ayam goreng, memulihkan energi cukup.',
                        },
                        {
                                id: 'rice',
                                name: '🍛 Rice',
                                price: env('SHOP_RICE_PRICE', 45),
                                sellPrice: env('SHOP_RICE_SELL', 18),
                                energyRestore: env('SHOP_RICE_ENERGY', 50),
                                description: 'Nasi komplit, memulihkan energi banyak.',
                        },
                        {
                                id: 'steak',
                                name: '🥩 Steak',
                                price: env('SHOP_STEAK_PRICE', 75),
                                sellPrice: env('SHOP_STEAK_SELL', 30),
                                energyRestore: env('SHOP_STEAK_ENERGY', 80),
                                description: 'Steak premium, memulihkan energi besar.',
                        },

                        // ------------------------------------------------------------------
                        // Task 54 — GIFT ITEMS (untuk .gif <karakter> <item>):
                        // hadiah buat karakter AI (miku/rikka/dll) — menaikkan
                        // relationship. Item biasa TETAP TIDAK disentuh; gift
                        // tidak mengembalikan energi (bukan makanan user) dan
                        // tidak bisa dijual kembali (sellable: false) supaya
                        // fungsinya jelas: dibeli → dihadiahkan.
                        // giftValue = exp relationship yang didapat karakter.
                        // RPG shop TIDAK tersentuh (rpg/ punya toko sendiri).
                        // ------------------------------------------------------------------
                        {
                                id: 'boba',
                                name: '🧋 Boba',
                                price: env('SHOP_BOBA_PRICE', 30),
                                sellPrice: env('SHOP_BOBA_SELL', 12),
                                giftValue: env('SHOP_BOBA_GIFT', 15),
                                sellable: false,
                                description: 'Teh susu boba manis — gift favorit anak zaman now.',
                        },
                        {
                                id: 'choco',
                                name: '🍫 Chocolate',
                                price: env('SHOP_CHOCO_PRICE', 25),
                                sellPrice: env('SHOP_CHOCO_SELL', 10),
                                giftValue: env('SHOP_CHOCO_GIFT', 12),
                                sellable: false,
                                description: 'Coklat lembut — gift klasik yang jarang gagal.',
                        },
                        {
                                id: 'rose',
                                name: '🌹 Rose',
                                price: env('SHOP_ROSE_PRICE', 20),
                                sellPrice: env('SHOP_ROSE_SELL', 8),
                                giftValue: env('SHOP_ROSE_GIFT', 10),
                                sellable: false,
                                description: 'Setangkai mawar merah — romantis tapi tidak lebay.',
                        },
                        {
                                id: 'cake',
                                name: '🍰 Cake',
                                price: env('SHOP_CAKE_PRICE', 40),
                                sellPrice: env('SHOP_CAKE_SELL', 16),
                                giftValue: env('SHOP_CAKE_GIFT', 20),
                                sellable: false,
                                description: 'Kue stroberi manis — cocok buat karakter penyuka manis.',
                        },
                        {
                                id: 'novel',
                                name: '📖 Novel',
                                price: env('SHOP_NOVEL_PRICE', 55),
                                sellPrice: env('SHOP_NOVEL_SELL', 22),
                                giftValue: env('SHOP_NOVEL_GIFT', 28),
                                sellable: false,
                                description: 'Novel ringan edisi spesial — buat si kutu buku.',
                        },
                        {
                                id: 'teddy',
                                name: '🧸 Teddy Bear',
                                price: env('SHOP_TEDDY_PRICE', 80),
                                sellPrice: env('SHOP_TEDDY_SELL', 32),
                                giftValue: env('SHOP_TEDDY_GIFT', 40),
                                sellable: false,
                                description: 'Boneka beruang super lembut — pelukan dijamin.',
                        },
                        {
                                id: 'headset',
                                name: '🎧 Headset',
                                price: env('SHOP_HEADSET_PRICE', 110),
                                sellPrice: env('SHOP_HEADSET_SELL', 44),
                                giftValue: env('SHOP_HEADSET_GIFT', 55),
                                sellable: false,
                                description: 'Headset musik berkualitas — buat si pencinta lagu.',
                        },
                        {
                                id: 'ring',
                                name: '💍 Ring',
                                price: env('SHOP_RING_PRICE', 250),
                                sellPrice: env('SHOP_RING_SELL', 100),
                                giftValue: env('SHOP_RING_GIFT', 130),
                                sellable: false,
                                description: 'Cincin perak berukir halus — gift paling istimewa.',
                        },
                ],
        },
}

export default economy
