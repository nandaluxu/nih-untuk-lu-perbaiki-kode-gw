/**
 * Konfigurasi sistem Leveling & Activity Statistics.
 * Semua bisa dioverride via env tanpa edit kode.
 */

/** Env int dengan fallback. */
function envInt(name, def, { min = 1, max = Number.MAX_SAFE_INTEGER } = {}) {
    const n = parseInt(process.env[name], 10)
    if (!Number.isFinite(n)) return def
    return Math.min(max, Math.max(min, n))
}

/** Env float dengan fallback. */
function envFloat(name, def, { min, max } = {}) {
    const n = parseFloat(process.env[name])
    if (!Number.isFinite(n)) return def
    if (min != null && n < min) return min
    if (max != null && n > max) return max
    return n
}

export const activity = {
    /** EXP dasar untuk naik dari level 1 → 2. */
    expBase: envInt('LEVELING_EXP_BASE', 100, { min: 10, max: 1_000_000 }),

    /**
     * Skala kurva EXP — makin besar makin curam di level tinggi.
     * 1.0 = linear (level n butuh base×n EXP), 1.5 = polinomial lembut,
     * 2.0 = kuadratik. Bisa dinaikkan tanpa reset data (kebutuhan EXP lama
     * otomatis dipakai ulang sebagai progress level berikutnya).
     */
    expExponent: envFloat('LEVELING_EXP_EXPONENT', 1.5, { min: 1, max: 3 }),

    /** Berapa hari bucket daily disimpan (untuk leaderboard mingguan/bulanan). */
    keepDays: envInt('ACTIVITY_KEEP_DAYS', 45, { min: 7, max: 400 }),

    /** Jeda flush debounced activity store ke disk (ms). */
    flushMs: envInt('ACTIVITY_FLUSH_MS', 15000, { min: 2000, max: 300000 }),

    /** Notifikasi level-up aktif (true/false via env LEVELUP_NOTIFY). */
    levelUpNotify: process.env.LEVELUP_NOTIFY !== 'off',

    /** Timezone untuk hari/streak (default WIB — server user). */
    tz: process.env.ACTIVITY_TZ || 'Asia/Jakarta',

    /** Jumlah baris per halaman leaderboard. */
    lbPageSize: envInt('ACTIVITY_LB_PAGE', 10, { min: 3, max: 25 }),
}
