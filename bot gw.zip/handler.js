import { getAllCommandNames } from './lib/command/command-parser.js'
import { findBestMatch } from './lib/command/fuzzy.js'
import { checkAdmin, checkBotAdmin } from './lib/protection/permissions.js'
import { RoleRepository, ROLE_CONFIG, ROLE_HIERARCHY } from './database/role-repository.js'
import { CooldownManager } from './lib/core/cooldown.js'
import logger from './lib/core/logger.js'
import { getLimitService, limitUserKeyOf } from './lib/command/limit-service.js'
import { formatUserError } from './lib/core/error-reply.js'
import { getCommandStats } from './lib/command/cmd-stats.js'
import { withWatchdog, withTimeout, createExecToken } from './lib/core/async-utils.js'
import { isSendUncertain } from './lib/messaging/send-fence.js'
import { setExecCommand } from './lib/messaging/send-ledger.js'
import { rpgGate, RPG_GATE_EXEMPT } from './rpg/index.js'
import { logDispatchTrace } from './lib/messaging/message-dedup.js'

const cooldowns = new CooldownManager()

const EXEC_GUARD_TTL_MS = 10 * 60_000
const EXEC_GUARD_CAP = 10_000
const _execGuard = new Map()

function _execGuardSweep() {
        if (_execGuard.size < EXEC_GUARD_CAP) return
        const now = Date.now()
        for (const [k, t] of _execGuard) {
                if (now - t > EXEC_GUARD_TTL_MS) _execGuard.delete(k)
        }
        while (_execGuard.size > EXEC_GUARD_CAP) {
                _execGuard.delete(_execGuard.keys().next().value)
        }
}

function claimExecution(execId, ctx) {
        if (!execId) return true
        if (_execGuard.has(execId)) {
                logger.warn(
                        '[exec-guard] DISPATCH GANDA DITOLAK (exec=%s cmd=%s id=%s) — pesan yang sama sudah didispatch %dms lalu; eksekusi kedua DIBATALKAN',
                        execId, ctx?.command || '-', ctx?.message?.key?.id || '-',
                        Date.now() - _execGuard.get(execId),
                )
                return false
        }
        _execGuard.set(execId, Date.now())
        _execGuardSweep()
        return true
}

export function _resetExecGuardForTest() {
        _execGuard.clear()
}

const EXEC_TIMEOUT_DEFAULT_MS = Math.max(30_000, Number(process.env.EXEC_TIMEOUT_DEFAULT_MS) || 180_000)
const EXEC_TIMEOUT_CATEGORY_MS = {
        nsfw: 50 * 60_000,
        downloader: 30 * 60_000,
        ai: 15 * 60_000,
        imagefilter: 15 * 60_000,
        creator: 10 * 60_000,
        jjcapcut: 10 * 60_000,
        search: 5 * 60_000,
        economy: 5 * 60_000,
        games: 10 * 60_000,
        rpg: 10 * 60_000,
        image: 5 * 60_000,
}

function execTimeoutMs(plugin) {
        const cat = String(plugin?.category || '').toLowerCase()
        return EXEC_TIMEOUT_CATEGORY_MS[cat] || EXEC_TIMEOUT_DEFAULT_MS
}

export async function dispatchCommand(ctx, deps) {
        const { pluginLoader, prefixManager, roleRepo, protection } = deps

        try { logDispatchTrace({ m: ctx.message, command: ctx.command, execId: ctx.message?.__execId }) } catch {}

        if (!claimExecution(ctx.message?.__execId, ctx)) return

        const plugin = pluginLoader.registry.get(ctx.command)

        try { setExecCommand(ctx.command) } catch {}

        const userKey = ctx.user?.user_id || ctx.sender || ctx.senderLid || ctx.chat || 'unknown'

        let userRole = 'free'
        if (ctx.isOwner) {
                userRole = 'owner'
        } else if (roleRepo) {
                let roleData = ctx.sender ? roleRepo.getRole(ctx.sender) : null
                if (!roleData?.found && ctx.senderLid) {
                        roleData = roleRepo.getRole(ctx.senderLid)
                }
                if (!roleData?.found && ctx.user?.role?.name && ROLE_HIERARCHY.includes(ctx.user.role.name)) {
                        const entry = ctx.user.role
                        const expired = entry.expires_at && new Date(entry.expires_at) < new Date()
                        if (!expired) roleData = { role: entry.name, found: true }
                }
                userRole = roleData?.role || 'free'
        }

        ctx.userRole = userRole

        if (protection) {
                const chatProtectionCfg = ctx.db?.data?.settings?.[ctx.chat]?.protection || null
                const verdict = protection.gate({
                        userKey,
                        command: ctx.command,
                        isOwner: ctx.isOwner,
                        userRole,
                        plugin,
                        chatConfig: chatProtectionCfg,
                })
                if (!verdict.ok) {
                        getCommandStats().record(ctx.command, { ok: false, ms: 0, reason: 'rejected' })
                        if (verdict.reply) await ctx.reply(verdict.reply).catch(() => {})
                        return
                }
        }

        if (!plugin) {
                await handleNotFound(ctx, deps)
                return
        }

        const rpgCat = String(plugin.category || '').toLowerCase()
        if (rpgCat === 'rpg' && !RPG_GATE_EXEMPT.has(plugin.name)) {
                const gate = await rpgGate(ctx)
                if (!gate.ok) {
                        getCommandStats().record(ctx.command, { ok: false, ms: 0, reason: 'rpg-gate' })
                        await ctx.message?.react?.('❌').catch(() => {})
                        if (gate.reason === 'unregistered') {
                                await ctx.reply(`Belum punya karakter RPG — daftar dulu: ${ctx.cmdRef('rpgdaftar')} <nama>`).catch(() => {})
                        } else if (gate.reason === 'disabled') {
                                await ctx.reply(`RPG kamu sedang mati — nyalakan lagi: ${ctx.cmdRef('rpg')} on`).catch(() => {})
                        }
                        return
                }
                ctx.rpgPlayer = gate.player
        }

        if (plugin.owner && !ctx.isOwner) {
                return ctx.reply('Command ini khusus owner.')
        }

        if (userRole === 'banned' && !ctx.isOwner) {
                return ctx.reply('Kamu dibanned dari bot.')
        }

        const ADMIN_ONLY_BYPASS_ROLE = 'co-owner'
        if (ctx.isGroup && ctx.db?.data?.settings?.[ctx.chat]?.adminOnly === true) {
                const canBypass =
                        ctx.isOwner ||
                        RoleRepository.hasPermission(userRole, ADMIN_ONLY_BYPASS_ROLE)

                if (!canBypass) {
                        const isAdmin = await checkAdmin(deps.sock, ctx.chat, ctx.sender).catch(() => false)
                        if (!isAdmin) {
                                return await ctx.message?.react?.('❌').catch(() => {})
                        }
                }
        }

        if (plugin.group && !ctx.isGroup) {
                return ctx.reply('Command ini hanya untuk grup.')
        }
        if (plugin.private && ctx.isGroup) {
                return ctx.reply('Command ini hanya untuk private chat.')
        }

        if (plugin.admin && !ctx.isOwner) {
                if (!ctx.isGroup && plugin.adminPm !== true) {
                        return ctx.reply('Command ini khusus admin grup (gunakan di dalam grup).')
                }
                if (ctx.isGroup) {
                        const isAdmin = await checkAdmin(deps.sock, ctx.chat, ctx.sender).catch(() => false)
                        if (!isAdmin) {
                                return ctx.reply('Kamu harus admin grup.')
                        }
                }
        }

        const pluginCat = (plugin.category || '').toLowerCase()
        if ((pluginCat === 'nsfw' || plugin.nsfw === true) && ctx.isGroup) {
                const nsfwEnabled = ctx.db?.data?.settings?.[ctx.chat]?.nsfw === true
                if (!nsfwEnabled) {
                        const hintPfx = ctx.prefix ?? ''
                        return ctx.reply(`NSFW dimatikan di grup ini. Minta admin untuk mengaktifkannya dengan ${hintPfx}gcnsfw on`)
                }
        }

        if (plugin.register !== false && !ctx.user && !ctx.isOwner) {
                const prefix = ctx.prefix ?? ''
                return ctx.reply(`Daftar dulu: ${prefix}daftar nama.umur`)
        }

        if (plugin.botAdmin && !ctx.isOwner) {
                if (!ctx.isGroup) {
                        return ctx.reply('Command ini khusus grup (bot harus admin grup).')
                }
                const botJid = deps.sock.user?.id
                const isBotAdmin = await checkBotAdmin(deps.sock, ctx.chat, botJid).catch(() => false)
                if (!isBotAdmin) {
                        return ctx.reply('Bot harus admin grup.')
                }
        }

        const effectiveMinRole = RoleRepository.normalizeMinRole(plugin.minRole, plugin.name)

        if (!RoleRepository.hasPermission(userRole, effectiveMinRole) && !ctx.isOwner) {
                return ctx.reply(`Command ini membutuhkan role *${effectiveMinRole}* atau lebih tinggi.\nRole kamu: *${userRole}*`)
        }

        if (plugin.cooldownMs && !ROLE_CONFIG[userRole]?.bypassCooldown) {
                const multiplier = ROLE_CONFIG[userRole]?.cooldownMultiplier ?? 1
                const effectiveCooldown = Math.floor(plugin.cooldownMs * multiplier)
                const remaining = cooldowns.check(userKey, plugin.name, effectiveCooldown)
                if (remaining > 0) {
                        const text = `\u23F3 Tunggu *${CooldownManager.format(remaining)}* lagi.`
                        const once = protection ? protection.feedbackOnce(userKey, 'limit', text) : text
                        if (once) await ctx.reply(once).catch(() => {})
                        return
                }
                cooldowns.set(userKey, plugin.name, effectiveCooldown)
        }

        let limitRes = null
        let limitService = null
        if (plugin.limit === true) {
                limitService = getLimitService(ctx.db)
                const limitUserKey = limitUserKeyOf(ctx)
                if (limitUserKey) {
                        limitRes = limitService.reserve({ userKey: limitUserKey, role: userRole, plugin })
                        if (!limitRes.ok) {
                                await ctx.reply(limitRes.replyText).catch(() => {})
                                return
                        }
                }
        }

        let releaseSlot = null
        if (protection) {
                const acq = await protection.acquire({
                        userKey,
                        command: ctx.command,
                        isOwner: ctx.isOwner,
                        plugin,
                })
                if (!acq.ok) {
                        if (acq.reply) await ctx.reply(acq.reply).catch(() => {})
                        return
                }
                releaseSlot = acq.release
        }

        let slotReleased = false
        const releaseOnce = () => {
                if (slotReleased) return
                slotReleased = true
                if (releaseSlot) releaseSlot()
        }
        const execToken = createExecToken(`plugin:${plugin.name}`)
        const timeoutMs = execTimeoutMs(plugin)
        ctx.execToken = execToken
        ctx.execDeadlineAt = Date.now() + timeoutMs

        try {
                const roleConf = ROLE_CONFIG[userRole]
                if (process.env.ROLE_DEBUG) {
                        logger.info(
                                '[ROLE-DEBUG] cmd=%s sender=%s senderLid=%s isOwner=%s resolvedRole=%s typingDelay=%s bypassDelay=%s profile=%s',
                                ctx.command, ctx.sender || '-', ctx.senderLid || '-', ctx.isOwner, userRole,
                                roleConf?.typingDelay ?? '-', roleConf?.bypassDelay ?? '-', ctx.user?.user_id || '-',
                        )
                }
                if (roleConf?.typingDelay && roleConf.typingDelay > 0 && !roleConf.bypassDelay) {
                        try {
                                await withTimeout((async () => {
                                        await deps.sock.sendPresenceUpdate('composing', ctx.chat)
                                        await new Promise(r => setTimeout(r, roleConf.typingDelay))
                                        await deps.sock.sendPresenceUpdate('paused', ctx.chat)
                                })(), roleConf.typingDelay + 5_000, 'typing-delay')
                        } catch {
                        }
                }

                if (deps.activity && ctx.sender) {
                        try {
                                deps.activity.recordCommand({
                                        userJid: ctx.sender,
                                        groupJid: ctx.isGroup ? ctx.chat : null,
                                        command: plugin.name,
                                })
                        } catch (e) {
                                logger.warn('Activity recordCommand gagal: %s', e.message)
                        }
                }

                const execStart = Date.now()
                const execId = ctx.message?.__execId || '-'
                logger.info(
                        '[exec] START cmd=%s exec=%s id=%s chat=%s timeout=%dms',
                        plugin.name, execId, ctx.message?.key?.id || '-', ctx.chat, timeoutMs,
                )
                try {
                        const result = await withWatchdog(
                                plugin.execute(ctx),
                                timeoutMs,
                                `plugin:${plugin.name}`,
                                () => releaseOnce(),
                                execToken,
                        )
                        if (limitRes) {
                                if (result === false) limitService.release(limitRes)
                                else limitService.commit(limitRes)
                        }
                        getCommandStats().record(plugin.name, { ok: result !== false, ms: Date.now() - execStart })
                        logger.info('[exec] FINISH cmd=%s exec=%s ms=%d', plugin.name, execId, Date.now() - execStart)
                } catch (error) {
                        if (limitRes) limitService.release(limitRes)
                        logger.info(
                                '[exec] FINISH(cmd gagal) cmd=%s exec=%s ms=%d err=%s',
                                plugin.name, execId, Date.now() - execStart,
                                String(error?.message || error).slice(0, 100),
                        )
                        const timedOut = error?.watchdog === true
                        getCommandStats().record(plugin.name, { ok: false, ms: Date.now() - execStart, reason: timedOut ? 'timeout' : 'error' })
                        if (timedOut) {
                                logger.error('Watchdog: %s melebihi %dms — slot dilepaksa lepas (execute jadi orphan, execToken di-set)', plugin.name, timeoutMs)
                                await ctx.reply(`\u23F1\uFE0F Command *${plugin.name}* kehabisan waktu (*${Math.round(timeoutMs / 60_000)} menit*) — slotnya sudah dilepas (watchdog). Kalau hasilnya belum sampai, coba lagi ya.`).catch(() => {})
                        } else if (error?.fence) {
                                logger.warn('Fence di %s: %s', plugin.name, error.message)
                                await ctx.reply(`\u26A0\uFE0F Koneksi WhatsApp bermasalah saat *${plugin.name}* (${error.fenceMethod || 'send'}). Coba lagi sebentar lagi ya.`).catch(() => {})
                        } else {
                                const safe = formatUserError(error, { context: `plugin:${plugin.name}`, log: logger })
                                await ctx.reply(`Error: ${safe}`).catch(() => {})
                        }
                }
        } finally {
                releaseOnce()
        }
}

async function handleNotFound(ctx, deps) {
        const correctionConfig = deps.prefixManager.getCorrection()
        if (!correctionConfig.enabled) return

        const prefixConfig = deps.prefixManager.get()
        if (!prefixConfig.enabled) return

        if (!ctx.command || ctx.command.length < 2) return

        const allNames = getAllCommandNames(deps.pluginLoader.registry)
        const best = findBestMatch(ctx.command, allNames)

        if (!best || !(best.similarity >= 40)) return

        const pfx = ctx.prefix ?? ''
        const fullCmd = `${pfx}${best.match}`

        const contentText =
                `\u2B50 Command yang kamu ketik tidak tersedia, mungkin yang kamu maksud:\n\n` +
                `\u250F\u2501\u2501 \u2291 *MUNGKIN INI* \u2292\n` +
                `\u2502 \u2937 Command : ${fullCmd}\n` +
                `\u2502 \u2937 Kemiripan : ${best.similarity}%\n` +
                `\u2570\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500\u2500`

        if (correctionConfig.mode === 'button') {
                try {
                        await deps.sock.sendInteractive(ctx.chat, [
                                { text: `\u27A4 ${best.match}`, id: fullCmd }
                        ], ctx.message, {
                                caption: contentText,
                                footer: 'Klik tombol untuk menjalankan command'
                        })
                } catch (err) {
                        if (isSendUncertain(err)) {
                                logger.warn('handleNotFound: kirim tombol koreksi tidak pasti (uncertain) — skip fallback teks (anti duplikat, cmd=%s)', ctx.command)
                                return
                        }
                        logger.debug('sendInteractive gagal, fallback ke text: %s', err.message)
                        await ctx.reply(contentText)
                }
        } else {
                await ctx.reply(contentText)
        }
}