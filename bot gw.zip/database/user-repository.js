import { resolveProfileByIdentifier } from '../lib/identity/index.js'

export class UserRepository {
        /**
         * @param {object} ufs - UserFileStore (index profil user)
         * @param {object} [opts]
         * @param {object} [opts.idRepo] - IdentifierRepository (mapping PN↔LID).
         *     Dipakai rantai kanonik identity utk menerjemahkan LID→PN bila
         *     profil lama belum menyimpan field lid (Task 58 fix F-2 —
         *     behavior kini dimiliki lib/identity, repo ini hanya delegasi).
         */
        constructor(ufs, { idRepo = null } = {}) {
                this.ufs = ufs
                this.idRepo = idRepo
        }

        /** Insert user baru. Return row yang di-insert. */
        create(data) {
                return this.ufs.create(data.player_id, data)
        }

        findByUserId(userId) { return this.ufs.findByUserId(userId) }
        findByPlayerId(playerId) { return this.ufs.findByPlayerId(playerId) }
        findByPN(pn) { return this.ufs.findByPN(pn) }
        findByJID(jid) { return this.ufs.findByJID(jid) }
        findByLID(lid) { return this.ufs.findByLID(lid) }

        /** Cek apakah player_id sudah dipakai. */
        playerIdExists(playerId) { return this.ufs.playerIdExists(playerId) }

        /**
         * Cari user berdasarkan identifier apapun (pn, jid, lid, player_id,
         * user_id). RANTAI KANONIK — implementasi dimiliki
         * lib/identity (resolveProfileByIdentifier, paritas persis rantai
         * lama + viaLidMapping Task 58: LID tak dikenal index profil →
         * terjemahkan lewat mapping identifiers → back-fill field lid
         * sekali supaya lookup berikutnya kena index _byLID).
         */
        findByIdentifier(identifier) {
                return resolveProfileByIdentifier(this.ufs, this.idRepo, identifier)
        }

        /** Update profil user. */
        updateByUserId(userId, data) {
                return this.ufs.updateByUserId(userId, data)
        }

        /**
         * Rename player_id user (pindah file + reindex). Return data baru atau null.
         * Delegasi ke UserFileStore.renamePlayerId.
         */
        renamePlayerId(oldPlayerId, newPlayerId) {
                return this.ufs.renamePlayerId(oldPlayerId, newPlayerId)
        }

        /** Update economy fields + optional inventory. Return updated row. */
        updateEconomy(userId, { wallet, bank, energy, lastEnergyRegen, inventory }) {
                const existing = this.findByUserId(userId)
                if (!existing) return null
                const patch = {
                        wallet: wallet ?? existing.wallet,
                        bank: bank ?? existing.bank,
                        energy: energy ?? existing.energy,
                        last_energy_regen: lastEnergyRegen || existing.last_energy_regen,
                }
                if (inventory !== undefined) patch.inventory = inventory
                return this.ufs.updateByUserId(userId, patch)
        }

        /** Cari username dengan LIKE untuk fuzzy search kandidat awal. */
        searchUsername(query, limit = 20) { return this.ufs.searchUsername(query, limit) }

        /**
         * Ambil semua profil user (read-only) — dipakai leaderboard
         * relationship (progress tersimpan di profil masing-masing user).
         * Delegasi polos ke UserFileStore (cache in-memory, tanpa I/O).
         */
        listAll() { return this.ufs.listAll() }

        /** Ambil player_id dari user_id. */
        getPlayerIdByUserId(userId) { return this.ufs.getPlayerIdByUserId(userId) }
}