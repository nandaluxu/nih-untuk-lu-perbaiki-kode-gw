export class InventoryRepository {
	constructor(ufs) {
		this.ufs = ufs
	}

	get(userId, itemId) {
		const user = this.ufs.findByUserId(userId)
		if (!user) return null
		const inv = user.inventory || {}
		const qty = inv[itemId]
		if (!qty || qty <= 0) return null
		return { user_id: userId, item_id: itemId, quantity: qty }
	}

	getAll(userId) {
		const user = this.ufs.findByUserId(userId)
		if (!user) return []
		const inv = user.inventory || {}
		return Object.entries(inv)
			.filter(([, qty]) => qty > 0)
			.map(([item_id, quantity]) => ({ user_id: userId, item_id, quantity }))
	}

	/** Tambah quantity. */
	add(userId, itemId, qty) {
		if (qty <= 0) return
		const user = this.ufs.findByUserId(userId)
		if (!user) return
		const inv = user.inventory || {}
		inv[itemId] = (inv[itemId] || 0) + qty
		this.ufs.updateByUserId(userId, { inventory: inv })
	}

	/** Kurangi quantity. Return true jika berhasil (cukup stok). */
	deduct(userId, itemId, qty) {
		if (qty <= 0) return false
		const user = this.ufs.findByUserId(userId)
		if (!user) return false
		const inv = user.inventory || {}
		const current = inv[itemId] || 0
		if (current < qty) return false
		inv[itemId] = current - qty
		this.ufs.updateByUserId(userId, { inventory: inv })
		return true
	}
}