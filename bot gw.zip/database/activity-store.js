import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import logger from '../lib/core/logger.js'
import { dayKey, weekDayKeys, monthDayKeys, sumWindows } from '../lib/economy/leveling.js'
import { activity as activityCfg } from '../config/activity.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const DEFAULT_DATA_DIR = path.join(__dirname, '..', 'activity')

// ============================================================================
// TASK 22 — PEMISAHAN STORAGE ACTIVITY (schema activity/v2)
//
// File legacy `activity/activity.json` DINYATAKAN TIDAK VALID:
//   - TIDAK PERNAH dibaca runtime (tidak ada migrasi / fallback / import /
//     auto-move apa pun — file dibiarkan apa adanya, hanya di-log bahwa
//     diabaikan).
//   - Semua data statistik kini DIBECAH per domain di folder activity/:
//
//     activity/
//     ├── root.json         → version/meta activity (schema, updatedAt, counts)
//     ├── user.json         → statistik user (level/EXP/chat/cmdTotal/streak)
//     ├── group.json        → statistik grup saja (chat + users {chat,cmdTotal})
//     ├── daily.json        → statistik harian global (chat/cmd total)
//     ├── dailyUser.json    → statistik harian user
//     ├── dailyGroup.json   → statistik harian grup
//     └── commandNames.json → statistik pemakaian command (total/user/grup)
//
// ROOT CAUSE yang ditutup patch ini: store lama schema-blind — loader menerima
// objek JSON APA PUN, _ensureShape memPERTAHANKAN key asing (settings grup,
// gcnsfw, nsfw, protection, prefix, dsb.), dan penulis mem ROUND-TRIP seluruh
// payload tiap flush 15 dtk → payload config grup yang pernah masuk ke file
// lama ditulis ulang selamanya dan MENUMPUK. Config group TIDAK punya jalur
// ke storage ini lagi: semua penulisan config group (gcnsfw/adminOnly/
// antilink/autodelete/protection/warn/mute/autodl/prefix) tetap di
// store/settings.json (JsonStore) + groups/<gid>.json (GroupFileStore).
//
// VALIDASI SCHEMA: setiap domain punya daftar key yang DIIZINKAN. Payload
// asing — terutama config grup (gcnsfw, nsfw, protection, prefix, settings,
// mutes, warns, antilink, autodelete, adminOnly, welcome, …) — DITOLAK saat
// load: dijatuhkan + WARN (bot tidak crash; statistik yang sah tetap hidup).
// Tulisan dari API internal HANYA pernah menyentuh key yang diizinkan.
//
// TASK 23 — PEMISAHAN OWNERSHIP PROGRESSION (schema activity/v3):
//   Level/EXP/totalExp/streak adalah PERSISTENT USER PROGRESSION — kini
//   MILIK USER DB (users/<player_id>.json — lihat database/user-progression.js).
//   ActivityStore = ACTIVITY/ANALYTICS SAJA (chat/cmd counters, bucket harian,
//   commandNames, firstDay/lastDay/lastActive). Field progression yang masih
//   tersisa di user.json v2 (sudah dipindahkan oleh transfer sekali-jalan saat
//   boot) di-DROP sebagai key asing + self-healing flush.
//   Leaderboard level/exp/streak tetap jalan lewat PROVIDER (pola yang sama
//   dengan money/userRepo, work-job/economy, afk/afkService):
//   activity.setProgressionProvider(jids => aggregateProgression(ufs, jids)).
//   grantExp DIHAPUS dari ActivityStore (pemilik tulis progression = user-
//   progression.js → USER DB) — satu source of truth, tanpa sinkronisasi
//   dua arah, tanpa nilai ganda.
//
// API PUBLIK: recordMessage/recordCommand/getUser/getGroup/getGroupUser/
// top/topCommands/rankOf/providers/flush/close — grantExp DIHAPUS (pemanggil
// game bermigrasi ke grantUserExp).
//
// PERFORMA (LAT-004 dipertahankan, kini per-domain): mutasi in-memory O(1);
// tulis disk debounced (activityCfg.flushMs) ASYNC single-flight + coalescing
// + generation guard (flush()/_write() sinkron membuang tulis async lama);
// atomic per file (tmp+rename). HANYA domain yang dirty yang ditulis.
// ============================================================================

/** Nama domain → file (semua di dalam activity/). */
const DOMAIN_FILES = {
    user: 'user.json',
    group: 'group.json',
    daily: 'daily.json',
    dailyUser: 'dailyUser.json',
    dailyGroup: 'dailyGroup.json',
    commandNames: 'commandNames.json',
    root: 'root.json',
}

const SCHEMA_ID = 'activity/v3'

/**
 * Field progression v2 yang kini MILIK USER DB — muncul di user.json lama
 * → di-drop dengan pesan khusus (bukan config grup, tapi kepemilikan pindah).
 */
const PROGRESSION_KEYS = new Set(['level', 'exp', 'totalExp', 'streak'])

/**
 * Key yang mengindikasikan PAYLOAD CONFIG GRUP — tidak pernah boleh ada di
 * storage activity. Dipakai untuk pesan penolakan yang eksplisit saat load.
 */
const GROUP_CONFIG_KEYS = new Set([
    'gcnsfw', 'nsfw', 'settings', 'protection', 'prefix', 'adminOnly',
    'adminonly', 'antilink', 'autodelete', 'autodl', 'mutes', 'warns',
    'welcome', 'goodbye', 'antispam', 'antisticker', 'antitoxic',
    'antimedia', 'antibot', 'config', 'members', 'participants', 'owner',
    'subject', 'desc', 'description', 'name', 'jid', 'isCommunity',
    'restrict', 'announce', 'ephemeral',
])

/** Key statistik yang diizinkan di record user (v3 — analytics SAJA). */
const USER_STAT_KEYS = ['chat', 'cmdTotal', 'firstDay', 'lastDay', 'lastActive']
/** Key yang diizinkan di record grup. */
const GROUP_STAT_KEYS = ['chat', 'users']
/** Key yang diizinkan di record user DALAM grup. */
const GROUP_USER_KEYS = ['chat', 'cmdTotal']
/** Key yang diizinkan di bucket harian (daily.json / dailyUser.json). */
const DAILY_BUCKET_KEYS = ['chat', 'cmd']
/** Key yang diizinkan di bucket harian grup. */
const DAILY_GROUP_KEYS = ['chat', 'users']
/** Key yang diizinkan di record commandNames. */
const CMD_STAT_KEYS = ['total', 'users', 'groups']
/** Key meta yang diizinkan di root.json. */
const ROOT_KEYS = ['schema', 'version', 'createdAt', 'updatedAt', 'counts']

const DAY_KEY_RE = /^\d{4}-\d{2}-\d{2}$/

/** Apakah value plain object (bukan array/null). */
function isPlainObject(v) {
    return v !== null && typeof v === 'object' && !Array.isArray(v)
}

export class ActivityStore {
    /** @param {object} [opts] @param {string} [opts.dataDir] override folder (test) */
    constructor({ dataDir = DEFAULT_DATA_DIR } = {}) {
        this.dataDir = dataDir
        // File legacy — HANYA untuk log "diabaikan". Tidak pernah dibaca/ditulis.
        this.legacyPath = path.join(dataDir, 'activity.json')
        // ---- Domain data (mirror disk) ----
        /** @type {Record<string, object>} jid → statistik user */
        this.users = {}
        /** @type {Record<string, object>} gjid → statistik grup */
        this.groups = {}
        /** @type {Record<string, {chat:number,cmd:number}>} hari → total global */
        this.daily = {}
        /** @type {Record<string, Record<string,{chat:number,cmd:number}>>} hari → jid → user */
        this.dailyUsers = {}
        /** @type {Record<string, Record<string,{chat:number,users:object}>>} hari → gjid → grup */
        this.dailyGroups = {}
        /** @type {Record<string,{total:number,users:object,groups:object}>} cmd → statistik */
        this.commandNames = {}
        /** @type {{schema:string,version:number,createdAt:string,updatedAt:string,counts:object}} */
        this.meta = { schema: SCHEMA_ID, version: 3, createdAt: new Date().toISOString(), updatedAt: null, counts: {} }
        // ---- Flush state (LAT-004 per-domain) ----
        /** @type {Set<string>} domain yang berubah sejak tulis terakhir */
        this._dirty = new Set()
        this._timer = null
        this._writing = false
        this._gen = 0 // naik saat tulis sinkron — tulis async yang lebih lama membuang tmp-nya
        this._mutSeq = 0 // naik di setiap mutasi — tulis async tahu state berubah setelah snapshot
        /** @type {null | ((jids: string[]) => Map<string, number>)} */
        this._moneyProvider = null
        /** @type {null | ((jids: string[], scope: object) => Map<string, object>)} */
        this._economyProvider = null
        /** @type {null | ((jids: string[]) => Map<string, object>)} */
        this._afkProvider = null
        /** @type {null | ((jids: string[]) => Map<string, {level:number,exp:number,streak:number}>)} */
        this._progressionProvider = null
        // TASK 26 (LB dobel nama): resolver identitas jid → jid kanonik (PN).
        // Pesan WA modern bisa beralamat LID (grup privacy) ATAU PN — orang
        // yang sama tercatat sebagai 2 user berbeda → .lb global menampilkan
        // nama yang sama DUA KALI. Resolver (disuntik bot.js dari profil user
        // + mapping lid-mapping.update) menyatukan identitas saat REKAM
        // (recordMessage/recordCommand) dan saat MEMBACA (_rankAll merge).
        /** @type {null | ((jid: string) => string|null)} */
        this._identityResolver = null
        /** @type {Map<string, string|null>} cache jid → kanonik (atau null) */
        this._identityCache = new Map()
    }

    // ------------------------------------------------------------------
    // Load / save
    // ------------------------------------------------------------------

    load() {
        fs.mkdirSync(this.dataDir, { recursive: true })

        // File legacy activity.json tidak valid — TIDAK dibaca. Kehadirannya
        // hanya di-log sekali supaya jelas bahwa pengabaian itu disengaja
        // (tidak ada migrasi, tidak ada fallback, tidak ada auto-import).
        try {
            if (fs.existsSync(this.legacyPath)) {
                logger.warn(
                    'Legacy activity/activity.json terdeteksi — TIDAK VALID & DIABAIKAN (tidak dibaca/dipindah). Statistik baru mulai bersih di activity/{user,group,daily,dailyUser,dailyGroup,commandNames,root}.json',
                )
            }
        } catch {}

        this._loadDomains()
        this._pruneDaily()
        this._startTimer()
        logger.info(
            'Activity store v3 (analytics-only) dimuat: %d user, %d grup, %d hari, %d command — progression user = USER DB',
            Object.keys(this.users).length, Object.keys(this.groups).length,
            Object.keys(this.dailyUsers).length, Object.keys(this.commandNames).length,
        )
        return this
    }

    /**
     * Muat + validasi setiap domain. File korup → backup .corrupt + domain
     * mulai kosong (domain lain tetap aman — isolasi per file).
     * Payload asing (config grup dsb.) DITOLAK: dijatuhkan + WARN.
     */
    _loadDomains() {
        const readSafe = (file) => {
            const full = path.join(this.dataDir, file)
            if (!fs.existsSync(full)) return null
            try {
                const parsed = JSON.parse(fs.readFileSync(full, 'utf8'))
                if (!isPlainObject(parsed)) throw new Error('bukan object')
                return parsed
            } catch (e) {
                try { fs.copyFileSync(full, `${full}.corrupt`) } catch {}
                logger.error('Activity domain %s korup — mulai kosong (backup .corrupt): %s', file, e.message)
                return {}
            }
        }

        this.users = this._sanitizeStats(readSafe(DOMAIN_FILES.user), USER_STAT_KEYS, 'user.json', {
            // key user harus JID — bukan nama config/setting
            keyFilter: (k) => typeof k === 'string' && k.includes('@'),
        })
        this.groups = this._sanitizeGroups(readSafe(DOMAIN_FILES.group, 'group'))
        this.daily = this._sanitizeDailyBuckets(readSafe(DOMAIN_FILES.daily, 'daily'), 'daily.json')
        this.dailyUsers = this._sanitizeDailyUsers(readSafe(DOMAIN_FILES.dailyUser, 'dailyUser'))
        this.dailyGroups = this._sanitizeDailyGroups(readSafe(DOMAIN_FILES.dailyGroup, 'dailyGroup'))
        this.commandNames = this._sanitizeCommands(readSafe(DOMAIN_FILES.commandNames))
        this._loadMeta(readSafe(DOMAIN_FILES.root))
    }

    /**
     * Meta root.json: validasi schema (activity/v3). Schema v2 lama → meta
     * direset ke v3 (data domain tetap dibaca + disanitasi; field progression
     * v2 di-drop — sudah dipindahkan ke USER DB oleh transfer sekali-jalan).
     */
    _loadMeta(raw) {
        if (isPlainObject(raw) && raw.schema === SCHEMA_ID) {
            this.meta = {
                schema: SCHEMA_ID,
                version: Number(raw.version) || 3,
                createdAt: String(raw.createdAt || new Date().toISOString()),
                updatedAt: raw.updatedAt ? String(raw.updatedAt) : null,
                counts: isPlainObject(raw.counts) ? { ...raw.counts } : {},
            }
            return
        }
        if (raw && Object.keys(raw).length > 0) {
            logger.info(
                'activity/root.json schema lama (%s) → meta direset ke %s v3 (progression kini milik USER DB)',
                raw?.schema || 'tanpa schema', SCHEMA_ID,
            )
        }
        this.meta = { schema: SCHEMA_ID, version: 3, createdAt: new Date().toISOString(), updatedAt: null, counts: {} }
        this._dirty.add('root')
    }

    // ------------------------------------------------------------------
    // Validasi schema (aktivitas SAJA — payload config grup DITOLAK)
    // ------------------------------------------------------------------

    /**
     * Bersihkan map <key → record statistik>: pertahankan HANYA key allowlist.
     * Key asing dijatuhkan; key config grup diberi WARN eksplisit (ditolak).
     * @param {Record<string,object>} raw
     * @param {string[]} allowedKeys key yang diizinkan DI DALAM record
     * @param {string} domain label file utk log
     * @param {object} [opts] { keyLabel, keyFilter }
     */
    _sanitizeStats(raw, allowedKeys, domain, opts = {}) {
        if (!isPlainObject(raw)) return {}
        const out = {}
        const droppedForeign = []
        const rejectedConfig = []
        for (const [k, v] of Object.entries(raw)) {
            if (!isPlainObject(v)) { droppedForeign.push(`${k} (bukan object)`); continue }
            if (opts.keyFilter && !opts.keyFilter(k)) {
                // key bukan identitas statistik (JID/hari) → buang (anti config)
                if (GROUP_CONFIG_KEYS.has(k)) rejectedConfig.push(`${k} (key-level)`)
                else droppedForeign.push(`${k} (key tidak sah)`)
                continue
            }
            const clean = {}
            for (const ak of allowedKeys) {
                if (v[ak] === undefined) continue
                if (ak === 'users' || ak === 'counts') {
                    if (isPlainObject(v[ak])) clean[ak] = v[ak]
                    continue
                }
                const n = Number(v[ak])
                clean[ak] = Number.isFinite(n) ? n : 0
            }
            // Key asing di dalam record → tolak (bukan bagian dari activity).
            // TASK 23: field progression v2 → pesan khusus (kepemilikan pindah
            // ke USER DB — bukan config grup, bukan error).
            const droppedProgression = []
            for (const fk of Object.keys(v)) {
                if (!allowedKeys.includes(fk)) {
                    if (PROGRESSION_KEYS.has(fk)) droppedProgression.push(`${k}.${fk}`)
                    else if (GROUP_CONFIG_KEYS.has(fk)) rejectedConfig.push(`${k}.${fk}`)
                    else droppedForeign.push(`${k}.${fk}`)
                }
            }
            if (droppedProgression.length) {
                logger.info(
                    'activity/%s: field progression v2 di-drop (kepemilikan kini di USER DB — users/<player_id>.json): %s',
                    domain, droppedProgression.slice(0, 8).join(', '),
                )
            }
            // Record tanpa sisa statistik numerik apa pun → buang
            const hasStat = allowedKeys.some(ak => clean[ak] !== undefined)
            if (hasStat) out[k] = clean
            else droppedForeign.push(`${k} (tanpa statistik)`)
        }
        this._reportRejected(domain, rejectedConfig, droppedForeign)
        return out
    }

    /** group.json: { <gjid>: { chat, users: { <jid>: { chat, cmdTotal } } } } */
    _sanitizeGroups(raw) {
        const cleaned = this._sanitizeStats(raw, GROUP_STAT_KEYS, 'group.json', {
            // key grup harus @g.us / @newsletter dsb — bukan nama config
            keyFilter: (k) => typeof k === 'string' && k.includes('@'),
        })
        // Bersihkan users di dalam tiap grup (allowlist chat/cmdTotal)
        for (const [gjid, g] of Object.entries(cleaned)) {
            g.users = this._sanitizeStats(g.users, GROUP_USER_KEYS, `group.json:${gjid}`, {
                keyFilter: (k) => typeof k === 'string' && k.includes('@'),
            })
        }
        return cleaned
    }

    /** daily.json: { <YYYY-MM-DD>: { chat, cmd } } */
    _sanitizeDailyBuckets(raw, domain) {
        return this._sanitizeStats(raw, DAILY_BUCKET_KEYS, domain, { keyFilter: (k) => DAY_KEY_RE.test(k) })
    }

    /** dailyUser.json: { <day>: { <jid>: { chat, cmd } } } */
    _sanitizeDailyUsers(raw) {
        if (!isPlainObject(raw)) return {}
        const out = {}
        const droppedForeign = []
        for (const [day, perUser] of Object.entries(raw)) {
            if (!DAY_KEY_RE.test(day) || !isPlainObject(perUser)) {
                droppedForeign.push(`dailyUser.json:${day} (key hari tidak sah)`)
                continue
            }
            out[day] = this._sanitizeStats(perUser, DAILY_BUCKET_KEYS, `dailyUser.json:${day}`, {
                keyFilter: (k) => typeof k === 'string' && k.includes('@'),
            })
        }
        this._reportRejected('dailyUser.json', [], droppedForeign)
        return out
    }

    /** dailyGroup.json: { <day>: { <gjid>: { chat, users: { <jid>: {chat,cmd} } } } } */
    _sanitizeDailyGroups(raw) {
        if (!isPlainObject(raw)) return {}
        const out = {}
        const droppedForeign = []
        for (const [day, perGroup] of Object.entries(raw)) {
            if (!DAY_KEY_RE.test(day) || !isPlainObject(perGroup)) {
                droppedForeign.push(`dailyGroup.json:${day} (key hari tidak sah)`)
                continue
            }
            const groups = this._sanitizeStats(perGroup, DAILY_GROUP_KEYS, `dailyGroup.json:${day}`, {
                keyFilter: (k) => typeof k === 'string' && k.includes('@'),
            })
            for (const [gjid, g] of Object.entries(groups)) {
                g.users = this._sanitizeStats(g.users, DAILY_BUCKET_KEYS, `dailyGroup.json:${day}:${gjid}`, {
                    keyFilter: (k) => typeof k === 'string' && k.includes('@'),
                })
            }
            out[day] = groups
        }
        this._reportRejected('dailyGroup.json', [], droppedForeign)
        return out
    }

    /** commandNames.json: { <cmd>: { total, users: {<jid>:n}, groups: {<gjid>:n} } } */
    _sanitizeCommands(raw) {
        if (!isPlainObject(raw)) return {}
        const out = {}
        const rejectedConfig = []
        const droppedForeign = []
        for (const [cmd, v] of Object.entries(raw)) {
            if (!cmd || typeof cmd !== 'string') continue
            if (GROUP_CONFIG_KEYS.has(cmd)) { rejectedConfig.push(cmd); continue }
            if (!isPlainObject(v)) continue
            const clean = { total: Math.max(0, Number(v.total) || 0) }
            clean.users = this._countMap(v.users)
            clean.groups = this._countMap(v.groups)
            for (const fk of Object.keys(v)) {
                if (!CMD_STAT_KEYS.includes(fk)) droppedForeign.push(`${cmd}.${fk}`)
            }
            if (clean.total > 0 || Object.keys(clean.users).length || Object.keys(clean.groups).length) out[cmd] = clean
        }
        this._reportRejected('commandNames.json', rejectedConfig, droppedForeign)
        return out
    }

    /** Map jid/gjid → angka (dipakai users/groups di commandNames). */
    _countMap(raw) {
        if (!isPlainObject(raw)) return {}
        const out = {}
        for (const [k, n] of Object.entries(raw)) {
            const num = Number(n)
            if (Number.isFinite(num) && num > 0 && typeof k === 'string') out[k] = num
        }
        return out
    }

    /**
     * Log penolakan payload asing (config grup = eksplisit DITOLAK) + tandai
     * domain dirty supaya versi BERSIH segera menimpa file yang terkontaminasi
     * (self-healing: junk di disk tidak bertahan melewati satu siklus flush).
     * @returns {number} jumlah key asing yang dijatuhkan
     */
    _reportRejected(domain, rejectedConfig, droppedForeign) {
        const dropped = rejectedConfig.length + droppedForeign.length
        if (rejectedConfig.length > 0) {
            logger.warn(
                'Activity %s: %d payload CONFIG GRUP DITOLAK (bukan data activity): %s — key: %s',
                domain, rejectedConfig.length,
                [...new Set(rejectedConfig.map(x => x.split('.').pop()))].slice(0, 10).join(', '),
                rejectedConfig.slice(0, 5).join(', '),
            )
        }
        if (droppedForeign.length > 0) {
            logger.warn(
                'Activity %s: %d key asing dijatuhkan (di luar schema statistik): %s',
                domain, droppedForeign.length, droppedForeign.slice(0, 5).join(', '),
            )
        }
        if (dropped > 0) {
            // label 'user.json' / 'group.json:GJID' / 'dailyGroup.json:DAY:GJID'
            // → domain key ('user' / 'group' / 'dailyGroup')
            const key = String(domain).split(':')[0].replace(/\.json$/, '')
            if (DOMAIN_FILES[key]) this._dirty.add(key)
        }
        return dropped
    }

    // ------------------------------------------------------------------
    // Tulis disk — debounced async per-domain (LAT-004 dipertahankan)
    // ------------------------------------------------------------------

    /** Tandai domain berubah + naikkan mutSeq. */
    _markDirty(...domains) {
        for (const d of domains) this._dirty.add(d)
        this._mutSeq++
    }

    /** Data aktual per domain (yang di-serialize ke file). */
    _domainData(domain) {
        switch (domain) {
            case 'user': return this.users
            case 'group': return this.groups
            case 'daily': return this.daily
            case 'dailyUser': return this.dailyUsers
            case 'dailyGroup': return this.dailyGroups
            case 'commandNames': return this.commandNames
            case 'root': return this._rootSnapshot()
            default: return null
        }
    }

    /** Snapshot meta + counts terkini. */
    _rootSnapshot() {
        this.meta.updatedAt = new Date().toISOString()
        this.meta.counts = {
            users: Object.keys(this.users).length,
            groups: Object.keys(this.groups).length,
            days: Object.keys(this.dailyUsers).length,
            commands: Object.keys(this.commandNames).length,
        }
        return this.meta
    }

    _fileOf(domain) {
        return path.join(this.dataDir, DOMAIN_FILES[domain])
    }

    /** Tulis atomic (tmp+rename) domain dirty — SINKRON (flush()/close()/test). */
    _write() {
        this._gen++ // tulis sinkron ini lebih baru → tulis async in-flight membuang tmp-nya
        const domains = this._dirty.size > 0 ? [...this._dirty] : Object.keys(DOMAIN_FILES)
        for (const domain of domains) {
            const file = this._fileOf(domain)
            const tmp = `${file}.tmp-${process.pid}`
            try {
                fs.writeFileSync(tmp, JSON.stringify(this._domainData(domain)), 'utf8')
                fs.renameSync(tmp, file)
            } catch (e) {
                logger.error('Gagal menulis activity %s: %s', DOMAIN_FILES[domain], e.message)
                try { fs.unlinkSync(tmp) } catch {}
            }
        }
        this._dirty.clear()
    }

    /**
     * Tulis atomic ASYNC (jalur timer) — single-flight; mutasi SELAMA tulis
     * berjalan (mutSeq naik setelah snapshot) membiarkan _dirty tetap ada →
     * siklus berikutnya menulis state terbaru (coalescing).
     */
    _flushAsync() {
        if (this._dirty.size === 0 || this._writing) return
        this._writing = true
        const gen = this._gen
        const domains = [...this._dirty]
        for (const d of domains) this._dirty.delete(d)
        // root.json ikut ditulis bila domain data lain berubah (meta terbaru)
        if (!domains.includes('root') && domains.some(d => d !== 'root')) domains.push('root')
        const files = domains.map((domain) => {
            const file = this._fileOf(domain)
            return { domain, file, tmp: `${file}.tmp-${process.pid}-${Date.now()}`, payload: JSON.stringify(this._domainData(domain)) }
        })
        Promise.all(files.map(({ tmp, file, payload, domain }) =>
            fs.promises.writeFile(tmp, payload, 'utf8')
                .then(() => {
                    if (gen !== this._gen) {
                        // flush()/_write() sinkron sudah menulis lebih baru → buang tmp
                        return fs.promises.unlink(tmp).catch(() => {})
                    }
                    return fs.promises.rename(tmp, file)
                })
                .catch((e) => {
                    // Gagal tulis → domain tetap dirty (ditulis lagi siklus/flush berikutnya)
                    this._dirty.add(domain)
                    logger.error('Gagal menulis activity (async) %s: %s', path.basename(file), e.message)
                    fs.promises.unlink(tmp).catch(() => {})
                }),
        )).finally(() => {
            this._writing = false
            // Mutasi selama menulis (dirty terisi lagi) → siklus berikutnya
            // menulis state terbaru (coalescing — tidak ada tulis overlap).
            if (this._dirty.size > 0) this._flushAsync()
        })
    }

    /** Flush sekarang jika ada perubahan (sinkron — durabilitas langsung). */
    flush() {
        if (this._dirty.size > 0) this._write()
    }

    _startTimer() {
        this.stopTimer()
        this._timer = setInterval(() => this._flushAsync(), activityCfg.flushMs)
        if (typeof this._timer.unref === 'function') this._timer.unref()
    }

    stopTimer() {
        if (this._timer) {
            clearInterval(this._timer)
            this._timer = null
        }
    }

    /** Dipanggil bot.stop() — flush terakhir + hentikan timer. */
    close() {
        this.stopTimer()
        this.flush()
    }

    // ------------------------------------------------------------------
    // Record
    // ------------------------------------------------------------------

    /**
     * Catat 1 pesan chat → +1 chat (global & grup) + bucket harian.
     * TASK 23: EXP & streak TIDAK lagi disentuh — progression user milik
     * USER DB (applyMessageProgression di database/user-progression.js,
     * dipanggil bot.js dengan baris user yang sama). Ini analytics murni.
     * Menyentuh: user, group, daily, dailyUser, dailyGroup.
     * @param {{userJid:string, groupJid?:string|null, now?:Date}} p
     */
    recordMessage({ userJid, groupJid = null, now = new Date() }) {
        if (!userJid || typeof userJid !== 'string') return null
        // TASK 26: kanonik dulu (LID → PN) — data baru tidak pecah identitas.
        userJid = this._identityOf(userJid) || userJid
        const u = this._user(userJid)
        const day = dayKey(now)

        // --- chat counters (user global) ---
        u.chat += 1
        u.lastActive = now.toISOString()
        u.lastDay = day
        if (!u.firstDay) u.firstDay = day

        let g = null
        if (groupJid && typeof groupJid === 'string') {
            g = this._group(groupJid)
            const gu = this._groupUser(g, userJid)
            gu.chat += 1
            g.chat += 1
        }

        // --- daily buckets: total global / user / grup ---
        const d = this._bucket(this.daily, day, { chat: 0, cmd: 0 })
        d.chat += 1
        const du = this._bucket(this.dailyUsers, day, null, userJid, { chat: 0, cmd: 0 })
        du.chat += 1
        if (g) {
            const dg = this._bucket(this.dailyGroups, day, null, groupJid, { chat: 0, users: {} })
            dg.chat += 1
            const dgu = this._bucket(dg.users, userJid, { chat: 0, cmd: 0 })
            dgu.chat += 1
        }

        this._markDirty('user', 'group', 'daily', 'dailyUser', ...(g ? ['dailyGroup'] : []))
        return { recorded: true, chat: u.chat }
    }

    /**
     * Catat 1 pemakaian command (dipanggil handler saat execute dijalankan).
     * Menyentuh: user, group, daily, dailyUser, dailyGroup, commandNames.
     * @param {{userJid:string, groupJid?:string|null, command:string, now?:Date}} p
     */
    recordCommand({ userJid, groupJid = null, command, now = new Date() }) {
        if (!userJid || typeof userJid !== 'string') return
        // TASK 26: kanonik dulu (LID → PN) — data baru tidak pecah identitas.
        userJid = this._identityOf(userJid) || userJid
        const cmd = String(command || '').trim().toLowerCase()
        if (!cmd) return
        const u = this._user(userJid)
        const day = dayKey(now)

        u.cmdTotal += 1
        if (!u.firstDay) u.firstDay = day

        let g = null
        if (groupJid && typeof groupJid === 'string') {
            g = this._group(groupJid)
            this._groupUser(g, userJid).cmdTotal += 1
            g.chat = g.chat || 0
        }

        // --- daily buckets ---
        this._bucket(this.daily, day, { chat: 0, cmd: 0 }).cmd += 1
        this._bucket(this.dailyUsers, day, null, userJid, { chat: 0, cmd: 0 }).cmd += 1
        if (g) {
            const dg = this._bucket(this.dailyGroups, day, null, groupJid, { chat: 0, users: {} })
            this._bucket(dg.users, userJid, { chat: 0, cmd: 0 }).cmd += 1
        }

        // --- statistik command (commandNames) ---
        const cn = this._commandEntry(cmd)
        cn.total += 1
        cn.users[userJid] = (cn.users[userJid] || 0) + 1
        if (g) cn.groups[groupJid] = (cn.groups[groupJid] || 0) + 1

        this._markDirty('user', 'group', 'daily', 'dailyUser', 'commandNames', ...(g ? ['dailyGroup'] : []))
    }

    // TASK 23: grantExp DIHAPUS dari ActivityStore — progression (level/EXP/
    // totalExp/streak) kini milik USER DB; satu-satunya penulis adalah
    // database/user-progression.js (applyMessageProgression / grantUserExp).
    // Memanggil activity.grantExp() sekarang = TypeError eksplisit supaya
    // pemanggil lama gagal CEPAT saat pengembangan, bukan silently menulis
    // dua tempat.

    // ------------------------------------------------------------------
    // Read — user & grup
    // ------------------------------------------------------------------

    /**
     * Snapshot statistik ANALYTIK 1 user (global) + window chat/cmd.
     * TASK 23: level/EXP/streak TIDAK ada di sini — progression dibaca dari
     * baris user (progressionOf(user) di database/user-progression.js).
     */
    getUser(userJid, now = new Date()) {
        // TASK 26: terima input LID/PN → baca bentuk kanonik (data direkam
        // kanonik sejak Task 26; data lama yang masih pecah dibaca apa adanya).
        const canon = this._identityOf(userJid) || String(userJid || '').trim()
        const u = this.users[canon]
        if (!u) return null
        return {
            jid: canon,
            chat: u.chat,
            cmdTotal: u.cmdTotal,
            cmd: this._userCmdMap(canon),
            firstDay: u.firstDay || null,
            lastDay: u.lastDay || null,
            lastActive: u.lastActive || null,
            window: this._userWindows(canon, now),
        }
    }

    /** Rekonstruksi { cmd: n } milik user dari commandNames.json ( bounded #cmd ). */
    _userCmdMap(userJid) {
        const out = {}
        for (const [cmd, cn] of Object.entries(this.commandNames)) {
            const n = cn.users?.[userJid]
            if (n > 0) out[cmd] = n
        }
        return out
    }

    /** Snapshot statistik 1 grup. */
    getGroup(groupJid, now = new Date()) {
        const g = this.groups[groupJid]
        const days = weekDayKeys(now)
        const month = monthDayKeys(now)
        if (!g) {
            return { jid: groupJid, chat: 0, users: 0, weekChat: 0, monthChat: 0, todayChat: 0, topCmds: [] }
        }
        const today = dayKey(now)
        const groupDay = (k) => this.dailyGroups[k]?.[groupJid]
        return {
            jid: groupJid,
            chat: g.chat,
            users: Object.keys(g.users).length,
            todayChat: groupDay(today)?.chat || 0,
            weekChat: sumWindows(Object.fromEntries(Object.keys(this.dailyGroups).map(k => [k, groupDay(k)?.chat || 0])), days),
            monthChat: sumWindows(Object.fromEntries(Object.keys(this.dailyGroups).map(k => [k, groupDay(k)?.chat || 0])), month),
            topCmds: this.topCommands({ scope: { type: 'group', jid: groupJid }, limit: 5 }),
        }
    }

    /** Statistik 1 user DI DALAM 1 grup (chat/cmd per grup) — utk profile. */
    getGroupUser(groupJid, userJid) {
        const gu = this.groups[groupJid]?.users?.[userJid]
        if (!gu) return null
        return { chat: gu.chat, cmdTotal: gu.cmdTotal }
    }

    /** Statistik window (today/week/month) untuk 1 user — chat & cmd global. */
    _userWindows(userJid, now = new Date()) {
        const pick = (keys) => {
            let chat = 0
            let cmd = 0
            for (const k of keys) {
                const v = this.dailyUsers[k]?.[userJid]
                if (v) { chat += v.chat || 0; cmd += v.cmd || 0 }
            }
            return { chat, cmd }
        }
        const today = dayKey(now)
        return {
            today: pick([today]),
            week: pick(weekDayKeys(now)),
            month: pick(monthDayKeys(now)),
        }
    }

    // ------------------------------------------------------------------
    // Read — leaderboard & rank
    // ------------------------------------------------------------------

    /** Kategori leaderboard yang didukung. */
    static CATEGORIES = ['level', 'exp', 'chat', 'cmd', 'money', 'streak', 'topcmd', 'work', 'job', 'afk', 'afktotal']

    /** Suntik penyedia saldo (dari userRepo — economy tidak disentuh). */
    setMoneyProvider(fn) { this._moneyProvider = typeof fn === 'function' ? fn : null }

    /** Suntik penyedia data economy/job (dari EconomyStore — pola moneyProvider). */
    setEconomyProvider(fn) { this._economyProvider = typeof fn === 'function' ? fn : null }

    /** Suntik penyedia statistik AFK (dari AfkService — pola economy). */
    setAfkProvider(fn) { this._afkProvider = typeof fn === 'function' ? fn : null }

    /**
     * TASK 23: suntik penyedia PROGRESSION (dari USER DB via
     * database/user-progression.js aggregateProgression). Leaderboard
     * level/exp/streak membaca dari sini — activity bukan lagi pemiliknya.
     */
    setProgressionProvider(fn) { this._progressionProvider = typeof fn === 'function' ? fn : null }

    /**
     * TASK 26 (LB dobol nama): suntik resolver identitas — LID → PN.
     * fn(jid) → jid kanonik (string) atau null (identitas tidak dikenal /
     * jid sudah kanonik). Dipakai di titik REKAM (recordMessage/
     * recordCommand) supaya data baru tidak pecah identitas, dan di titik
     * BACA (_rankAll/_mergeIdentity) menyatukan data lama yang sudah pecah.
     */
    setIdentityResolver(fn) {
        this._identityResolver = typeof fn === 'function' ? fn : null
        this._identityCache.clear()
    }

    /** jid kanonik untuk jid ini (resolver + cache), null bila tak dikenal. */
    _identityOf(jid) {
        if (!this._identityResolver) return null
        const key = String(jid)
        if (this._identityCache.has(key)) return this._identityCache.get(key)
        let out = null
        try {
            const r = this._identityResolver(key)
            out = typeof r === 'string' && r ? r : null
        } catch {
            out = null
        }
        if (this._identityCache.size >= 4000) this._identityCache.clear()
        this._identityCache.set(key, out)
        return out
    }

    /**
     * Bentuk kanonik sebuah jid untuk API publik: hasil resolver bila ada,
     * selain itu jid apa adanya (trim). Selalu string valid.
     */
    resolveIdentity(jid) {
        const s = String(jid || '').trim()
        if (!s) return s
        return this._identityOf(s) || s
    }

    _progressionOf(jids) {
        if (!this._progressionProvider) return new Map()
        try {
            const m = this._progressionProvider(jids)
            return m instanceof Map ? m : new Map()
        } catch (e) {
            logger.warn('progressionProvider error: %s', e.message)
            return new Map()
        }
    }

    _economyOf(jids, scope) {
        if (!this._economyProvider) return new Map()
        try {
            const m = this._economyProvider(jids, scope)
            return m instanceof Map ? m : new Map()
        } catch (e) {
            logger.warn('economyProvider error: %s', e.message)
            return new Map()
        }
    }

    _moneyOf(jids) {
        if (!this._moneyProvider) return new Map()
        try {
            const m = this._moneyProvider(jids)
            return m instanceof Map ? m : new Map()
        } catch (e) {
            logger.warn('moneyProvider error: %s', e.message)
            return new Map()
        }
    }

    _afkOf(jids) {
        if (!this._afkProvider) return new Map()
        try {
            const m = this._afkProvider(jids)
            return m instanceof Map ? m : new Map()
        } catch (e) {
            logger.warn('afkProvider error: %s', e.message)
            return new Map()
        }
    }

    /**
     * Leaderboard.
     * @param {object} o
     * @param {'level'|'exp'|'chat'|'cmd'|'money'|'streak'|'topcmd'} o.category
     * @param {{type:'global'|'group', jid?:string}} o.scope
     * @param {'daily'|'weekly'|'monthly'|'all'} [o.window] hanya utk chat/cmd
     * @param {number} [o.limit] @param {number} [o.offset]
     */
    top({ category, scope, window = 'all', limit = 10, offset = 0 } = {}) {
        const lim = Math.max(1, Math.min(50, Math.floor(Number(limit) || 10)))
        const off = Math.max(0, Math.floor(Number(offset) || 0))

        if (category === 'topcmd') {
            const all = this.topCommands({ scope, limit: 0, offset: 0 })
            return { rows: all.slice(off, off + lim), total: all.length }
        }

        const entries = this._rankAll({ category, scope, window })
        return { rows: entries.slice(off, off + lim), total: entries.length }
    }

    /**
     * Nilai kategori dari record. TASK 23: level/exp/streak TIDAK lagi
     * dibaca dari record (progression milik USER DB via provider) — hanya
     * chat/cmd (analytics) yang dibaca dari sini.
     */
    _catValue(rec, category, window, jid, groupJid = null) {
        switch (category) {
            case 'chat': return this._windowValue(rec, window, jid, 'chat', groupJid)
            case 'cmd': return this._windowValue(rec, window, jid, 'cmd', groupJid)
            default: return 0
        }
    }

    /**
     * Nilai chat/cmd menurut window. all-time = counter total (user.json /
     * group.json users); daily/weekly/monthly dijumlah dari bucket harian
     * (dailyUser.json global / dailyGroup.json per grup) sesuai scope.
     */
    _windowValue(rec, window, jid, field, groupJid = null) {
        if (window === 'all') return Math.max(0, Number(rec?.[field === 'chat' ? 'chat' : 'cmdTotal']) || 0)
        const keys = window === 'daily' ? [dayKey()] : window === 'weekly' ? weekDayKeys() : monthDayKeys()
        if (!jid) return 0
        let total = 0
        for (const k of keys) {
            const v = groupJid
                ? this.dailyGroups[k]?.[groupJid]?.users?.[jid]
                : this.dailyUsers[k]?.[jid]
            if (v) total += v[field] || 0
        }
        return total
    }

    /**
     * Command paling populer dalam scope — agregasi dari commandNames.json.
     * @returns {Array<{name:string, value:number}>}
     */
    topCommands({ scope, limit = 10, offset = 0 } = {}) {
        const isGroup = scope?.type === 'group' && scope.jid
        const valueOf = (cn) => (isGroup ? (cn.groups?.[scope.jid] || 0) : (cn.total || 0))
        const all = Object.entries(this.commandNames)
            .map(([name, cn]) => ({ name, value: valueOf(cn) }))
            .filter(e => e.value > 0)
        all.sort((a, b) => b.value - a.value || a.name.localeCompare(b.name))
        if (!limit || limit <= 0) return all
        return all.slice(Math.max(0, offset || 0), Math.max(0, offset || 0) + limit)
    }

    /**
     * Peringkat user dalam sebuah kategori + scope (1-based).
     * @returns {{rank:number|null, total:number}}
     */
    rankOf({ userJid, category, scope, window = 'all' } = {}) {
        const isGroup = scope?.type === 'group' && scope.jid
        if (category === 'topcmd') return { rank: null, total: 0 }

        const all = this._rankAll({ category, scope, window })
        const total = all.length
        // TASK 26: userJid di-kanonik dulu — self-rank harus cocok dengan
        // baris yang sudah di-merge (nama yang sama, identitas yang sama).
        const canon = this._identityOf(userJid) || String(userJid || '').trim()
        const idx = all.findIndex(e => e.jid === canon)
        if (idx === -1) return { rank: null, total }
        return { rank: idx + 1, total }
    }

    /**
     * Daftar lengkap terurut utk leaderboard & perhitungan rank.
     * TASK 23: level/exp/streak → dari USER DB via progressionProvider
     * (pola identik dengan money/work/afk — scope grup memfilter anggota
     * dari statistik grup; global = semua jid yang dikenal activity).
     * chat/cmd → record sesuai scope, window harian membaca bucket scope.
     * TASK 26: SEMUA jalur di-merge per identitas kanonik (LID+PN milik
     * orang yang sama → SATU baris) sebelum sort — data lama yang sudah
     * pecah identitas tetap tampil benar tanpa migrasi file.
     */
    _rankAll({ category, scope, window }) {
        const isGroup = scope?.type === 'group' && Boolean(scope.jid)
        const sumMerge = category === 'chat' || category === 'cmd'

        // --- level / exp / streak: dari USER DB via provider (Task 23) ---
        if (category === 'level' || category === 'exp' || category === 'streak') {
            const jids = isGroup ? Object.keys(this.groups[scope.jid]?.users || {}) : Object.keys(this.users)
            const prog = this._progressionOf(jids)
            const entries = []
            for (const [jid, p] of prog) {
                const value = category === 'level'
                    ? Math.max(1, Number(p?.level) || 1)
                    : category === 'exp'
                        ? Math.max(0, Number(p?.exp) || 0)
                        : Math.max(0, Number(p?.streak) || 0)
                if (value > 0) entries.push({ jid, value })
            }
            const merged = this._mergeIdentity(entries, { sum: sumMerge })
            merged.sort((a, b) => b.value - a.value || String(a.jid).localeCompare(String(b.jid)))
            return merged
        }

        // --- work / job: dari EconomyStore via provider (pola money) ---
        if (category === 'work' || category === 'job') {
            const jids = isGroup ? Object.keys(this.groups[scope.jid]?.users || {}) : Object.keys(this.users)
            const econ = this._economyOf(jids, scope)
            const entries = []
            for (const [jid, e] of econ) {
                if (category === 'work') {
                    const earned = Math.max(0, Number(e?.workEarned) || 0)
                    if (earned > 0) entries.push({ jid, value: earned, extra: { workCount: e?.workCount || 0 } })
                } else {
                    const lv = Math.max(0, Number(e?.jobLevel) || 0)
                    if (lv > 0) entries.push({ jid, value: lv, extra: { jobExp: e?.jobExp || 0, jobName: e?.jobName || null } })
                }
            }
            const merged = this._mergeIdentity(entries, { sum: sumMerge })
            merged.sort((a, b) =>
                b.value - a.value
                || (b.extra?.jobExp || 0) - (a.extra?.jobExp || 0)
                || String(a.jid).localeCompare(String(b.jid)))
            return merged
        }

        // --- afk / afktotal: dari AfkService via provider ---
        if (category === 'afk' || category === 'afktotal') {
            const jids = isGroup ? Object.keys(this.groups[scope.jid]?.users || {}) : Object.keys(this.users)
            const afk = this._afkOf(jids)
            const entries = []
            for (const [jid, a] of afk) {
                const value = Math.max(0, Number(category === 'afk' ? a?.longestAfkRun : a?.totalAfkDuration) || 0)
                if (value > 0) entries.push({ jid, value, extra: { sessions: Math.max(0, Number(a?.sessions) || 0) } })
            }
            const merged = this._mergeIdentity(entries, { sum: sumMerge })
            merged.sort((a, b) =>
                b.value - a.value
                || (b.extra?.sessions || 0) - (a.extra?.sessions || 0)
                || String(a.jid).localeCompare(String(b.jid)))
            return merged
        }

        if (category === 'money') {
            const jids = isGroup ? Object.keys(this.groups[scope.jid]?.users || {}) : Object.keys(this.users)
            const money = this._moneyOf(jids)
            const merged = this._mergeIdentity([...money.entries()]
                .map(([jid, v]) => ({ jid, value: Math.max(0, Number(v) || 0) }))
                .filter(e => e.value > 0), { sum: sumMerge })
            merged.sort((a, b) => b.value - a.value || String(a.jid).localeCompare(String(b.jid)))
            return merged
        }

        // --- chat / cmd: analytics internal (record scope + window) ---
        let source
        let groupJid = null
        if (isGroup) {
            source = this.groups[scope.jid]?.users || {}
            groupJid = scope.jid
        } else {
            source = this.users
        }

        const entries = Object.entries(source)
            .map(([jid, rec]) => ({ jid, value: this._catValue(rec, category, window, jid, groupJid) }))
            .filter(e => e.value > 0)
        // chat/cmd = SUM saat merge (hituran terpisah PN/LID dijumlahkan);
        // kategori provider = dedupe (duplikat bawa nilai sama — cukup satu).
        const merged = this._mergeIdentity(entries, { sum: sumMerge })
        merged.sort((a, b) => b.value - a.value || String(a.jid).localeCompare(String(b.jid)))
        return merged
    }

    /**
     * TASK 26 (LB dobol nama): satukan entry yang jid-nya menunjuk ORANG
     * YANG SAMA (LID vs PN) via identityResolver.
     * - sum=true (chat/cmd): nilai dijumlah (hituran terpisah sebelumnya).
     * - sum=false (level/exp/money/…): duplikat bawa nilai sama → ambil
     *   nilai terbesar (dedupe, JANGAN dijumlah — level tidak boleh dobel).
     * Baris hasil memakai jid KANONIK supaya resolusi nama di lb.js
     * (username terdaftar / pushname) menemukan satu orang yang sama.
     * Tanpa resolver terpasang → entries dikembalikan apa adanya.
     */
    _mergeIdentity(entries, { sum = false } = {}) {
        if (!this._identityResolver || !Array.isArray(entries) || entries.length <= 1) return entries
        const out = []
        const idxByCanon = new Map() // jid kanonik → index di out
        let mergedCount = 0
        for (const e of entries) {
            const canon = this._identityOf(e.jid)
            if (!canon || canon === e.jid) {
                // identitas tidak dikenal / jid sudah kanonik → baris sendiri
                idxByCanon.set(e.jid, out.length)
                out.push(e)
                continue
            }
            // canon valid & beda dari jid entry → satukan ke baris kanonik
            const idx = idxByCanon.get(canon)
            if (idx === undefined) {
                idxByCanon.set(canon, out.length)
                out.push({ ...e, jid: canon })
                mergedCount++
                continue
            }
            const cur = out[idx]
            if (sum) {
                cur.value = (Number(cur.value) || 0) + (Number(e.value) || 0)
            } else if ((Number(e.value) || 0) > (Number(cur.value) || 0)) {
                cur.value = e.value
                if (e.extra) cur.extra = { ...(cur.extra || {}), ...e.extra }
            } else if (e.extra && !cur.extra) {
                cur.extra = e.extra
            }
            mergedCount++
        }
        if (mergedCount > 0) {
            logger.debug('Activity LB: %d baris identitas kembar digabung (LID→PN)', mergedCount)
        }
        return out
    }

    // ------------------------------------------------------------------
    // Internal helpers
    // ------------------------------------------------------------------

    /** Ambil/buat record user global (user.json). */
    _user(jid) {
        let u = this.users[jid]
        if (!u || typeof u !== 'object') {
            u = this._blankUser()
            this.users[jid] = u
        }
        return u
    }

    _blankUser() {
        return {
            chat: 0, cmdTotal: 0,
            firstDay: null, lastDay: null, lastActive: null,
        }
    }

    /** Ambil/buat record grup (group.json — statistik SAJA, tanpa config). */
    _group(gjid) {
        let g = this.groups[gjid]
        if (!g || typeof g !== 'object' || typeof g.users !== 'object') {
            g = { chat: 0, users: {} }
            this.groups[gjid] = g
        }
        return g
    }

    _groupUser(g, jid) {
        let gu = g.users[jid]
        if (!gu || typeof gu !== 'object') {
            gu = { chat: 0, cmdTotal: 0 }
            g.users[jid] = gu
        }
        return gu
    }

    /** Ambil/buat bucket harian. Pola A: map[day]=blank. Pola B: map[day][key]=blank. */
    _bucket(map, day, blank, key = null, keyBlank = null) {
        if (key === null) {
            if (!isPlainObject(map[day])) map[day] = blank
            return map[day]
        }
        if (!isPlainObject(map[day])) map[day] = {}
        if (!isPlainObject(map[day][key])) map[day][key] = keyBlank
        return map[day][key]
    }

    /** Ambil/buat entry statistik command (commandNames.json). */
    _commandEntry(cmd) {
        let cn = this.commandNames[cmd]
        if (!isPlainObject(cn)) {
            cn = { total: 0, users: {}, groups: {} }
            this.commandNames[cmd] = cn
        }
        return cn
    }

    /** Buang bucket daily lebih tua dari KEEP_DAYS (3 file harian). */
    _pruneDaily(now = new Date()) {
        const cutoff = new Date(now.getTime() - activityCfg.keepDays * 86400000)
        const cutoffKey = dayKey(cutoff)
        let removed = 0
        for (const map of [this.daily, this.dailyUsers, this.dailyGroups]) {
            for (const k of Object.keys(map)) {
                if (String(k).localeCompare(cutoffKey) < 0) {
                    delete map[k]
                    removed++
                }
            }
        }
        if (removed > 0) {
            this._markDirty('daily', 'dailyUser', 'dailyGroup')
            logger.info('Activity: %d bucket daily kadaluarsa dibuang (≤ %s)', removed, cutoffKey)
        }
        return removed
    }
}
