export class SettingsRepository {
	constructor(store) {
		this.store = store
		this._globalCache = null
	}

	// ---- Global Settings ----

	getGlobal(key, fallback = null) {
		if (this._globalCache === null) this._loadGlobalCache()
		const v = this._globalCache.get(key)
		return v !== undefined ? v : fallback
	}

	setGlobal(key, value) {
		const strVal = String(value)
		this.store.data.global_settings[key] = strVal
		this.store.writeDirty?.('global_settings')
		if (this._globalCache === null) this._loadGlobalCache()
		this._globalCache.set(key, strVal)
	}

	_loadGlobalCache() {
		this._globalCache = new Map()
		for (const [k, v] of Object.entries(this.store.data.global_settings)) {
			this._globalCache.set(k, v)
		}
	}
}
