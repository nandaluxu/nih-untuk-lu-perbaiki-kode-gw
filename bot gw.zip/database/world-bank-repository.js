import { EconomyService } from '../lib/economy/economy-service.js'
import logger from '../lib/core/logger.js'

export class WorldBankRepository {
        constructor(store) {
                this.store = store
        }

        get() {
                return this.store.data.world_bank || null
        }

        /**
         * Update saldo + timestamp. B6 guard: nilai non-finite (NaN/Infinity/
         * undefined) DITOLAK dan diganti nilai aman (clamp 0..max) — store
         * tidak pernah berisi NaN (JSON.stringify(NaN) = "null" = korupsi).
         */
        update(balance, lastRegen) {
                const raw = Number(balance)
                const safe = EconomyService.safeInt(balance, { min: 0, fallback: 0 })
                if (!Number.isFinite(raw)) {
                        logger.warn('WorldBank update menolak saldo non-finite (%s) — dipakai %d.', String(balance), safe)
                } else if (raw !== safe) {
                        logger.debug('WorldBank saldo di-clamp: %s → %d', String(balance), safe)
                }
                this.store.data.world_bank.balance = safe
                this.store.data.world_bank.last_regen = lastRegen || new Date().toISOString()
                this.store.writeDirty?.('world_bank')
        }

        updateMaxBalance(maxBalance) {
                this.store.data.world_bank.max_balance = EconomyService.safeInt(maxBalance, { min: 1, fallback: 1 })
                this.store.writeDirty?.('world_bank')
        }
}
