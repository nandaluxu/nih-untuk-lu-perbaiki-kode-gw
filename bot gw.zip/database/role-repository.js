import fs from 'fs'
import logger from '../lib/core/logger.js'
// PHASE 1 (identity consolidation): primitif kanonik lib/identity.
import { toPnJid } from '../lib/identity/index.js'

export const ROLE_HIERARCHY = ['banned', 'free', 'premium', 'vip', 'co-owner', 'owner']

export const ROLE_CONFIG = {
        'banned':    { cooldownMultiplier: 1,    typingDelay: 0,  bypassCooldown: false, bypassDelay: false },
        'free':      { cooldownMultiplier: 1,    typingDelay: 3000, bypassCooldown: false, bypassDelay: false },
        'premium':   { cooldownMultiplier: 1/1.5, typingDelay: 2000, bypassCooldown: false, bypassDelay: false },
        'vip':       { cooldownMultiplier: 1/2,   typingDelay: 1000, bypassCooldown: false, bypassDelay: false },
        'co-owner':  { cooldownMultiplier: 1/3,   typingDelay: 0,    bypassCooldown: false, bypassDelay: true  },
        'owner':     { cooldownMultiplier: 0,    typingDelay: 0,    bypassCooldown: true,  bypassDelay: true  },
}

/**
 * RoleRepository — source of truth role adalah USER PROFILE (users/{player_id}.json).
 *
 * Struktur role di user profile (nested object, natural seperti ainsfw_settings):
 *   "role": { "name": "premium", "set_at": "<ISO>", "expires_at": "<ISO>|null" }
 *
 * TIDAK ADA lagi tabel role global. store.json → roles TIDAK dibaca sama sekali
 * (fallback legacy dimatikan — keputusan owner). Sisa data lama dimigrasikan
 * ke profil saat startup / via command .migraterole, lalu DIHAPUS dari store.json.
 * Entry tanpa profil tidak bisa dimigrasi → didrop, tapi dibackup dulu ke
 * store.role-backup.json (tidak ada data hilang total).
 *
 * plugin_min_roles TIDAK disimpan di database. minRole plugin dibaca langsung
 * dari metadata plugin (source of truth = file plugin, ikut hot-reload).
 *
 * PHASE 2 STORAGE NOTE — sinkron-by-design (sengaja TIDAK dimigrasi ke
 * writeDirty): empat titik _syncWrite sinkron pada store di kelas ini
 * semuanya di jalur MIGRASI LEGACY satu-arah (migrateLegacyRoles saat
 * startup / .migraterole / _deleteLegacyEntries pasca-set-role).
 * Karakteristiknya:
 * (1) one-shot — bukan hot path pesan/command; (2) HARUS tuntas sinkron
 * sebelum baris berikutnya (backup → hapus → rename store.json.migrated
 * butuh urutan tulis yang sudah selesai di disk); (3) hasilnya diverifikasi
 * ulang oleh pemanggil. Memigrasikannya ke flush async justru membuka race
 * shutdown-vs-debounce di tengah migrasi. Hot-path role (get/set harian)
 * TIDAK lewat _syncWrite — source of truth role ada di UserFileStore (async
 * atomic per file).
 */
export class RoleRepository {
        /**
         * @param {object} store - JsonStore (store.json) — untuk migration + cleanup legacy
         * @param {object} userRepo - UserRepository (user profile = source of truth role)
         * @param {object|null} idRepo - IdentifierRepository (index PN↔LID existing, untuk resolving)
         */
        constructor(store, userRepo, idRepo = null) {
                this.store = store
                this.userRepo = userRepo
                this.idRepo = idRepo
        }

        // ============================================================
        // Role user (disimpan di user profile)
        // ============================================================

        /**
         * Get role user berdasarkan identifier apapun (PN JID / LID JID / user_id / player_id).
         * Urutan lookup:
         *   1. User profile via index existing (pn/jid/lid/user_id/player_id)
         *   2. LID → PN via IdentifierRepository (index existing) → user profile
         *
         * TIDAK ada fallback ke store.json → roles (legacy dimatikan total).
         * Data legacy hanya hidup sampai migrateLegacyRoles() memindahkannya.
         *
         * Expiration selalu dicek: expires_at < now → role dianggap free.
         * Role expired di profile dibersihkan lazily (1 file user kecil, murah).
         *
         * @returns {{ role: string, permanent: boolean, expires_at: string|null, set_at: string|null, found: boolean }}
         */
        getRole(identifier) {
                if (!identifier) return this._free()

                // 1. User profile (source of truth)
                const user = this._resolveProfile(identifier)
                if (user) {
                        const entry = user.role
                        if (!entry || !entry.name) return this._free()

                        // Expiration check
                        if (entry.expires_at && new Date(entry.expires_at) < new Date()) {
                                // Lazy cleanup — tulis 1 file user kecil, bukan seluruh store
                                this._clearProfileRole(user)
                                return this._free()
                        }

                        return {
                                role: entry.name,
                                permanent: !entry.expires_at,
                                expires_at: entry.expires_at || null,
                                set_at: entry.set_at || null,
                                found: true,
                        }
                }

                return this._free()
        }

        /**
         * Set role user. Role ditulis ke USER PROFILE (1 file user), bukan tabel global.
         * Identifier akan di-resolve ke profil dulu; user yang belum terdaftar ditolak.
         *
         * @param {string} identifier - PN JID / LID JID / user_id / player_id
         * @param {string} role - salah satu dari ROLE_HIERARCHY
         * @param {number|null} durationDays - null = permanen
         * @returns {boolean} true jika berhasil (profil ditemukan & role valid)
         */
        setRole(identifier, role, durationDays = null) {
                if (!ROLE_HIERARCHY.includes(role)) return false
                if (!identifier) return false

                const user = this._resolveProfile(identifier)
                if (!user || !user.user_id) {
                        logger.warn('setRole gagal: tidak ada profil user untuk %s', identifier)
                        return false
                }

                const entry = {
                        name: role,
                        set_at: new Date().toISOString(),
                        expires_at: durationDays
                                ? new Date(Date.now() + durationDays * 86400000).toISOString()
                                : null,
                }

                // Tulis hanya ke profil user ini (atomic single-file write via UserFileStore)
                this.userRepo.updateByUserId(user.user_id, { role: entry })

                // Migration-on-write: bersihkan legacy entry untuk identitas user ini
                this._deleteLegacyEntries([identifier, user.pn, user.jid, user.lid])

                return true
        }

        /** Remove role user (kembali ke free). Role dihapus dari user profile. */
        removeRole(identifier) {
                if (!identifier) return false
                const user = this._resolveProfile(identifier)
                if (!user || !user.user_id) return false

                this._clearProfileRole(user)
                this._deleteLegacyEntries([identifier, user.pn, user.jid, user.lid])
                return true
        }

        // ============================================================
        // Migration (db.roles legacy → user profile)
        // ============================================================

        /**
         * Migrasi role lama dari store.json → roles ke user profile, lalu bersihkan
         * store.json TOTAL dari data role (keputusan owner: legacy tidak dipertahankan).
         * Dipanggil otomatis di startup + bisa dipicu manual via command .migraterole.
         * Sifat:
         *   - Idempotent: re-run tidak menduplikasi / menimpa role profile yang sudah ada
         *   - Aman di tengah jalan: profil ditulis dulu (atomic per-file), legacy dihapus belakangan;
         *     crash di tengah → re-run menyelesaikan sisanya
         *   - Entry tanpa profil TIDAK bisa dimigrasi → didrop dari store.json, tapi SEBELUM
         *     dihapus dibackup dulu ke store.role-backup.json (merge, tidak menimpa backup lama)
         *   - Entry expired tidak disalin (langsung free), tetap dibersihkan
         *
         * @returns {{ total: number, migrated: number, skippedHasRole: number, droppedNoProfile: number, expired: number, pluginMinRolesRemoved: number, backupFile: string|null }}
         */
        migrateLegacyRoles() {
                const report = {
                        total: 0,
                        migrated: 0,
                        skippedHasRole: 0,
                        droppedNoProfile: 0,
                        expired: 0,
                        pluginMinRolesRemoved: 0,
                        backupFile: null,
                }
                let storeDirty = false

                // ---- Cleanup plugin_min_roles legacy (TIDAK dipakai lagi — minRole dari source plugin) ----
                if ('plugin_min_roles' in this.store.data) {
                        const pmr = this.store.data.plugin_min_roles
                        report.pluginMinRolesRemoved = pmr && typeof pmr === 'object' ? Object.keys(pmr).length : 0
                        if (report.pluginMinRolesRemoved > 0) {
                                logger.warn('Migration: %d override plugin_min_roles dihapus dari database. minRole kini hanya dibaca dari source plugin (edit file plugin → hot reload).', report.pluginMinRolesRemoved)
                        }
                        delete this.store.data.plugin_min_roles
                        storeDirty = true
                }

                // ---- Migrasi roles legacy → user profile ----
                const legacyRoles = this.store.data?.roles
                if (!legacyRoles || typeof legacyRoles !== 'object') {
                        if (storeDirty) this.store._syncWrite()
                        logger.info('Migration role: store.json bersih — tidak ada data role legacy yang perlu dimigrasi.')
                        return report
                }

                const jids = Object.keys(legacyRoles)
                report.total = jids.length
                if (jids.length === 0) {
                        // Sudah kosong — pastikan key legacy tidak dibuat lagi
                        delete this.store.data.roles
                        this.store._syncWrite()
                        logger.info('Migration role: store.json bersih — tidak ada data role legacy yang perlu dimigrasi.')
                        return report
                }

                const removeKeys = []
                const droppedEntries = {} // tanpa profil → dibackup sebelum dihapus

                for (const jid of jids) {
                        const entry = legacyRoles[jid]
                        if (!entry?.role) {
                                removeKeys.push(jid)
                                continue
                        }

                        // Entry expired → tidak perlu disalin, buang saja
                        const expired = entry.expires_at && new Date(entry.expires_at) < new Date()
                        if (expired) {
                                report.expired++
                                removeKeys.push(jid)
                                continue
                        }

                        const user = this._resolveProfile(jid)
                        if (!user || !user.user_id) {
                                // Tanpa profil (belum terdaftar) → tidak ada tempat migrasi.
                                // Owner memutuskan legacy TIDAK dipertahankan: didrop dari store.json,
                                // tapi dibackup dulu supaya tidak ada data hilang total.
                                droppedEntries[jid] = entry
                                report.droppedNoProfile++
                                removeKeys.push(jid)
                                continue
                        }

                        // Idempotent: profile yang sudah punya role tidak ditimpa
                        if (user.role?.name) {
                                report.skippedHasRole++
                                removeKeys.push(jid)
                                continue
                        }

                        const ok = this.userRepo.updateByUserId(user.user_id, {
                                role: {
                                        name: entry.role,
                                        set_at: entry.set_at || new Date().toISOString(),
                                        expires_at: entry.expires_at || null,
                                },
                        })

                        if (ok) {
                                report.migrated++
                                removeKeys.push(jid)
                        } else {
                                logger.error('Migration role: gagal tulis profil untuk %s', jid)
                        }
                }

                // Hapus key legacy yang sudah diproses (sekali write di akhir)
                if (removeKeys.length > 0) {
                        for (const k of removeKeys) delete legacyRoles[k]
                        if (Object.keys(legacyRoles).length === 0) {
                                delete this.store.data.roles
                        }
                        storeDirty = true
                }

                // Backup entry yang didrop (sebelum/tanpa menunggu store write)
                if (Object.keys(droppedEntries).length > 0) {
                        report.backupFile = this._writeLegacyBackup(droppedEntries)
                }

                if (storeDirty) {
                        this.store._syncWrite()
                }

                logger.info(
                        'Migration role selesai: total %d | dimigrasi ke profil: %d | skip (sudah punya role): %d | expired: %d | didrop (belum terdaftar): %d%s',
                        report.total, report.migrated, report.skippedHasRole, report.expired, report.droppedNoProfile,
                        report.backupFile ? ` | backup: ${report.backupFile}` : ''
                )

                return report
        }

        // ============================================================
        // Permission
        // ============================================================

        /** Cek apakah userRole >= minRole berdasarkan hierarchy. */
        static hasPermission(userRole, minRole) {
                const userIdx = ROLE_HIERARCHY.indexOf(userRole)
                const minIdx = ROLE_HIERARCHY.indexOf(minRole)
                if (userIdx < 0 || minIdx < 0) return false
                return userIdx >= minIdx
        }

        /**
         * Normalisasi minRole dari metadata plugin.
         * minRole plugin berasal dari source plugin; nilai invalid → 'free' (+ warning).
         */
        static normalizeMinRole(minRole, pluginName = '?') {
                if (!minRole) return 'free'
                if (ROLE_HIERARCHY.includes(minRole)) return minRole
                logger.warn('Plugin %s punya minRole invalid: %s — diabaikan (fallback free). Role valid: %s', pluginName, minRole, ROLE_HIERARCHY.join(', '))
                return 'free'
        }

        // ============================================================
        // Private
        // ============================================================

        _free() {
                return { role: 'free', permanent: true, expires_at: null, set_at: null, found: false }
        }

        /**
         * Resolve identifier → user profile.
         * Gunakan index existing UserFileStore (pn/jid/lid/user_id/player_id) +
         * IdentifierRepository (index PN↔LID existing) — tidak membuat mapping baru.
         */
        _resolveProfile(identifier) {
                if (!identifier) return null

                let id = String(identifier).trim()

                // Nomor polos → PN JID (primitif kanonik identity — Phase 1)
                if (/^\d+$/.test(id)) {
                        id = toPnJid(id)
                }

                // Phase 1: rantai kanonik dimiliki UserRepository.findByIdentifier
                // (lib/identity) — sudah mencakup LID → PN via mapping identifiers
                // + back-fill lid (Task 58); cabang manual lama redundant → dihapus.
                return this.userRepo.findByIdentifier(id)
        }

        /** Hapus field role dari profil (single-file write). */
        _clearProfileRole(user) {
                try {
                        this.userRepo.updateByUserId(user.user_id, { role: null })
                } catch (e) {
                        logger.error('Gagal clear role profil %s: %s', user.user_id, e.message)
                }
        }

        /** Path file backup role legacy (store.role-backup.json), atau null jika path store tidak tersedia. */
        _backupPath() {
                try {
                        if (this.store?.path && typeof this.store.path === 'string') {
                                return this.store.path.replace(/\.json$/, '') + '.role-backup.json'
                        }
                } catch { /* store tanpa path (fake di test) — skip backup */ }
                return null
        }

        /**
         * Backup entry legacy yang didrop ke store.role-backup.json.
         * MERGE dengan isi backup lama (tidak pernah menimpa backup sebelumnya).
         * @param {Record<string, object>} entries - { jid: legacyEntry }
         * @returns {string|null} path backup, atau null jika tidak bisa menulis
         */
        _writeLegacyBackup(entries) {
                const backupPath = this._backupPath()
                if (!backupPath) {
                        logger.warn('Migration role: %d entry legacy didrop TANPA backup (path store tidak tersedia)', Object.keys(entries).length)
                        return null
                }

                let merged = {}
                try {
                        if (fs.existsSync(backupPath)) {
                                const prev = JSON.parse(fs.readFileSync(backupPath, 'utf8'))
                                if (prev?.entries && typeof prev.entries === 'object') merged = prev.entries
                        }
                } catch (e) {
                        logger.warn('Migration role: backup lama tidak terbaca (%s) — dibuat baru', e.message)
                }

                Object.assign(merged, entries)

                const payload = {
                        _info: 'Backup data role legacy dari store.json (dimigrasikan/didrop oleh RoleRepository). File ini tidak dibaca bot — hanya untuk recovery manual.',
                        backed_up_at: new Date().toISOString(),
                        entries: merged,
                }

                try {
                        const tmp = backupPath + '.tmp'
                        fs.writeFileSync(tmp, JSON.stringify(payload, null, 2), 'utf8')
                        fs.renameSync(tmp, backupPath)
                        return backupPath
                } catch (e) {
                        logger.error('Migration role: gagal tulis backup %s: %s', backupPath, e.message)
                        return null
                }
        }

        /** Hapus legacy entries dari store.json → roles (untuk identitas yang sudah dimigrasi). */
        _deleteLegacyEntries(identifiers) {
                const legacyRoles = this.store.data?.roles
                if (!legacyRoles || typeof legacyRoles !== 'object') return

                let changed = false
                for (const id of identifiers) {
                        if (id && legacyRoles[id] !== undefined) {
                                delete legacyRoles[id]
                                changed = true
                        }
                }
                if (changed) {
                        if (Object.keys(legacyRoles).length === 0) delete this.store.data.roles
                        this.store._syncWrite()
                }
        }
}
