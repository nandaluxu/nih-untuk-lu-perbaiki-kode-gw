import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import logger from '../lib/core/logger.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const USERS_DIR = path.join(__dirname, '..', 'users')

let _tmpSeq = 0

/**
 * UserFileStore — 1 file JSON per user.
 * Nama file = player_id (misal: nanda.json, nanda1.json).
 * Setiap file berisi data user + inventory.
 *
 * Index in-memory di-build saat load() untuk lookup cepat
 * (pn, jid, lid, user_id → player_id).
 *
 * Audit execution: tulis file kini ASYNC ter-queue per player (dulu
 * writeFileSync+renameSync di SETIAP mutasi economy — wallet/energy/regen —
 * memblokir event loop bot berulang-ulang; bersama spawnSync ffprobe ini
 * penyebab jam event-loop beku → pesan menumpuk → "command lama tiba-tiba
 * dieksekusi"). Cache tetap di-update SINKRON (read-after-write dari memory
 * aman); hanya I/O disk yang async dengan atomic tmp+rename + urutan
 * terjamin per player (chain). flushAllSync() dipanggil saat shutdown.
 */
export class UserFileStore {
        constructor() {
                /** @type {Map<string, object>} playerId → user data (in-memory cache) */
                this._cache = new Map()
                /** @type {Map<string, string>} userId → playerId */
                this._byUserId = new Map()
                /** @type {Map<string, string>} pn → playerId */
                this._byPN = new Map()
                /** @type {Map<string, string>} jid → playerId */
                this._byJID = new Map()
                /** @type {Map<string, string>} lid → playerId */
                this._byLID = new Map()
                /** @type {Map<string, object>} playerId → snapshot TERBARU yang belum ditulis */
                this._pending = new Map()
                /** @type {Map<string, Promise>} playerId → chain flush async aktif */
                this._chains = new Map()
                /** Shutdown: flushAllSync sudah jalan — loop async berhenti merename. */
                this._closed = false
        }

        /** Buat folder users/ kalau belum ada, lalu load semua file. */
        load() {
                if (!fs.existsSync(USERS_DIR)) {
                        fs.mkdirSync(USERS_DIR, { recursive: true })
                        logger.info('Folder users dibuat: %s', USERS_DIR)
                        return
                }

                const files = fs.readdirSync(USERS_DIR).filter(f => f.endsWith('.json'))
                for (const file of files) {
                        const playerId = file.slice(0, -5) // hapus .json
                        try {
                                const raw = fs.readFileSync(path.join(USERS_DIR, file), 'utf8')
                                const data = JSON.parse(raw)
                                this._indexUser(data)
                                this._cache.set(playerId, data)
                        } catch (e) {
                                logger.error('Gagal muat user file %s: %s', file, e.message)
                        }
                }

                logger.info('UserFileStore: %d user dimuat dari %s', this._cache.size, USERS_DIR)
        }

        // ---- Public Read API ----

        /** Baca user by player_id (dari cache). */
        read(playerId) {
                return this._cache.get(playerId) || null
        }

        /** Cari user by user_id. */
        findByUserId(userId) {
                const pid = this._byUserId.get(userId)
                if (!pid) return null
                return this._cache.get(pid) || null
        }

        /** Cari user by player_id. */
        findByPlayerId(playerId) {
                return this._cache.get(playerId) || null
        }

        /** Cari user by pn. */
        findByPN(pn) {
                const pid = this._byPN.get(pn)
                if (!pid) return null
                return this._cache.get(pid) || null
        }

        /** Cari user by jid. */
        findByJID(jid) {
                const pid = this._byJID.get(jid)
                if (!pid) return null
                return this._cache.get(pid) || null
        }

        /** Cari user by lid. */
        findByLID(lid) {
                const pid = this._byLID.get(lid)
                if (!pid) return null
                return this._cache.get(pid) || null
        }

        /** Cek apakah player_id sudah ada. */
        playerIdExists(playerId) {
                return this._cache.has(playerId)
        }

        /** Cari player_id dari user_id. */
        getPlayerIdByUserId(userId) {
                return this._byUserId.get(userId) || null
        }

        /** Ambil semua user objects. */
        listAll() {
                return Array.from(this._cache.values())
        }

        /** Cari username yang mengandung query. */
        searchUsername(query, limit = 20) {
                const q = query.toLowerCase()
                const results = []
                for (const u of this._cache.values()) {
                        if (u.username.toLowerCase().includes(q)) {
                                results.push(u)
                                if (results.length >= limit) break
                        }
                }
                return results
        }

        /** List semua player_id yang ada. */
        listPlayerIds() {
                return Array.from(this._cache.keys())
        }

        // ---- Public Write API ----

        /** Tulis user baru. Return data yang ditulis. */
        create(playerId, data) {
                const now = new Date().toISOString()
                const user = {
                        user_id: data.user_id,
                        player_id: playerId,
                        username: data.username,
                        age: data.age,
                        pn: data.pn || null,
                        jid: data.jid || null,
                        lid: data.lid || null,
                        registered_at: data.registered_at || now,
                        updated_at: data.updated_at || now,
                        wallet: data.wallet || 0,
                        bank: data.bank || 0,
                        energy: data.energy ?? 100,
                        last_energy_regen: now,
                        inventory: data.inventory || {},
                        // Task baru: stats akinator (per user)
                        akinator: data.akinator || {
                                totalGames: 0,
                                wins: 0,
                                losses: 0,
                                totalAttempts: 0,
                                totalSteps: 0,
                                fastestSteps: null,
                                longestSteps: null,
                                history: [],
                                charStats: {},
                                firstAt: null,
                                lastAt: null,
                        },
                }

                this._cache.set(playerId, user)
                this._indexUser(user)
                this._writeFile(playerId, user)
                return user
        }

        /** Update user by player_id (partial merge). */
        update(playerId, patch) {
                const existing = this._cache.get(playerId)
                if (!existing) return null

                const updated = { ...existing, ...patch, updated_at: new Date().toISOString() }
                this._cache.set(playerId, updated)
                this._reindexUser(updated)
                this._writeFile(playerId, updated)
                return updated
        }

        /** Update user by user_id (partial merge). */
        updateByUserId(userId, patch) {
                const playerId = this._byUserId.get(userId)
                if (!playerId) return null
                return this.update(playerId, patch)
        }

        /** Hapus user file. */
        remove(playerId) {
                const user = this._cache.get(playerId)
                if (!user) return

                this._unindexUser(user)
                this._cache.delete(playerId)

                try {
                        const filePath = this._filePath(playerId)
                        if (fs.existsSync(filePath)) fs.unlinkSync(filePath)
                } catch (e) {
                        logger.error('Gagal hapus user file %s: %s', playerId, e.message)
                }
        }

        /**
         * Rename player_id: pindah file, reindex cache, pertahankan SEMUA field
         * (wallet, bank, energy, last_energy_regen, inventory, akinator, dll).
         *
         * Return data baru, atau null kalau:
         *   - playerId lama tidak ada
         *   - newPlayerId sudah dipakai user lain
         *   - newPlayerId === oldPlayerId (return data existing)
         *
         * @param {string} oldPlayerId
         * @param {string} newPlayerId
         * @returns {object|null}
         */
        renamePlayerId(oldPlayerId, newPlayerId) {
                if (oldPlayerId === newPlayerId) {
                        return this._cache.get(oldPlayerId) || null
                }

                const existing = this._cache.get(oldPlayerId)
                if (!existing) return null
                if (this._cache.has(newPlayerId)) return null // sudah dipakai

                // 1. Unindex & hapus dari cache lama
                this._unindexUser(existing)
                this._cache.delete(oldPlayerId)

                // 2. Bentuk data baru — pertahankan semua field, hanya player_id & updated_at berubah
                const updated = {
                        ...existing,
                        player_id: newPlayerId,
                        updated_at: new Date().toISOString(),
                }

                // 3. Masukkan ke cache & index baru
                this._cache.set(newPlayerId, updated)
                this._indexUser(updated)

                // 4. Tulis file baru, hapus file lama
                this._writeFile(newPlayerId, updated)
                try {
                        const oldPath = this._filePath(oldPlayerId)
                        if (fs.existsSync(oldPath)) fs.unlinkSync(oldPath)
                } catch (e) {
                        logger.error('Gagal hapus file lama %s: %s', oldPlayerId, e.message)
                }

                return updated
        }

        // ---- Index Management ----

        _indexUser(user) {
                if (user.user_id) this._byUserId.set(user.user_id, user.player_id)
                if (user.pn) this._byPN.set(user.pn, user.player_id)
                if (user.jid) this._byJID.set(user.jid, user.player_id)
                if (user.lid) this._byLID.set(user.lid, user.player_id)
        }

        _reindexUser(user) {
                // Hapus index lama, rebuild
                this._unindexUser(user)
                this._indexUser(user)
        }

        _unindexUser(user) {
                if (user.user_id) this._byUserId.delete(user.user_id)
                if (user.pn) this._byPN.delete(user.pn)
                if (user.jid) this._byJID.delete(user.jid)
                if (user.lid) this._byLID.delete(user.lid)
        }

        // ---- File I/O ----

        _filePath(playerId) {
                return path.join(USERS_DIR, `${playerId}.json`)
        }

        /**
         * Jadwalkan tulis atomic ASYNC untuk player (audit execution).
         * Snapshot data disimpan di _pending; chain per player menulis
         * snapshot TERBARU (coalescing) dengan urutan terjamin.
         * Cache sudah di-update caller secara sinkron — fungsi ini tidak
         * memblokir event loop.
         */
        _writeFile(playerId, data) {
                this._pending.set(playerId, data)
                if (this._chains.has(playerId)) return // chain aktif akan ambil snapshot terbaru
                if (this._closed) return // shutdown: flushAllSync yang menuntaskan

                const chain = (async () => {
                        try {
                                while (this._pending.has(playerId) && !this._closed) {
                                        const snapshot = this._pending.get(playerId)
                                        this._pending.delete(playerId)
                                        await this._writeFileAsync(playerId, snapshot)
                                }
                        } catch (e) {
                                logger.error('Gagal menulis user file %s: %s', playerId, e.message)
                        } finally {
                                this._chains.delete(playerId)
                                // Data baru datang SELAMA flush jalan → jadwalkan lagi
                                if (this._pending.has(playerId) && !this._closed) {
                                        this._writeFile(playerId, this._pending.get(playerId))
                                }
                        }
                })()
                this._chains.set(playerId, chain)
        }

        /** Tulis atomic async (tmp unik + rename). @private */
        async _writeFileAsync(playerId, data) {
                const filePath = this._filePath(playerId)
                const tmp = `${filePath}.tmp-${process.pid}-${++_tmpSeq}`
                await fs.promises.writeFile(tmp, JSON.stringify(data, null, 2), 'utf8')
                // flushAllSync sudah menulis data terbaru → buang tmp lama,
                // JANGAN rename (snapshot ini lebih tua dari yang di disk).
                if (this._closed) {
                        await fs.promises.unlink(tmp).catch(() => {})
                        return
                }
                await fs.promises.rename(tmp, filePath)
        }

        /**
         * Flush sinkron SEMUA pending (dipanggil Bot.stop saat shutdown).
         * Setelah dipanggil, loop async berhenti merename supaya snapshot
         * lama tidak menimpa data terbaru yang barusan ditulis sinkron.
         */
        flushAllSync() {
                this._closed = true
                let written = 0
                for (const [playerId, data] of this._pending) {
                        try {
                                const filePath = this._filePath(playerId)
                                const tmp = `${filePath}.tmp-${process.pid}-${++_tmpSeq}`
                                fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8')
                                fs.renameSync(tmp, filePath)
                                this._pending.delete(playerId)
                                written++
                        } catch (e) {
                                logger.error('Gagal flush user file %s: %s', playerId, e.message)
                        }
                }
                if (written > 0) logger.info('UserFileStore: %d user file di-flush sinkron (shutdown)', written)
                return written
        }
}

/** Singleton */
let instance = null

export function getUserFileStore() {
        if (!instance) {
                instance = new UserFileStore()
                instance.load()
        }
        return instance
}