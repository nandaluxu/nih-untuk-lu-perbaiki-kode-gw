import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import logger from '../lib/core/logger.js'
import { applyJobExp, jobExpToNext, findJob } from '../lib/economy/jobs.js'
import { economy as economyCfg } from '../config/economy.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const DEFAULT_DATA_DIR = path.join(__dirname, '..', 'economy')

/**
 * EconomyStore — progresi job + statistik economy (work/transfer/rob/sell/buy)
 * dalam satu file JSON `economy/economy.json`. Pola sama dengan ActivityStore:
 *
 *   users["<jid>"]   → job (current, owned, jobs{id:{level,exp,totalExp,count,
 *                      earned,success,failed}}) + stats global all-time
 *   groups["<gjid>"] → users{jid:{work, sell, rob, transfer}} — PER GRUP
 *
 * IDENTITAS: key = sender JID (PN) — sama dengan ActivityStore, sehingga
 * leaderboard .lb work/.lb job bisa memakai daftar jid yang sama.
 *
 * PERFORMA: mutasi in-memory O(1); tulis disk DEBOUNCED (default 15s).
 * Atomic write (tmp+rename). File korup → backup .corrupt + mulai kosong.
 * Wallet/bank/energy/inventory TETAP di user file — store ini TIDAK menyimpan
 * saldo (tidak ada duplikasi economy).
 */
// Cache formatter day-key (LAT-007 sekelas): _touch jalan per mutasi
// work/transfer/rob/sell/buy — new Intl.DateTimeFormat per panggilan mahal.
const _touchDayFmt = new Intl.DateTimeFormat('en-CA', { timeZone: 'Asia/Jakarta' })

export class EconomyStore {
    /** @param {object} [opts] @param {string} [opts.dataDir] override folder (test) */
    constructor({ dataDir = DEFAULT_DATA_DIR } = {}) {
        this.dataDir = dataDir
        this.filePath = path.join(dataDir, 'economy.json')
        this.data = null
        this._dirty = false
        this._timer = null
        // LAT-004 (audit latency): flush 15s ASYNC — pola sama ActivityStore
        // (single-flight + coalescing + generation guard vs tulis sinkron).
        this._writing = false
        this._gen = 0
        this._mutSeq = 0 // naik di setiap mutasi — tulis async tahu apakah state berubah setelah snapshot
    }

    // ------------------------------------------------------------------
    // Load / save (pola ActivityStore)
    // ------------------------------------------------------------------

    load() {
        fs.mkdirSync(this.dataDir, { recursive: true })
        this.data = this._loadFile()
        this._ensureShape()
        this._startTimer()
        logger.info('Economy store dimuat: %d user, %d grup', Object.keys(this.data.users).length, Object.keys(this.data.groups).length)
        return this
    }

    _loadFile() {
        try {
            if (!fs.existsSync(this.filePath)) return null
            const parsed = JSON.parse(fs.readFileSync(this.filePath, 'utf8'))
            if (parsed && typeof parsed === 'object') return parsed
            return null
        } catch (e) {
            try { fs.copyFileSync(this.filePath, this.filePath + '.corrupt') } catch {}
            logger.error('Economy store korup, mulai kosong (backup .corrupt): %s', e.message)
            return null
        }
    }

    _ensureShape() {
        const d = this.data && typeof this.data === 'object' ? this.data : {}
        d.version = 1
        d.users = (d.users && typeof d.users === 'object') ? d.users : {}
        d.groups = (d.groups && typeof d.groups === 'object') ? d.groups : {}
        this.data = d
    }

    _write() {
        this._gen++ // tulis sinkron lebih baru → tulis async in-flight membuang tmp-nya
        const tmp = `${this.filePath}.tmp-${process.pid}`
        try {
            fs.writeFileSync(tmp, JSON.stringify(this.data), 'utf8')
            fs.renameSync(tmp, this.filePath)
            this._dirty = false
        } catch (e) {
            logger.error('Gagal menulis economy store: %s', e.message)
            try { fs.unlinkSync(tmp) } catch {}
        }
    }

    /** Tulis atomic ASYNC (LAT-004) — jalur timer; single-flight + coalescing.
     *  Mutasi selama menulis (mutSeq naik setelah snapshot) → _dirty tetap true
     *  → siklus berikutnya menulis state terbaru. */
    _flushAsync() {
        if (!this._dirty || this._writing) return
        this._writing = true
        const gen = this._gen
        const seq = this._mutSeq
        const tmp = `${this.filePath}.tmp-${process.pid}-${Date.now()}`
        const payload = JSON.stringify(this.data)
        fs.promises.writeFile(tmp, payload, 'utf8')
            .then(() => {
                if (gen !== this._gen) {
                    return fs.promises.unlink(tmp).catch(() => {})
                }
                return fs.promises.rename(tmp, this.filePath).then(() => {
                    if (seq === this._mutSeq) this._dirty = false
                })
            })
            .catch((e) => {
                logger.error('Gagal menulis economy store (async): %s', e.message)
                fs.promises.unlink(tmp).catch(() => {})
            })
            .finally(() => {
                this._writing = false
                if (this._dirty) this._flushAsync()
            })
    }

    /** Tandai ada perubahan (dipakai semua method mutasi — naikkan mutSeq). */
    _markDirty() {
        this._dirty = true
        this._mutSeq++
    }

    flush() { if (this._dirty) this._write() }

    _startTimer() {
        this.stopTimer()
        this._timer = setInterval(() => this._flushAsync(), economyCfg.stats.flushMs)
        if (typeof this._timer.unref === 'function') this._timer.unref()
    }

    stopTimer() {
        if (this._timer) { clearInterval(this._timer); this._timer = null }
    }

    close() { this.stopTimer(); this.flush() }

    // ------------------------------------------------------------------
    // Internal blank records
    // ------------------------------------------------------------------

    _user(jid) {
        let u = this.data.users[jid]
        if (!u || typeof u !== 'object') {
            u = {
                job: { current: null, owned: [], changedAt: null, changeCount: 0, jobs: {} },
                stats: this._blankStats(),
                firstDay: null, lastDay: null,
            }
            this.data.users[jid] = u
        }
        u.job = u.job && typeof u.job === 'object' ? u.job : { current: null, owned: [], changedAt: null, changeCount: 0, jobs: {} }
        u.job.owned = Array.isArray(u.job.owned) ? u.job.owned : []
        u.job.jobs = u.job.jobs && typeof u.job.jobs === 'object' ? u.job.jobs : {}
        u.stats = u.stats && typeof u.stats === 'object' ? { ...this._blankStats(), ...u.stats } : this._blankStats()
        return u
    }

    _blankStats() {
        return {
            work: { count: 0, success: 0, great: 0, perfect: 0, failed: 0, critFailed: 0, earned: 0, expGained: 0 },
            transfer: { sentCount: 0, sentAmount: 0, recvCount: 0, recvAmount: 0, feesPaid: 0 },
            rob: { attempts: 0, success: 0, failed: 0, stolen: 0, lost: 0 },
            sell: { count: 0, items: 0, earned: 0 },
            buy: { count: 0, items: 0, spent: 0 },
        }
    }

    _blankJobRecord(now = new Date()) {
        return { level: 1, exp: 0, totalExp: 0, count: 0, earned: 0, success: 0, failed: 0, startedAt: now.toISOString(), lastWork: null }
    }

    _group(gjid) {
        let g = this.data.groups[gjid]
        if (!g || typeof g !== 'object' || typeof g.users !== 'object') {
            g = { users: {} }
            this.data.groups[gjid] = g
        }
        g.users = g.users && typeof g.users === 'object' ? g.users : {}
        return g
    }

    _groupUser(gjid, jid) {
        const g = this._group(gjid)
        let gu = g.users[jid]
        if (!gu || typeof gu !== 'object') {
            gu = {
                work: { count: 0, earned: 0 },
                sell: { count: 0, earned: 0 },
                rob: { attempts: 0, success: 0, stolen: 0, lost: 0 },
                transfer: { sentCount: 0, sentAmount: 0 },
            }
            g.users[jid] = gu
        }
        return gu
    }

    _touch(u, now = new Date()) {
        const day = _touchDayFmt.format(now)
        if (!u.firstDay) u.firstDay = day
        u.lastDay = day
    }

    // ------------------------------------------------------------------
    // Job
    // ------------------------------------------------------------------

    /**
     * Set job aktif user. Job pertama gratis; pindah job = tanggung jawab
     * plugin (fee/cooldown) — store hanya mencatat. EXP per-job tidak pernah
     * direset (keepExp). Job baru otomatis masuk daftar owned.
     */
    setJob({ userJid, jobId, now = new Date() }) {
        if (!userJid || !jobId) return null
        const job = findJob(jobId)
        if (!job) return null
        const u = this._user(userJid)
        if (!u.job.owned.includes(job.id)) u.job.owned.push(job.id)
        if (!u.job.jobs[job.id]) u.job.jobs[job.id] = this._blankJobRecord(now)
        const prev = u.job.current
        u.job.current = job.id
        if (prev !== job.id) {
            u.job.changeCount = (u.job.changeCount || 0) + 1
            u.job.changedAt = now.toISOString()
        }
        this._touch(u, now)
        this._dirty = true
        this._mutSeq++
        return { current: job.id, previous: prev, record: { ...u.job.jobs[job.id] } }
    }

    /** Apakah user pernah membuka/memakai job ini? (job gratis auto-owned saat dipilih) */
    ownsJob(userJid, jobId) {
        const u = this.data.users[userJid]
        return Boolean(u?.job?.owned?.includes(jobId))
    }

    /** Snapshot job aktif + progress EXP (untuk profile/jobinfo/work). */
    getJob(userJid) {
        const u = this.data.users[userJid]
        if (!u?.job) return null
        const current = u.job.current
        const rec = current ? u.job.jobs[current] : null
        const level = rec?.level || 1
        const needed = jobExpToNext(level)
        const exp = rec?.exp || 0
        return {
            current,
            changedAt: u.job.changedAt || null,
            changeCount: u.job.changeCount || 0,
            owned: [...(u.job.owned || [])],
            jobs: Object.fromEntries(Object.entries(u.job.jobs).map(([id, r]) => [id, { ...r }])),
            level,
            exp,
            expNeeded: needed,
            progress: { current: Math.min(exp, needed), needed, pct: needed > 0 ? Math.floor((Math.min(exp, needed) / needed) * 100) : 0 },
        }
    }

    /** Tambah EXP ke job tertentu (dipakai engine work). Return state baru. */
    addJobExp({ userJid, jobId, exp, now = new Date() }) {
        if (!userJid || !jobId) return null
        const u = this._user(userJid)
        const rec = u.job.jobs[jobId] || (u.job.jobs[jobId] = this._blankJobRecord(now))
        const res = applyJobExp({ level: rec.level, exp: rec.exp }, exp)
        rec.level = res.level
        rec.exp = res.exp
        rec.totalExp = (rec.totalExp || 0) + res.expGained
        this._touch(u, now)
        this._dirty = true
        this._mutSeq++
        return res
    }

    // ------------------------------------------------------------------
    // Record transaksi / sesi
    // ------------------------------------------------------------------

    /**
     * Catat 1 sesi work selesai (semua grade). Update stats global, record
     * job (count/earned/success/failed + EXP), dan statistik grup.
     * @returns {object|null} hasil applyJobExp job aktif
     */
    recordWork({ userJid, groupJid = null, jobId, grade, earned = 0, expGained = 0, now = new Date() }) {
        if (!userJid || !jobId) return null
        const u = this._user(userJid)
        const ok = grade === 'perfect' || grade === 'great' || grade === 'success'

        const s = u.stats.work
        s.count += 1
        s.earned += Math.max(0, earned)
        s.expGained += Math.max(0, expGained)
        if (ok) {
            s.success += 1
            if (grade === 'perfect') s.perfect += 1
            else if (grade === 'great') s.great += 1
        } else if (grade === 'crit_failed') s.critFailed += 1
        else s.failed += 1

        const rec = u.job.jobs[jobId] || (u.job.jobs[jobId] = this._blankJobRecord(now))
        rec.count += 1
        rec.earned += Math.max(0, earned)
        rec.lastWork = now.toISOString()
        if (ok) rec.success += 1
        else rec.failed += 1

        if (groupJid && typeof groupJid === 'string') {
            const gu = this._groupUser(groupJid, userJid)
            gu.work.count += 1
            gu.work.earned += Math.max(0, earned)
        }

        this._touch(u, now)
        const res = this.addJobExp({ userJid, jobId, exp: expGained, now })
        this._dirty = true
        this._mutSeq++
        return res
    }

    /** Catat transfer (pengirim + penerima + fee). amount = yang dikirim. */
    recordTransfer({ fromJid, toJid, groupJid = null, amount = 0, fee = 0, now = new Date() }) {
        if (!fromJid || !toJid || !(amount > 0)) return
        const from = this._user(fromJid)
        from.stats.transfer.sentCount += 1
        from.stats.transfer.sentAmount += amount
        from.stats.transfer.feesPaid += Math.max(0, fee)
        this._touch(from, now)

        const to = this._user(toJid)
        to.stats.transfer.recvCount += 1
        to.stats.transfer.recvAmount += amount
        this._touch(to, now)

        if (groupJid && typeof groupJid === 'string') {
            const gu = this._groupUser(groupJid, fromJid)
            gu.transfer.sentCount += 1
            gu.transfer.sentAmount += amount
        }
        this._dirty = true
        this._mutSeq++
    }

    /** Catat percobaan rob (kedua pihak). amount = uang curi; penalty = denda perampok. */
    recordRob({ robberJid, targetJid, groupJid = null, success = false, amount = 0, penalty = 0, now = new Date() }) {
        if (!robberJid || !targetJid) return
        const robber = this._user(robberJid)
        robber.stats.rob.attempts += 1
        if (success) {
            robber.stats.rob.success += 1
            robber.stats.rob.stolen += Math.max(0, amount)
        } else {
            robber.stats.rob.failed += 1
            robber.stats.rob.lost += Math.max(0, penalty)
        }
        this._touch(robber, now)

        const target = this._user(targetJid)
        if (success) target.stats.rob.lost += Math.max(0, amount)
        this._touch(target, now)

        if (groupJid && typeof groupJid === 'string') {
            const gu = this._groupUser(groupJid, robberJid)
            gu.rob.attempts += 1
            if (success) { gu.rob.success += 1; gu.rob.stolen += Math.max(0, amount) }
            else gu.rob.lost += Math.max(0, penalty)
        }
        this._dirty = true
        this._mutSeq++
    }

    /** Catat penjualan item. */
    recordSell({ userJid, groupJid = null, quantity = 0, earned = 0, now = new Date() }) {
        if (!userJid) return
        const u = this._user(userJid)
        u.stats.sell.count += 1
        u.stats.sell.items += Math.max(0, quantity)
        u.stats.sell.earned += Math.max(0, earned)
        this._touch(u, now)

        if (groupJid && typeof groupJid === 'string') {
            const gu = this._groupUser(groupJid, userJid)
            gu.sell.count += 1
            gu.sell.earned += Math.max(0, earned)
        }
        this._dirty = true
        this._mutSeq++
    }

    /** Catat pembelian item. */
    recordBuy({ userJid, groupJid = null, quantity = 0, spent = 0, now = new Date() }) {
        if (!userJid) return
        const u = this._user(userJid)
        u.stats.buy.count += 1
        u.stats.buy.items += Math.max(0, quantity)
        u.stats.buy.spent += Math.max(0, spent)
        this._touch(u, now)
        this._dirty = true
        this._mutSeq++
    }

    // ------------------------------------------------------------------
    // Read
    // ------------------------------------------------------------------

    /** Snapshot statistik lengkap 1 user. */
    getStats(userJid) {
        const u = this.data.users[userJid]
        if (!u) return null
        return {
            stats: {
                work: { ...u.stats.work },
                transfer: { ...u.stats.transfer },
                rob: { ...u.stats.rob },
                sell: { ...u.stats.sell },
                buy: { ...u.stats.buy },
            },
            firstDay: u.firstDay || null,
            lastDay: u.lastDay || null,
        }
    }

    /** Statistik economy 1 user dalam 1 grup (untuk .gstat dsb — opsional). */
    getGroupUser(groupJid, userJid) {
        const gu = this.data.groups[groupJid]?.users?.[userJid]
        if (!gu) return null
        return { work: { ...gu.work }, sell: { ...gu.sell }, rob: { ...gu.rob }, transfer: { ...gu.transfer } }
    }

    /**
     * Agregasi utk leaderboard (dipasang ke ActivityStore.setEconomyProvider).
     * @param {string[]} jids daftar user jid yang difilter scope
     * @param {{type:'global'|'group', jid?:string}} [scope]
     * @returns {Map<string, {workEarned:number, workCount:number, jobLevel:number,
     *                     jobExp:number, jobName:string|null}>}
     *   workEarned: scope group → hasil kerja DI GRUP itu; global → all-time.
     *   jobLevel/jobExp/jobName: atribut GLOBAL user (sama seperti level).
     */
    aggregate(jids, scope = { type: 'global' }) {
        const map = new Map()
        const isGroup = scope?.type === 'group' && scope.jid
        for (const jid of jids || []) {
            const u = this.data.users[jid]
            if (!u) continue
            const jobRec = u.job?.current ? u.job.jobs[u.job.current] : null
            let workEarned = 0
            let workCount = 0
            if (isGroup) {
                const gu = this.data.groups[scope.jid]?.users?.[jid]
                if (gu) { workEarned = gu.work.earned; workCount = gu.work.count }
            } else {
                workEarned = u.stats.work.earned
                workCount = u.stats.work.count
            }
            const jobMeta = u.job?.current ? findJob(u.job.current) : null
            map.set(jid, {
                workEarned,
                workCount,
                jobLevel: jobRec?.level || 0,
                jobExp: jobRec?.exp || 0,
                jobName: jobMeta ? jobMeta.name : null,
            })
        }
        return map
    }
}
