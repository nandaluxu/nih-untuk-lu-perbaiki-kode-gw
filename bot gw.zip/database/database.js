import { getStore, closeStore } from './json-store.js'
import logger from '../lib/core/logger.js'

let _store = null

export function getDatabase() {
	if (!_store) {
		_store = getStore()
		logger.info('Database (JSON) dimuat')
	}
	return _store
}

export function closeDatabase() {
	closeStore()
}