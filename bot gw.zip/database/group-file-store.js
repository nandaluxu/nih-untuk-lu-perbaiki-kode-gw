import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import logger from '../lib/core/logger.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const GROUPS_DIR = path.join(__dirname, '..', 'groups')

/**
 * GroupFileStore — 1 file JSON per grup.
 * Nama file = group ID (bagian sebelum @g.us).json.
 * Data: { jid, prefix, nsfw }
 */
export class GroupFileStore {
	constructor() {
		/** @type {Map<string, object>} jid → group data */
		this._cache = new Map()
	}

	/** Buat folder groups/ kalau belum ada, lalu load semua file. */
	load() {
		if (!fs.existsSync(GROUPS_DIR)) {
			fs.mkdirSync(GROUPS_DIR, { recursive: true })
			logger.info('Folder groups dibuat: %s', GROUPS_DIR)
			return
		}

		const files = fs.readdirSync(GROUPS_DIR).filter(f => f.endsWith('.json'))
		for (const file of files) {
			const gid = file.slice(0, -5)
			try {
				const raw = fs.readFileSync(path.join(GROUPS_DIR, file), 'utf8')
				const data = JSON.parse(raw)
				this._cache.set(data.jid || gid + '@g.us', data)
			} catch (e) {
				logger.error('Gagal muat group file %s: %s', file, e.message)
			}
		}

		logger.info('GroupFileStore: %d grup dimuat dari %s', this._cache.size, GROUPS_DIR)
	}

	// ---- Public API ----

	/** JID grup → group ID (angka sebelum @g.us). */
	static toGroupId(jid) {
		return jid ? jid.split('@')[0] : jid
	}

	/** Baca data grup (dari cache). Return default kalau belum ada. */
	get(jid) {
		if (this._cache.has(jid)) return this._cache.get(jid)
		const def = this._defaultData(jid)
		this._cache.set(jid, def)
		return def
	}

	/** Ambil prefix khusus grup. null = pakai global. */
	getPrefix(jid) {
		return this.get(jid).prefix ?? null
	}

	/** Set prefix khusus grup. null = hapus (pakai global). */
	setPrefix(jid, prefix) {
		const data = this.get(jid)
		data.prefix = prefix
		this._writeFile(jid, data)
	}

	/** Cek apakah NSFW aktif di grup. */
	getNsfw(jid) {
		return this.get(jid).nsfw === true
	}

	/** Set NSFW on/off di grup. */
	setNsfw(jid, enabled) {
		const data = this.get(jid)
		data.nsfw = enabled
		this._writeFile(jid, data)
	}

	// ---- Internal ----

	_defaultData(jid) {
		return { jid, prefix: null, nsfw: false }
	}

	_filePath(jid) {
		const gid = GroupFileStore.toGroupId(jid)
		return path.join(GROUPS_DIR, `${gid}.json`)
	}

	_writeFile(jid, data) {
		try {
			const filePath = this._filePath(jid)
			const tmpPath = filePath + '.tmp'
			fs.writeFileSync(tmpPath, JSON.stringify(data, null, 2), 'utf8')
			fs.renameSync(tmpPath, filePath)
		} catch (e) {
			logger.error('Gagal menulis group file %s: %s', jid, e.message)
		}
	}
}

/** Singleton */
let instance = null

export function getGroupFileStore() {
	if (!instance) {
		instance = new GroupFileStore()
		instance.load()
	}
	return instance
}
