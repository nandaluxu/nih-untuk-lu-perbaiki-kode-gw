/** Separator internal kunci pasangan pn+lid (karakter yang tak mungkin muncul di JID). */
const PAIR_SEP = '\u0000'

/**
 * IdentifierRepository — pemilik PERSISTENCE mapping PN↔LID
 * (store/identifiers.json via JsonStore: debounced atomic write — TIDAK berubah).
 *
 * PHASE 1 (fix F-16 P0): lookup/upsert kini O(1) via tiga Map in-memory
 * (byPn / byLid / byPair) — bukan lagi array.find/findIndex linear.
 *
 * PARITAS SEMANTIK PERSIS dengan implementasi array lama:
 *   - findByPN/findByLID mengembalikan entri PERTAMA yang cocok
 *     (first-wins — Map dibangun sekali dari urutan array).
 *   - upsert(pn, lid, ...) memakai predikat findIndex lama:
 *       pn && lid → cocok baris dengan pasangan (pn, lid) EKSAK;
 *       pn saja   → baris pertama dengan pn sama;
 *       lid saja  → baris pertama dengan lid sama;
 *     tidak ketemu → PUSH entri baru (bukan merge parsial).
 *   - format entri { pn, lid, jid, user_id, discovered_at } TIDAK berubah
 *     (reload parity dengan 786 entri existing).
 *
 * PRUNING: sengaja BELUM (metadata cuma discovered_at — belum cukup untuk
 * memutuskan aman-dihapus; lihat IDENTITY-CONSOLIDATION-REPORT §12).
 * findByUserId tetap linear filter (jalur admin jarang, bukan hot path).
 */
export class IdentifierRepository {
        constructor(store) {
                this.store = store
                this._byPn = new Map()
                this._byLid = new Map()
                this._byPair = new Map()
                this._rebuildIndex()
        }

        /** Bangun ulang index dari data store (dipanggil saat konstruksi). */
        _rebuildIndex() {
                this._byPn = new Map()
                this._byLid = new Map()
                this._byPair = new Map()
                const ids = this.store?.data?.identifiers
                if (!Array.isArray(ids)) return
                for (let i = 0; i < ids.length; i++) {
                        this._indexEntry(i, ids[i])
                }
        }

        /** Index satu entri (first-wins: kunci yang sudah ada tidak ditimpa). */
        _indexEntry(idx, entry) {
                if (!entry) return
                if (entry.pn && !this._byPn.has(entry.pn)) this._byPn.set(entry.pn, idx)
                if (entry.lid && !this._byLid.has(entry.lid)) this._byLid.set(entry.lid, idx)
                if (entry.pn && entry.lid) {
                        const k = entry.pn + PAIR_SEP + entry.lid
                        if (!this._byPair.has(k)) this._byPair.set(k, idx)
                }
        }

        /** Insert atau update mapping PN <-> LID. */
        upsert(pn, lid, jid, userId) {
                const ids = this.store.data.identifiers
                // Predikat findIndex lama: pair-eksak → pn → lid (first-match)
                let idx = -1
                if (pn && lid) {
                        idx = this._byPair.get(pn + PAIR_SEP + lid) ?? -1
                } else if (pn) {
                        idx = this._byPn.get(pn) ?? -1
                } else if (lid) {
                        idx = this._byLid.get(lid) ?? -1
                }

                const entry = {
                        pn: pn || null,
                        lid: lid || null,
                        jid: jid || null,
                        user_id: userId || null,
                        discovered_at: new Date().toISOString(),
                }

                if (idx >= 0) {
                        const old = ids[idx]
                        // Lepas kunci lama yang menunjuk idx ini (bila masih menunjuk sini)
                        if (old?.pn && this._byPn.get(old.pn) === idx) this._byPn.delete(old.pn)
                        if (old?.lid && this._byLid.get(old.lid) === idx) this._byLid.delete(old.lid)
                        if (old?.pn && old?.lid) {
                                const k = old.pn + PAIR_SEP + old.lid
                                if (this._byPair.get(k) === idx) this._byPair.delete(k)
                        }
                        ids[idx] = entry
                } else {
                        idx = ids.length
                        ids.push(entry)
                }
                this._indexEntry(idx, entry)
                this.store.writeDirty?.('identifiers')
        }

        /** Entri pertama dengan pn cocok (O(1)). */
        findByPN(pn) {
                if (!pn) return null
                const idx = this._byPn.get(pn)
                return idx === undefined ? null : (this.store.data.identifiers[idx] || null)
        }

        /** Entri pertama dengan lid cocok (O(1)). */
        findByLID(lid) {
                if (!lid) return null
                const idx = this._byLid.get(lid)
                return idx === undefined ? null : (this.store.data.identifiers[idx] || null)
        }

        findByUserId(userId) {
                return this.store.data.identifiers.filter(i => i.user_id === userId)
        }

        /**
         * TASK 26 (LB dobel nama): daftar seluruh mapping PN↔LID (copy)
         * — dipakai peta identitas LID-core → PN untuk leaderboard
         * (mapping terpelajar dari event lid-mapping.update).
         */
        list() {
                try {
                        return Array.from(this.store?.data?.identifiers || [])
                } catch {
                        return []
                }
        }
}
