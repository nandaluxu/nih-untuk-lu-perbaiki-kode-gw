/**
 * user-progression — PROGRESSION USER (level/EXP/streak) MILIK USER DB.
 *
 * TASK 23 (ownership refactor) — pertanyaan yang dijawab modul ini:
 *   "Kenapa data user ditumpuk di ActivityStore padahal user sudah punya
 *    DB sendiri?" — jawabannya: TIDAK ADA alasan arsitektural yang valid.
 *    Level/EXP/totalExp/streak adalah PERSISTENT USER PROGRESSION, dan
 *    User DB (users/<player_id>.json — UserFileStore) sudah menyediakan
 *    penyimpanan persistent per user. Menaruhnya di ActivityStore hanya
 *    warisan desain lama (fitur leveling tumbuh dari fitur statistik
 *    pesan — applyExp ditempel di recordMessage). Akibatnya progression
 *    user diambil sebagai "sandera" kesehatan ActivityStore: file
 *    activity/user.json dihapus / diganti backup lama / korup = level,
 *    EXP, streak, seluruh progression user ikut hilang/rollback.
 *
 * Kontrak SETELAH refactor (pemilik tunggal — tanpa dua source of truth):
 *   - USER DB (users/*.json)        → source of truth PERSISTENT USER STATE:
 *                                     identitas + economy + INVENTORY +
 *                                     PROGRESSION {level, exp, totalExp,
 *                                     streak{count,best,lastDay}}.
 *   - GROUP DB (groups/*.json + store/settings.json) → source of truth
 *                                     konfigurasi grup (tidak berubah).
 *   - ActivityStore (activity/*.json) → ACTIVITY/ANALYTICS SAJA: chat/cmd
 *     counters, bucket harian, commandNames, firstDay/lastDay/lastActive.
 *     TIDAK lagi menyimpan level/EXP/streak — schema v3 menolak field itu.
 *
 * Konsekuensi desain (eksplisit, bukan bug):
 *   - Progression hanya bagi user TERDAFTAR (punya baris user DB — .daftar).
 *     Task 36 memang mewajibkan registrasi untuk command; analitik chat/cmd
 *     tetap dicatat untuk SEMUA pengirim (analytics ≠ progression).
 *   - Unregistered sender yang sebelumnya punya level di activity/user.json:
 *     datanya TIDAK dipindah (tidak ada baris user tujuan) — progression
 *     dimulai saat ia mendaftar. Ini trade-off eksplisit dari pemisahan
 *     ownership; didokumentasikan di AUDIT-REPORT.
 *
 * TRANSFER kepemilikan SEKALI (bukan fallback, bukan legacy-read):
 *   migrateProgressionFromActivityOnce() — dipanggil bot.js SEBELUM
 *   ActivityStore.load(): membaca activity/user.json (schema v2 yang SAH,
 *   BUKAN legacy activity/activity.json — file itu tetap tidak pernah
 *   disentuh), menyalin {level,exp,totalExp,streak} ke baris user yang
 *   belum punya progression, lalu menulis marker store/progression_
 *   migration.json supaya idempotent. Setelah marker ada, jalur ini MATI
 *   PERMANEN — ActivityStore v3 kemudian men-drop field progression dari
 *   activity/user.json sebagai key asing (self-healing flush). Ini
 *   pemindahan kepemilikan data live sekali-jalan, bukan path kompatibilitas
 *   runtime: progression tidak pernah dibaca kembali dari activity/.
 */
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import logger from '../lib/core/logger.js'
import { applyExp, dayKey } from '../lib/economy/leveling.js'
// PHASE 1 (identity consolidation): rantai lookup kanonik lib/identity.
import { resolveProfileByIdentifier } from '../lib/identity/index.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const ACTIVITY_USER_FILE = path.join(__dirname, '..', 'activity', 'user.json')
const MARKER_FILE = path.join(__dirname, '..', 'store', 'progression_migration.json')

/** Field progression yang dimiliki USER DB. */
export const PROGRESSION_FIELDS = ['level', 'exp', 'totalExp', 'streak']

/** Progression default user baru. */
export function blankProgression() {
        return {
                level: 1,
                exp: 0,
                totalExp: 0,
                streak: { count: 0, best: 0, lastDay: null },
        }
}

/** Progression ternormalisasi dari baris user (atau default). */
export function progressionOf(user) {
        const p = user?.progression
        if (!p || typeof p !== 'object') return blankProgression()
        const streak = p.streak && typeof p.streak === 'object' ? p.streak : {}
        return {
                level: Math.max(1, Number(p.level) || 1),
                exp: Math.max(0, Number(p.exp) || 0),
                totalExp: Math.max(0, Number(p.totalExp) || 0),
                streak: {
                        count: Math.max(0, Number(streak.count) || 0),
                        best: Math.max(0, Number(streak.best) || 0),
                        lastDay: typeof streak.lastDay === 'string' ? streak.lastDay : null,
                },
        }
}

// ============================================================
// Transfer kepemilikan (sekali)
// ============================================================

/**
 * Cari statistik user di map activity lama berdasarkan identifier baris user.
 * Key activity = JID (pn / jid / lid — urutan dicoba semua).
 */
function _findLegacyStat(activityUsers, user) {
        const keys = [user?.pn, user?.jid, user?.lid].filter(Boolean)
        for (const k of keys) {
                const stat = activityUsers?.[k]
                if (stat && typeof stat === 'object') return stat
        }
        return null
}

/**
 * TRANSFER SEKALI: activity/user.json (v2) → baris user DB.
 * Idempotent lewat marker file; fail-safe (JSON korup → skip).
 * @param {object} [opts] { ufs, activityUserFile?, markerFile?, force? } (test)
 * @returns {{transferred:number, skippedRegistered:number, markerWritten:boolean, alreadyDone:boolean}}
 */
export function migrateProgressionFromActivityOnce(opts = {}) {
        const ufs = opts.ufs
        const activityFile = opts.activityUserFile || ACTIVITY_USER_FILE
        const markerFile = opts.markerFile || MARKER_FILE

        // Marker → sudah pernah jalan (atau dipaksa ulang oleh test).
        let marker = null
        try {
                if (fs.existsSync(markerFile)) marker = JSON.parse(fs.readFileSync(markerFile, 'utf8'))
        } catch { /* marker korup → jalankan ulang (idempotent by-design) */ }
        if (marker?.done && !opts.force) {
                return { alreadyDone: true, transferred: 0, markerWritten: false }
        }

        const result = { alreadyDone: false, transferred: 0, markerWritten: false }

        // Baca statistik v2 (hanya file activity/user.json yang SAH — legacy
        // activity/activity.json TIDAK PERNAH disentuh).
        let activityUsers = null
        try {
                if (fs.existsSync(activityFile)) {
                        const raw = JSON.parse(fs.readFileSync(activityFile, 'utf8'))
                        activityUsers = raw && typeof raw === 'object' ? raw : null
                }
        } catch (e) {
                logger.warn('[progression-migrate] activity/user.json korup/diabaikan: %s', e.message)
        }

        if (activityUsers && ufs && typeof ufs.listAll === 'function') {
                const users = ufs.listAll()
                for (const user of users) {
                        if (!user?.player_id) continue
                        if (user.progression) continue // sudah punya progression → jangan timpa
                        const stat = _findLegacyStat(activityUsers, user)
                        if (!stat) continue
                        const streak = stat.streak && typeof stat.streak === 'object' ? stat.streak : {}
                        user.progression = {
                                level: Math.max(1, Number(stat.level) || 1),
                                exp: Math.max(0, Number(stat.exp) || 0),
                                totalExp: Math.max(0, Number(stat.totalExp) || 0),
                                streak: {
                                        count: Math.max(0, Number(streak.count) || 0),
                                        best: Math.max(0, Number(streak.best) || 0),
                                        lastDay: typeof streak.lastDay === 'string' ? streak.lastDay : null,
                                },
                        }
                        // Persist via API publik (chain write async + atomic).
                        try { ufs.update(user.player_id, { progression: user.progression }) } catch {}
                        result.transferred++
                }
        }

        // Tulis marker (atomic best-effort).
        try {
                const dir = path.dirname(markerFile)
                if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })
                const tmp = `${markerFile}.${process.pid}.tmp`
                fs.writeFileSync(tmp, JSON.stringify({
                        done: true,
                        at: new Date().toISOString(),
                        transferred: result.transferred,
                }, null, 2))
                fs.renameSync(tmp, markerFile)
                result.markerWritten = true
        } catch (e) {
                logger.warn('[progression-migrate] marker gagal ditulis (non-fatal): %s', e.message)
        }

        logger.info(
                '[progression-migrate] transfer kepemilikan progression → USER DB selesai: %d user dipindah (sisa field progression di activity/user.json akan di-drop oleh schema v3)',
                result.transferred,
        )
        return result
}

// ============================================================
// WRITE — mutation progression (pemilik tulis: modul ini SAJA)
// ============================================================

/**
 * Terapkan +1 EXP & streak harian untuk baris user (dipanggil bot.js per
 * pesan chat live, jalur sama dengan yang lama di recordMessage).
 * Mutasi IN-PLACE pada objek user + persist via ufs.update (chain async).
 * @param {object} user baris user (dari UserFileStore — WAJIB punya player_id)
 * @param {object} [ufs] UserFileStore (persist; null = test tanpa I/O)
 * @param {Date} [now]
 * @returns {{leveledUp:boolean, level:number, levelsGained:number, streak:number}|null}
 */
export function applyMessageProgression(user, ufs = null, now = new Date()) {
        if (!user || !user.player_id) return null
        const p = progressionOf(user)
        const day = dayKey(now)

        // --- streak harian (progression — logika identik dengan yang lama) ---
        if (p.streak.lastDay !== day) {
                const yesterday = dayKey(new Date(now.getTime() - 86400000))
                p.streak.count = p.streak.lastDay === yesterday ? (p.streak.count || 0) + 1 : 1
                p.streak.count = Math.max(1, p.streak.count)
                p.streak.best = Math.max(p.streak.best || 0, p.streak.count)
                p.streak.lastDay = day
        }

        // --- EXP per pesan (jalur applyExp yang sama) ---
        const res = applyExp({ level: p.level, exp: p.exp }, 1)
        p.level = res.level
        p.exp = res.exp
        p.totalExp = (p.totalExp || 0) + res.expGained

        user.progression = p
        try { if (ufs) ufs.update(user.player_id, { progression: p }) } catch {}
        return {
                leveledUp: res.leveledUp,
                level: res.level,
                levelsGained: res.levelsGained,
                streak: p.streak.count,
        }
}

/**
 * Berikan EXP reward (game menang, dsb) — pengganti ActivityStore.grantExp.
 * Jalur penulisan progression yang sama (satu pemilik tulis).
 * @param {object} ufs UserFileStore
 * @param {string} identifier pn/jid/lid/user_id/player_id
 * @param {number} amount
 * @returns {{leveledUp:boolean, level:number, levelsGained:number}|null}
 */
export function grantUserExp(ufs, identifier, amount) {
        if (!ufs || !identifier) return null
        const add = Math.max(0, Math.floor(Number(amount) || 0))
        if (add <= 0) return null
        // Phase 1: rantai kanonik lib/identity — PN→JID→LID→UserId→PlayerId
        // (paritas urutan lama; tanpa idRepo: tanpa mapping LID→PN —
        // reward game memang identitas-sederhana, behavior sama).
        const user = resolveProfileByIdentifier(ufs, null, identifier)
        if (!user) return null
        const p = progressionOf(user)
        const res = applyExp({ level: p.level, exp: p.exp }, add)
        p.level = res.level
        p.exp = res.exp
        p.totalExp = (p.totalExp || 0) + res.expGained
        user.progression = p
        try { ufs.update(user.player_id, { progression: p }) } catch {}
        return { leveledUp: res.leveledUp, level: res.level, levelsGained: res.levelsGained }
}

// ============================================================
// READ — agregasi leaderboard (provider utk ActivityStore — pola
// setMoneyProvider/setEconomyProvider/setAfkProvider yang sudah ada)
// ============================================================

/**
 * Map jid → {level, exp(totalExp), streakCount} dari USER DB.
 * Dipasang bot.js: activity.setProgressionProvider(jids => ...).
 * Jids kosong/null → SEMUA user terdaftar (scope global).
 * @returns {Map<string, {level:number, exp:number, streak:number}>}
 */
export function aggregateProgression(ufs, jids = null) {
        const out = new Map()
        try {
                const users = ufs?.listAll?.() || []
                // TASK 26 (LB dobel nama): jangan lagi mem-FAN-OUT satu user
                // ke semua kunci identitasnya (pn+jid+lid) — itu membuat
                // orang yang sama muncul 2-3 baris di .lb level/exp/streak.
                // Sekarang: index key→rec, keluarkan HANYA jid yang diminta
                // (scope grup tetap akurat), atau satu entry per user (pn
                // diprioritaskan) bila tanpa filter.
                const want = Array.isArray(jids) && jids.length ? new Set(jids.map(String)) : null
                if (want) {
                        const keyToRec = new Map()
                        for (const user of users) {
                                const p = user?.progression
                                if (!p || typeof p !== 'object') continue
                                const level = Math.max(1, Number(p.level) || 1)
                                const exp = Math.max(0, Number(p.totalExp) || 0)
                                const streak = Math.max(0, Number(p.streak?.count) || 0)
                                if (level <= 1 && exp <= 0 && streak <= 0) continue
                                const rec = { level, exp, streak }
                                for (const k of [user.pn, user.jid, user.lid]) {
                                        if (k) keyToRec.set(String(k), rec)
                                }
                        }
                        for (const jid of want) {
                                if (!out.has(jid)) {
                                        const rec = keyToRec.get(jid)
                                        if (rec) out.set(jid, rec)
                                }
                        }
                } else {
                        for (const user of users) {
                                const p = user?.progression
                                if (!p || typeof p !== 'object') continue
                                const level = Math.max(1, Number(p.level) || 1)
                                const exp = Math.max(0, Number(p.totalExp) || 0)
                                const streak = Math.max(0, Number(p.streak?.count) || 0)
                                if (level <= 1 && exp <= 0 && streak <= 0) continue
                                // satu entry per user — pn diprioritaskan
                                const primary = user.pn || user.jid || user.lid
                                if (primary) out.set(String(primary), { level, exp, streak })
                        }
                }
        } catch (e) {
                logger.warn('aggregateProgression error: %s', e.message)
        }
        return out
}

/** Ringkasan owner-level (dipakai .status / diagnostics). */
export function progressionSummary(ufs) {
        const users = ufs?.listAll?.() || []
        let withProgression = 0
        let totalLevel = 0
        let top = null
        for (const u of users) {
                if (u?.progression) {
                        withProgression++
                        totalLevel += Number(u.progression.level) || 1
                        if (!top || (Number(u.progression.level) || 1) > top.level) {
                                top = { name: u.username || u.player_id, level: Number(u.progression.level) || 1 }
                        }
                }
        }
        return { registeredUsers: users.length, withProgression, avgLevel: withProgression ? Math.round(totalLevel / withProgression) : 0, top }
}
