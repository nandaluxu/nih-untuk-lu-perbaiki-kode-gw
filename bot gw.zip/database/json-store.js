import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import logger from '../lib/core/logger.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const DEFAULT_STORE_DIR = path.join(__dirname, '..', 'store')
const SAFE_KEY_RE = /^[A-Za-z0-9_-]+$/

/**
 * LAT-003 (audit latency): tulis hot path kini ASYNC dengan antrean per
 * domain + COALESCING. Dulu writeDirty = writeFileSync+renameSync per commit
 * command (limit/AI ref/names/lid-mapping/warn) — blocking event loop dan
 * membesar diam-diam seiring data. Sekarang: writeDirty hanya menandai dirty
 * + menjadwalkan flush async (debounce 200ms); bila domain sama dirty LAGI
 * saat tulis berjalan, TIDAK dibuat tulisan baru — tulis berikutnya (siklus
 * yang sudah terjadwal) mengambil state terbaru.
 * Durabilitas: jendela kehilangan data saat crash membesar ~200ms (sebelumnya
 * ~0). flushDirty()/_syncWrite()/transaction() TETAP SINKRON — dipakai saat
 * shutdown/migrasi/test yang butuh tulis langsung.
 */
const ASYNC_FLUSH_DEBOUNCE_MS = 200

/**
 * JsonStore — data global, DIPECAH SATU FILE PER DOMAIN (folder store/).
 * Tidak ada lagi store.json ribuan baris — tiap domain data jadi file kecil
 * yang mudah dikelola:
 *
 *   store/
 *   ├── identifiers.json      ← data.identifiers  (mapping LID↔PN)
 *   ├── settings.json         ← data.settings     (per-chat: mutes/warns/antilink/...)
 *   ├── global_settings.json  ← data.global_settings (prefix/protection/...)
 *   ├── world_bank.json       ← data.world_bank   (ekonomi)
 *   ├── ai.json               ← data.ai           (session/memori AI)
 *   ├── limit_usage.json      ← data.limit_usage  (pemakaian limit harian)
 *   └── _misc.json            ← domain lain yang namanya tidak aman utk filename
 *
 * - MIGRASI OTOMATIS: store.json lama masih ada → isinya dipindah ke store/
 *   per-domain saat load, lalu file lamanya direname → store.json.migrated
 *   (backup; boleh dihapus manual kalau sudah yakin).
 * - API TIDAK BERUBAH: data (objek agregat), _syncWrite(), transaction(),
 *   get path() — semua repository (identifier/settings/world-bank/limit/ai)
 *   tetap jalan tanpa perubahan.
 * - _syncWrite() menulis ulang semua file domain (atomic per file: tmp+rename)
 *   — total I/O sama seperti dulu menulis satu store.json besar.
 * - File domain korup → di-skip + warning (domain lain tetap aman).
 */
export class JsonStore {
        /**
         * @param {object} [opts]
         * @param {string} [opts.storeDir] - override folder store (untuk test)
         */
        constructor({ storeDir = DEFAULT_STORE_DIR } = {}) {
                this.storeDir = storeDir
                // Legacy store.json = sibling folder store (biar test dengan dir
                // temp tetap bisa simulasi migrasi dari file legacy).
                this.legacyPath = path.join(path.dirname(storeDir), 'store.json')
                this.data = null
                // Task 32 — dirty flag per domain: hot path (limit commit, balasan
                // AI, lid-mapping, world bank) hanya menulis domain yang berubah,
                // bukan SEMUA file di folder store/.
                /** @type {Set<string>} */
                this._dirty = new Set()
                // ---- State flush async (LAT-003) ----
                this._flushTimer = null      // debounce timer pending
                this._flushing = false       // siklus tulis async sedang jalan
                /** @type {Promise|null} */ this._flushPromise = null
                this._closed = false         // closeStore() — stop jadwal baru
                this._tmpSeq = 0             // nama tmp unik (hindari tabrakan sync vs async)
                // Generation guard: _syncWrite() (sinkron) menaikkan _gen; tulis
                // async yang dimulai sebelum _gen naik MEMBUANG tmp-nya saat rename
                // → tidak ada data lama menimpa data baru yang ditulis sinkron.
                this._gen = 0
        }

        /**
         * Tandai domain berubah (Task 32). Return this agar bisa chaining:
         *   store.markDirty('ai').flushDirty()
         * @param {string} key - nama domain (mis. 'ai', 'world_bank', 'limit_usage')
         */
        markDirty(key) {
                this._dirty.add(key)
                return this
        }

        /**
         * Flush HANYA domain yang di-tandai dirty sejak flush terakhir.
         * Domain tak dikenal/safe-key tetap ikut aturan file per domain.
         */
        flushDirty() {
                if (!this.data || this._dirty.size === 0) return 0
                let written = 0
                const misc = []
                for (const key of this._dirty) {
                        if (!(key in this.data)) { this._dirty.delete(key); continue }
                        if (SAFE_KEY_RE.test(key)) {
                                this._writeDomainFile(path.join(this.storeDir, `${key}.json`), this.data[key])
                                written++
                        } else {
                                misc.push(key)
                        }
                        this._dirty.delete(key)
                }
                if (misc.length > 0) {
                        // _misc berisi domain gabungan — tulis ulang bila ada yang dirty
                        this._writeDomainFile(path.join(this.storeDir, '_misc.json'), this._buildMisc())
                        written++
                }
                return written
        }

        /**
         * Shortcut: tandai beberapa domain dirty lalu JADWALKAN flush async
         * (coalescing — lihat catatan ASYNC_FLUSH_DEBOUNCE_MS di atas).
         * Pola pemakaian di repository/helper:
         *   db.writeDirty('settings')   // hanya file settings.json yang ditulis
         * Return: jumlah domain yang menunggu ditulis.
         */
        writeDirty(...keys) {
                for (const k of keys) this.markDirty(k)
                this._scheduleFlush()
                return this._dirty.size
        }

        /** Jadwalkan flush async (debounce). Dipanggil writeDirty. @private */
        _scheduleFlush() {
                if (this._closed || this._flushTimer || this._flushing) return
                this._flushTimer = setTimeout(() => {
                        this._flushTimer = null
                        this.flushAsync().catch(() => {})
                }, ASYNC_FLUSH_DEBOUNCE_MS)
                if (typeof this._flushTimer.unref === 'function') this._flushTimer.unref()
        }

        /**
         * Flush async SEKARANG (tanpa debounce) — resolve setelah semua domain
         * dirty tersulis (dan domain yang dirty lagi SELAMA tulis ikut tersulis).
         * Dipakai test & pemanggil yang butuh kepastian durabilitas.
         */
        flushAsync() {
                if (this._flushTimer) {
                        clearTimeout(this._flushTimer)
                        this._flushTimer = null
                }
                if (!this._flushPromise) {
                        this._flushPromise = this._doAsyncFlush().finally(() => { this._flushPromise = null })
                }
                return this._flushPromise
        }

        /** Siklus tulis async dengan coalescing. @private */
        async _doAsyncFlush() {
                if (this._flushing) return
                this._flushing = true
                try {
                        do {
                                const keys = [...this._dirty]
                                for (const k of keys) this._dirty.delete(k)
                                if (keys.length === 0) break
                                await this._flushKeysAsync(keys)
                        } while (this._dirty.size > 0)
                } finally {
                        this._flushing = false
                        // Race kecil: writeDirty datang saat flag masih true
                        // (scheduleFlush skip) → pastikan ada jadwal lagi.
                        if (!this._closed && this._dirty.size > 0 && !this._flushTimer) this._scheduleFlush()
                }
        }

        /** Tulis kumpulan domain secara async (safe-key per file; sisanya _misc). @private */
        async _flushKeysAsync(keys) {
                const misc = []
                for (const key of keys) {
                        if (!(key in this.data)) continue
                        if (SAFE_KEY_RE.test(key)) {
                                await this._writeDomainFileAsync(path.join(this.storeDir, `${key}.json`), this.data[key])
                        } else {
                                misc.push(key)
                        }
                }
                if (misc.length > 0) {
                        await this._writeDomainFileAsync(path.join(this.storeDir, '_misc.json'), this._buildMisc())
                }
        }

        /** Tulis satu file domain secara atomic ASYNC (tmp + rename). @private */
        async _writeDomainFileAsync(file, dataRef) {
                const gen = this._gen
                // Stringify SINKRON di sini (snapshot state saat siklus ini)
                const payload = JSON.stringify(dataRef, null, 2)
                const tmp = `${file}.tmp-${process.pid}-${++this._tmpSeq}`
                try {
                        await fs.promises.writeFile(tmp, payload, 'utf8')
                        if (gen !== this._gen) {
                                // _syncWrite() sinkron lebih baru sudah menulis domain ini
                                // → buang tmp (jangan timpa data baru dengan snapshot lama).
                                await fs.promises.unlink(tmp).catch(() => {})
                                return
                        }
                        await fs.promises.rename(tmp, file)
                } catch (e) {
                        logger.error('Gagal menulis store (async) %s: %s', file, e.message)
                        try { fs.unlinkSync(tmp) } catch {}
                }
        }

        /** Kumpulkan semua domain non-safe-key jadi satu objek _misc. @private */
        _buildMisc() {
                const misc = {}
                for (const [key, value] of Object.entries(this.data)) {
                        if (!SAFE_KEY_RE.test(key)) misc[key] = value
                }
                return misc
        }

        /** Path virtual store.json (dipakai RoleRepository utk naming backup). */
        get path() {
                return path.join(this.storeDir, 'store.json')
        }

        load() {
                fs.mkdirSync(this.storeDir, { recursive: true })

                // 1. Muat semua file domain
                this.data = this._loadDir()

                // 2. Migrasi legacy store.json (kalau masih ada)
                this._migrateLegacy()

                // 3. Ensure semua key default ada (forward compatibility)
                const def = this._defaultData()
                for (const key of Object.keys(def)) {
                        if (!(key in this.data)) {
                                this.data[key] = def[key]
                        }
                }
                if (!this.data.world_bank) {
                        this.data.world_bank = def.world_bank
                }

                this._syncWrite()
                logger.info('Store dimuat dari: %s (%d domain)', this.storeDir, Object.keys(this.data).length)
        }

        /** Baca semua file *.json di folder store → objek agregat. */
        _loadDir() {
                const data = {}
                let files = []
                try {
                        files = fs.readdirSync(this.storeDir).filter(f => f.endsWith('.json') && !f.includes('.tmp'))
                } catch {
                        return data
                }
                for (const f of files) {
                        if (f === '_misc.json') continue // diproses terakhir
                        const key = f.slice(0, -'.json'.length)
                        try {
                                data[key] = JSON.parse(fs.readFileSync(path.join(this.storeDir, f), 'utf8'))
                        } catch (e) {
                                logger.warn('Store domain %s korup, diabaikan: %s', f, e.message)
                        }
                }
                try {
                        const miscFile = path.join(this.storeDir, '_misc.json')
                        if (fs.existsSync(miscFile)) {
                                const misc = JSON.parse(fs.readFileSync(miscFile, 'utf8'))
                                if (misc && typeof misc === 'object' && !Array.isArray(misc)) {
                                        Object.assign(data, misc)
                                }
                        }
                } catch (e) {
                        logger.warn('Store _misc.json korup, diabaikan: %s', e.message)
                }
                return data
        }

        /**
         * Migrasi legacy store.json → store/ per-domain. Idempotent: key yang
         * sudah ada di store/ TIDAK ditimpa; setelah selesai file legacy
         * direname → store.json.migrated (backup, tidak dihapus).
         */
        _migrateLegacy() {
                if (!fs.existsSync(this.legacyPath)) return false

                let legacy = null
                try {
                        legacy = JSON.parse(fs.readFileSync(this.legacyPath, 'utf8'))
                } catch (e) {
                        logger.error('Legacy store.json korup — tidak dimigrasi: %s', e.message)
                        return false
                }

                const imported = []
                if (legacy && typeof legacy === 'object' && !Array.isArray(legacy)) {
                        for (const [key, value] of Object.entries(legacy)) {
                                if (!(key in this.data)) {
                                        this.data[key] = value
                                        imported.push(key)
                                }
                        }
                }

                this._syncWrite()
                try {
                        fs.renameSync(this.legacyPath, this.legacyPath + '.migrated')
                } catch (e) {
                        logger.warn('Gagal rename legacy store.json → .migrated: %s', e.message)
                        return true
                }
                logger.info(
                        'Migrasi store.json → store/ selesai: %d domain dipindah (%s). Backup: store.json.migrated',
                        imported.length, imported.join(', ') || '-'
                )
                return true
        }

        _defaultData() {
                return {
                        identifiers: [],
                        settings: {},
                        global_settings: {},
                        // Task 37: cache push name WA per JID (lib/names.js) —
                        // fallback nama tampilan utk user belum terdaftar.
                        names: {},
                        world_bank: {
                                id: 1,
                                balance: 5000,
                                max_balance: 50000,
                                last_regen: new Date().toISOString(),
                        },
                        ai: {
                                provider_config: {
                                        active: 'groq',
                                        keys: {}
                                },
                                sessions: {},
                                user_memories: {},
                                group_memories: {},
                                message_refs: {},
                                provider_usage: {}
                        }
                }
        }

        /**
         * transaction(fn) — menjalankan fn dengan data store, lalu flush ke disk.
         * Digunakan untuk operasi yang butuh atomicity (misal world_bank update).
         */
        transaction(fn) {
                fn(this.data)
                this._syncWrite()
        }

        /** Tulis satu file domain secara atomic (tmp + rename, POSIX atomic). */
        _writeDomainFile(file, data) {
                const tmp = `${file}.tmp-${process.pid}`
                fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8')
                fs.renameSync(tmp, file)
        }

        /**
         * Flush SEMUA domain ke file masing-masing (folder store/) — SINKRON.
         * Dipakai: load/migrasi/transaction/plugin owner-command/closeStore.
         * Key dengan nama aman → <key>.json; sisanya digabung di _misc.json.
         * Naikkan _gen agar tulis async yang sedang berjalan membuang hasilnya
         * (data sinkron ini lebih baru).
         */
        _syncWrite() {
                if (!this.data) return
                this._gen++
                try {
                        const misc = {}
                        for (const [key, value] of Object.entries(this.data)) {
                                if (SAFE_KEY_RE.test(key)) {
                                        this._writeDomainFile(path.join(this.storeDir, `${key}.json`), value)
                                } else {
                                        misc[key] = value
                                }
                        }
                        if (Object.keys(misc).length > 0) {
                                this._writeDomainFile(path.join(this.storeDir, '_misc.json'), misc)
                        }
                } catch (e) {
                        logger.error('Gagal menulis store: %s', e.message)
                }
        }
}

let instance = null

export function getStore() {
        if (!instance) {
                instance = new JsonStore()
                instance.load()
        }
        return instance
}

export function closeStore() {
        if (instance) {
                try {
                        // Stop jadwal async lalu tulis ulang SEMUA domain sinkron —
                        // tulis async yang masih in-flight membuang tmp-nya (gen guard).
                        instance._closed = true
                        if (instance._flushTimer) {
                                clearTimeout(instance._flushTimer)
                                instance._flushTimer = null
                        }
                        instance._syncWrite()
                } catch (e) {
                        logger.error('Final store flush error: %s', e.message)
                }
                instance = null
                logger.info('Store ditutup')
        }
}
