/**
 * ai/providers/chatgpt.js — PROVIDER ChatGPT (scrape anon, Task 51).
 *
 * Scrape owner (lib/scrape/chatgpt.js — klien Android OpenAI) dibungkus jadi
 * provider resmi sistem AI rikka — kini OPSI UTAMA (default aktif):
 *   - TANPA API KEY (anon) — keyless: providerManager memberi pseudo-key.
 *   - Memory percakapan HIDUP DI SERVER OpenAI (conversation_id +
 *     parent_message_id): pesan PERTAMA membawa prompt penuh (system
 *     personality + memory + context + pesan user), pesan BERIKUTNYA cukup
 *     TEKS USER doang → token seminimal mungkin (permintaan owner).
 *   - Sesi per (personality + chat + user) — ikut masa hidup session rikka:
 *     session baru / idle 30 menit / sesi server mati → percakapan server
 *     baru dimulai dgn prompt penuh lagi (retry sekali otomatis).
 *   - Timeout: stream sudah di-fence internal scrape (watchdog + req
 *     timeout); provider mendeklarasikan cap luar 180 dtk supaya
 *     withTimeout providerManager tidak memotong stream panjang lebih dulu
 *     (env CHATGPT_PROVIDER_TIMEOUT_MS).
 *
 * Kontrak provider (sama dengan groq/gemini/openrouter):
 *   generate({ model, messages, apiKey, temperature, maxTokens, extra })
 *     messages: [{ role: 'system'|'user'|'assistant', content }]
 *     extra: { conversationKey, sessionId } — kunci state percakapan
 *   healthCheck() → getSession() sukses / gagal
 */

/** Idle maksimum state percakapan server (ms). */
const CONV_TTL_MS = 30 * 60_000
/** Cap timeout luar (dipakai providerManager — stream panjang tidak terpotong). */
const PROVIDER_TIMEOUT_MS = num(process.env.CHATGPT_PROVIDER_TIMEOUT_MS, 180_000)

function num(v, dflt) {
    const n = Number(v)
    return Number.isFinite(n) && n > 0 ? n : dflt
}

/** State percakapan server: conversationKey → { auth, chatId, sessionId, lastAt } */
const _convs = new Map()

/** Export test: reset seluruh state percakapan. */
export function resetChatgptProviderState() {
    _convs.clear()
}

/** Export test: intip state percakapan. */
export function peekChatgptProviderState(key) {
    return _convs.get(key) || null
}

/**
 * Susun state percakapan yang masih hidup utk kunci ini — null kalau harus
 * mulai percakapan server baru (belum ada / kedaluwarsa / session rikka
 * berganti → memory rikka sendiri juga sudah reset, konsisten mulai baru).
 */
function _liveConv(conversationKey, sessionId) {
    const st = _convs.get(conversationKey)
    if (!st) return null
    if (Date.now() - st.lastAt > CONV_TTL_MS) {
        _convs.delete(conversationKey)
        return null
    }
    if (sessionId && st.sessionId && sessionId !== st.sessionId) {
        _convs.delete(conversationKey)
        return null
    }
    return st
}

/**
 * Gabung messages (system/user/assistant) jadi SATU prompt teks — dipakai
 * HANYA di pesan pertama percakapan server; follow-up cukup teks user.
 * Format mengikuti urutan natural: system dulu, lalu dialog.
 */
function flattenMessages(messages) {
    const lines = []
    for (const msg of messages || []) {
        const role = msg?.role || 'user'
        const content = String(msg?.content ?? '').trim()
        if (!content) continue
        if (role === 'system') {
            lines.push(content)
        } else if (role === 'assistant') {
            lines.push(`Assistant: ${content}`)
        } else {
            lines.push(`User: ${content}`)
        }
    }
    return lines.join('\n')
}

/** Pesan user terakhir (follow-up hemat token — teks doang). */
function lastUserText(messages) {
    for (let i = (messages || []).length - 1; i >= 0; i--) {
        if (messages[i]?.role === 'user') {
            const t = String(messages[i].content ?? '').trim()
            if (t) return t
        }
    }
    return null
}

export default {
    id: 'chatgpt',
    name: 'ChatGPT (scrape anon)',
    models: ['auto'],
    /** Provider tanpa API key — providerManager kasih pseudo-key. */
    keyless: true,
    /** Cap timeout luar (providerManager hormati ini, bukan AI_TIMEOUT_MS). */
    timeoutMs: PROVIDER_TIMEOUT_MS,

    /**
     * generate — dipanggil providerManager (sudah di-semaphore + withTimeout).
     * extra.conversationKey + extra.sessionId dikirim aiResponse.js;
     * extra.http = injeksi klien HTTP (test SSE tanpa jaringan).
     */
    async generate({ messages, extra = {} }) {
        const { chatgpt, getSession } = await import('../../lib/scrape/chatgpt.js')
        const conversationKey = String(extra.conversationKey || 'rikka:default')
        const st = _liveConv(conversationKey, extra.sessionId)
        const opts = extra.http ? { http: extra.http } : {}

        const fullPrompt = flattenMessages(messages)
        const followUp = st ? lastUserText(messages) : null
        // follow-up null (tak ada baris user) → pakai prompt penuh (aman)
        const prompt = st && followUp ? followUp : fullPrompt

        let res
        try {
            res = await chatgpt(prompt, st?.auth, st?.chatId, opts)
        } catch (e) {
            // Sesi server mati/kedaluwarsa → percakapan BARU dgn prompt penuh
            // (retry sekali — pola provider ai-characters task50).
            _convs.delete(conversationKey)
            const fresh = await getSession(opts)
            res = await chatgpt(fullPrompt, fresh, null, opts)
        }

        const answer = res?.response
        if (!answer || typeof answer !== 'string' || !answer.trim()) {
            throw new Error('jawaban kosong dari chatgpt (scrape)')
        }

        // simpan state utk giliran berikutnya (hemat token: follow-up = teks
        // doang; auth.parentMessageId sudah di-update scrape ke balasan ini)
        _convs.set(conversationKey, {
            auth: res.auth,
            chatId: res.chatId,
            sessionId: extra.sessionId || null,
            lastAt: Date.now(),
        })
        // jaga ukuran map (maks 200 percakapan idle)
        if (_convs.size > 200) {
            const oldest = [..._convs.entries()].sort((a, b) => a[1].lastAt - b[1].lastAt)[0]
            if (oldest) _convs.delete(oldest[0])
        }

        return answer.trim()
    },

    async healthCheck() {
        try {
            const { getSession } = await import('../../lib/scrape/chatgpt.js')
            const auth = await getSession()
            return Boolean(auth?.cookie)
        } catch {
            return false
        }
    },
}
