import { Groq } from 'groq-sdk'
import fs from 'fs'
import path from 'path'
import logger from '../../lib/core/logger.js'

const DEBUG_FILE = path.join(process.cwd(), 'ai-debug.json')

// B4: debug file MATI secara default (production). Aktif hanya dengan
// AI_DEBUG=true di env — dan tetap DIREDAKSI (tanpa API key, tanpa JID,
// konten pesan terpotong) supaya tidak menyimpan percakapan pribadi.
const AI_DEBUG = /^true$/i.test(process.env.AI_DEBUG || '')

/** Redaksi payload untuk debug: strip API key, JID, dan potong konten. */
function redactForDebug(payload) {
        const REDACTED = '[REDACTED]'
        const scrub = (s) => String(s)
                .replace(/\b\d{5,}(@s\.whatsapp\.net|@lid|@g\.us)\b/g, REDACTED)
                .replace(/\b\d{5,}:\d+(@s\.whatsapp\.net|@lid)\b/g, REDACTED)
        return {
                ...payload,
                messages: (payload.messages || []).map(m => ({
                        role: m.role,
                        content: scrub(String(m.content || '')).slice(0, 300),
                })),
        }
}

export default {
        id: 'groq',
        name: 'Groq',
        models: ['groq/compound'],

        defaultModel: 'groq/compound',
        defaultOptions: {
                temperature: 1,
                max_completion_tokens: 768,
                top_p: 1
        },

        async generate({ model, messages, apiKey, temperature, maxTokens, compoundCustom, extra = {} }) {
                const client = new Groq({ apiKey })

                const payload = {
                        model: model || this.defaultModel,
                        messages,
                        temperature: temperature ?? this.defaultOptions.temperature,
                        max_completion_tokens: maxTokens ?? this.defaultOptions.max_completion_tokens,
                        top_p: this.defaultOptions.top_p,
                        stream: true,
                        ...extra
                }

                // B4: debug hanya saat AI_DEBUG=true — dan direduksi (no key/JID,
                // konten dipotong). Production default: TIDAK menulis apa pun.
                if (AI_DEBUG) {
                        const debug = {
                                timestamp: new Date().toISOString(),
                                endpoint: 'chat.completions.create',
                                payload: redactForDebug(payload),
                                apiKeyPresent: Boolean(apiKey),
                                messageCount: messages.length,
                                totalChars: messages.reduce((s, m) => s + (m.content?.length || 0), 0),
                        }
                        fs.writeFileSync(DEBUG_FILE, JSON.stringify(debug, null, 2))
                }

                // Rate limit retry: parse "Please try again in Xs" dari error Groq
                let lastError = null
                const MAX_RETRIES = 3
                for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
                        try {
                                const chatCompletion = await client.chat.completions.create(payload)
                                let response = ''
                                for await (const chunk of chatCompletion) {
                                        response += chunk.choices?.[0]?.delta?.content || ''
                                }
                                return response
                        } catch (e) {
                                lastError = e
                                const errMsg = e.message || ''
                                const status = e.status || e.statusCode || 0

                                // Cek apakah rate limit error (429 atau pesan rate limit)
                                const isRateLimit = status === 429
                                        || /rate.?limit/i.test(errMsg)
                                        || /try again in \d+s/i.test(errMsg)

                                if (!isRateLimit || attempt >= MAX_RETRIES) throw e

                                // Parse retry-after dari pesan error: "Please try again in 12s"
                                const retryMatch = errMsg.match(/try again in (\d+)s/i)
                                let waitMs = 5000 // default 5 detik
                                if (retryMatch) {
                                        waitMs = (parseInt(retryMatch[1]) + 1) * 1000 // +1s buffer
                                }

                                logger.warn('Groq rate limit, retry %d/%d in %dms: %s', attempt + 1, MAX_RETRIES, waitMs, errMsg.slice(0, 100))
                                await new Promise(r => setTimeout(r, waitMs))
                        }
                }

                throw lastError || new Error('Groq: gagal setelah retry.')
        },

        async healthCheck(apiKey) {
                try {
                        const client = new Groq({ apiKey })
                        await client.chat.completions.create({
                                model: this.defaultModel,
                                messages: [{ role: 'user', content: 'hi' }],
                                max_completion_tokens: 1
                        })
                        return true
                } catch {
                        return false
                }
        }
}
