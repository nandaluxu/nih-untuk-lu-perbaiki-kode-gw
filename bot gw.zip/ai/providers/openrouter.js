import OpenAI from 'openai'
import logger from '../../lib/core/logger.js'

export default {
        id: 'openrouter',
        name: 'OpenRouter',
        models: ['nvidia/nemotron-3-nano-30b-a3b:free'],

        defaultModel: 'nvidia/nemotron-3-nano-30b-a3b:free',
        defaultOptions: {
                temperature: 0.7,
                max_tokens: 768
        },

        async generate({ model, messages, apiKey, temperature, maxTokens, extra = {} }) {
                const client = new OpenAI({
                        baseURL: 'https://openrouter.ai/api/v1',
                        apiKey
                })

                const payload = {
                        model: model || this.defaultModel,
                        messages,
                        temperature: temperature ?? this.defaultOptions.temperature,
                        max_tokens: maxTokens ?? this.defaultOptions.max_tokens,
                        stream: true,
                        ...extra
                }

                const chatCompletion = await client.chat.completions.create(payload)

                let response = ''
                for await (const chunk of chatCompletion) {
                        response += chunk.choices?.[0]?.delta?.content || ''
                }

                if (!response.trim()) {
                        throw new Error('OpenRouter: response kosong.')
                }

                return response
        },

        async healthCheck(apiKey) {
                try {
                        const client = new OpenAI({
                                baseURL: 'https://openrouter.ai/api/v1',
                                apiKey
                        })
                        await client.chat.completions.create({
                                model: this.defaultModel,
                                messages: [{ role: 'user', content: 'hi' }],
                                max_tokens: 1
                        })
                        return true
                } catch {
                        return false
                }
        }
}
