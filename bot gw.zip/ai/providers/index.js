import groq from './groq.js'
import gemini from './gemini.js'
import openrouter from './openrouter.js'
// Task 51: scrape ChatGPT anon (owner) — provider UTAMA rikka, tanpa API key.
import chatgptScrape from './chatgpt.js'

// chatgpt duluan → urutan fallback: scrape → groq → gemini → openrouter
export default [chatgptScrape, groq, gemini, openrouter]
