const BASE_URL = 'https://generativelanguage.googleapis.com/v1beta/models'

function toGemini(messages, systemPrompt) {
	const contents = []
	for (const msg of messages) {
		if (msg.role === 'system') continue
		contents.push({
			role: msg.role === 'assistant' ? 'model' : 'user',
			parts: [{ text: msg.content }]
		})
	}
	const systemInstruction = systemPrompt ? { parts: [{ text: systemPrompt }] } : undefined
	return { contents, systemInstruction }
}

function fromGemini(data) {
	return data.candidates?.[0]?.content?.parts?.[0]?.text || ''
}

export default {
	id: 'gemini',
	name: 'Gemini',
	models: [
		'gemini-2.0-flash',
		'gemini-2.0-flash-lite',
		'gemini-1.5-flash',
		'gemini-1.5-pro'
	],

	async generate({ model, messages, apiKey, temperature = 0.7, maxTokens = 2048 }) {
		const systemPrompt = messages.find(m => m.role === 'system')?.content || ''
		const { contents, systemInstruction } = toGemini(messages, systemPrompt)

		const url = `${BASE_URL}/${model}:generateContent?key=${apiKey}`
		const res = await fetch(url, {
			method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({ contents, systemInstruction, generationConfig: { temperature, maxOutputTokens: maxTokens } })
		})
		if (!res.ok) {
			const err = await res.text().catch(() => '')
			throw new Error(`Gemini ${res.status}: ${err.slice(0, 200)}`)
		}
		const data = await res.json()
		return fromGemini(data)
	},

	async healthCheck(apiKey) {
		try {
			const url = `${BASE_URL}/${this.models[0]}:generateContent?key=${apiKey}`
			const res = await fetch(url, {
				method: 'POST',
			headers: { 'Content-Type': 'application/json' },
			body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: 'hi' }] }], generationConfig: { maxOutputTokens: 1 } })
		})
			return res.ok
		} catch {
			return false
		}
	}
}
