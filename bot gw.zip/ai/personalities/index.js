import rikka from './rikka.js'

export default [rikka]
