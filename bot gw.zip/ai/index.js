import logger from '../lib/core/logger.js'

import { ScheduleManager } from './core/scheduleManager.js'
import { SessionManager } from './core/sessionManager.js'
import { MemoryManager } from './core/memoryManager.js'
import { ContextManager } from './core/contextManager.js'
import { PromptManager } from './core/promptManager.js'
import { PersonalityManager } from './core/personalityManager.js'
import { ProviderManager } from './core/providerManager.js'
import { aiResponse } from './core/aiResponse.js'

import groqProvider from './providers/groq.js'
import openrouterProvider from './providers/openrouter.js'
import geminiProvider from './providers/gemini.js'
// Task 51: scrape ChatGPT anon (owner) — provider UTAMA (opsi utama, tanpa key).
import chatgptProvider from './providers/chatgpt.js'
import rikkaPersonality from './personalities/rikka.js'
// Task 53: karakter aianime disintesis jadi personality — fix
// "Personal miku tidak ditemukan" (file owner mikuai.js dkk memanggil
// aiResponse({ personality: 'miku' }) — dulu cuma 'rikka' yang terdaftar).
import { getCharacters, isCharDisabled, normalizeMentions, AI_LIMIT_PLUGIN, buildGiftEventText } from '../lib/ai-characters/engine.js'
// Task 54: relationship + limit AI (sistem yang sama dengan engine karakter —
// rikka memakai charId 'rikka', scope limit group:aichar BERSAMA, tanpa
// implementasi dobel).
import { extractMentions } from '../lib/features/afk.js'
import { getLimitService, limitUserKeyOf, buildLimitExhaustedText } from '../lib/command/limit-service.js'
// Phase 1.A (F-01): health monitor — init fail-loud AI.
import { getHealth } from '../lib/features/health.js'
// PHASE 1 (identity consolidation): rantai profil kanonik lib/identity.
import { findProfileForMessage } from '../lib/identity/index.js'
import {
    buildMentionedContext, recordInteraction,
    shouldNotice, unregisteredText, logRegWarnTrace,
} from '../lib/ai-characters/relationship.js'
// AI WORLD KNOWLEDGE: blok pengetahuan dunia (char → group → global) ikut
// di context gift-reply rikka — satu modul yang sama dengan engine karakter.
import { buildWorldKnowledgeBlock } from '../lib/ai-characters/world-knowledge.js'
// AI CHAT BERBASIS RELATIONSHIP — generator instruksi perilaku terpusat
// (fakta + aturan per tier + overlay pasangan resmi + prioritas). Satu
// modul yang sama dengan engine karakter — tanpa duplikasi; stateKey/
// updateNote dipakai provider chatgpt utk pembaruan mid-session.
import { getRelationshipInstructions } from '../lib/ai-characters/rel-behavior.js'

/** Interval sinkronisasi karakter → personality (file karakter nempel tanpa restart). */
const CHAR_PERSONALITY_SYNC_MS = 30_000

/**
 * Task 53 — daftarkan SEMUA karakter aianime sebagai personality SINTESIS.
 *
 * Kenapa perlu: file owner hasil copy dari bot AI lama (mis. mikuai.js)
 * memanggil aiResponse({ personality: 'miku' }) — registry lama hanya punya
 * 'rikka' → throw "Personal miku tidak ditemukan" (0ms, log owner 9/9).
 * Sintesis ini membuat get('miku') (juga get('rem'), get('alya'), …) sah.
 *
 * KEAMANAN JALUR (anti dobel-pesan):
 *   - triggers: [] KOSONG — trigger kata & reply-continue karakter TETAP
 *     milik engine ai-characters (hook bot.js jalan SEBELUM checkAiTrigger).
 *     detect() rikka tidak akan pernah mencuri pesan "miku halo".
 *   - mirror ref engine memakai prefix 'aichar:miku' → get() tetap null →
 *     rikka tidak memproses reply pesan balasan engine.
 *   - karakter dimatikan (.setaireply off miku) → guard _isAicharDisabled
 *     mem-blok jalur reply rikka (tidak membalas sebagai karakter yang off).
 *   - id yang sudah dipakai personality eksplisit (rikka) TIDAK ditimpa.
 */
function registerCharacterPersonalities(personalityManager) {
    return (async () => {
        try {
            const chars = await getCharacters()
            let added = 0
            for (const c of chars) {
                if (personalityManager.get(c.id)) continue // rikka/eksplisit menang
                personalityManager.register({
                    id: c.id,
                    name: c.character.displayName || c.name,
                    triggers: [], // KOSONG — jalur trigger tetap milik engine aianime
                    systemPrompt: c.character.prompt,
                    provider: 'auto',
                    model: 'auto',
                    session: { enabled: true, timeout: 300000 },
                    context: { enabled: false }, // context grup = urusan rikka biasa, bukan karakter
                    memory: { enabled: false },  // memory rikka = urusan rikka; karakter punya ingatan Task 53 sendiri
                    schedule: null,
                    // RELATIONSHIP BEHAVIOR PER KARAKTER: ikut dibawa ke
                    // personality sintesis (pemanggil aiResponse langsung bisa
                    // membacanya — jalur chat utama karakter tetap lewat engine,
                    // yang membaca behavior FRESH dari file per request).
                    ...(c.character?.relationshipBehavior ? { relationshipBehavior: c.character.relationshipBehavior } : {}),
                    ...(typeof c.character?.getRelationshipBehavior === 'function' ? { getRelationshipBehavior: c.character.getRelationshipBehavior } : {}),
                    __aichar: true, // marker: personality sintesis dari aianime
                })
                added++
            }
            if (added) {
                logger.info(
                    'Task 53: %d karakter aianime disintesis jadi personality (aiResponse({personality:’%s’}) kini sah) — total %d',
                    added, chars[0]?.id, personalityManager.personalities.size,
                )
            }
        } catch (e) {
            logger.warn('Task 53: sinkronisasi karakter→personality gagal: %s', e?.message || e)
        }
    })()
}

/** Guard: personality = karakter aianime SINTESIS dan karakter itu dimatikan owner. */
function _isAicharDisabled(store, personality) {
    if (!personality?.__aichar) return false
    try { return isCharDisabled(store, personality.id) } catch { return false }
}

export function initAiSystem(store, aiConfig) {
        logger.info('Menginisialisasi AI system...')

        const scheduleManager = new ScheduleManager()
        const sessionManager = new SessionManager(store)
        const memoryManager = new MemoryManager(store)
        const contextManager = new ContextManager()
        const promptManager = new PromptManager()
        const personalityManager = new PersonalityManager(store)

        // B5: gemini kini TERDAFTAR — GEMINI_API_KEY sebelumnya di-parse tapi
        // provider tidak pernah dipakai (konfigurasi mati yang menyesatkan).
        // Task 51: chatgpt SCRAPE duluan — ops utama owner (gratis, tanpa key);
        // groq/gemini/openrouter jadi fallback otomatis saat scrape gagal.
        const providers = [chatgptProvider, groqProvider, openrouterProvider, geminiProvider]
        const providerManager = new ProviderManager(providers, store, aiConfig)

        // Task 51: migrasi SEKALI — deployment lama menyimpan active='groq'
        // (nilai default lama yang tak pernah dipilih owner secara eksplisit).
        // Owner minta scrape chatgpt jadi OPSI UTAMA → default berganti.
        // Setelah migrasi owner tetap bebas `.ai model set <apa pun>` — nilai
        // pilihan owner sendiri tidak pernah ditimpa lagi (flag migrate51).
        try {
                const cfg = store.data.ai?.provider_config
                if (cfg?.active === 'groq' && !cfg.migrate51ChatgptPrimary) {
                        cfg.active = 'chatgpt'
                        cfg.migrate51ChatgptPrimary = true
                        store.writeDirty?.('ai')
                        logger.info('AI provider aktif: groq → chatgpt (migrasi default Task 51 — scrape ChatGPT jadi opsi utama)')
                }
        } catch (e) {
                logger.warn('Migrasi provider default Task 51 gagal (dilewati): %s', e?.message || e)
        }

        const personalities = [rikkaPersonality]
        for (const p of personalities) {
                personalityManager.register(p)
                if (p.schedule && p.schedule.slots) {
                        scheduleManager.registerSlots(p.id, p.schedule.slots)
                }
        }

        // Task 53 — karakter aianime → personality sintesis (fix "Personal miku
        // tidak ditemukan"). Sinkron awal (async) + interval 30s (file karakter
        // baru nempel tanpa restart ikut kebaca — pola rescan engine 5s).
        const charSyncPromise = registerCharacterPersonalities(personalityManager)
        const charSyncTimer = setInterval(
                () => { registerCharacterPersonalities(personalityManager) },
                CHAR_PERSONALITY_SYNC_MS,
        )
        charSyncTimer.unref?.()

        // Cleanup session & expired refs setiap 5 menit (Task 32: timer
        // di-track + unref + bisa di-stop lewat system.stop())
        const cleanupTimer = setInterval(() => {
                sessionManager.cleanup(300000)
                contextManager.cleanupAll()
                _cleanupExpiredRefs(store)
        }, 5 * 60 * 1000)
        cleanupTimer.unref?.()

        const system = {
                scheduleManager,
                sessionManager,
                memoryManager,
                contextManager,
                promptManager,
                personalityManager,
                providerManager,
                store,
                aiConfig,

                // Toggle state
                aiEnabled: true,

                // Schedule bypass: Map<chatId, expiresAt>
                scheduleBypass: new Map(),

                setEnabled(enabled) {
                        this.aiEnabled = enabled
                        return enabled
                },

                setScheduleBypass(chatId, durationMs = 3600000) {
                        this.scheduleBypass.set(chatId, Date.now() + durationMs)
                },

                hasScheduleBypass(chatId) {
                        const expires = this.scheduleBypass.get(chatId)
                        if (!expires) return false
                        if (Date.now() > expires) {
                                this.scheduleBypass.delete(chatId)
                                return false
                        }
                        return true
                },

                clearScheduleBypass(chatId) {
                        this.scheduleBypass.delete(chatId)
                },

                /** Stop timer internal (dipanggil bot.stop() — graceful shutdown). */
                stop() {
                        clearInterval(cleanupTimer)
                        clearInterval(charSyncTimer)
                }
        }

        logger.info('AI system siap. Personalities: %s', personalities.map(p => p.id).join(', '))
        // Task 53: initAiSystem TETAP SINKRON (kontrak pemanggil lama — bot.js &
        // test pakai hasilnya langsung). Sintesis karakter jalan async (selesai
        // dalam hitungan ms); promise diekspos utk test yang mau deterministik.
        system._charSync = charSyncPromise
        return system
}

// ============================================================
// Phase 1.A — F-01: AI INIT FAIL-LOUD + HEALTH STATE
// ============================================================

/**
 * Wrapper init AI dengan health state — pengganti catch warn-only bot.js.
 *
 * SEBELUM (bot.js):
 *   try { aiSystem = initAiSystem(...) } catch (e) { logger.warn(...) }
 *   → kegagalan init AI tertelan sebagai warning; health monitor tetap
 *     default HEALTHY; bot "tampak hidup" padahal AI mati senyap sampai
 *     restart (F-01, P0 baseline).
 *
 * SEKARANG (di sini, agar bisa diuji langsung tanpa import bot.js):
 *   - health: STARTING → UP (dengan verifikasi pasca-init) atau DOWN
 *     (error + lastErrorAt tercatat di lib/health.js — tampil di .status).
 *   - log: [AI HEALTH] STARTING / UP / DOWN — DOWN membawa error + stack
 *     penuh (stack dipertahankan, tidak dipotong).
 *   - "Tidak throw" BUKAN bukti sehat: hasil init diverifikasi (personality
 *     rikka terdaftar, provider terdaftar, manager lengkap).
 *   - GAGAL → return null, TIDAK process.exit — AI subsystem opsional:
 *     bot tetap melayani command non-AI / RPG / economy / group tools.
 *     Konsumen AI sudah berpagar (`this.aiSystem &&` di pipeline bot.js;
 *     `.ai`/`.aion`/`.aioff`/`.aifree` menjawab terkontrol
 *     "AI system belum diinisialisasi.").
 *   - Tidak ada auto-retry/reinit (kesengajaan — audit Phase 1.A: belum ada
 *     mekanisme retry di lifecycle existing; failure cukup jadi DOWN dan
 *     bisa didiagnosis; reinit bounded = kandidat follow-up terpisah).
 *
 * Dipanggil SEKALI di level modul bot.js — event 'ready' berulang/reconnect
 * tidak re-init (timer charSync/cleanup dibuat di sini sekali + unref,
 * di-clear oleh system.stop(); sock._aiSystem = assignment idempotent).
 *
 * @param {object} store - JsonStore db (diteruskan ke initAiSystem).
 * @param {object} aiConfig - { groqKeys, geminiKeys, openrouterKeys }.
 * @param {object} [opts] - injeksi utk test: { initFn, health, log }.
 * @returns {object|null} system AI, atau null bila init gagal (health DOWN).
 */
export function initAiSystemGuarded(store, aiConfig, opts = {}) {
        const health = opts.health || getHealth()
        const log = opts.log || logger
        const initFn = opts.initFn || initAiSystem

        health.markInitStarting('AI')
        log.info('[AI HEALTH] STARTING — inisialisasi AI system')

        let system = null
        try {
                system = initFn(store, aiConfig)

                // Verifikasi pasca-init — hasil init nyata, bukan sekadar
                // "tidak throw": personality (rikka) + provider harus
                // terdaftar, manager inti lengkap. Kontrak sinkron tetap.
                const problems = []
                if (!system?.personalityManager || system.personalityManager.personalities.size === 0) {
                        problems.push('tidak ada personality terdaftar (minimal rikka)')
                }
                if (!system?.providerManager || system.providerManager._providers.size === 0) {
                        problems.push('tidak ada provider AI terdaftar')
                }
                for (const k of ['scheduleManager', 'sessionManager', 'memoryManager', 'contextManager', 'promptManager']) {
                        if (!system?.[k]) problems.push(`manager hilang: ${k}`)
                }
                if (problems.length) throw new Error(`verifikasi pasca-init gagal: ${problems.join('; ')}`)
        } catch (e) {
                // FAIL-LOUD: health DOWN + error terstruktur + stack penuh.
                // Bot TIDAK dimatikan (lihat docblock).
                health.markInitDown('AI', e)
                log.error('[AI HEALTH] DOWN subsystem=ai/init error=%s', e?.message || e)
                if (e?.stack) log.error('[AI HEALTH] DOWN subsystem=ai/init stack:\n%s', e.stack)
                return null
        }

        const nPersonalities = system.personalityManager.personalities.size
        const nProviders = system.providerManager._providers.size
        const active = system.providerManager.getActiveProviderId()
        health.markInitUp('AI', `personality=${nPersonalities} provider=${nProviders} active=${active}`)
        log.info('[AI HEALTH] UP — personality=%d provider=%d active=%s', nPersonalities, nProviders, active)
        return system
}

// ============================================================
// Message Reference helpers
//
// Task 49: helper message-ref kini DIEKSPOR PUBLIK. Dulu fungsi ini
// privat (_saveMessageRef) — file buatan owner yang meng-import
// `saveAiMessageRef` (pola dari bot AI lain) langsung gagal load:
//   SyntaxError: The requested module './ai/index.js' does not
//   provide an export named 'saveAiMessageRef'
// Kontrak lama (private) tetap jalan — versi publik hanya wrapper.
// Semua nama yang wajar dipakai file lama diekspor supaya import
// APAPUN dari keluarga fungsi ini tidak pernah melempar error lagi.
// ============================================================

/**
 * Simpan message ref (id pesan balasan AI) — dipakai reply-continue.
 * Public sejak Task 49; sebelumnya private sebagai _saveMessageRef.
 */
export function saveAiMessageRef(store, msgId, chatId, personalityId, sessionId) {
        return _saveMessageRef(store, msgId, chatId, personalityId, sessionId)
}

/** Alias — file lama bisa menyebut saveMessageRef. */
export const saveMessageRef = saveAiMessageRef

/** Cek apakah msgId adalah balasan AI di chat itu. Return ref / null. */
export function findAiMessageRef(store, quotedMsgId, chatId) {
        return _findMessageRef(store, quotedMsgId, chatId)
}

/** Alias findAiMessageRef. */
export const findMessageRef = findAiMessageRef

/** Ambil id pesan yang di-reply (quoted) dari berbagai bentuk message. */
export function getQuotedMessageId(m) {
        return _getQuotedMessageId(m)
}

/** Ekstrak quoted message ID dari berbagai kemungkinan path starcore/Baileys */
function _getQuotedMessageId(m) {
        // Path 1: starcore m.quoted.id
        if (m.quoted?.id) return m.quoted.id
        // Path 2: starcore m.quoted.key.id
        if (m.quoted?.key?.id) return m.quoted.key.id
        // Path 3: Baileys raw m.msg.extendedTextMessage.contextInfo.stanzaId
        const stanza = m.msg?.extendedTextMessage?.contextInfo?.stanzaId
                || m.message?.extendedTextMessage?.contextInfo?.stanzaId
        if (stanza) return stanza
        return null
}

/** Simpan message ref setelah Rikka kirim response */
function _saveMessageRef(store, msgId, chatId, personalityId, sessionId) {
        if (!msgId || !chatId) return
        if (!store.data.ai) store.data.ai = {}
        if (!store.data.ai.message_refs) store.data.ai.message_refs = {}
        store.data.ai.message_refs[msgId] = {
                chatId,
                personalityId,
                sessionId,
                createdAt: Date.now()
        }
        store.writeDirty('ai')
}

/** Cek apakah quotedMsgId adalah response AI, return ref atau null */
function _findMessageRef(store, quotedMsgId, chatId) {
        if (!quotedMsgId || !chatId) return null
        const refs = store.data.ai?.message_refs
        if (!refs) return null
        const ref = refs[quotedMsgId]
        if (!ref) return null
        // Pastikan chatId cocok
        if (ref.chatId !== chatId) {
                logger.debug('[AI-REPLY] chatId mismatch: quoted chat=%s, stored chat=%s', chatId, ref.chatId)
                return null
        }
        return ref
}

/** Cleanup message refs yang sudah expired (> session timeout) */
function _cleanupExpiredRefs(store) {
        const refs = store.data.ai?.message_refs
        if (!refs) return
        const now = Date.now()
        const expired = 300000 // sama dengan session timeout
        let cleaned = 0
        for (const id of Object.keys(refs)) {
                if (now - refs[id].createdAt > expired) {
                        delete refs[id]
                        cleaned++
                }
        }
        if (cleaned > 0) {
                store.writeDirty('ai')
                logger.debug('Message ref cleanup: %d expired', cleaned)
        }
}

/** Ekstrak message ID dari return value m.reply() atau sock.sendMessage() */
function _getSentMessageId(result) {
        if (!result) return null
        return result.id || result.key?.id || null
}

// ============================================================
// Reply Detection
// ============================================================

/**
 * Cek apakah user sudah terdaftar di userRepo.
 * Return { registered, userName, pushName, userId } atau null kalau gaada userRepo.
 * (Task 54: userId ikut dibawa — dipakai relationship & basis limit.)
 */
function _checkUserRegistration(userRepo, m) {
        // Ambil data user dari database (jika userRepo tersedia)
        if (!userRepo || !m.sender) return { registered: false, userName: null, pushName: null, userId: null }

        // Task 58 (fix F-2 — mirror gate engine): rantai kanonik
        // lib/identity — findByIdentifier DULU (LID→PN via mapping
        // identifiers + back-fill lid profil; profil lama tanpa lid tidak
        // lagi terbaca "belum terdaftar"). Paritas rantai lama + superset.
        const user = findProfileForMessage(userRepo, { sender: m.sender, senderLid: m.senderLid })

        // pushName dari WhatsApp (nama yang dipake di WA)
        const pushName = m.pushName || m.name || null

        if (user) {
                return {
                        registered: true,
                        userName: user.username, // nama dari .daftar
                        pushName,
                        userId: user.user_id || null, // Task 54
                }
        }

        return { registered: false, userName: null, pushName, userId: null }
}

/**
 * Resolve nama untuk dipake AI: prioritaskan nama terdaftar, fallback ke pushName.
 */
function _resolveUserName(userInfo) {
        if (userInfo.userName) return userInfo.userName
        if (userInfo.pushName) return userInfo.pushName
        return null
}

/**
 * Cek apakah pesan ini adalah reply ke response AI.
 * Return { ref, personalityId, sessionId } atau null.
 */
function _detectReplyToAI(system, m) {
        const quotedMsgId = _getQuotedMessageId(m)
        if (!quotedMsgId) {
                logger.debug('[AI-REPLY] No quoted message ID found')
                return null
        }

        const ref = _findMessageRef(system.store, quotedMsgId, m.chat)
        if (!ref) {
                logger.debug('[AI-REPLY] Quoted ID %s not found in message_refs', quotedMsgId)
                return null
        }

        // Cek session masih aktif
        const personality = system.personalityManager.get(ref.personalityId)
        if (!personality) return null

        const timeout = personality.session?.timeout || 300000
        const session = system.sessionManager.getActive(ref.chatId, ref.sessionId?.split(':')[1] || null, ref.personalityId, timeout)
        if (!session) {
                logger.debug('[AI-REPLY] Session expired for quoted message %s', quotedMsgId)
                return null
        }

        logger.debug('[AI-REPLY] Valid reply detected: msgId=%s, chatId=%s, personality=%s, sessionId=%s',
                quotedMsgId, ref.chatId, ref.personalityId, session.id)

        return { ref, personalityId: ref.personalityId, sessionId: session.id }
}

// ============================================================
// Main trigger check
// ============================================================

/**
 * Pre-check MURAH (tanpa API call, tanpa efek samping): apakah pesan ini akan
 * memicu AI? Dipakai bot.js agar AI gate (rate limit AI) HANYA diterapkan ke
 * pesan yang benar-benar memicu AI — bukan semua pesan chat.
 *
 * Harus MIRROR dengan alur keputusan checkAiTrigger:
 *   1. Reply ke response AI (message_refs + session masih aktif) → kandidat
 *      (Task 54: user harus terdaftar — gate registrasi berlaku juga di rikka)
 *   2. User terdaftar + text diawali trigger personality → kandidat
 *   3. Selain itu → BUKAN kandidat (checkAiTrigger pasti return false)
 *
 * Task 58 (audit full — finding F-1): ROUTING DULU, REGISTRASI BELAKANGAN.
 * Dulu _checkUserRegistration dipanggil di sini untuk SETIAP pesan masuk
 * (bot.js:1396 memanggil pre-check ini tanpa gating) → chat biasa/command
 * tetap menulis 2 lookup repo per pesan di jalur normal. Tidak pernah
 * menghasilkan warning (gate warn ada di checkAiTrigger), tapi melanggar
 * spesifikasi "chat biasa = tanpa cek registrasi" + membakar lookup tiap
 * pesan. Mirror persis pola Task 56 di checkAiTrigger: probe interaksi AI
 * (read-only) dulu → bukan interaksi → return false TANPA menyentuh repo.
 *
 * @returns {boolean}
 */
export function isAiCandidate(system, m, userRepo) {
        if (!m || !m.text) return false
        if (!system || !system.aiEnabled) return false
        try { if (m.fromMe) return false } catch { return false }

        // ---- 1. probe reply-aktif (read-only — mirror checkAiTrigger) ----
        const replyInfo = _detectReplyToAI(system, m)
        let replyUsable = false
        if (replyInfo) {
                const p = system.personalityManager.get(replyInfo.personalityId)
                replyUsable = Boolean(p && !_isAicharDisabled(system.store, p))
        }

        // ---- 2. probe trigger (read-only; hanya bila reply tidak usable) ----
        const trigMatch = replyUsable ? null : system.personalityManager.detect(m.text)

        // BUKAN interaksi AI → SILENT tanpa cek registrasi (chat biasa /
        // command / reply manusia / reply bot biasa: 0 lookup repo).
        if (!replyUsable && !trigMatch) return false

        // ---- interaksi AI terkonfirmasi → registrasi menentukan kandidat ----
        // Task 54: user belum terdaftar → tidak pernah kandidat (gate
        // registrasi berlaku juga ke rikka — mirror checkAiTrigger). Tanpa
        // userRepo (jalur lama/test) cek tidak bisa dilakukan → jangan blokir.
        const userInfo = _checkUserRegistration(userRepo, m)
        if (userRepo && !userInfo.registered) return false
        return true
}

// ============================================================
// Task 54 — AI LIMIT (scope group:aichar, sistem limit existing) +
// RELATIONSHIP context utk jalur rikka. Sama persis dengan engine
// karakter (satu scope bersama, satu fungsi rel) — tanpa duplikasi.
// ============================================================

/**
 * Reserve kuota AI. Return { ok: true, res } | { ok: false, replyText }.
 * res = hasil LimitService.reserve() (null bila limit tak tersedia /
 * user tak dikenali — obrolan tetap jalan, best-effort).
 */
function _reserveAiLimit(system, m, userInfo, role) {
        try {
                const userKey = limitUserKeyOf({
                        sender: m?.sender,
                        user: userInfo?.userId ? { user_id: userInfo.userId } : null,
                })
                if (!userKey) return { ok: true, res: null }
                const res = getLimitService(system.store).reserve({
                        userKey,
                        role: role || 'free',
                        plugin: AI_LIMIT_PLUGIN,
                })
                if (!res.ok) {
                        return { ok: false, replyText: res.replyText || buildLimitExhaustedText({ scope: res.scope, remaining: 0 }) }
                }
                return { ok: true, res }
        } catch (e) {
                logger.warn('Task 54: limit reserve AI gagal (dilewati): %s', e?.message || e)
                return { ok: true, res: null }
        }
}

/** Commit kuota — HANYA saat AI benar-benar menghasilkan response. */
function _commitAiLimit(system, res) {
        try { if (res) getLimitService(system.store).commit(res) } catch { /* best effort */ }
}

/** Release kuota — request gagal / tanpa response (kuota utuh). */
function _releaseAiLimit(system, res) {
        try { if (res) getLimitService(system.store).release(res) } catch { /* best effort */ }
}

/**
 * Dynamic relationship context (Task 54 #4/#6/#7) → dikirim sebagai
 * extraPrompt (info internal AI, bukan bagian personality prompt):
 * hubungan dengan user yang sedang bicara + user lain yang di-tag
 * dan memang dikenal (tidak mengarang).
 *
 * AI CHAT BERBASIS RELATIONSHIP: kini via generator TERPUSAT
 * getRelationshipInstructions (rel-behavior.js) — fakta + ATURAN PERILAKU
 * lengkap per tier + overlay pasangan resmi + prioritas & anti-fabrikasi,
 * dibaca FRESH per request. Return objek { block, stateKey, updateNote }
 * (stateKey/updateNote → dinamisme mid-session provider chatgpt) atau
 * null bila tidak ada data sama sekali (prompt perilaku lama utuh).
 *
 * RELATIONSHIP BEHAVIOR PER KARAKTER/PERSONA: personality boleh membawa
 * relationshipBehavior (peta tier→teks) / getRelationshipBehavior (function
 * dinamis) — cara personality ini bereaksi terhadap tier kedekatan yang sama
 * boleh berbeda dari personality lain (contoh: rikka.js tsundere menunjukkan
 * kedekatan secara tidak langsung). Tanpa konfigurasi → fallback generik
 * global. Pemanggil mengoper objek personality (semua 3 call site sudah
 * memegangnya).
 */
function _buildRelExtraPrompt(userRepo, m, personalityId, userInfo, db, personality) {
        try {
                if (!userInfo?.userId) return null
                const rel = getRelationshipInstructions({
                        userRepo,
                        db,
                        userId: userInfo.userId,
                        charId: personalityId,
                        userName: _resolveUserName(userInfo),
                        charName: personality?.name || personalityId,
                        behavior: personality?.relationshipBehavior ?? null,
                        behaviorFn: typeof personality?.getRelationshipBehavior === 'function'
                                ? personality.getRelationshipBehavior
                                : null,
                })
                if (!rel || (!rel.block && !rel.stateKey)) return null
                // User lain yang di-tag & dikenal tetap dibawa (blok terpisah,
                // tidak memengaruhi stateKey — dinamisme hanya milik SPEAKER).
                rel.block += buildMentionedContext({ userRepo, charId: personalityId, jids: extractMentions(m) })
                return rel
        } catch (e) {
                logger.debug('Task 54: rel context rikka gagal (diabaikan): %s', e?.message || e)
                return null
        }
}

/** Catat 1 interaksi relationship (best-effort). */
function _recordRelInteraction(userRepo, userInfo, personalityId) {
        try {
                if (!userInfo?.userId || typeof userRepo?.findByUserId !== 'function') return
                recordInteraction(userRepo, userInfo.userId, personalityId)
        } catch { /* best effort */ }
}

export async function checkAiTrigger(system, m, sock, userRepo, opts = {}) {
        if (!m || !m.text) return false
        if (!system.aiEnabled) return false

        // Skip pesan dari bot sendiri
        try { if (m.fromMe) return false } catch { return false }

        // Task 53 (tambahan): tag "@digit" di teks dinormalisasi dulu ke
        // nama tampilan user yang di-tag (username terdaftar / push name)
        // sebelum jadi message prompt — jalur reply maupun trigger sama-sama
        // dapat teks bersih (mencocokkan kata trigger tidak terganggu: pola
        // tag hanya menyentuh digit mention di tengah teks).
        const text = normalizeMentions(m.text, m, system.store, userRepo)
        const chatId = m.chat

        // ============================================================
        // Task 56 — ROOT CAUSE FIX "warn registrasi salah sasaran":
        // ROUTING DULU, GATE REGISTRASI BELAKANGAN.
        //
        // Dulu (Task 54): gate registrasi berdiri DI SINI — sebelum
        // routing — padahal bot.js memanggil checkAiTrigger untuk SETIAP
        // pesan masuk (chat biasa, command, reply ke manusia / bot biasa).
        // Akibat: user belum daftar kena warn "🔐 Fitur Character AI..."
        // cuma karena ngoobrol (shouldNotice 1x/menit → kesan "kadang-
        // kadang kena warn"). Flow yang benar: tentukan DULU apakah pesan
        // ini interaksi AI; BUKAN → pulang diam-diam TANPA menyentuh
        // registrasi; interaksi AI nyata → baru dicek (dan boleh di-warn).
        // Kedua probe di bawah murni read-only (tanpa efek samping).
        // ============================================================

        // ---- 1. CEK REPLY KE RESPONSE AI (priority) ----
        const replyInfo = _detectReplyToAI(system, m)

        // Jalur reply hanya "usable" bila personality-nya hidup. Task 53:
        // karakter dimatikan (.setaireply off) → jatuh ke jalur trigger
        // (mirror alur lama — reply path di bawah mengecek ulang kondisi
        // yang sama, hasil identik karena keduanya read-only).
        let replyUsable = false
        if (replyInfo) {
                const p = system.personalityManager.get(replyInfo.personalityId)
                replyUsable = Boolean(p && !_isAicharDisabled(system.store, p))
        }

        // ---- 2. CEK TRIGGER TEXT (rik/rikka) ----
        // Hanya dihitung bila jalur reply tidak dipakai (reply aktif menang).
        const trigMatch = replyUsable ? null : system.personalityManager.detect(text)

        // BUKAN interaksi AI → SILENT. Registrasi TIDAK PERNAH dicek di
        // jalur ini — chat biasa / command / reply ke manusia / reply ke
        // bot biasa (menu dll) mustahil menghasilkan warning registrasi.
        if (!replyUsable && !trigMatch) return false

        // ---- CEK REGISTRASI — HANYA setelah interaksi AI terkonfirmasi ----
        // (Feed context group TIDAK dilakukan di sini — bot.js sudah feed semua
        // pesan group sebelum memanggil fungsi ini. Duplikasi feed membuat context
        // AI berisi pesan yang sama dua kali.)
        const userInfo = _checkUserRegistration(userRepo, m)
        const userName = _resolveUserName(userInfo)

        // ---- Task 54: GATE REGISTRASI (berlaku juga ke rikka) ----
        // Owner bypass (pemilik bot tidak perlu .daftar untuk mengetes).
        // Tanpa userRepo (jalur lama/test) cek tidak bisa dilakukan → lewati
        // (mirror engine: jangan mematahkan jalur tanpa userRepo).
        if (userRepo && !userInfo.registered && !opts.isOwner) {
                // Task 56: debug trace sementara — bukti gate hanya jalan
                // SETELAH routing interaksi AI cocok (lihat relationship.js).
                logRegWarnTrace({
                        route: 'rikka',
                        scope: replyUsable ? 'reply-continue' : 'trigger',
                        characterId: (replyUsable ? replyInfo?.personalityId : trigMatch?.personalityId) || null,
                        sessionId: replyInfo?.sessionId || null,
                        m, chatId, text,
                })
                if (shouldNotice(`${chatId}|${m.sender || 'anon'}`)) {
                        await m.reply(unregisteredText()).catch(() => {})
                }
                return false
        }

        if (replyInfo) {
                const { personalityId } = replyInfo
                const personality = system.personalityManager.get(personalityId)
                // Task 53: personality sintesis karakter aianime yang DIMATIKAN
                // owner (.setaireply off miku) → jangan dibalas rikka di sini.
                if (personality && !_isAicharDisabled(system.store, personality)) {
                        // Task 54: reserve kuota AI SEBELUM provider call.
                        const gate = _reserveAiLimit(system, m, userInfo, opts.role)
                        if (!gate.ok) {
                                await m.reply(gate.replyText).catch(() => {})
                                return true
                        }
                        try {
                                logger.debug('[AI-REPLY] Processing reply to AI: chatId=%s, personality=%s, text=%s', chatId, personalityId, text)

                                // AI CHAT BERBASIS RELATIONSHIP: blok perilaku +
                                // stateKey/updateNote (dinamisme mid-session).
                                const relPrompt = _buildRelExtraPrompt(userRepo, m, personalityId, userInfo, system.store, personality)
                                const result = await aiResponse(system, {
                                        personality: personalityId,
                                        userId: m.sender,
                                        chatId,
                                        message: text,
                                        isGroup: m.isGroup,
                                        isReply: true,
                                        userName,
                                        userRepo,
                                        // Task 54: relationship context (dynamic, info internal)
                                        extraPrompt: relPrompt?.block || undefined,
                                        relStateKey: relPrompt?.stateKey || undefined,
                                        relUpdateNote: relPrompt?.updateNote || undefined,
                                })

                                if (result.response) {
                                        // Task 54: AI benar-benar membalas → konsumsi kuota
                                        // (GAGAL/koSONG → release, kuota utuh).
                                        _commitAiLimit(system, gate.res)
                                        _recordRelInteraction(userRepo, userInfo, personalityId)
                                        const sentResult = await m.reply(String(result.response))
                                        const sentId = _getSentMessageId(sentResult)
                                        if (sentId) {
                                                _saveMessageRef(system.store, sentId, chatId, personalityId, result.session?.id)
                                                logger.debug('[AI-REPLY] Saved new ref: %s', sentId)
                                        }
                                } else {
                                        _releaseAiLimit(system, gate.res)
                                }

                                return true
                        } catch (e) {
                                _releaseAiLimit(system, gate.res)
                                logger.error('AI reply error (%s): %s\n%s', personalityId, e.message, e.stack || '')
                                return false
                        }
                }
        }

        // ---- 2. CEK TRIGGER TEXT (rik/rikka) ----
        // (trigMatch sudah dihitung saat routing Task 56 — sampai sini pasti
        // non-null utk jalur trigger; fallback detect hanya pengaman, read-only
        // dengan hasil identik.)
        const match = trigMatch || system.personalityManager.detect(text)
        if (!match) return false

        const { personalityId } = match
        const personality = system.personalityManager.get(personalityId)
        if (!personality) return false

        // ---- SCHEDULE CHECK (tanpa API call) ----
        // (belum reserve kuota — rikka tidak aktif = tidak ada jawaban AI
        // = tidak boleh konsumsi kuota.)
        if (!system.hasScheduleBypass(chatId)) {
                const scheduleStatus = system.scheduleManager.getStatus(personalityId, personality)
                if (!scheduleStatus.active) {
                        const reply = scheduleStatus.message || `${personality.name} sedang tidak tersedia.`
                        await m.reply(String(reply))
                        return true
                }
        }

        // ---- Task 54: reserve kuota AI SEBELUM API call ----
        const gate = _reserveAiLimit(system, m, userInfo, opts.role)
        if (!gate.ok) {
                await m.reply(gate.replyText).catch(() => {})
                return true
        }

        // ---- API CALL ----
        try {
                // AI CHAT BERBASIS RELATIONSHIP: blok perilaku +
                // stateKey/updateNote (dinamisme mid-session).
                const relPrompt = _buildRelExtraPrompt(userRepo, m, personalityId, userInfo, system.store, personality)
                const result = await aiResponse(system, {
                        personality: personalityId,
                        userId: m.sender,
                        chatId,
                        message: text,
                        isGroup: m.isGroup,
                        isReply: Boolean(m.quoted),
                        userName,
                        userRepo,
                        // Task 54: relationship context (dynamic, info internal)
                        extraPrompt: relPrompt?.block || undefined,
                        relStateKey: relPrompt?.stateKey || undefined,
                        relUpdateNote: relPrompt?.updateNote || undefined,
                })

                if (result.response) {
                        // Task 54: AI benar-benar membalas → konsumsi kuota
                        _commitAiLimit(system, gate.res)
                        _recordRelInteraction(userRepo, userInfo, personalityId)
                        const sentResult = await m.reply(String(result.response))
                        const sentId = _getSentMessageId(sentResult)
                        if (sentId) {
                                _saveMessageRef(system.store, sentId, chatId, personalityId, result.session?.id)
                                logger.debug('[AI-TRIGGER] Saved ref: %s for chatId=%s', sentId, chatId)
                        }
                } else {
                        _releaseAiLimit(system, gate.res)
                }

                return true
        } catch (e) {
                _releaseAiLimit(system, gate.res)
                logger.error('AI trigger error (%s): %s\n%s', personalityId, e.message, e.stack || '')
                return false
        }
}

// ============================================================
// AI WORLD KNOWLEDGE TASK — GIFT → AI REPLY (jalur rikka)
// ============================================================

/**
 * FUNNEL GIFT → AI REPLY untuk RIKKA (karakter built-in, BUKAN file
 * aianime — engine notifyGiftEvent tidak menemukannya). Dipanggil
 * plugins/aianime/gif.js SETELAH giveGift() sukses ke rikka.
 *
 * Alur MIRROR checkAiTrigger (tanpa duplikasi logika baru — semua helper
 * existing): schedule → registrasi → reserve limit → aiResponse (extraPrompt
 * = relationship context + world knowledge) → commit → reply → simpan ref
 * (reply-continue jalan). Interaksi relationship TIDAK dicatat ulang —
 * giveGift sudah memberi exp/gifts/giftLog (anti dobel hitung).
 *
 * Rikka sedang tidur (schedule tidak aktif) → TIDAK ada balasan AI (gift
 * tetap sah — konfirmasi transaksi .gif sudah terkirim; sistem AI dimatikan
 * → idem). Best-effort: error → { ok:false } — transaksi gift tidak
 * terpengaruh.
 *
 * @param {object} system - aiSystem (ctx.sock._aiSystem)
 * @param {object} p - { m, userRepo, role, gift, userName }
 * @param {object} p.gift - { name, qty, after, before, levelUp, beforeLevel }
 *     (after/before = hasil relStatus() giveGift)
 * @returns {Promise<{ok: boolean, error?: string}>}
 */
export async function triggerGiftReply(system, { m, userRepo, role, gift, userName } = {}) {
        try {
                if (!system || !system.aiEnabled) return { ok: false, error: 'ai-off' }
                if (!m || !m.chat) return { ok: false, error: 'konteks tidak valid' }
                const personalityId = 'rikka'
                const personality = system.personalityManager.get(personalityId)
                if (!personality) return { ok: false, error: 'personality' }
                if (_isAicharDisabled(system.store, personality)) return { ok: false, error: 'karakter dimatikan' }

                // schedule rikka tidur → tanpa balasan AI (transaksi sudah dibalas .gif)
                if (!system.hasScheduleBypass?.(m.chat)) {
                        const st = system.scheduleManager.getStatus(personalityId, personality)
                        if (!st?.active) return { ok: false, error: 'schedule' }
                }

                // registrasi — pemberi gift selalu terdaftar (giveGift syarat ctx.user),
                // cek tetap dijaga utk jalur tidak normal.
                const userInfo = _checkUserRegistration(userRepo, m)
                if (userRepo && !userInfo.registered) return { ok: false, error: 'unregistered' }

                const text = buildGiftEventText({ userName: userName || _resolveUserName(userInfo), gift })

                // reserve kuota (sistem limit yang sama — AI benar-benar membalas → commit)
                const gate = _reserveAiLimit(system, m, userInfo, role)
                if (!gate.ok) {
                        await m.reply(gate.replyText).catch(() => {})
                        return { ok: false, error: 'limit' }
                }

                let result
                try {
                        // AI CHAT BERBASIS RELATIONSHIP: blok perilaku +
                        // stateKey/updateNote (dinamisme mid-session) + world
                        // knowledge (fakta char 'rikka' → group chat → global —
                        // modul sama dengan engine karakter, tanpa implementasi dobel).
                        const relPrompt = _buildRelExtraPrompt(userRepo, m, personalityId, userInfo, system.store, personality)
                        result = await aiResponse(system, {
                                personality: personalityId,
                                userId: m.sender,
                                chatId: m.chat,
                                message: text,
                                isGroup: m.isGroup,
                                isReply: true,
                                userName: _resolveUserName(userInfo),
                                userRepo,
                                extraPrompt: ((relPrompt?.block || '')
                                        + buildWorldKnowledgeBlock({ db: system.store, chatId: m.chat, charId: personalityId }))
                                        || undefined,
                                relStateKey: relPrompt?.stateKey || undefined,
                                relUpdateNote: relPrompt?.updateNote || undefined,
                        })
                } catch (e) {
                        // API gagal → RELEASE kuota (kuota utuh — pola checkAiTrigger)
                        _releaseAiLimit(system, gate.res)
                        logger.warn('[AI-GIFT] gift reply rikka gagal (api): %s', e?.message || e)
                        return { ok: false, error: 'api' }
                }

                if (result.response) {
                        _commitAiLimit(system, gate.res)
                        // gift exp sudah dicatat giveGift → TIDAK recordInteraction
                        const sentResult = await m.reply(String(result.response))
                        const sentId = _getSentMessageId(sentResult)
                        if (sentId) {
                                _saveMessageRef(system.store, sentId, m.chat, personalityId, result.session?.id)
                        }
                        return { ok: true }
                }
                _releaseAiLimit(system, gate.res)
                return { ok: false, error: 'empty' }
        } catch (e) {
                logger.warn('[AI-GIFT] gift reply rikka gagal: %s', e?.message || e)
                return { ok: false, error: 'api' }
        }
}

export { aiResponse }