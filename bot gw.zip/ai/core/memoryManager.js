import logger from '../../lib/core/logger.js'

export class MemoryManager {
        constructor(store) {
                this.store = store
                this.maxPerKey = 50
        }

        _ensureData() {
                if (!this.store.data.ai) this.store.data.ai = {}
                if (!this.store.data.ai.user_memories) this.store.data.ai.user_memories = {}
                if (!this.store.data.ai.group_memories) this.store.data.ai.group_memories = {}
        }

        add(scope, id, personalityId, memory) {
                this._ensureData()
                if (!memory || !memory.content) return null

                const content = String(memory.content)
                const storeKey = scope === 'user' ? 'user_memories' : 'group_memories'
                const target = this.store.data.ai[storeKey]

                if (!target[id]) target[id] = {}
                if (!target[id][personalityId]) target[id][personalityId] = []

                const entry = {
                        content,
                        keywords: memory.keywords || this._extractKeywords(content),
                        importance: memory.importance || 0.5,
                        createdAt: Date.now(),
                }

                target[id][personalityId].push(entry)

                if (target[id][personalityId].length > this.maxPerKey) {
                        target[id][personalityId] = target[id][personalityId].slice(-this.maxPerKey)
                }

                this.store.writeDirty?.('ai')
                return entry
        }

        getRelevant({ personalityId, userId, chatId, query, limit = 10 }) {
                this._ensureData()
                const scored = []

                const sources = []
                if (userId) {
                        sources.push(this.store.data.ai.user_memories[userId]?.[personalityId] || [])
                }
                if (chatId) {
                        sources.push(this.store.data.ai.group_memories[chatId]?.[personalityId] || [])
                }

                const queryLower = (query || '').toLowerCase()
                const queryWords = queryLower.split(/\s+/).filter(Boolean)

                for (const source of sources) {
                        for (const mem of source) {
                                const content = (mem.content || '').toLowerCase()
                                let score = 0
                                for (const kw of (mem.keywords || [])) {
                                        if (queryLower.includes(String(kw).toLowerCase())) score += 1
                                }
                                for (const w of queryWords) {
                                        if (content.includes(w)) score += 0.5
                                }
                                score += (mem.importance || 0.5)
                                if (score > 0) scored.push({ ...mem, score })
                        }
                }

                scored.sort((a, b) => b.score - a.score)
                return scored.slice(0, limit)
        }

        delete(scope, id, personalityId, index) {
                this._ensureData()
                const storeKey = scope === 'user' ? 'user_memories' : 'group_memories'
                const target = this.store.data.ai[storeKey]

                if (!target[id]?.[personalityId]) return false
                if (index < 0 || index >= target[id][personalityId].length) return false

                target[id][personalityId].splice(index, 1)
                this.store.writeDirty?.('ai')
                return true
        }

        list(scope, id, personalityId) {
                this._ensureData()
                const storeKey = scope === 'user' ? 'user_memories' : 'group_memories'
                return this.store.data.ai[storeKey]?.[id]?.[personalityId] || []
        }

        _extractKeywords(text) {
                const safe = String(text || '')
                const stopWords = new Set([/* ... sama ... */])
                return safe.toLowerCase()
                        .split(/[^a-zA-Z0-9\u00C0-\u024F]+/)
                        .filter(w => w.length > 2 && !stopWords.has(w))
                        .slice(0, 10)
        }
}