import logger from '../../lib/core/logger.js'

export class SessionManager {
        constructor(store) {
                this.store = store
        }

        _ensureData() {
                if (!this.store.data.ai) this.store.data.ai = {}
                if (!this.store.data.ai.sessions) this.store.data.ai.sessions = {}
        }

        _key(chatId, userId, personalityId) {
                return `${chatId}:${userId || 'shared'}:${personalityId}`
        }

        getActive(chatId, userId, personalityId, timeout = 300000) {
                this._ensureData()
                const key = this._key(chatId, userId, personalityId)
                const session = this.store.data.ai.sessions[key]
                if (!session) return null

                const now = Date.now()
                if (now - session.lastActivity > timeout) {
                        delete this.store.data.ai.sessions[key]
                        this.store.writeDirty?.('ai')   // FIX: persist delete
                        return null
                }
                return session
        }

        create(chatId, userId, personalityId) {
                this._ensureData()
                const key = this._key(chatId, userId, personalityId)
                const session = {
                        id: key,
                        chatId,
                        userId,
                        personalityId,
                        createdAt: Date.now(),
                        lastActivity: Date.now(),
                        messageCount: 0,
                }
                this.store.data.ai.sessions[key] = session
                this.store.writeDirty?.('ai')
                return session
        }

        update(session) {
                if (!session) return
                session.lastActivity = Date.now()
                session.messageCount = (session.messageCount || 0) + 1
                this.store.writeDirty?.('ai')
        }

        destroy(chatId, userId, personalityId) {
                this._ensureData()
                const key = this._key(chatId, userId, personalityId)
                if (this.store.data.ai.sessions[key]) {
                        delete this.store.data.ai.sessions[key]
                        this.store.writeDirty?.('ai')
                }
        }

        cleanup(timeout = 300000) {
                this._ensureData()
                const now = Date.now()
                const sessions = this.store.data.ai.sessions
                let cleaned = 0
                for (const key of Object.keys(sessions)) {
                        if (now - sessions[key].lastActivity > timeout) {
                                delete sessions[key]
                                cleaned++
                        }
                }
                if (cleaned > 0) {
                        this.store.writeDirty?.('ai')
                        logger.debug('Session cleanup: %d expired', cleaned)
                }
        }
}