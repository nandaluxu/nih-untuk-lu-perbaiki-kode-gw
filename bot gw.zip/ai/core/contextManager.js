import logger from '../../lib/core/logger.js'

export class ContextManager {
        constructor() {
                this.buffers = new Map()
                this.retentionMs = 10 * 60 * 1000
                this.maxMessages = 100
                this.maxMessageChars = 500
        }

        add(chatId, sender, text) {
                if (!text) return
                const safeText = String(text)
                if (!this.buffers.has(chatId)) {
                        this.buffers.set(chatId, { messages: [], lastActivity: Date.now() })
                }
                const buf = this.buffers.get(chatId)
                buf.messages.push({
                        sender: sender || 'unknown',
                        text: safeText.length > this.maxMessageChars
                                ? safeText.slice(0, this.maxMessageChars) + '…'
                                : safeText,
                        timestamp: Date.now(),
                })
                buf.lastActivity = Date.now()

                if (buf.messages.length > this.maxMessages) {
                        buf.messages = buf.messages.slice(-this.maxMessages)
                }
        }

        /**
         * @param {Object} opts
         * @param {number} opts.maxMessages
         * @param {number} opts.maxChars
         * @param {Function} opts.resolveName - async (senderOrMsg) => string|null
         * @param {string} [opts.excludeSender] - kalau diisi, pesan dgn sender ini
         *        di akhir buffer dianggap current message dan di-exclude.
         *        Kalau tidak diisi, pesan terakhir selalu di-exclude (asumsi
         *        add() dipanggil sebelum aiResponse).
         */
        async getRecentFormatted(chatId, { maxMessages = 20, maxChars = 6000, resolveName, excludeSender } = {}) {
                const buf = this.buffers.get(chatId)
                if (!buf) return null

                this._cleanupExpired(chatId, buf)
                if (buf.messages.length <= 1) return null

                let recent
                if (excludeSender !== undefined) {
                        // Buang pesan terakhir hanya kalau sender-nya cocok
                        const last = buf.messages[buf.messages.length - 1]
                        recent = last.sender === excludeSender
                                ? buf.messages.slice(-(maxMessages + 1), -1)
                                : buf.messages.slice(-maxMessages)
                } else {
                        recent = buf.messages.slice(-(maxMessages + 1), -1)
                }

                if (recent.length === 0) return null

                const formatted = []
                for (const msg of recent) {
                        let name = msg.sender
                        if (resolveName) {
                                try {
                                        const resolved = await resolveName(msg.sender)
                                        if (resolved) name = resolved
                                } catch { /* fallback */ }
                        }
                        formatted.push({ name, text: msg.text, timestamp: msg.timestamp })
                }

                let result = ''
                let chars = 0
                for (let i = formatted.length - 1; i >= 0; i--) {
                        const msg = formatted[i]
                        const line = `[${msg.name}]: ${msg.text}`
                        if (chars + line.length > maxChars) break
                        result = line + '\n' + result
                        chars += line.length
                }

                return result.trim() || null
        }

        _cleanupExpired(chatId, buf) {
                const now = Date.now()
                const cutoff = now - this.retentionMs
                const before = buf.messages.length
                buf.messages = buf.messages.filter(m => m.timestamp >= cutoff)
                if (buf.messages.length !== before) {
                        // Refresh lastActivity supaya buffer tidak dianggap "hidup"
                        // hanya karena pesan lama yang belum kehapus.
                        buf.lastActivity = now
                }
                if (buf.messages.length === 0) {
                        this.buffers.delete(chatId)
                }
        }

        cleanupAll() {
                const now = Date.now()
                for (const [chatId, buf] of this.buffers) {
                        if (now - buf.lastActivity > this.retentionMs) {
                                this.buffers.delete(chatId)
                        } else {
                                this._cleanupExpired(chatId, buf)
                        }
                }
        }
}