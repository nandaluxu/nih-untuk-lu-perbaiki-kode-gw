/**
 * ProviderManager — registry + rotasi + health + concurrency AI (Task 32).
 *
 * Dulu:
 *  - rotasi linear SELALU mulai key[0] → key pertama menanggung semua beban,
 *    retry 429 3× berturut-turut (~30-40 dtk) di dalam handler.
 *  - TANPA timeout SDK → request bisa menggantung tanpa batas.
 *  - TANPA limit concurrency global → grup ramai = lonjakan call paralel.
 *
 * Kini:
 *  - Health state per (provider, key): { failures, cooldownUntil, lastError }.
 *    429 → cooldown sesuai retry-after (min 15s, max 10 menit); error lain →
 *    cooldown pendek 30s. Key yang sedang cooldown dilewati.
 *  - Round-robin start index → beban key merata.
 *  - Timeout request keras (AI_TIMEOUT_MS, default 60s) via lib/async-utils.
 *  - Semaphore global (AI_MAX_CONCURRENCY, default 3) + antrean bounded
 *    (AI_QUEUE_MAX, default 20) → overload ditolak cepat (AI_BUSY).
 */
import logger from '../../lib/core/logger.js'
import { withTimeout, Semaphore } from '../../lib/core/async-utils.js'
import { getHealth } from '../../lib/features/health.js'

const DEFAULT_TIMEOUT_MS = 60_000
const DEFAULT_MAX_CONCURRENCY = 3
const DEFAULT_MAX_QUEUE = 20
const COOLDOWN_OTHER_MS = 30_000
const COOLDOWN_429_MIN_MS = 15_000
const COOLDOWN_429_MAX_MS = 600_000

export class ProviderManager {
        constructor(providers, store, aiConfig) {
                this._providers = new Map()
                for (const p of providers) {
                        this._providers.set(p.id, p)
                }
                this.store = store
                this.aiConfig = aiConfig

                // ---- Task 32: timeout + concurrency dari env (dengan default) ----
                const envInt = (name, dflt) => {
                        const n = Number.parseInt(process.env[name] || '', 10)
                        return Number.isFinite(n) && n > 0 ? n : dflt
                }
                this.timeoutMs = envInt('AI_TIMEOUT_MS', DEFAULT_TIMEOUT_MS)
                this.maxConcurrency = envInt('AI_MAX_CONCURRENCY', DEFAULT_MAX_CONCURRENCY)
                this.maxQueue = envInt('AI_QUEUE_MAX', DEFAULT_MAX_QUEUE)
                this._semaphore = new Semaphore(this.maxConcurrency, this.maxQueue)

                /**
                 * Health state per `${providerId}:${keyIndex}`.
                 * @type {Map<string, { failures: number, cooldownUntil: number, lastError: string|null }>}
                 */
                this._health = new Map()
                /** Round-robin cursor per provider. */
                this._rr = new Map()
        }

        getProvider(id) {
                return this._providers.get(id) || null
        }

        getActiveProviderId() {
                return this.store.data.ai?.provider_config?.active || 'chatgpt'
        }

        setActiveProvider(id) {
                if (!this._providers.has(id)) return false
                if (!this.store.data.ai) this.store.data.ai = {}
                if (!this.store.data.ai.provider_config) {
                        this.store.data.ai.provider_config = { active: 'chatgpt', keys: {} }
                }
                this.store.data.ai.provider_config.active = id
                this.store.writeDirty?.('ai')
                return true
        }

        getKeys(providerId) {
                // Task 51: provider keyless (scrape chatgpt) — pseudo-key tunggal;
                // health/cooldown tetap jalan per pseudo-key ini.
                const provider = this._providers.get(providerId)
                if (provider?.keyless) {
                        return ['anon']
                }
                const envKeys = this.aiConfig[providerId + 'Keys'] || []
                const stored = this.store.data.ai?.provider_config?.keys?.[providerId]
                return stored || envKeys
        }

        listProviders() {
                const active = this.getActiveProviderId()
                return Array.from(this._providers.values()).map(p => ({
                        id: p.id,
                        name: p.name,
                        active: p.id === active,
                        models: p.models,
                        keys: this.getKeys(p.id).length,
                        coolingKeys: this._coolingCount(p.id, this.getKeys(p.id).length),
                }))
        }

        resolveModel(providerId, requestedModel) {
                const provider = this.getProvider(providerId)
                if (!provider) return null
                if (requestedModel && requestedModel !== 'auto' && provider.models.includes(requestedModel)) {
                        return requestedModel
                }
                return provider.models[0]
        }

        // ------------------------------------------------------------------
        // Health state (Task 32)
        // ------------------------------------------------------------------

        _healthKey(providerId, keyIndex) {
                return `${providerId}:${keyIndex}`
        }

        _coolingCount(providerId, keyCount) {
                let n = 0
                const now = Date.now()
                for (let i = 0; i < keyCount; i++) {
                        const h = this._health.get(this._healthKey(providerId, i))
                        if (h && h.cooldownUntil > now) n++
                }
                return n
        }

        _markFailure(providerId, keyIndex, err) {
                const key = this._healthKey(providerId, keyIndex)
                const h = this._health.get(key) || { failures: 0, cooldownUntil: 0, lastError: null }
                h.failures++
                h.lastError = String(err?.message || err).slice(0, 200)

                const status = err?.status || err?.statusCode || 0
                const msg = h.lastError
                const is429 = status === 429 || /rate.?limit/i.test(msg) || /try again in \d+s/i.test(msg)

                if (is429) {
                        // Hormati retry-after dari pesan provider bila ada
                        const m = msg.match(/try again in (\d+)s/i)
                        let ms = m ? Number(m[1]) * 1000 : COOLDOWN_429_MIN_MS
                        ms = Math.min(Math.max(ms, COOLDOWN_429_MIN_MS), COOLDOWN_429_MAX_MS)
                        h.cooldownUntil = Date.now() + ms
                } else {
                        h.cooldownUntil = Date.now() + COOLDOWN_OTHER_MS
                }
                this._health.set(key, h)
        }

        _markSuccess(providerId, keyIndex) {
                this._health.set(this._healthKey(providerId, keyIndex), {
                        failures: 0, cooldownUntil: 0, lastError: null,
                })
        }

        /**
         * Bersihkan health state yang sudah lama sehat supaya Map tidak tumbuh
         * tanpa batas. Panggil periodik (mis. tiap jam).
         */
        cleanupHealth(maxAgeMs = 60 * 60 * 1000) {
                const now = Date.now()
                for (const [key, h] of this._health) {
                        // Sehat (tidak cooldown, tanpa failure) → hapus
                        if (h.cooldownUntil < now && h.failures === 0) {
                                this._health.delete(key)
                        }
                        // Cooldown lama yang sudah lewat jauh → hapus
                        else if (h.cooldownUntil && h.cooldownUntil < now - maxAgeMs) {
                                this._health.delete(key)
                        }
                }
        }

        /** Susun urutan percobaan (provider × key) dengan round-robin + skip cooldown. */
        _buildAttempts(providerOrder, requestedModel) {
                const attempts = []
                const now = Date.now()
                for (const pid of providerOrder) {
                        const provider = this.getProvider(pid)
                        if (!provider) continue
                        const keys = this.getKeys(pid)
                        if (!keys.length) continue
                        const resolved = this.resolveModel(pid, requestedModel)
                        if (!resolved) continue

                        // Task 51: provider keyless (scrape chatgpt) → 1 pseudo-key
                        // 'anon' — tidak butuh env/store key.
                        if (provider.keyless) {
                                const h = this._health.get(this._healthKey(pid, 0))
                                if (h && h.cooldownUntil > now) continue
                                attempts.push({ provider, pid, keyIndex: 0, key: 'anon', model: resolved })
                                continue
                        }

                        const start = (this._rr.get(pid) || 0) % keys.length
                        let pushedAny = false
                        for (let off = 0; off < keys.length; off++) {
                                const idx = (start + off) % keys.length
                                const h = this._health.get(this._healthKey(pid, idx))
                                if (h && h.cooldownUntil > now) continue // sedang cooldown
                                attempts.push({ provider, pid, keyIndex: idx, key: keys[idx], model: resolved })
                                pushedAny = true
                        }
                        // FIX: cursor maju HANYA kalau ada key yang benar-benar dicoba
                        // — supaya key yang sedang cooldown tidak "dilewati permanen".
                        if (pushedAny) {
                                this._rr.set(pid, (start + 1) % keys.length)
                        }
                }
                return attempts
        }

        async generate({ provider: requestedProvider, model: requestedModel, messages, temperature, maxTokens, compoundCustom, extra = {} }) {
                const providerOrder = this._getProviderOrder(requestedProvider)
                const attempts = this._buildAttempts(providerOrder, requestedModel)
                let lastError = null

                if (attempts.length === 0) {
                        const cooling = providerOrder
                                .map(pid => `${pid}:${this._coolingCount(pid, this.getKeys(pid).length)}/${this.getKeys(pid).length} cooling`)
                                .join(', ')
                        const err = new Error(`Semua provider/key AI sedang cooldown atau tidak dikonfigurasi (${cooling}).`)
                        err.status = 503
                        throw err
                }

                for (const attempt of attempts) {
                        const { provider, pid, keyIndex, key, model } = attempt
                        try {
                                logger.debug('AI: trying %s/%s (key #%d)', pid, model, keyIndex)
                                // Task 51: provider bisa mendeklarasikan timeout sendiri
                                // (scrape chatgpt: stream di-fence internal 150s — cap
                                // luar 180s, supaya withTimeout default 60s TIDAK memotong
                                // stream panjang lebih dulu).
                                const timeoutMs = provider.timeoutMs || this.timeoutMs
                                const response = await this._semaphore.run(() =>
                                        withTimeout(
                                                provider.generate({ model, messages, apiKey: key, temperature, maxTokens, compoundCustom, extra }),
                                                timeoutMs,
                                                `AI ${pid}/${model}`,
                                        )
                                )
                                this._markSuccess(pid, keyIndex)
                                this._logUsage(pid, model, true)
                                getHealth().healthy('AI')
                                return { response, provider: pid, model }
                        } catch (e) {
                                if (e?.code === 'AI_BUSY') throw e // antrean penuh — jangan coba key lain
                                lastError = e
                                this._markFailure(pid, keyIndex, e)
                                logger.debug('AI: %s/%s key #%d failed: %s', pid, model, keyIndex, e.message)
                        }
                }

                // FIX: providerOrder[0] bisa undefined kalau order kosong
                this._logUsage(providerOrder[0] || 'unknown', requestedModel, false)
                getHealth().degraded('AI', 'semua provider gagal')
                throw lastError || new Error('Semua provider gagal.')
        }

        _getProviderOrder(requested) {
                if (!requested || requested === 'auto') {
                        const active = this.getActiveProviderId()
                        const others = Array.from(this._providers.keys()).filter(id => id !== active)
                        return [active, ...others]
                }
                const others = Array.from(this._providers.keys()).filter(id => id !== requested)
                return [requested, ...others]
        }

        _logUsage(provider, model, success) {
                if (!this.store.data.ai) this.store.data.ai = {}
                if (!this.store.data.ai.provider_usage) this.store.data.ai.provider_usage = {}
                const key = `${provider}:${model}`
                if (!this.store.data.ai.provider_usage[key]) {
                        this.store.data.ai.provider_usage[key] = { total: 0, success: 0, fail: 0 }
                }
                const stat = this.store.data.ai.provider_usage[key]
                stat.total++
                if (success) stat.success++
                else stat.fail++
        }
}