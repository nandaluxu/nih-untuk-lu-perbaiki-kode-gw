import logger from '../../lib/core/logger.js'
// PHASE 1 (identity consolidation): rantai profil kanonik lib/identity.
import { findProfileForMessage } from '../../lib/identity/index.js'

/**
 * Resolve senderId (JID/PN/LID) ke nama user.
 * CATATAN: findProfileForMessage butuh message object (sender, senderLid),
 * bukan hanya senderId. Karena itu resolver menerima { sender, senderLid }
 * atau string; kalau string, dipakai sebagai sender + senderLid.
 */
function _makeNameResolver(userRepo, currentUserName) {
        const cache = new Map()

        return async function resolveName(senderOrMsg) {
                if (!senderOrMsg) return null

                // Normalisasi: string → { sender, senderLid }
                const msg = typeof senderOrMsg === 'string'
                        ? { sender: senderOrMsg, senderLid: senderOrMsg }
                        : senderOrMsg

                const cacheKey = msg.sender || msg.senderLid
                if (!cacheKey || cacheKey === 'unknown') return null

                if (cache.has(cacheKey)) return cache.get(cacheKey)

                if (userRepo) {
                        try {
                                const user = findProfileForMessage(userRepo, msg)
                                if (user?.username) {
                                        cache.set(cacheKey, user.username)
                                        return user.username
                                }
                        } catch (e) {
                                logger.debug('resolveName gagal untuk %s: %s', cacheKey, e.message)
                        }
                }

                cache.set(cacheKey, null)
                return null
        }
}

export async function aiResponse(system, options) {
        const {
                personality: personalityId,
                userId,
                chatId,
                message,
                isGroup,
                isReply,
                useMemory = true,
                useContext = true,
                provider,
                model,
                compoundCustom,
                extraPrompt,
                temperature,
                maxTokens,
                userName,
                userRepo,
                sender,          // opsional: objek/ID pengirim untuk resolver
        } = options

        const startTime = Date.now()
        let usedProvider = null
        let usedModel = null

        try {
                // 1. Get personality
                const personality = system.personalityManager.get(personalityId)
                if (!personality) throw new Error(`Personal ${personalityId} tidak ditemukan.`)

                // 2. Check schedule
                const scheduleStatus = system.scheduleManager.getStatus(personalityId, personality)

                // 3. Session
                let session = null
                if (personality.session?.enabled !== false) {
                        const timeout = personality.session?.timeout || 300000
                        session = system.sessionManager.getActive(chatId, userId, personalityId, timeout)
                        if (!session) {
                                session = system.sessionManager.create(chatId, userId, personalityId)
                        }
                }

                // 4. Context (async, resolve JID ke nama)
                let context = null
                if (useContext && personality.context?.enabled !== false && isGroup) {
                        const resolveName = _makeNameResolver(userRepo, userName)
                        context = await system.contextManager.getRecentFormatted(chatId, {
                                maxMessages: personality.context?.maxMessages || 6,
                                maxChars: personality.context?.maxChars || 1200,
                                resolveName,
                        })
                }

                // 5. Memory
                let memories = null
                if (useMemory && personality.memory?.enabled !== false) {
                        memories = system.memoryManager.getRelevant({
                                personalityId, userId, chatId, query: message, limit: 10,
                        })
                }

                // 6. Build prompt (current message TERPISAH dari context)
                const messages = system.promptManager.build({
                        systemPrompt: personality.systemPrompt,
                        scheduleStatus,
                        memories,
                        context,
                        message,
                        extraPrompt,
                        userName,
                })

                // 7. Resolve provider/model
                // FIX: personality.provider undefined ≠ 'auto'
                const resolvedProvider = (provider === 'auto' || !provider)
                        ? (personality.provider && personality.provider !== 'auto' ? personality.provider : null)
                        : provider
                const resolvedModel = (model === 'auto' || !model)
                        ? (personality.model && personality.model !== 'auto' ? personality.model : null)
                        : model

                // 8. Generate
                const conversationUserId = userId || 'shared'  // konsisten dgn SessionManager
                const result = await system.providerManager.generate({
                        provider: resolvedProvider,
                        model: resolvedModel,
                        messages,
                        temperature,
                        maxTokens,
                        compoundCustom: compoundCustom || null,
                        extra: {
                                conversationKey: `${personalityId}|${chatId}|${conversationUserId}`,
                                sessionId: session?.id || null,
                        },
                })

                usedProvider = result.provider
                usedModel = result.model

                // 9. Update session
                if (session) system.sessionManager.update(session)

                // 10. Log
                const latency = Date.now() - startTime
                logger.debug('AI: %s | %s/%s | %dms', personalityId, usedProvider, usedModel, latency)

                return {
                        response: result.response,
                        session,
                        personality,
                        provider: usedProvider,
                        model: usedModel,
                        latency,
                }
        } catch (e) {
                const latency = Date.now() - startTime
                logger.error('AI: %s | error: %s (%dms)', personalityId, e.message, latency)
                throw e
        }
}