import logger from '../../lib/core/logger.js'
import { tzParts, tzWeekday } from '../../lib/core/timezone.js'

export class ScheduleManager {
        constructor() {
                this.timeSlots = []
        }

        /**
         * Register slot untuk satu personality.
         * FIX: slot lama untuk personalityId yang sama dibersihkan dulu
         * supaya tidak menumpuk saat personality di-reload.
         */
        registerSlots(personalityId, slots) {
                if (!personalityId) {
                        logger.warn('ScheduleManager.registerSlots: personalityId kosong, dilewati')
                        return
                }
                if (!Array.isArray(slots)) {
                        logger.warn('ScheduleManager.registerSlots: slots bukan array untuk %s', personalityId)
                        return
                }

                // Clear slot lama untuk personality ini
                this.clearSlots(personalityId)

                for (const slot of slots) {
                        if (!slot || typeof slot !== 'object') continue

                        const startHour = Number(slot.startHour)
                        const endHour = Number(slot.endHour)
                        if (!Number.isFinite(startHour) || !Number.isFinite(endHour)) {
                                logger.warn(
                                        'ScheduleManager: slot %s/%s jam tidak valid (start=%s end=%s), dilewati',
                                        personalityId, slot.name, slot.startHour, slot.endHour
                                )
                                continue
                        }

                        this.timeSlots.push({
                                personalityId,
                                name: slot.name || 'unnamed',
                                startHour,
                                endHour,
                                days: Array.isArray(slot.days) ? slot.days : null,
                                status: slot.status || 'busy',
                                message: slot.message || null,
                        })
                }
        }

        /**
         * Hapus semua slot milik personality tertentu.
         */
        clearSlots(personalityId) {
                const before = this.timeSlots.length
                this.timeSlots = this.timeSlots.filter(s => s.personalityId !== personalityId)
                const removed = before - this.timeSlots.length
                if (removed > 0) {
                        logger.debug('ScheduleManager: %d slot lama dibersihkan untuk %s', removed, personalityId)
                }
        }

        /**
         * Hapus semua slot (semua personality).
         */
        clearAll() {
                this.timeSlots = []
        }

        /**
         * Cek status jadwal untuk personality saat ini.
         * Return: { active: boolean, status: string, message: string|null }
         */
        getStatus(personalityId, personality) {
                const now = new Date()
                const { hour } = tzParts(now)
                const day = tzWeekday(now)

                for (const slot of this.timeSlots) {
                        if (slot.personalityId !== personalityId) continue
                        if (slot.days && !slot.days.includes(day)) continue

                        const inRange = slot.startHour <= slot.endHour
                                ? hour >= slot.startHour && hour < slot.endHour
                                : hour >= slot.startHour || hour < slot.endHour  // lewat tengah malam

                        if (inRange) {
                                return {
                                        active: slot.status === 'available',
                                        status: slot.status,
                                        message: slot.message || `Sekarang jam ${slot.name}.`,
                                }
                        }
                }

                return { active: true, status: 'available', message: null }
        }

        /**
         * List semua slot (untuk debug/UI).
         */
        listSlots(personalityId = null) {
                return personalityId
                        ? this.timeSlots.filter(s => s.personalityId === personalityId)
                        : this.timeSlots.slice()
        }
}