import logger from '../../lib/core/logger.js'

export class PersonalityManager {
        constructor(store) {
                this.store = store
                this.personalities = new Map()
                // Trigger index: Map<triggerLowercase, personalityId>
                // Untuk O(1) lookup
                this.triggerIndex = new Map()
        }

        /**
         * Register personality.
         * personality: {
         *   id, name, triggers: string[],
         *   systemPrompt, provider, model,
         *   session, context, memory,
         *   schedule, compoundCustom
         * }
         */
        register(personality) {
                const id = personality.id
                if (!id) throw new Error('Personality harus punya id.')

                this.personalities.set(id, personality)

                // Index triggers — longest match first nanti di detect()
                for (const trigger of (personality.triggers || [])) {
                        const lower = trigger.toLowerCase()
                        // Kalau trigger sudah ada, jangan overwrite (first register wins)
                        if (!this.triggerIndex.has(lower)) {
                                this.triggerIndex.set(lower, id)
                        }
                }

                logger.debug('Personality terdaftar: %s (triggers: %s)', id, (personality.triggers || []).join(', '))
        }

        /**
         * Get personality by id.
         */
        get(id) {
                return this.personalities.get(id) || null
        }

        /**
         * List semua personality.
         */
        list() {
                return Array.from(this.personalities.values()).map(p => ({
                        id: p.id,
                        name: p.name,
                        triggers: p.triggers || [],
                        provider: p.provider || 'auto',
                        model: p.model || 'auto'
                }))
        }

        /**
         * Deteksi apakah text diawali trigger personality.
         * Trigger HARUS di awal pesan (setelah trim), bukan di tengah kata.
         * "rikka hai" -> match, "hai rikka" -> ga match, "mena'rik'" -> ga match.
         *
         * Returns: { personalityId, trigger, matchIndex } atau null.
         * Strategi: longest match first.
         */
        detect(text) {
                if (!text) return null

                const lower = text.toLowerCase().trim()
                let bestMatch = null
                let bestLength = 0

                for (const [trigger, personalityId] of this.triggerIndex) {
                        // HARUS match di awal string (index 0), DAN
                        // karakter setelah trigger harus bukan huruf/angka (word boundary)
                        if (!lower.startsWith(trigger)) continue

                        const nextChar = lower[trigger.length]
                        // Trigger di akhir string, atau diikuti non-alphanumeric
                        if (nextChar !== undefined && /[a-zA-Z0-9]/.test(nextChar)) continue

                        if (trigger.length > bestLength) {
                                bestMatch = {
                                        personalityId,
                                        trigger,
                                        matchIndex: 0
                                }
                                bestLength = trigger.length
                        }
                }

                return bestMatch
        }
}