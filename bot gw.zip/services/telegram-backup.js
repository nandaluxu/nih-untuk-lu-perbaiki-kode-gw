/**
 * services/telegram-backup.js — entry point service backup Telegram.
 *
 * PROSES TERPISAH dari bot WhatsApp (node index.js):
 *   - beban CPU/IO zip tidak mengganggu event loop bot;
 *   - crash service ≠ bot mati; bot restart ≠ backup berhenti;
 *   - jadwal persisten di store/tgbackup/config.json — pulih otomatis.
 *
 * Jalankan (cwd bebas — project root dideteksi dari lokasi file ini):
 *   node services/telegram-backup.js
 *   pm2 start services/telegram-backup.js --name tg-backup
 *
 * Env (.env):
 *   TELEGRAM_BOT_TOKEN   token dari @BotFather (WAJIB)
 *   TELEGRAM_OWNER_IDS   user id yang boleh kontrol (bootstrap allowlist)
 *   SESSION_DIR          dipakai utk exclude session dari backup (default ./sessions)
 */
import 'dotenv/config'
import path from 'node:path'
import { fileURLToPath } from 'node:url'
import { mkdir } from 'node:fs/promises'
import logger from '../lib/core/logger.js'
import { TelegramClient, TelegramFatalError } from '../lib/tgbackup/telegram.js'
import { ConfigStore, HistoryStore, runtimeDir } from '../lib/tgbackup/config.js'
import { BackupEngine, isOtherInstanceRunning, writeLockFile, removeLockFile, sweepStaleParts } from '../lib/tgbackup/engine.js'
import { RestoreManager } from '../lib/tgbackup/restore.js'
import { Scheduler } from '../lib/tgbackup/scheduler.js'
import { CommandRouter } from '../lib/tgbackup/commands.js'
import { sleep } from '../lib/tgbackup/util.js'

const HERE = path.dirname(fileURLToPath(import.meta.url))
const ROOT = path.resolve(HERE, '..')
const RUNTIME = runtimeDir(ROOT)

// ---------------------------------------------------------------------------
// Bootstrap
// ---------------------------------------------------------------------------
const token = process.env.TELEGRAM_BOT_TOKEN
if (!token) {
	console.error('[tgbackup] TELEGRAM_BOT_TOKEN kosong — set di .env (token dari @BotFather). Lihat TELEGRAM-BACKUP-README.md')
	process.exit(1)
}

// lock anti dua instance (lock.pid berisi PID — cek proses masih hidup)
if (await isOtherInstanceRunning(RUNTIME)) {
	console.error('[tgbackup] instance lain masih berjalan (lock.pid aktif) — matikan dulu.')
	process.exit(1)
}
await writeLockFile(RUNTIME)

const store = new ConfigStore(ROOT)
const history = new HistoryStore(ROOT)
await store.load()
await history.load()

// bersihkan sisa part/staging dari crash sebelumnya
const sweptParts = await sweepStaleParts(path.join(RUNTIME, 'parts'))
const sweptStaging = await new RestoreManager({ root: ROOT, store, history, tg: null, logger }).sweepStale().catch(() => 0)
if (sweptParts || sweptStaging) {
	logger.info('[tgbackup] bersih %d part basi + %d staging basi dari run sebelumnya', sweptParts, sweptStaging)
}

const tg = new TelegramClient(token, { logger })
const engine = new BackupEngine({ root: ROOT, store, history, tg, logger })
const restore = new RestoreManager({ root: ROOT, store, history, tg, logger })
const scheduler = new Scheduler({
	store,
	fire: (trigger) => engine.runBackup({ trigger }),
	logger,
})
const router = new CommandRouter({ store, history, engine, restore, scheduler, tg, logger, startedAt: Date.now() })

// ---------------------------------------------------------------------------
// Validasi token + info start
// ---------------------------------------------------------------------------
let me = null
try {
	me = await tg.getMe()
	logger.info('[tgbackup] login sebagai @%s (id %s)', me.username, me.id)
} catch (e) {
	if (e instanceof TelegramFatalError) {
		console.error(`[tgbackup] FATAL: ${e.message}`)
		await removeLockFile(RUNTIME)
		process.exit(1)
	}
	logger.warn('[tgbackup] getMe gagal (jaringan?) — lanjut: %s', e.message)
}

const cfg = store.get()
logger.info('[tgbackup] project root: %s', ROOT)
logger.info('[tgbackup] storage: %s', cfg.storage ? `${cfg.storage.title} (${cfg.storage.chatId})` : 'BELUM DIKONFIGURASI (/setbackup di grup)')
logger.info('[tgbackup] allowlist: %d user', store.effectiveAllowlist().length)
if (cfg.schedule.enabled) {
	logger.info('[tgbackup] jadwal AKTIF tiap %s — recovery…', (cfg.schedule.intervalMs / 3600000).toFixed(cfg.schedule.intervalMs % 3600000 ? 2 : 0) + ' jam')
}

// pulihkan jadwal (max 1 catch-up — lihat scheduler.js)
const rec = await scheduler.bootRecovery()
if (rec) logger.info('[tgbackup] scheduler recovery: %s', rec)
scheduler.start()

// ---------------------------------------------------------------------------
// Handler /id — balas info pengirim biar gampang nyalin ke .env
// ---------------------------------------------------------------------------
async function handleIdCommand(msg) {
	const from = msg.from || {}
	const chat = msg.chat || {}
	const lines = [
		'🆔 *Info Telegram kamu*',
		'',
		`👤 User ID: \`${from.id}\``,
		`📛 Username: ${from.username ? '@' + from.username : '-'}`,
		`🧑 Nama: ${[from.first_name, from.last_name].filter(Boolean).join(' ') || '-'}`,
		`💬 Chat ID: \`${chat.id}\``,
		`📂 Tipe: ${chat.type}`,
		'',
		'Salin *User ID* ke `.env`:',
		'`TELEGRAM_OWNER_IDS=' + from.id + '`',
	]
	const text = lines.join('\n')

	// Coba beberapa signature sendMessage supaya kompatibel dgn TelegramClient kamu
	try {
		if (typeof tg.sendMessage === 'function') {
			await tg.sendMessage(chat.id, text, { parse_mode: 'Markdown' })
		} else if (typeof tg.callApi === 'function') {
			await tg.callApi('sendMessage', { chat_id: chat.id, text, parse_mode: 'Markdown' })
		} else if (typeof tg.request === 'function') {
			await tg.request('sendMessage', { chat_id: chat.id, text, parse_mode: 'Markdown' })
		} else {
			logger.warn('[tgbackup] tidak ada method kirim pesan di TelegramClient — /id gagal balas')
		}
	} catch (e) {
		logger.error('[tgbackup] gagal balas /id: %s', e.message)
	}
}

// ---------------------------------------------------------------------------
// Long polling
// ---------------------------------------------------------------------------
let stopping = false
let offset = 0

async function pollLoop() {
	while (!stopping) {
		try {
			const updates = await tg.getUpdates(offset, 30)
			for (const u of updates || []) {
				offset = Math.max(offset, (u.update_id || 0) + 1)

				// ---- LOG + /id ----
				const msg = u.message || u.edited_message || u.channel_post
				if (msg) {
					const from = msg.from || {}
					const chat = msg.chat || {}
					const text = msg.text || msg.caption || '[non-text]'

					// log tiap pesan masuk
					logger.info(
						'[TG] chat=%s (%s) | from=%s (@%s) | name=%s %s | text=%s',
						chat.id,
						chat.type,
						from.id,
						from.username || '-',
						from.first_name || '',
						from.last_name || '',
						text
					)

					// command /id → balas info pengirim
					const cmd = (msg.text || '').trim().toLowerCase()
					if (cmd === '/id' || cmd === 'id' || cmd === '/start') {
						handleIdCommand(msg).catch((e) => {
							logger.error('[tgbackup] handleIdCommand error: %s', e.message)
						})
						continue   // jangan diteruskan ke router
					}
				}
				// ---- /LOG + /id ----

				router.handleUpdate(u).catch((e) => {
					logger.error('[tgbackup] handler error: %s', e.message)
				})
			}
		} catch (e) {
			if (e instanceof TelegramFatalError) {
				console.error(`[tgbackup] FATAL: ${e.message}`)
				await shutdown('fatal', 1)
				return
			}
			logger.error('[tgbackup] polling error: %s — retry 5s', e.message)
			await sleep(5000)
		}
	}
}

// ---------------------------------------------------------------------------
// Graceful shutdown (SIGINT/SIGTERM — panel/pm2 mengirim SIGTERM)
// ---------------------------------------------------------------------------
async function shutdown(signal, code = 0) {
	if (stopping) return
	stopping = true
	logger.info('[tgbackup] shutdown (%s)…', signal)
	scheduler.stop()
	if (engine.running) {
		engine.requestCancel()
		logger.info('[tgbackup] menunggu backup berjalan berhenti di titik aman (max 60s)…')
		const t0 = Date.now()
		while (engine.running && Date.now() - t0 < 60_000) await sleep(2000)
	}
	await removeLockFile(RUNTIME)
	process.exit(code)
}

process.on('SIGINT', () => shutdown('SIGINT'))
process.on('SIGTERM', () => shutdown('SIGTERM'))
process.on('uncaughtException', (e) => logger.error('[tgbackup] Uncaught: %s', e.stack || e.message))
process.on('unhandledRejection', (e) => logger.error('[tgbackup] Unhandled: %s', e?.stack || e))

await pollLoop()