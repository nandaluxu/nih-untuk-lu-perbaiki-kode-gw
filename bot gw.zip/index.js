// WAJIB paling awal: redirect TMPDIR → disk proyek kalau /tmp panel ketat
// (±100MB) — baileys menulis salinan enkripsi media ke os.tmpdir() saat
// upload; tanpa redirect, file >100MB mustahil terkirim (lihat lib/temp-dir.js).
import { sweepTempDir } from './lib/core/temp-dir.js'
import logger from './lib/core/logger.js'
import { Bot } from './bot.js'

// ---- Spawn Telegram Backup sebagai child process ----
// Dijalankan SETELAH temp-dir.js supaya TMPDIR hasil redirect ikut ke child.
import { spawn } from 'node:child_process'
import path from 'node:path'
import { fileURLToPath } from 'node:url'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

// Task 32: bersihkan file orphan di temp/ dari run sebelumnya (umur > 1 jam —
// file yang masih dipakai proses ini tidak mungkin lebih tua dari uptime).
// Dulu temp/ tidak pernah di-sweep → 28 file sampah tertinggal saat audit.
try {
	sweepTempDir({ maxAgeMs: 60 * 60 * 1000 })
} catch (e) {
	logger.warn('Temp sweep gagal: %s', e.message)
}

// ---------------------------------------------------------------------------
// Telegram Backup child process (auto-restart kalau mati)
// ---------------------------------------------------------------------------
let tgBackup = null
let tgBackupRestartTimer = null
let tgBackupStopping = false

function startTgBackup() {
	tgBackup = spawn(
		process.execPath,
		[path.join(__dirname, 'services', 'telegram-backup.js')],
		{
			cwd: __dirname,
			stdio: 'inherit',   // log nyatu ke console bot
			env: process.env,   // PENTING: TMPDIR hasil redirect ikut kebawa
		}
	)

	tgBackup.on('exit', (code, signal) => {
		tgBackup = null
		if (tgBackupStopping) return
		logger.warn('tg-backup mati (code=%s signal=%s) — restart 5s', code, signal)
		tgBackupRestartTimer = setTimeout(startTgBackup, 5000)
	})

	tgBackup.on('error', (e) => {
		logger.error('tg-backup spawn error: %s', e.message)
	})
}

startTgBackup()

// ---------------------------------------------------------------------------
// Bot WA
// ---------------------------------------------------------------------------
const bot = new Bot()
await bot.start()

// ---- Cleanup (Task 32: graceful shutdown IDEMPOTEN untuk SIGINT/SIGTERM) ----
// Panel (Docker/PM2) mengirim SIGTERM — sebelumnya hanya SIGINT yang ditangani
// → activity/economy 15 dtk terakhir hilang tiap restart panel.
//
// Update: sekarang juga menunggu child tg-backup selesai supaya lock.pid
// terhapus dengan bersih (kalau tidak, start berikutnya gagal dengan pesan
// "instance lain masih berjalan").
let shuttingDown = false

function killTgBackup() {
	return new Promise((resolve) => {
		if (!tgBackup || tgBackup.killed) return resolve()
		const child = tgBackup
		const t = setTimeout(() => {
			if (!child.killed) {
				logger.warn('tg-backup tidak berhenti dalam 10s, SIGKILL')
				try { child.kill('SIGKILL') } catch {}
			}
			resolve()
		}, 10000)
		child.once('exit', () => { clearTimeout(t); resolve() })
		try { child.kill('SIGTERM') } catch { clearTimeout(t); resolve() }
	})
}

async function shutdown(signal) {
	if (shuttingDown) {
		// Sinyal kedua → operator memang ingin keluar paksa
		logger.warn('Shutdown sedang berjalan, keluar paksa (%s).', signal)
		process.exit(1)
	}
	shuttingDown = true
	tgBackupStopping = true
	if (tgBackupRestartTimer) {
		clearTimeout(tgBackupRestartTimer)
		tgBackupRestartTimer = null
	}
	logger.info('Shutting down (%s)...', signal)

	try {
		bot.stop()
	} catch (e) {
		logger.error('Gagal stop bersih: %s', e.stack || e.message)
	}

	// Beri child tg-backup waktu menghapus lock.pid (max 10s)
	await killTgBackup()
	process.exit(0)
}

process.on('SIGINT', () => shutdown('SIGINT'))
process.on('SIGTERM', () => shutdown('SIGTERM'))

// beforeExit = event loop mau kosong (bukan sinyal) — flush terakhir best-effort
process.on('beforeExit', (code) => {
	if (shuttingDown) return
	logger.warn('beforeExit (%s) — flush data terakhir.', code)
	shuttingDown = true
	tgBackupStopping = true
	if (tgBackupRestartTimer) clearTimeout(tgBackupRestartTimer)
	try { bot.stop() } catch {}
	if (tgBackup && !tgBackup.killed) {
		try { tgBackup.kill('SIGTERM') } catch {}
	}
})

process.on('uncaughtException', e => logger.error('Uncaught: %s', e.stack || e.message))
process.on('unhandledRejection', e => logger.error('Unhandled: %s', e?.stack || e))