import axios from 'axios'
import logger from '../../lib/core/logger.js'

/** Timeout API (ms). */
const API_TIMEOUT_MS = 30_000

/**
 * Lookup IP via API kyzzz.xyz
 */
async function lookupIP(ip) {
    try {
        const apiKey = process.env.KYZZZ_API_KEY || ''
        const res = await axios.get(
            `https://api.kyzzz.xyz/api/tools/ip-lookup?ip=${encodeURIComponent(ip)}&apikey=${apiKey}`,
            { timeout: API_TIMEOUT_MS }
        )
        return res.data
    } catch (e) {
        logger.error('[iplookup] API error:', e)
        return null
    }
}

/**
 * Format response jadi teks WhatsApp yang rapi.
 */
function formatIPInfo(data) {
    const result = data.result || {}
    
    const lines = [
        `🌐 *IP LOOKUP*\n`,
        `━━━━━━━━━━━━━━━━━━`,
        `\n📡 *IP:* ${result.ip || 'Unknown'}`,
        `🏢 *ISP:* ${result.isp || 'Unknown'}`,
        `🏛️ *Org:* ${result.org || 'Unknown'}`,
        `🔢 *AS:* ${result.as || 'Unknown'}`,
        `\n━━━ *📍 LOKASI* ━━━`,
        `🌏 *Negara:* ${result.country || 'Unknown'} (${result.country_code || 'N/A'})`,
        `🗺️ *Region:* ${result.region || 'Unknown'}`,
        `🏙️ *Kota:* ${result.city || 'Unknown'}`,
        `📮 *Kode Pos:* ${result.zip || 'N/A'}`,
        `\n━━━ *🗺️ KOORDINAT* ━━━`,
        `📐 *Latitude:* ${result.latitude || 'N/A'}`,
        `📐 *Longitude:* ${result.longitude || 'N/A'}`,
        `\n━━━ *🕐 WAKTU* ━━━`,
        `⏰ *Timezone:* ${result.timezone || 'N/A'}`,
        `\n━━━━━━━━━━━━━━━━━━`,
        `\n🗺️ *Maps:* https://www.google.com/maps?q=${result.latitude || 0},${result.longitude || 0}`
    ]
    
    return lines.join('\n')
}

export default {
    name: 'iplookup',
    aliases: ['ip', 'cekip', 'ipinfo'], // audit fase-2: alias 'lookup' dihapus — bentrok nama kanonik .lookup (PN/LID/JID)
    description: 'Cek informasi IP address',
    category: 'information',
    usage: '.iplookup <ip>',
    register: true,

    async execute(ctx) {
        const { sock, chat, message, args, prefix, command, reply } = ctx
        const input = args.join(' ').trim()
        
        if (!input) {
            return reply(
`🌐 *IP Lookup*

Cek informasi lengkap IP address.

📌 *Contoh:*
${prefix + command} 1.1.1.1
${prefix + command} 8.8.8.8

✨ *Fitur:*
- Lokasi (negara, kota, region)
- Koordinat + link Google Maps
- ISP & Organisasi
- Timezone`)
        }
        
        // Validasi IP sederhana
        if (!/^(\d{1,3}\.){3}\d{1,3}$/.test(input)) {
            return reply('❌ Format IP tidak valid!\nContoh: 1.1.1.1')
        }
        
        await sock.sendMessage(chat, { react: { text: '🔍', key: message.key } }).catch(() => {})
        
        try {
            const data = await lookupIP(input)
            
            if (!data?.status || !data?.result) {
                await sock.sendMessage(chat, { react: { text: '❌', key: message.key } }).catch(() => {})
                return reply('❌ Gagal lookup IP.')
            }
            
            const text = formatIPInfo(data)
            
            // Kirim langsung satu pesan
            await sock.sendMessage(chat, { text }, { quoted: message })
            
            await sock.sendMessage(chat, { react: { text: '✅', key: message.key } }).catch(() => {})
            
        } catch (e) {
            logger.error('[iplookup] Error:', e)
            await sock.sendMessage(chat, { react: { text: '❌', key: message.key } }).catch(() => {})
            
            if (e.code === 'ECONNABORTED') {
                return reply('⏱️ Request timeout. Coba lagi.')
            }
            
            return reply(`❌ Error: ${e.message || 'Gagal lookup IP.'}`)
        }
    }
}