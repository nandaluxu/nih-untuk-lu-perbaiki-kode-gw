/**
 * ttinfo2.js — Info lengkap video TikTok tanpa download
 * Usage:
 *   .ttinfo2 <url>
 *   .ttinfo2 <url> --comments=5   → sekalian 5 komen teratas
 */
import logger from '../../lib/core/logger.js'
import tiktok, { formatCount, formatDuration, TikTokError } from '../../lib/scrape/tiktokwhatsapp.js'

function parseArgs(rawText) {
  const tokens = String(rawText || '').trim().split(/\s+/).filter(Boolean)
  let url = null
  let comments = 0

  for (const t of tokens) {
    const mc = t.match(/^--(?:comments?|c)=(\d+)$/i)
    if (mc) {
      const n = parseInt(mc[1], 10)
      if (Number.isFinite(n) && n > 0) comments = Math.min(n, 10)
      continue
    }
    if (!url) url = t
  }
  return { url, comments }
}

function truncate(s, n = 80) {
  const t = String(s || '').replace(/\s+/g, ' ').trim()
  return t.length > n ? `${t.slice(0, n - 1)}…` : t
}

export default {
  name: 'ttinfo',
  aliases: ['tti'],
  description: 'Info lengkap video TikTok tanpa download',
  category: 'search',
  limit: true,
  limitType: 'category',
  usage: '.ttinfo2 <url> [--comments=N]',

  async execute(ctx) {
    const { sock, chat, message, args, prefix, command, reply } = ctx
    const pfx = prefix ?? '.'

    const rawText = Array.isArray(args) ? args.join(' ') : (ctx.text || '')
    const { url, comments } = parseArgs(rawText)

    if (!url) {
      return reply(
        `ℹ️ *Info Video TikTok*\n\n` +
        `Contoh:\n` +
        `${pfx + command} https://www.tiktok.com/@user/video/123\n` +
        `${pfx + command} https://vt.tiktok.com/xxxxx --comments=5`
      )
    }

    const react = (emoji) =>
      sock.sendMessage(chat, { react: { text: emoji, key: message.key } }).catch(() => {})

    await react('⏳')

    try {
      logger.info('[ttinfo2] url=%s comments=%s', url, comments)

      const v = await tiktok.getVideo(url, { comments })
      const isPhoto = v.images?.length > 0
      const stats = v.stats || {}

      const lines = [
        `🎬 *${truncate(v.title, 150) || '(tanpa judul)'}*\n`,
        `👤 *${v.author?.nickname || '-'}* (@${v.author?.username || '-'})${v.author?.id ? '' : ''}`,
        `📅 ${v.createTime ? new Date(v.createTime * 1000).toISOString().slice(0, 10) : '-'}` +
        (v.duration ? ` · ⏱️ ${formatDuration(v.duration)}` : ''),
        '',
        `📊 *Stats:*`,
        `   ❤️ ${formatCount(stats.likes, 'id') || 0}`,
        `   💬 ${formatCount(stats.comments, 'id') || 0}`,
        `   🔁 ${formatCount(stats.shares, 'id') || 0}`,
        `   🔖 ${formatCount(stats.saves, 'id') || 0}`,
        `   👁️ ${formatCount(stats.plays, 'id') || 0}`,
      ]

      if (isPhoto) {
        lines.push('', `🖼️ *Photo post* — ${v.images.length} foto`)
      } else {
        lines.push('', `📹 *Video*`)
      }

      if (v.music) {
        lines.push(
          '',
          `🎵 *Music:*`,
          `   ${truncate(v.music.title, 60) || '-'}`,
          v.music.author ? `   👤 ${v.music.author}` : null,
          v.music.duration ? `   ⏱️ ${formatDuration(v.music.duration)}` : null,
          v.music.original ? `   🎼 Original sound` : null
        )
      }

      // Download link availability
      const dl = []
      if (v.downloads?.hd) dl.push('HD')
      if (v.downloads?.sd) dl.push('SD')
      if (v.downloads?.watermarked) dl.push('WM')
      if (dl.length) lines.push('', `📥 *Download tersedia:* ${dl.join(' · ')}`)

      lines.push('', `🔗 ${v.url}`)

      // Komentar teratas (kalau diminta)
      if (comments > 0 && v.comments?.length) {
        lines.push('', `💬 *Komentar teratas:*`)
        v.comments.slice(0, comments).forEach((c, i) => {
          lines.push(
            `${i + 1}. *${truncate(c.user?.nickname || '-', 20)}*: ` +
            `"${truncate(c.text, 80)}" (${formatCount(c.likes, 'id') || 0}❤️)`
          )
        })
      }

      lines.push('', `_💡 Download:_ \`${pfx}ttdl2 ${v.url}\``)

      await reply(lines.join('\n'))
      await react('✅')

    } catch (err) {
      logger.error('[ttinfo2] %s', err.message)
      await react('❌')

      let pesan = `❌ Gagal ambil info: ${err.message}`
      if (err instanceof TikTokError) {
        if (err.code === 'VIDEO_NOT_FOUND') pesan = `❌ Video tidak ditemukan / dihapus / private.`
        else if (err.code === 'ALL_ROUTES_FAILED') pesan = `❌ Rute scraping diblokir dari IP ini.`
        else if (err.code === 'CF_CHALLENGED') pesan = `❌ TikWM challenge. Coba lagi.`
        pesan += `\n\n_Kode: ${err.code}_`
      }
      await reply(pesan)
    }
  },
}