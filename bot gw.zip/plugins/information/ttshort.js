/**
 * ttshort.js — Resolve short link TikTok → URL penuh + sharer
 * Usage:
 *   .ttshort <short-url>
 */
import logger from '../../lib/core/logger.js'
import tiktok, { TikTokError } from '../../lib/scrape/tiktokwhatsapp.js'

function parseUrl(rawText) {
  const t = String(rawText || '').trim().split(/\s+/)[0] || ''
  return t.trim()
}

export default {
  name: 'ttshort',
  aliases: ['ttresolve', 'tturl'],
  description: 'Resolve short link TikTok → URL penuh',
  category: 'utility',
  limit: true,
  limitType: 'category',
  usage: '.ttshort <short-url>',

  async execute(ctx) {
    const { sock, chat, message, args, prefix, command, reply } = ctx
    const pfx = prefix ?? '.'

    const rawText = Array.isArray(args) ? args.join(' ') : (ctx.text || '')
    const url = parseUrl(rawText)

    if (!url) {
      return reply(
        `🔗 *Resolve Short Link TikTok*\n\n` +
        `Contoh:\n` +
        `${pfx + command} https://vt.tiktok.com/ZSqGP35Xy/\n` +
        `${pfx + command} https://vm.tiktok.com/xxxxx`
      )
    }

    const react = (emoji) =>
      sock.sendMessage(chat, { react: { text: emoji, key: message.key } }).catch(() => {})

    await react('🔗')

    try {
      logger.info('[ttshort] url=%s', url)

      const r = await tiktok.resolveShort(url)

      const lines = [
        `🔗 *Short Link Resolved*\n`,
        `📥 Asli    : ${url}`,
        `📤 Canonical: ${r.canonical || r.url}`,
      ]

      if (r.sharer?.username) {
        lines.push(`👤 Sharer  : @${r.sharer.username}${r.sharer.nickname ? ` (${r.sharer.nickname})` : ''}`)
      }

      if (r.params && Object.keys(r.params).length) {
        lines.push('', `_Tracking params:_`)
        for (const [k, v] of Object.entries(r.params)) {
          lines.push(`   ${k} = ${v}`)
        }
      }

      lines.push('', `_💡 Download:_ \`${pfx}ttdl2 ${r.canonical || url}\``)

      await reply(lines.join('\n'))
      await react('✅')

    } catch (err) {
      logger.error('[ttshort] %s', err.message)
      await react('❌')

      let pesan = `❌ Gagal resolve: ${err.message}`
      if (err.code === 'SHORT_RESOLVE_FAILED') pesan = `❌ Gagal resolve short link. Pastikan URL valid.`
      await reply(pesan)
    }
  },
}