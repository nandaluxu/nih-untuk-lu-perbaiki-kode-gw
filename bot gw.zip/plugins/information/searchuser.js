import { similarity } from '../../lib/command/fuzzy.js'

export default {
	name: 'searchuser',
	aliases: ['cariuser'],
	description: 'Cari user berdasarkan username',
	category: 'information',
	usage: '.searchuser nanda',

	async execute(ctx) {
			const _pfx = (typeof ctx !== 'undefined' && ctx?.prefix) || ''
		const query = ctx.args.join(' ').trim()
		if (!query) {
			return ctx.reply(`Masukkan username yang ingin dicari. Contoh: ${_pfx}searchuser nanda`)
		}

		const { userRepo } = ctx

		// 1. Exact match
		const exact = userRepo.searchUsername(query, 1)
		if (exact.length === 1 && exact[0].username.toLowerCase() === query.toLowerCase()) {
			return ctx.reply([
				'*Pencarian (exact)*',
				'',
				`Nama: ${exact[0].username}`,
				`Player ID: ${exact[0].player_id}`,
				'Similarity: 100%'
			].join('\n'))
		}

		// 2. Ambil kandidat dari DB dengan LIKE
		const candidates = userRepo.searchUsername(query, 20)
		if (!candidates.length) {
			return ctx.reply('Tidak ditemukan user yang cocok.')
		}

		// 3. Fuzzy ranking
		const normalizedQuery = query.toLowerCase()
		const results = candidates.map(u => ({
			...u,
			score: similarity(normalizedQuery, u.username.toLowerCase())
		}))
			.filter(r => r.score >= 0.40)
			.sort((a, b) => b.score - a.score)
			.slice(0, 5)

		if (!results.length) {
			return ctx.reply('Tidak ditemukan user yang cukup mirip.')
		}

		const lines = ['*Hasil Pencarian:*', '']
		for (let i = 0; i < results.length; i++) {
			const r = results[i]
			lines.push(`${i + 1}. ${r.username}`)
			lines.push(`   Player ID: ${r.player_id}`)
			lines.push(`   Similarity: ${Math.round(r.score * 100)}%`)
			if (i < results.length - 1) lines.push('')
		}

		await ctx.reply(lines.join('\n'))
	}
}
