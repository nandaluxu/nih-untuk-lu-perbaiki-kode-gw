import { sanitizeUsername, isValidName, isValidAge } from '../../lib/core/validators.js'
import { findProfileForMessage } from '../../lib/identity/index.js'

// Key yang dikenal + aliasnya
const KEY_ALIASES = {
        nama: 'nama',
        username: 'nama',
        name: 'nama',
        umur: 'umur',
        age: 'umur',
        playerid: 'playerid',
        player_id: 'playerid',
        pid: 'playerid',
        id: 'playerid',
}

/**
 * Parser key=value yang mengizinkan value mengandung spasi.
 * Value berhenti saat ketemu key= berikutnya (yang dikenal) atau akhir string.
 */
function parseKeyValue(input) {
        const result = {}
        const unknown = []

        const keyPattern = /(?:^|\s)(nama|username|name|umur|age|playerid|player_id|pid|id)\s*=/gi

        const matches = []
        let m
        while ((m = keyPattern.exec(input)) !== null) {
                matches.push({
                        key: m[1].toLowerCase(),
                        start: m.index + (m[0].startsWith(' ') ? 1 : 0),
                        valueStart: keyPattern.lastIndex,
                })
        }

        if (matches.length === 0) return { result, unknown }

        for (let i = 0; i < matches.length; i++) {
                const cur = matches[i]
                const next = matches[i + 1]
                const valueEnd = next ? next.start : input.length
                const value = input.slice(cur.valueStart, valueEnd).trim()

                const normKey = KEY_ALIASES[cur.key]
                if (!normKey) {
                        unknown.push(cur.key)
                        continue
                }

                // Yang terakhir menang (misal nama= lalu username=)
                result[normKey] = value
        }

        return { result, unknown }
}

/**
 * Sanitizer untuk username display: boleh spasi, huruf, angka, dan
 * simbol ringan. Buang karakter aneh & rapikan spasi ganda.
 * Tidak lowercase — biar user bisa pakai huruf besar.
 */
function sanitizeDisplayName(raw) {
        if (!raw) return ''
        return String(raw)
                .trim()
                .replace(/\s+/g, ' ')            // rapikan spasi ganda
                .replace(/[^\p{L}\p{N} _.\-']/gu, '') // sisakan huruf, angka, spasi, _ . - '
                .slice(0, 40)
}

/**
 * Sanitizer untuk player_id: hanya huruf, angka, underscore, dash.
 * Spasi & karakter aneh dibuang. Lowercase.
 */
function sanitizePlayerId(raw) {
        if (!raw) return ''
        return String(raw)
                .toLowerCase()
                .trim()
                .replace(/\s+/g, '')
                .replace(/[^a-z0-9_-]/g, '')
                .slice(0, 32)
}

/** Validasi player_id hasil sanitize. */
function isValidPlayerId(pid) {
        if (!pid) return false
        if (pid.length < 2 || pid.length > 32) return false
        if (!/^[a-z]/.test(pid)) return false
        return true
}

export default {
        name: 'editprofile',
        aliases: ['editprof', 'setprofile'],
        description: 'Edit profile sendiri, atau orang lain (khusus owner)',
        category: 'information',
        usage: '.editprofile umur=18 nama=nanda playerid=nandaluxu',
        register: false,

        async execute(ctx) {
                const _pfx = ctx?.prefix || ''
                const { args, mentionedJid, userRepo, resolver, message } = ctx

                // ============================================================
                // 1. TENTUKAN TARGET
                // ============================================================
                const allMentions = []

                if (mentionedJid && mentionedJid.length > 0) {
                        allMentions.push(...mentionedJid)
                }

                const contextInfo = message?.message?.extendedTextMessage?.contextInfo
                if (contextInfo?.mentionedJid) {
                        allMentions.push(...contextInfo.mentionedJid)
                }
                if (message?.contextInfo?.mentionedJid) {
                        allMentions.push(...message.contextInfo.mentionedJid)
                }

                const uniqueMentions = [...new Set(allMentions)]

                const quoted = ctx.quoted
                const quotedSender = quoted?.sender || quoted?.participant || quoted?.key?.participant || null

                let rawArgs = args.join(' ').trim()
                let targetJid = null

                if (quotedSender) {
                        targetJid = quotedSender
                } else if (uniqueMentions.length > 0) {
                        targetJid = uniqueMentions[0]
                } else if (rawArgs) {
                        const first = rawArgs.split(/\s+/)[0] || ''
                        const digits = first.replace(/[^0-9]/g, '')
                        const isNumber = !first.includes('=') && !first.includes('.') && digits.length >= 8
                        if (isNumber) {
                                let num = digits
                                if (num.startsWith('0')) num = '62' + num.slice(1)
                                targetJid = num + '@s.whatsapp.net'
                                rawArgs = rawArgs.split(/\s+/).slice(1).join(' ').trim()
                        }
                }

                // ============================================================
                // 2. RESOLVE USER TARGET
                // ============================================================
                const self = findProfileForMessage(userRepo, {
                        sender: ctx.sender,
                        senderLid: ctx.senderLid,
                })

                let targetUser = null
                let isSelf = false

                if (!targetJid) {
                        targetUser = self
                        isSelf = true
                } else {
                        try {
                                const resolved = await resolver.resolveUser(targetJid)
                                const pn = resolved.pn || targetJid
                                const lid = resolved.lid || null
                                targetUser = userRepo.findByIdentifier(pn)
                                        || (lid ? userRepo.findByIdentifier(lid) : null)
                                        || userRepo.findByIdentifier(targetJid)
                        } catch {
                                targetUser = userRepo.findByIdentifier(targetJid)
                                        || userRepo.findByJID(targetJid)
                                        || userRepo.findByPN(targetJid)
                        }

                        if (targetUser && self && targetUser.user_id === self.user_id) {
                                isSelf = true
                        }
                }

                if (!targetUser) {
                        return ctx.reply('❌ User target tidak ditemukan atau belum terdaftar.')
                }

                // ============================================================
                // 3. CEK IZIN
                // ============================================================
                if (!isSelf && !ctx.isOwner) {
                        return ctx.reply('❌ Hanya owner yang bisa mengedit profile orang lain.')
                }

                // ============================================================
                // 4. TANPA ARGUMEN → TAMPILKAN INFO
                // ============================================================
                if (!rawArgs) {
                        const header = isSelf
                                ? '📝 *Edit Profile*'
                                : `📝 *Edit Profile — ${targetUser.username}*`
                        return ctx.reply([
                                header,
                                '',
                                `Username  : ${targetUser.username}`,
                                `Player ID : ${targetUser.player_id}`,
                                `Umur      : ${targetUser.age}`,
                                '',
                                'Cara pakai:',
                                `• ${_pfx}editprofile nama=sasha sayang hisoka`,
                                `• ${_pfx}editprofile umur=18`,
                                `• ${_pfx}editprofile nama=sasha sayang hisoka umur=18`,
                                `• ${_pfx}editprofile playerid=nandaluxu (owner, tanpa spasi)`,
                                '',
                                'Ke orang lain (owner):',
                                `• ${_pfx}editprofile @tag nama=budi umur=20`,
                                `• ${_pfx}editprofile 628xxx nama=budi`,
                        ].join('\n'))
                }

                // ============================================================
                // 5. PARSE key=value
                // ============================================================
                const { result: parsed } = parseKeyValue(rawArgs)

                if (Object.keys(parsed).length === 0) {
                        return ctx.reply([
                                '❌ Format salah. Gunakan `key=value`.',
                                '',
                                'Contoh:',
                                `• ${_pfx}editprofile nama=sasha sayang hisoka umur=18`,
                                `• ${_pfx}editprofile playerid=nandaluxu`,
                        ].join('\n'))
                }

                // ============================================================
                // 6. VALIDASI & BENTUK PATCH
                // ============================================================
                const patch = {}
                let newPlayerId = null

                // --- nama (boleh spasi) ---
                if (parsed.nama !== undefined) {
                        const newUsername = sanitizeDisplayName(parsed.nama)

                        if (!newUsername || !isValidName(newUsername)) {
                                return ctx.reply('❌ Nama tidak valid. Minimal 2 karakter. Contoh: sasha sayang hisoka')
                        }

                        const dup = userRepo.searchUsername(newUsername)
                        const bentrok = dup?.some(u =>
                                u.user_id !== targetUser.user_id &&
                                String(u.username).toLowerCase() === newUsername.toLowerCase()
                        )
                        if (bentrok) {
                                return ctx.reply('❌ Username itu sudah dipakai user lain.')
                        }
                        patch.username = newUsername
                }

                // --- umur ---
                if (parsed.umur !== undefined) {
                        const newAge = Number(parsed.umur)
                        if (!isValidAge(newAge)) {
                                return ctx.reply('❌ Umur harus angka antara 10-80.')
                        }
                        patch.age = newAge
                }

                // --- playerid (khusus owner, tanpa spasi) ---
                if (parsed.playerid !== undefined) {
                        if (!ctx.isOwner) {
                                return ctx.reply('❌ Hanya owner yang bisa mengubah Player ID.')
                        }
                        if (/\s/.test(parsed.playerid)) {
                                return ctx.reply('❌ Player ID tidak boleh mengandung spasi.')
                        }
                        const rawPid = sanitizePlayerId(parsed.playerid)
                        if (!isValidPlayerId(rawPid)) {
                                return ctx.reply([
                                        '❌ Player ID tidak valid.',
                                        'Aturan: huruf/angka/underscore/dash, tanpa spasi,',
                                        'diawali huruf, 2-32 karakter.',
                                        'Contoh: nandaluxu',
                                ].join('\n'))
                        }
                        if (rawPid !== targetUser.player_id && userRepo.playerIdExists(rawPid)) {
                                return ctx.reply('❌ Player ID itu sudah dipakai user lain.')
                        }
                        newPlayerId = rawPid
                }

                if (Object.keys(patch).length === 0 && !newPlayerId) {
                        return ctx.reply('Tidak ada yang diubah.')
                }

                // ============================================================
                // 7. EKSEKUSI
                // ============================================================
                try {
                        const wantsRename = newPlayerId && newPlayerId !== targetUser.player_id

                        if (wantsRename) {
                                const renamed = userRepo.renamePlayerId(targetUser.player_id, newPlayerId)
                                if (!renamed) {
                                        return ctx.reply('❌ Gagal rename Player ID (mungkin sudah dipakai).')
                                }
                                if (Object.keys(patch).length > 0) {
                                        userRepo.updateByUserId(targetUser.user_id, patch)
                                }
                        } else if (Object.keys(patch).length > 0) {
                                userRepo.updateByUserId(targetUser.user_id, patch)
                        }
                } catch (e) {
                        return ctx.reply(`❌ Gagal update profile: ${e.message}`)
                }

                // ============================================================
                // 8. TAMPILKAN HASIL
                // ============================================================
                const after = userRepo.findByUserId(targetUser.user_id) || { ...targetUser, ...patch }

                await ctx.reply([
                        isSelf ? '✅ *Profile diperbarui*' : `✅ *Profile ${after.username} diperbarui*`,
                        '',
                        `Username  : ${after.username}`,
                        `Player ID : ${after.player_id}`,
                        `Umur      : ${after.age}`,
                ].join('\n'))
        },
}