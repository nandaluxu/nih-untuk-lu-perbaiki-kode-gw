import os from 'os'
import { performance } from 'perf_hooks'
import { BUILD_TASK, BUILD_DATE } from '../../lib/features/build.js'

export default {
        name: 'ping',
        aliases: ['p'],
        description: 'Cek latency bot',
        category: 'information',
        usage: '.ping',
        register: false, // Task 36: basic info — cek bot hidup tanpa akun

        async execute(ctx) {
                const start = performance.now()
                await ctx.message.react('🕒').catch(() => {})
                const latency = Math.round(performance.now() - start)

                const used = process.memoryUsage().rss
                const total = os.totalmem()
                const ram = `${formatBytes(used)} / ${formatBytes(total)}`

                const upSec = process.uptime()
                const d = Math.floor(upSec / 86400)
                const h = Math.floor((upSec % 86400) / 3600)
                const m = Math.floor((upSec % 3600) / 60)
                const s = Math.floor(upSec % 60)
                const uptime = [d && `${d}d`, h && `${h}h`, m && `${m}m`, `${s}s`].filter(Boolean).join(' ')

                await ctx.reply([
                        '*PONG*',
                        `Latency: ${latency} ms`,
                        `Uptime: ${uptime}`,
                        `RAM: ${ram}`,
                        `Node: ${process.version}`,
                        `Build: ${BUILD_TASK} (${BUILD_DATE})`,
                ].join('\n'))
        }
}

function formatBytes(b) {
        if (b >= 1073741824) return `${(b / 1073741824).toFixed(2)} GB`
        if (b >= 1048576) return `${(b / 1048576).toFixed(2)} MB`
        if (b >= 1024) return `${(b / 1024).toFixed(2)} KB`
        return `${b} B`
}