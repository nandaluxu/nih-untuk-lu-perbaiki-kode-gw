/**
 * .whois — Smart Profile & Identity (major improvement).
 *
 * Kartu identitas komprehensif SATU target, read-only murni:
 *   • JID asli + JID normalized + tipe JID (PN/LID/grup) — helper resmi
 *     lib/identity (sama dengan .jid; TIDAK ada helper JID baru);
 *   • Nama terdaftar di DB (resolver resmi userRepo.findByIdentifier /
 *     ctx.user utk sender — rantai kanonik Phase 1);
 *   • WhatsApp push name (sender/reply = metadata live; mention/input =
 *     cache resmi lib/names.js bertanda "(cache)" — push name PENGGIRIM
 *     tidak pernah dipakai sebagai push name target);
 *   • Level/XP/balance/role dari sumber yang SAMA dengan .profile
 *     (progressionOf, formatCoin, roleRepo.getRole);
 *   • Status AFK (ctx.afk.findActiveByJid — service AFK resmi);
 *   • Status warn grup (db.data.settings[chat].warns — store warn-core,
 *     hanya bila dipakai di grup).
 *
 * Target: mention → reply → input → sender (dibedakan, ditampilkan sebagai
 * "Sumber"). Data tidak tersedia → "Tidak tersedia". Tidak ada tebakan.
 *
 * Read-only: TIDAK menulis DB apa pun (back-fill field lid Task 58 oleh
 * findByIdentifier resolver resmi = efek samping idempotent, identik
 * .profile/.jid). Lihat MAJOR-IMPROVEMENT-REPORT.md.
 */
import {
        normalizeJid,
        jidDigits,
        isLidJid,
        isPnJid,
        isGroupJid,
} from '../../lib/identity/index.js'
import { fmtJid } from '../../lib/command/group-utils.js'
import { getPushName, sanitizeName } from '../../lib/features/names.js'
import { formatCoin } from '../../lib/economy/economy.js'
import { progressionOf } from '../../database/user-progression.js'
import { expToNext } from '../../lib/economy/leveling.js'
import { MAX_WARN } from '../../lib/protection/warn-core.js'

const ROLE_BADGE = {
        banned: '⛔',
        free: '👤',
        premium: '💎',
        vip: '🌟',
        'co-owner': '🛡️',
        owner: '👑',
}

/** Kandidat JID sender dari pesan yang di-reply — pola plugins/group/mute.js. */
function quotedCandidates(quoted, message) {
        const cands = []
        if (quoted?.sender) cands.push(quoted.sender)
        if (quoted?.senderLid) cands.push(quoted.senderLid)
        if (quoted?.key?.participantAlt) cands.push(quoted.key.participantAlt)
        if (quoted?.key?.participant) cands.push(quoted.key.participant)
        if (quoted?.participant) cands.push(quoted.participant)
        const ci = message?.msg?.contextInfo
                || Object.values(message?.message || {}).find(v => v?.contextInfo)?.contextInfo
        if (ci?.participantAlt) cands.push(ci.participantAlt)
        if (ci?.participant) cands.push(ci.participant)
        return cands.map(c => String(c).trim()).filter(c => c.includes('@'))
}

/** Klasifikasi tipe JID via helper resmi identity (paritas .jid). */
function classify(jid) {
        if (isGroupJid(jid)) return 'Grup (@g.us)'
        if (isLidJid(jid)) return 'LID (identitas internal WhatsApp)'
        if (isPnJid(jid)) return 'PN (@s.whatsapp.net)'
        return 'Tanpa domain (nomor polos)'
}

/** Profil DB via resolver resmi — pola dbProfileOf .jid (tidak pernah throw). */
function dbProfileOf(ctx, normalized, source) {
        try {
                if (source === 'sender' && ctx.user) return ctx.user
                const repo = ctx.userRepo
                if (repo && typeof repo.findByIdentifier === 'function') {
                        return repo.findByIdentifier(normalized)
                }
        } catch { /* resolver bermasalah → dianggap tidak terdaftar */ }
        return null
}

/** Push name live: sender → metadata pesan ini; reply → metadata pesan quoted. */
function livePushNameOf(source, message, quoted, ctxPushName) {
        if (source === 'sender') {
                return sanitizeName(message?.pushName || ctxPushName || '')
        }
        if (source === 'reply') {
                return sanitizeName(quoted?.pushName || '')
        }
        return ''
}

/** Push name cache resmi lib/names.js (kunci = JID kanonik target sendiri). */
function cachedPushNameOf(ctx, normalized, profile) {
        try {
                const forms = [normalized]
                const pn = profile?.pn
                if (typeof pn === 'string' && pn.includes('@') && pn !== normalized) {
                        forms.push(pn)
                }
                if (isLidJid(normalized) && typeof ctx?.resolver?.toCanonical === 'function') {
                        const canon = ctx.resolver.toCanonical(normalized)
                        if (canon && canon !== normalized && !forms.includes(canon)) {
                                forms.push(canon)
                        }
                }
                for (const f of forms) {
                        const n = getPushName(ctx.db, f)
                        if (n) return n
                }
        } catch { /* cache tidak tersedia → null */ }
        return null
}

/** Durasi ringkas (ms → "3j 5m" / "2 hari"). */
function fmtDur(ms) {
        const s = Math.max(0, Math.floor(ms / 1000))
        const d = Math.floor(s / 86400)
        const h = Math.floor((s % 86400) / 3600)
        const m = Math.floor((s % 3600) / 60)
        if (d) return `${d} hari ${h} jam`
        if (h) return `${h} jam ${m} mnt`
        if (m) return `${m} mnt`
        return `${s} dtk`
}

export default {
        name: 'whois',
        description: 'Kartu identitas lengkap: JID, nama DB, push name, level, balance, AFK, warn',
        category: 'information',
        usage: '.whois | .whois @tag | .whois (reply) | .whois 628xxx',
        example: ['.whois', '.whois @6281234567890'],
        register: false, // basic info — pola .jid/.ping (Task 36)

        async execute(ctx) {
                const ref = (ctx.cmdRef && ctx.cmdRef('whois')) || `${ctx?.prefix || ''}whois`
                const { args, mentionedJid, quoted, message, sender } = ctx

                // ---- Resolusi target: mention → reply → input → pengirim ----
                let original = null
                let source = null

                const mention = (Array.isArray(mentionedJid) ? mentionedJid : []).find(m => m)
                        || message?.contextInfo?.mentionedJid?.[0]
                        || message?.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
                if (mention) {
                        original = String(mention)
                        source = 'mention'
                }

                if (!original && quoted) {
                        const cands = quotedCandidates(quoted, message)
                        const pick = cands.find(c => c.endsWith('@s.whatsapp.net')) || cands[0]
                        if (pick) {
                                original = pick
                                source = 'reply'
                        }
                }

                if (!original) {
                        const raw = String(args?.[0] || '').trim().replace(/^@/, '')
                        if (raw) {
                                original = raw
                                source = 'input'
                        }
                }

                if (!original && sender) {
                        original = String(sender)
                        source = 'sender'
                }

                if (!original) {
                        return ctx.reply(
                                `❌ Target tidak dapat ditentukan.\n` +
                                `Contoh: *${ref} @tag*, reply pesan orang, atau *${ref} 6281234567890*`
                        )
                }

                const normalized = normalizeJid(original)
                if (!normalized) {
                        return ctx.reply(
                                `Input tidak valid (kosong/null).\n` +
                                `Contoh: *${ref} @tag* atau *${ref} 6281234567890@s.whatsapp.net*`
                        )
                }

                // ---- Sumber identitas (semua read-only) ----
                const dbProfile = dbProfileOf(ctx, normalized, source)
                const dbName = sanitizeName(dbProfile?.username || dbProfile?.name || '')

                const livePush = livePushNameOf(source, message, quoted, ctx.pushName)
                const cachedPush = livePush ? null : cachedPushNameOf(ctx, normalized, dbProfile)
                const pushDisplay = livePush
                        || (cachedPush ? `${cachedPush} (cache)` : '')
                        || ''

                // Level/XP — progressionOf (sumber sama dengan .profile)
                let levelLine = null
                try {
                        if (dbProfile) {
                                const prog = progressionOf(dbProfile)
                                const need = expToNext(prog.level)
                                levelLine = `Lv.${prog.level} • ${prog.exp}/${need} XP`
                        }
                } catch { /* progression tidak tersedia */ }

                // Balance — wallet + bank (field economy user, sumber .profile)
                let balLine = null
                try {
                        if (dbProfile) {
                                const wallet = Number(dbProfile.wallet) || 0
                                const bank = Number(dbProfile.bank) || 0
                                balLine = formatCoin(wallet + bank)
                        }
                } catch { /* economy tidak tersedia */ }

                // Role — roleRepo.getRole (sumber sama dengan ._formatRoleLine .profile)
                let roleLine = null
                try {
                        if (ctx.roleRepo && dbProfile?.user_id) {
                                const data = ctx.roleRepo.getRole(dbProfile.user_id)
                                const badge = ROLE_BADGE[data.role] || '👤'
                                if (!data.found || data.role === 'free') {
                                        roleLine = `${badge} Free`
                                } else {
                                        const label = data.role.charAt(0).toUpperCase() + data.role.slice(1)
                                        roleLine = data.expires_at
                                                ? `${badge} ${label} (s/d ${new Date(data.expires_at).toLocaleDateString('id-ID')})`
                                                : `${badge} ${label} (permanen)`
                                }
                        }
                } catch { /* role tidak tersedia */ }

                // AFK — service AFK resmi (findActiveByJid, global lintas grup)
                let afkLine = null
                try {
                        const rec = ctx.afk?.findActiveByJid?.(normalized)
                                || (dbProfile?.pn ? ctx.afk?.findActiveByJid?.(dbProfile.pn) : null)
                        if (rec) {
                                const dur = rec.startedAt ? fmtDur(Date.now() - rec.startedAt) : '-'
                                afkLine = `💤 AFK ${dur}${rec.reason ? ` — ${String(rec.reason).slice(0, 60)}` : ''}`
                        }
                } catch { /* afk tidak tersedia */ }

                // Warn — store warn-core grup ini (hanya relevan di grup)
                let warnLine = null
                if (ctx.isGroup) {
                        try {
                                const warns = ctx.db?.data?.settings?.[ctx.chat]?.warns || {}
                                let count = null
                                for (const [key, v] of Object.entries(warns)) {
                                        if (key === normalized || key === dbProfile?.pn || key === dbProfile?.lid) {
                                                count = v?.count || 0
                                                break
                                        }
                                }
                                if (count != null) warnLine = `${count}/${MAX_WARN}`
                        } catch { /* warn store tidak tersedia */ }
                }

                // ---- Render kartu ----
                const type = classify(normalized)
                const digits = jidDigits(normalized)

                const lines = [
                        '╭─❁ *WHOIS — PROFILE & IDENTITY* ❁',
                        `◦❒ *Sumber:* ${source}`,
                        `◦❒ *Target:* @${fmtJid(normalized)}`,
                        `◦❒ *JID asli:* ${original}`,
                        `◦❒ *JID normalized:* ${normalized}`,
                        `◦❒ *Tipe JID:* ${type}`,
                        `◦❒ *Digits:* ${digits || '-'}`,
                        `◦❒ *Nama DB:* ${dbName || 'Tidak terdaftar'}`,
                        `◦❒ *Push Name WA:* ${pushDisplay || 'Tidak tersedia'}`,
                        `◦❒ *Level:* ${levelLine || 'Tidak tersedia'}`,
                        `◦❒ *Balance:* ${balLine || 'Tidak tersedia'}`,
                        `◦❒ *Role:* ${roleLine || 'Tidak tersedia'}`,
                        `◦❒ *AFK:* ${afkLine || 'Tidak AFK'}`,
                        `◦❒ *Warn (${ctx.isGroup ? 'grup ini' : '—'}):* ${warnLine || 'Tidak tersedia'}`,
                        '╰─❁',
                ]

                if (!ctx.isGroup) {
                        lines.splice(lines.length - 1, 0,
                                '_Status warn hanya tampil bila command dipakai di grup._')
                }

                const mentions = isPnJid(normalized) ? [normalized] : []
                return ctx.reply(lines.join('\n'), { mentions })
        }
}
