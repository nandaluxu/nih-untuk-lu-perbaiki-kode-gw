/**
 * .owner — kirim kontak owner bot (vcard).
 *
 * Task 37: tombol "⎋ ᴏᴡɴᴇʀ" di menu interactive mixed (.menu) menjalankan
 * command ini. Data dari env OWNER_NUMBER / OWNER_NAME (config/index.js).
 * register:false — discovery/basic info boleh tanpa akun terdaftar.
 */
import config from '../../config/index.js'

export default {
    name: 'owner',
    aliases: ['creator'],
    description: 'Kirim kontak owner bot',
    category: 'information',
    usage: '.owner',
    register: false,

    async execute(ctx) {
        const num = String(config.ownerNumber || '').replace(/\D/g, '')
        const name = config.ownerName || 'Owner'

        if (!num) {
            return ctx.reply('Nomor owner belum dikonfigurasi (set OWNER_NUMBER di .env).')
        }

        const vcard =
            'BEGIN:VCARD\n' +
            'VERSION:3.0\n' +
            `FN:${name}\n` +
            `TEL;type=CELL;type=VOICE;waid=${num}:+${num}\n` +
            'END:VCARD'

        try {
            await ctx.sock.sendMessage(
                ctx.chat,
                { contacts: { displayName: name, contacts: [{ vcard }] } },
                { quoted: ctx.message }
            )
        } catch {
            // fallback: teks saja (vcard ditolak klien)
            await ctx.reply(`📞 *Owner Bot*\n${name}\nwa.me/${num}`)
        }
    },
}
