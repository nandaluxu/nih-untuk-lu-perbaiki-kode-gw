/**
 * .limit — Informasi & manajemen Limit System (lib/limit-service.js).
 *
 * Semua user:
 *   .limit                    → penggunaan limit sendiri hari ini
 *
 * Manajemen (minRole co-owner — dicek via RoleRepository.hasPermission,
 * fungsi permission YANG SAMA dengan framework; cek di level subcommand
 * karena ".limit" info harus tetap terbuka utk semua user):
 *   .limit list                          → daftar scope yang punya config
 *   .limit get global                    → config quota global
 *   .limit get category downloader       → config quota category
 *   .limit get group am                  → config quota group
 *   .limit get cmd ytmp3                 → config quota command
 *   .limit set global free 10            → set quota role
 *   .limit set group am premium 5        → set + persist (tanpa restart)
 *   .limit set group am owner unlimited  → disimpan "owner": null
 *   .limit set group am free 0           → role tidak mendapat kuota
 *   .limit reset @user                   → hapus semua usage user
 *   .limit reset @user group am          → hapus usage satu scope
 *
 * Catatan desain:
 *   - Limit ≠ permission: akses command tetap dari minRole plugin.
 *   - Scope tanpa file config → fallback config global (ditampilkan di get).
 *   - Usage reset otomatis per tanggal (timezone LIMIT_TIMEZONE, default WIB).
 */
import { RoleRepository } from '../../database/role-repository.js'
import { normalizeJid } from '../../lib/identity/index.js'
import { fmtJid } from '../../lib/command/group-utils.js'
import { getLimitService, LIMIT_TYPES, scopeOf } from '../../lib/command/limit-service.js'
import { extractTarget, toKey } from '../group/mute.js'

/** Label role utk tampilan. */
const ROLE_LABEL = { free: 'Free', premium: 'Premium', vip: 'VIP', 'co-owner': 'Co-owner', owner: 'Owner' }
const ROLE_ORDER = ['free', 'premium', 'vip', 'co-owner', 'owner']

export default {
    name: 'limit',
    description: 'Info & manajemen quota limit harian (.limit / .limit get|set|reset|list)',
    category: 'information',
    usage: '.limit · .limit get global · .limit set group am premium 5 · .limit reset @user',

    async execute(ctx) {
			const _pfx = (typeof ctx !== 'undefined' && ctx?.prefix) || ''
        const { args = [], db, sender, userRole, mentionedJid, quoted, message } = ctx
        const service = getLimitService(db)
        const tokens = args.map(a => String(a || '').trim()).filter(Boolean)
        const sub = (tokens[0] || '').toLowerCase()

        // ================= INFO USER (semua role) =================
        if (!sub) {
            return replyOwnUsage(ctx, service, sender)
        }

        // ================= MANAGEMENT GATE (co-owner+) =================
        // Sengaja di level subcommand — fungsi permission SAMA dengan framework
        // (RoleRepository.hasPermission), hanya tidak via metadata plugin karena
        // ".limit" tanpa subcommand harus terbuka untuk semua user.
        if (!RoleRepository.hasPermission(userRole, 'co-owner')) {
            return ctx.reply('Command ini membutuhkan role *co-owner* atau lebih tinggi.\nRole kamu: *' + (userRole || 'free') + '*')
        }

        if (sub === 'list') return replyList(ctx, service)
        if (sub === 'get') return replyGetConfig(ctx, service, tokens.slice(1))
        if (sub === 'set') return handleSet(ctx, service, tokens.slice(1))
        if (sub === 'reset') return handleReset(ctx, service, { tokens: tokens.slice(1), mentionedJid, quoted, message })

        return ctx.reply(
            `Subcommand tidak dikenal: *${sub}*.\n` +
            `Pakai: *${_pfx}limit* (info) · *${_pfx}limit list* · *${_pfx}limit get* · *${_pfx}limit set* · *${_pfx}limit reset*`
        )
    },
}

// ============================================================================
// Info user
// ============================================================================

async function replyOwnUsage(ctx, service, sender) {
    const userKey = normalizeJid(sender)
    const usage = service.getUsage(userKey)

    // Scope "relevan/terpakai": global selalu, lainnya hanya yang pernah dipakai hari ini
    const lines = []
    const pushScope = (label, used, remaining) => {
        if (remaining === null) lines.push(`${label}: *Unlimited* (${used} hari ini)`)
        else if (remaining === 0 && used === 0) lines.push(`${label}: *0 / 0* (tidak tersedia utk role kamu)`)
        else lines.push(`${label}: *${used} / ${remaining + used}*`)
    }

    // Global — role user saat ini
    const role = ctx.userRole || 'free'
    const g = service.getRemaining(userKey, role, { limitType: 'global', name: 'x' })
    pushScope('Global', usage.global || 0, g.remaining)

    // Category/group/cmd yang terpakai hari ini
    for (const [cat, used] of Object.entries(usage.category || {})) {
        if (!used) continue
        const r = service.getRemaining(userKey, role, { limitType: 'category', category: cat, name: 'x' })
        pushScope(`Category ${cat}`, used, r.remaining)
    }
    for (const [grp, used] of Object.entries(usage.group || {})) {
        if (!used) continue
        const r = service.getRemaining(userKey, role, { limitType: 'group', limitGroup: grp, name: 'x' })
        pushScope(`Group ${grp}`, used, r.remaining)
    }
    for (const [cmd, used] of Object.entries(usage.cmd || {})) {
        if (!used) continue
        const r = service.getRemaining(userKey, role, { limitType: 'cmd', name: cmd })
        pushScope(`Command ${cmd}`, used, r.remaining)
    }

    return ctx.reply(
        `📊 *LIMIT KAMU*\n\n` +
        `Role: *${ROLE_LABEL[role] || role}*\n\n` +
        `${lines.join('\n')}\n\n` +
        `Reset: *${service.resetLabel()}*`
    )
}

// ============================================================================
// Management: list / get / set / reset
// ============================================================================

async function replyList(ctx, service) {
    const list = service.listConfigs()
    const lines = []
    lines.push(`• global: ${list.global.length ? list.global.join(', ') : '(fallback default)'}`)
    lines.push(`• category: ${list.category.length ? list.category.join(', ') : '(fallback global)'}`)
    lines.push(`• group: ${list.group.length ? list.group.join(', ') : '(fallback global)'}`)
    lines.push(`• cmd: ${list.cmd.length ? list.cmd.join(', ') : '(fallback global)'}`)
    return ctx.reply(
        `📋 *LIMIT CONFIG*\n\n${lines.join('\n')}\n\n` +
        `Scope tanpa file config otomatis memakai config global.\n` +
        `Lihat isi: *.limit get global* / *.limit get group am*`
    )
}

function parseScopeToken(tokens) {
    // [scope, key?] → { type, key, scopeKey, label } | error
    const type = (tokens[0] || '').toLowerCase()
    if (!LIMIT_TYPES.includes(type)) return { error: `Scope tidak valid: *${tokens[0] || '(kosong)'}*. Pilihan: ${LIMIT_TYPES.join(', ')}.` }
    let key = null
    if (type === 'global') key = null
    else {
        key = tokens[1]
        if (!key) return { error: `Scope *${type}* butuh key. Contoh: *.limit get ${type} ${type === 'category' ? 'downloader' : type === 'group' ? 'am' : 'ytmp3'}*` }
    }
    const fake = { limitType: type, category: key, limitGroup: key, name: key || 'global' }
    return { scope: scopeOf(fake) }
}

async function replyGetConfig(ctx, service, tokens) {
    const p = parseScopeToken(tokens)
    if (p.error) return ctx.reply(p.error)
    const { scope } = p

    const { data, source } = service.getConfig(scope.type, scope.key)
    const srcNote = source === 'file' ? '' : source === 'fallback-global' ? '\n_(file config scope ini belum ada — memakai config global)_' : '\n_(file config belum ada — memakai default)_'

    const lines = ROLE_ORDER.map(r => {
        const v = data[r]
        const has = r in data
        if (!has) return `${ROLE_LABEL[r]}: *0/day* (tidak dikonfigurasi)`
        return `${ROLE_LABEL[r]}: ${v === null ? '*Unlimited*' : `*${v}/day*`}`
    })

    const title = scope.type === 'global' ? 'Global Limit' : `Limit ${scope.label}`
    return ctx.reply(`📊 *${title}*\n\n${lines.join('\n')}${srcNote}`)
}

async function handleSet(ctx, service, tokens) {
    // .limit set <scope> [key] <role> <value|unlimited>
    const p = parseScopeToken(tokens)
    if (p.error) return ctx.reply(p.error)
    const { scope } = p

    const rest = tokens.slice(scope.type === 'global' ? 1 : 2)
    const role = (rest[0] || '').toLowerCase()
    const rawValue = rest.slice(1).join(' ').trim()

    if (!rawValue) {
        return ctx.reply(`Nilai wajib diisi: angka (>= 0) atau *unlimited*.\nContoh: *.limit set group am premium 5* / *.limit set group am owner unlimited*`)
    }

    const value = /^unlimited$/i.test(rawValue) ? null : Number(rawValue)
    if (value !== null && (!Number.isInteger(value) || value < 0)) {
        return ctx.reply(`Nilai tidak valid: *${rawValue}*.\nGunakan angka bulat >= 0 atau kata *unlimited*.`)
    }

    const r = await service.setConfig(scope.type, scope.key, role, value)
    if (!r.ok) return ctx.reply(`❌ Gagal set limit: ${r.error}`)

    const saved = value === null ? 'Unlimited (null)' : `${value}/day`
    return ctx.reply(
        `✅ Limit *${scope.label}* → *${ROLE_LABEL[role] || role}* = *${saved}*\n` +
        `Tersimpan ke file config (langsung aktif, tanpa restart).`
    )
}

async function handleReset(ctx, service, { tokens, mentionedJid, quoted, message }) {
    const target0 = extractTarget({ mentionedJid, quoted, message })
    if (!target0 || typeof target0 === 'object') {
        return ctx.reply('Tag orang yang usage-nya mau direset.\nContoh: *.limit reset @tag* / *.limit reset @tag group am*')
    }

    // Kanonikalisasi ke PN (konsisten key usage = sender PN)
    let key = await toKey(ctx, target0)
    key = normalizeJid(key)

    // Scope opsional SETELAH mention: [.limit reset @user] [global|category x|...]
    // Token mention (@...) bukan bagian dari scope — difilter sebelum parse.
    let scopeKey = null
    let scopeNote = 'semua scope'
    const scopeTokens = tokens.filter(t => !t.startsWith('@'))
    if (scopeTokens.length) {
        const p = parseScopeToken(scopeTokens)
        if (p.error) return ctx.reply(p.error)
        scopeKey = p.scope.scopeKey
        scopeNote = p.scope.label
    }

    const ok = service.resetUsage(key, scopeKey)
    if (!ok) {
        return ctx.reply(`@${fmtJid(key)} tidak punya pemakaian limit yang tersimpan.`, { mentions: [key] })
    }
    return ctx.reply(
        `♻️ Limit *@${fmtJid(key)}* direset (${scopeNote}). Pemakaian kembali ke 0.`,
        { mentions: [key] }
    )
}
