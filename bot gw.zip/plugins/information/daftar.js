import { sanitizeUsername, generatePlayerId, generateUserId, isValidName, isValidAge } from '../../lib/core/validators.js'
import { findProfileForMessage } from '../../lib/identity/index.js'

export default {
	name: 'daftar',
	aliases: ['register', 'reg'],
	description: 'Registrasi user baru',
	category: 'information',
	usage: '.daftar nama.umur',
	register: false,

	async execute(ctx) {
			const _pfx = (typeof ctx !== 'undefined' && ctx?.prefix) || ''
		const { args, sender, senderLid, resolver, userRepo, idRepo } = ctx
		const rawArgs = args.join(' ')

		// Parse: nama.umur
		const parts = rawArgs.split(/[.|,]/).map(s => s.trim())
		const name = parts[0]
		const age = Number(parts[1])

		if (!isValidName(name)) {
			return ctx.reply(`Format salah. Contoh: ${_pfx}daftar Nanda.17`)
		}
		if (!isValidAge(age)) {
			return ctx.reply('Umur harus angka antara 10-80.')
		}

		// Cek apakah sender sudah terdaftar
		// (Phase 1: rantai kanonik lib/identity — PN→JID→LID+mapping Task 58)
		const existing = findProfileForMessage(userRepo, { sender, senderLid })
		if (existing) {
			return ctx.reply(`Kamu sudah terdaftar sebagai *${existing.username}* (Player ID: ${existing.player_id}).`)
		}

		// Generate base playerID dari nama
		let baseId = generatePlayerId(name)
		let playerId = baseId

		// Kalau sudah ada, tambah angka di belakang: nanda → nanda1 → nanda2 → ...
		if (userRepo.playerIdExists(playerId)) {
			let suffix = 1
			while (userRepo.playerIdExists(baseId + suffix) && suffix < 100) {
				suffix++
			}
			if (suffix >= 100) {
				return ctx.reply('Gagal generate Player ID unik. Coba nama lain.')
			}
			playerId = baseId + suffix
		}

		const userId = generateUserId()

		// Save
		const now = new Date().toISOString()
		try {
			const user = userRepo.create({
				user_id: userId,
				player_id: playerId,
				username: name,
				age,
				pn: sender,
				jid: sender,
				lid: senderLid,
				registered_at: now,
				updated_at: now
			})

			// Simpan identifier mapping — SATU jalur kanonik (Phase 1:
			// recordMapping sudah mem-upsert idRepo + cache; idRepo.upsert
			// kedua = double-write data identik — dihapus.)
			if (resolver) resolver.recordMapping(sender, senderLid, sender, userId)

			await ctx.reply([
				'*Registrasi Berhasil*',
				'',
				`User ID: ${user.user_id}`,
				`Player ID: ${user.player_id}`,
				`Nama: ${user.username}`,
				`Umur: ${user.age}`
			].join('\n'))
		} catch (error) {
			if (error.message?.includes('UNIQUE') || error.message?.includes('exist')) {
				return ctx.reply('Data kamu sudah terdaftar.')
			}
			throw error
		}
	}
}
