import axios from 'axios'
import logger from '../../lib/core/logger.js'

/** Timeout API (ms). */
const API_TIMEOUT_MS = 30_000

/**
 * Compare dua device via API kyzzz.xyz
 */
async function compareDevice(hp1, hp2) {
    try {
        const apiKey = process.env.KYZZZ_API_KEY || ''
        const res = await axios.get(
            `https://api.kyzzz.xyz/api/tools/compare-device?hp1=${encodeURIComponent(hp1)}&hp2=${encodeURIComponent(hp2)}&apikey=${apiKey}`,
            { timeout: API_TIMEOUT_MS }
        )
        return res.data
    } catch (e) {
        logger.error('[comparedevice] API error:', e)
        return null
    }
}

/**
 * Format section menjadi teks WhatsApp yang rapi.
 */
function formatSection(section) {
    const lines = []
    
    // Skip section yang tidak penting
    if (section.section === 'ARTIKEL TERKAIT') return ''
    
    lines.push(`\n━━━ *${section.section}* ━━━`)
    
    for (const row of section.rows || []) {
        // Skip row dengan label null atau kosong
        if (!row.label) continue
        
        // Skip row yang isinya link
        if (row.label === 'Cek Harga Terbaru' || row.label === 'Halaman Spesifikasi »') continue
        
        lines.push(`\n📌 *${row.label}*`)
        lines.push(`├─ 📱 *HP 1:* ${row.value1 || '-'}`)
        lines.push(`└─ 📱 *HP 2:* ${row.value2 || '-'}`)
    }
    
    return lines.join('\n')
}

/**
 * Format response lengkap jadi teks WhatsApp.
 */
function formatComparison(data) {
    const phone1 = data.phone1?.title || 'HP 1'
    const phone2 = data.phone2?.title || 'HP 2'
    
    const lines = [
        `📱 *PERBANDINGAN DEVICE*\n`,
        `━━━━━━━━━━━━━━━━━━`,
        `\n*📱 HP 1:* ${phone1}`,
        `*📱 HP 2:* ${phone2}`,
    ]
    
    // Gabung semua section
    const sections = data.sections || []
    for (const section of sections) {
        const formatted = formatSection(section)
        if (formatted) lines.push(formatted)
    }
    
    return lines.join('\n')
}

export default {
    name: 'comparedevice',
    aliases: ['comparehp', 'bandingkan', 'vs'],
    description: 'Bandingkan spesifikasi dua HP',
    category: 'information',
    usage: '.comparedevice <hp1> | <hp2>',
    register: true,

    async execute(ctx) {
        const { sock, chat, message, args, prefix, command, reply } = ctx
        const input = args.join(' ').trim()
        
        if (!input) {
            return reply(
`📱 *Compare Device*

Bandingkan spesifikasi dua HP.

📌 *Contoh:*
${prefix + command} samsung j2 prime | rog phone 8
${prefix + command} iphone 15 | samsung s24

✨ *Fitur:*
- Perbandingan lengkap semua spesifikasi
- Tampilan rapi per kategori
- Info spesifikasi detail`)
        }
        
        // Split input dengan "|"
        const [hp1, hp2] = input.split('|').map(v => v?.trim())
        
        if (!hp1 || !hp2) {
            return reply('❌ Format salah!\nGunakan: .comparedevice <hp1> | <hp2>')
        }
        
        await sock.sendMessage(chat, { react: { text: '🔍', key: message.key } }).catch(() => {})
        
        try {
            const data = await compareDevice(hp1, hp2)
            
            if (!data?.status || !data?.sections?.length) {
                await sock.sendMessage(chat, { react: { text: '❌', key: message.key } }).catch(() => {})
                return reply('❌ Gagal membandingkan device.')
            }
            
            const text = formatComparison(data)
            
            // Kirim langsung satu pesan (WhatsApp support panjang)
            await sock.sendMessage(chat, { text }, { quoted: message })
            
            await sock.sendMessage(chat, { react: { text: '✅', key: message.key } }).catch(() => {})
            
        } catch (e) {
            logger.error('[comparedevice] Error:', e)
            await sock.sendMessage(chat, { react: { text: '❌', key: message.key } }).catch(() => {})
            
            if (e.code === 'ECONNABORTED') {
                return reply('⏱️ Request timeout. Coba lagi.')
            }
            
            return reply(`❌ Error: ${e.message || 'Gagal membandingkan device.'}`)
        }
    }
}