/**
 * .jid — Command helper-testing: informasi JID + nama (Task lanjutan
 * "JID NAME + PUSHNAME"): normalisasi via helper identitas RESMI
 * (lib/identity/index.js — kanonik Phase 1), plus nama terdaftar di
 * database bot dan WhatsApp push name.
 *
 * Contoh pemakaian yang benar (jangan buat implementasi sendiri di plugin):
 *   import { normalizeJid } from '../../lib/identity/index.js'
 *   import { getPushName } from '../../lib/features/names.js'      // cache push name resmi
 *   import { userRepo.findByIdentifier } from ctx          // resolver DB resmi
 *
 * Perintah:
 *   .jid                → JID pengirim command (diri sendiri)
 *   .jid @tag           → ambil JID dari mention pertama
 *   .jid (reply pesan)  → ambil sender pesan yang di-reply
 *   .jid 123@lid        → input JID mentah (testing helper: PN/LID/device/c.us)
 *
 * Resolusi target: mention → reply → input mentah → pengirim command.
 *
 * NAMA DB — via resolver resmi userRepo.findByIdentifier(normalizedJid)
 * (rantai kanonik: pn/jid/lid/player_id/user_id + viaLidMapping Task 58 —
 * sama dengan .profile). Untuk target sender, dipakai ctx.user (profil yang
 * SUDAH di-resolve dispatch bot.js dari pasangan sender+senderLid) bila ada.
 * Field nama = username terdaftar (pola afk.js/names.js: u?.username || u?.name).
 *
 * PUSH NAME WA — hanya dari sumber yang benar-benar berkaitan dengan target:
 *   • sender → m.pushName (metadata pesan ini, via ctx.pushName);
 *   • reply  → quoted.pushName (metadata pesan yang di-reply);
 *   • mention/input JID → metadata mention TIDAK membawa push name, jadi
 *     HANYA cache nama resmi lib/names.js (db.data.names[JID kanonik],
 *     direkam bot.js dari pesan-pesan sebelumnya JID tsb) — ditandai
 *     "(cache)". Push name PENGGIRIM tidak pernah dipakai sebagai push name
 *     target mention/input.
 * Bila tidak tersedia → "Tidak tersedia". Tidak ada nilai palsu/tebakan.
 *
 * Read-only murni: TIDAK menulis apa pun — tidak recordPushName, tidak
 * update profil, tidak network request. Satu-satunya efek samping
 * resolver resmi adalah back-fill field lid Task 58 (idempotent, perilaku
 * identik dengan .profile dan konsumen findByIdentifier lainnya).
 */
import {
        normalizeJid,
        jidDigits,
        isLidJid,
        isPnJid,
        isGroupJid,
} from '../../lib/identity/index.js'
import { fmtJid } from '../../lib/command/group-utils.js'
import { getPushName, sanitizeName } from '../../lib/features/names.js'

/**
 * Kandidat JID sender dari pesan yang di-reply — pola extractTarget
 * plugins/group/mute.js (participantAlt/participant, prefer bentuk PN).
 * @returns {string[]} daftar kandidat ber-'@' (bisa kosong)
 */
function quotedCandidates(quoted, message) {
        const cands = []
        if (quoted?.sender) cands.push(quoted.sender)
        if (quoted?.senderLid) cands.push(quoted.senderLid)
        if (quoted?.key?.participantAlt) cands.push(quoted.key.participantAlt)
        if (quoted?.key?.participant) cands.push(quoted.key.participant)
        if (quoted?.participant) cands.push(quoted.participant)
        const ci = message?.msg?.contextInfo
                || Object.values(message?.message || {}).find(v => v?.contextInfo)?.contextInfo
        if (ci?.participantAlt) cands.push(ci.participantAlt)
        if (ci?.participant) cands.push(ci.participant)
        return cands.map(c => String(c).trim()).filter(c => c.includes('@'))
}

/** Klasifikasi tipe JID via helper resmi identity. */
function classify(jid) {
        if (isGroupJid(jid)) return 'Grup (@g.us)'
        if (isLidJid(jid)) return 'LID (identitas internal WhatsApp)'
        if (isPnJid(jid)) return 'PN (@s.whatsapp.net)'
        return 'Tanpa domain (nomor polos)'
}

/**
 * Profil DB target — via resolver resmi userRepo.findByIdentifier
 * (LANGKAH 3: cari berdasarkan JID ternormalisasi; rantai fallback
 * identifier dimiliki resolver). Target sender memakai ctx.user lebih
 * dulu (hasil resolveProfile dispatch — pasangan sender+senderLid).
 * @returns {object|null} profil atau null (tidak pernah melempar)
 */
function dbProfileOf(ctx, normalized, source) {
        try {
                if (source === 'sender' && ctx.user) return ctx.user
                const repo = ctx.userRepo
                if (repo && typeof repo.findByIdentifier === 'function') {
                        return repo.findByIdentifier(normalized)
                }
        } catch { /* resolver bermasalah → dianggap tidak terdaftar */ }
        return null
}

/**
 * Nama terdaftar di DB — field username (pola afk.js/_displayNameOf &
 * names.js/resolveDisplayName: u?.username || u?.name, disanitize).
 * @returns {string} nama bersih ('' bila tidak ada)
 */
function dbNameOf(profile) {
        return sanitizeName(profile?.username || profile?.name || '')
}

/**
 * Push name LIVE dari metadata pesan yang benar-benar berkaitan dengan
 * target (LANGKAH 4): sender → pushName pesan ini; reply → pushName
 * pesan yang di-reply. Mention/input JID tidak punya metadata push name
 * target → '' (bukan pushName pengirim!).
 * @returns {string} nama bersih ('' bila tidak ada)
 */
function livePushNameOf(source, message, quoted, ctxPushName) {
        if (source === 'sender') {
                return sanitizeName(message?.pushName || ctxPushName || '')
        }
        if (source === 'reply') {
                return sanitizeName(quoted?.pushName || '')
        }
        return ''
}

/**
 * Push name dari cache nama RESMI lib/names.js (db.data.names) — direkam
 * bot.js per pesan masuk di bawah JID KANONIK JID pengirimnya sendiri,
 * jadi entry-nya benar-benar milik JID target. Bentuk kunci yang dicoba:
 * normalized → pn profil (bila profil ditemukan) → bentuk kanonik LID→PN
 * (resolver.toCanonical, murni peta memori). Murni baca — tidak menulis.
 * @returns {string|null} nama atau null
 */
function cachedPushNameOf(ctx, normalized, profile) {
        try {
                const forms = [normalized]
                const pn = profile?.pn
                if (typeof pn === 'string' && pn.includes('@') && pn !== normalized) {
                        forms.push(pn)
                }
                if (isLidJid(normalized) && typeof ctx?.resolver?.toCanonical === 'function') {
                        const canon = ctx.resolver.toCanonical(normalized)
                        if (canon && canon !== normalized && !forms.includes(canon)) {
                                forms.push(canon)
                        }
                }
                for (const f of forms) {
                        const n = getPushName(ctx.db, f)
                        if (n) return n
                }
        } catch { /* cache tidak tersedia → null */ }
        return null
}

export default {
        name: 'jid',
        aliases: ['normalizejid'],
        description: 'Lihat info JID: normalisasi, tipe, nama DB & push name WA',
        category: 'information',
        usage: '.jid | .jid @tag | .jid (reply) | .jid 123@lid',
        register: false, // helper-testing/basic info — tanpa wajib daftar (pola .ping, Task 36)

        async execute(ctx) {
                const ref = (ctx.cmdRef && ctx.cmdRef('jid')) || `${ctx?.prefix || ''}jid`
                const { args, mentionedJid, quoted, message, sender } = ctx

                // ---- Resolusi target: mention → reply → input mentah → pengirim ----
                let original = null
                let source = null

                const mention = (Array.isArray(mentionedJid) ? mentionedJid : []).find(m => m)
                        || message?.contextInfo?.mentionedJid?.[0]
                        || message?.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0]
                if (mention) {
                        original = String(mention)
                        source = 'mention'
                }

                if (!original && quoted) {
                        const cands = quotedCandidates(quoted, message)
                        const pick = cands.find(c => c.endsWith('@s.whatsapp.net')) || cands[0]
                        if (pick) {
                                original = pick
                                source = 'reply'
                        }
                }

                if (!original) {
                        const raw = String(args?.[0] || '').trim().replace(/^@/, '')
                        if (raw) {
                                original = raw
                                source = 'input'
                        }
                }

                if (!original && sender) {
                        original = String(sender)
                        source = 'sender'
                }

                if (!original) {
                        return ctx.reply(
                                `❌ Target JID tidak dapat ditentukan.\n` +
                                `Contoh: *${ref} @tag*, reply pesan orang, atau *${ref} 123@lid*`
                        )
                }

                // ---- Jalankan helper resmi (satu-satunya normalisasi di project ini) ----
                const normalized = normalizeJid(original)
                if (!normalized) {
                        return ctx.reply(
                                `Input tidak valid (kosong/null).\n` +
                                `Contoh: *${ref} @tag* atau *${ref} 6281234567890@s.whatsapp.net*`
                        )
                }

                // ---- Nama DB (resolver resmi) & push name WA (sumber valid saja) ----
                const dbProfile = dbProfileOf(ctx, normalized, source)
                const dbName = dbNameOf(dbProfile)

                const livePush = livePushNameOf(source, message, quoted, ctx.pushName)
                const cachedPush = livePush ? null : cachedPushNameOf(ctx, normalized, dbProfile)
                const pushDisplay = livePush
                        || (cachedPush ? `${cachedPush} (cache)` : '')
                        || ''

                const same = original === normalized
                const type = classify(normalized)
                const digits = jidDigits(normalized)

                const lines = [
                        '╭─❁ *JID INFORMATION* ❁',
                        `◦❒ *Sumber:* ${source}`,
                        `◦❒ *Target:* @${fmtJid(normalized)}`,
                        `◦❒ *JID asli:* ${original}`,
                        `◦❒ *JID normalized:* ${normalized}`,
                        `◦❒ *Tipe:* ${type}`,
                        `◦❒ *Digits:* ${digits || '-'}`,
                        `◦❒ *Status:* ${same ? 'sudah kanonik (tidak berubah)' : 'dinormalisasi'}`,
                        `◦❒ *Nama DB:* ${dbName || 'Tidak terdaftar'}`,
                        `◦❒ *Push Name WA:* ${pushDisplay || 'Tidak tersedia'}`,
                ]
                if (isLidJid(normalized)) {
                        lines.push('◦❒ *Catatan:* @lid = format internal — hanya utk testing helper')
                }
                lines.push('╰─❁')

                // Highlight target bila bentuk PN (mention WA bisa resolve).
                // LID tidak di-mention (client umumnya tidak me-resolve highlight LID).
                const mentions = isPnJid(normalized) ? [normalized] : []
                return ctx.reply(lines.join('\n'), { mentions })
        }
}
