/**
 * .lb — leaderboard aktivitas (level/exp/chat/cmd/money/streak + topcmd).
 *
 * Format:
 *   .lb                          → level, scope grup (PM → global)
 *   .lb <kategori> [global] [waktu] [halaman]
 *     kategori : level | exp | chat | cmd | money | streak | topcmd
 *     scope    : global (atau default scope saat ini)
 *     waktu    : harian | mingguan | bulanan | all  (hanya chat & cmd)
 *     halaman  : angka (10 baris/halaman)
 *
 * Contoh: .lb money • .lb chat global • .lb level global • .lb chat mingguan 2
 *
 * Money TIDAK punya sistem ekonomi baru — membaca wallet+bank user terdaftar
 * lewat moneyProvider (disuntik bot.js dari userRepo).
 * Level/EXP/streak selalu all-time (global 1 nilai per user); window hanya
 * berlaku untuk chat & cmd.
 */
import { parseWindowArg, windowLabel } from '../../lib/economy/leveling.js'
import { formatCoin } from '../../lib/economy/economy.js'
import { formatDurationShort } from '../../lib/features/afk.js'
import { getPushName } from '../../lib/features/names.js'
import { isSendUncertain } from '../../lib/messaging/send-fence.js'
import logger from '../../lib/core/logger.js'
import { activity as activityCfg } from '../../config/activity.js'

const CATEGORY_META = {
    level: { label: 'LEVEL', emoji: '🏅', windowed: false },
    exp: { label: 'EXP (TOTAL)', emoji: '✨', windowed: false },
    chat: { label: 'CHAT', emoji: '💬', windowed: true },
    cmd: { label: 'COMMAND', emoji: '⚡', windowed: true },
    money: { label: 'COIN', emoji: '💰', windowed: false },
    streak: { label: 'STREAK AKTIF', emoji: '🔥', windowed: false },
    topcmd: { label: 'COMMAND TERPOPULER', emoji: '📊', windowed: false },
    work: { label: 'WORK EARNINGS', emoji: '💼', windowed: false },
    job: { label: 'JOB LEVEL', emoji: '🧰', windowed: false },
    afk: { label: 'AFK TERLAMA — SATU SESI', emoji: '💤', windowed: false },
    afktotal: { label: 'AFK TERLAMA — TOTAL', emoji: '💤', windowed: false },
}

const CATEGORY_ALIASES = {
    lvl: 'level', rank: 'level',
    xp: 'exp',
    pesan: 'chat', message: 'chat', messages: 'chat', aktif: 'chat', active: 'chat', msg: 'chat',
    command: 'cmd', commands: 'cmd', komando: 'cmd',
    coin: 'money', uang: 'money', saldo: 'money', balance: 'money', bal: 'money', dompet: 'money', rich: 'money',
    rentetan: 'streak',
    popular: 'topcmd', populer: 'topcmd', topcommands: 'topcmd', topcommand: 'topcmd',
    kerja: 'work', gaji: 'work', earnings: 'work', upah: 'work',
    pekerjaan: 'job', profesi: 'job', joblevel: 'job',
    // fase-4 AFK — masuk leaderboard EXISTING (requirement #7/#8)
    afksesi: 'afk', sesiafk: 'afk', tidur: 'afk',
    totalafk: 'afktotal',
}

const MEDALS = ['🥇', '🥈', '🥉']

/** Parse argumen .lb → {category, scope, window, page}. */
export function parseLbArgs(tokens, { defaultScope } = {}) {
    let category = 'level'
    let scope = defaultScope // 'group' | 'global'
    let window = 'all'
    let page = 1

    for (const raw of tokens) {
        const t = String(raw || '').toLowerCase()
        if (!t) continue
        if (t === 'global' || t === '-g' || t === 'semua') { scope = 'global'; continue }
        if (t === 'grup' || t === 'group' || t === 'di sini' || t === 'sini') { scope = 'group'; continue }

        const w = parseWindowArg(t)
        if (w) { window = w; continue }

        if (/^\d{1,3}$/.test(t)) { page = Math.max(1, parseInt(t, 10) || 1); continue }

        const cat = CATEGORY_ALIASES[t] || (CATEGORY_META[t] ? t : null)
        if (cat) { category = cat; continue }
        // token tak dikenal diabaikan (biar .lb money global 69 tetap masuk akal)
    }
    return { category, scope, window, page }
}

/** Format 1 baris leaderboard user. Task 36: pakai NAMA TERDAFTAR bila ada. */
export function formatLbRow({ rank, jid, value, category, extra = null, name = null }) {
    const medal = MEDALS[rank - 1] || `${rank}.`
    let val
    switch (category) {
        case 'level': val = `Level ${value}`; break
        case 'exp': val = `${Number(value).toLocaleString('id-ID')} EXP`; break
        case 'money': val = `${formatCoin(value)} coin`; break
        case 'streak': val = `${value} hari`; break
        case 'chat': val = `${Number(value).toLocaleString('id-ID')} pesan`; break
        case 'cmd': val = `${Number(value).toLocaleString('id-ID')}x command`; break
        case 'work': val = `${formatCoin(value)} coin (kerja)`; break
        case 'job': val = `${extra?.jobName || 'Job'} Lv. ${value}`; break
        case 'afk':
        case 'afktotal': val = formatDurationShort(value); break
        default: val = String(value)
    }
    const display = String(name || '').trim() || `@${String(jid).split('@')[0]}`
    return `${medal} ${display} — ${val}`
}

/**
 * Rakit teks leaderboard lengkap (pure — dites).
 * @param {object} o
 * @param {Array<{jid:string, value:number}>} o.rows
 * @param {number} o.total @param {number} o.page @param {number} o.pageSize
 * @param {string} o.category @param {'group'|'global'} o.scope
 * @param {string} o.window @param {boolean} [o.windowIgnored]
 * @param {boolean} [o.isTopcmd] rows = {name, value}
 * @param {Map<string,string>} [o.names] jid → nama terdaftar (Task 36)
 */
export function buildLbText({ rows, total, page, pageSize, category, scope, window, windowIgnored = false, isTopcmd = false, names = null }) {
    const meta = CATEGORY_META[category] || CATEGORY_META.level
    const scopeLabel = scope === 'group' ? '👥 Grup ini' : '🌐 Global'
    const winLabel = windowLabel(window)
    const header =
        `${meta.emoji} *LEADERBOARD — ${meta.label}*\n` +
        `${scopeLabel} • ${meta.windowed ? winLabel : 'All-time'}` +
        (windowIgnored ? '\n> Kategori ini selalu all-time (filter waktu tidak berlaku).' : '')
    const lines = [header, '━━━━━━━━━━━━━━━━━━']

    if (!rows.length) {
        lines.push('Belum ada data. Ngobrol dulu biar masuk ranking 😄')
    } else if (isTopcmd) {
        rows.forEach((r, i) => {
            const rank = (page - 1) * pageSize + i + 1
            const medal = MEDALS[rank - 1] || `${rank}.`
            lines.push(`${medal} .${r.name} — ${Number(r.value).toLocaleString('id-ID')}x`)
        })
    } else {
        rows.forEach((r, i) => {
            const rank = (page - 1) * pageSize + i + 1
            const name = names instanceof Map ? names.get(r.jid) : names?.[r.jid] || null
            lines.push(formatLbRow({ rank, jid: r.jid, value: r.value, category, extra: r.extra, name }))
        })
    }

    const pages = Math.max(1, Math.ceil(total / pageSize))
    lines.push('━━━━━━━━━━━━━━━━━━')
    if (pages > 1) {
        lines.push(`Hal *${page}/${pages}* • total ${total} data`)
        if (page < pages) lines.push(`→ Lanjut: .lb ${category}${scope === 'global' ? ' global' : ''}${meta.windowed && window !== 'all' ? ` ${window}` : ''} ${page + 1}`)
    }
    return lines.join('\n')
}

/** Teks bantuan kategori (argumen tidak dikenal / .lb help). */
export function buildLbHelp() {
    return (
        `🏆 *LEADERBOARD*\n\n` +
        `Cara pakai: .lb <kategori> [global] [waktu] [halaman]\n\n` +
        `*Kategori:*\n` +
        `• level — level tertinggi\n` +
        `• exp — EXP total terbanyak\n` +
        `• chat — pesan terbanyak\n` +
        `• cmd — command terbanyak dipakai\n` +
        `• money — coin terbanyak (wallet + bank)\n` +
        `• work — total upah kerja terbanyak\n` +
        `• job — job level tertinggi\n` +
        `• streak — streak aktif harian\n` +
        `• topcmd — command paling populer\n` +
        `• afk — AFK terlama (satu sesi + total, dua seksi)\n\n` +
        `*Scope:* ketik \`global\` utk seluruh bot (default: grup ini / chat ini)\n` +
        `*Waktu:* harian / mingguan / bulanan / all (hanya chat & cmd)\n\n` +
        `Contoh:\n` +
        `• .lb — level grup ini\n` +
        `• .lb money — coin grup ini\n` +
        `• .lb chat global mingguan — chat 7 hari terakhir (global)\n` +
        `• .lb level global 2 — halaman 2 level global\n` +
        `• .lb afk global — AFK terlama seluruh bot`
    )
}

/**
 * Tampilan GABUNGAN kategori afk (requirement #7 — dua seksi dalam satu
 * output, format baris/pagination tetap konsisten dengan buildLbText).
 * @param {object} o
 * @param {Array<{jid,value,extra}>} o.sesiRows @param {number} o.sesiTotal
 * @param {Array<{jid,value,extra}>} o.totalRows @param {number} o.totalTotal
 * @param {number} o.page @param {number} o.pageSize
 * @param {'group'|'global'} o.scope
 * @param {Map<string,string>} [o.names] jid → nama terdaftar
 * @param {boolean} [o.windowIgnored]
 */
export function buildAfkLbText({ sesiRows, sesiTotal, totalRows, totalTotal, page, pageSize, scope, names = null, windowIgnored = false }) {
    const scopeLabel = scope === 'group' ? '👥 Grup ini' : '🌐 Global'
    const lines = [
        `💤 *LEADERBOARD — AFK*`,
        `${scopeLabel} • All-time` + (windowIgnored ? '\n> Kategori ini selalu all-time (filter waktu tidak berlaku).' : ''),
        '━━━━━━━━━━━━━━━━━━',
    ]

    const sections = [
        [CATEGORY_META.afk, sesiRows],
        [CATEGORY_META.afktotal, totalRows],
    ]
    for (const [meta, rows] of sections) {
        lines.push('', `${meta.emoji} *${meta.label}*`)
        if (!rows.length) {
            lines.push('Belum ada data — belum ada yang AFK tercatat 😴')
        } else {
            rows.forEach((r, i) => {
                const rank = (page - 1) * pageSize + i + 1
                const name = names instanceof Map ? names.get(r.jid) : (names?.[r.jid] || null)
                lines.push(formatLbRow({ rank, jid: r.jid, value: r.value, category: meta === CATEGORY_META.afk ? 'afk' : 'afktotal', extra: r.extra, name }))
            })
        }
    }

    lines.push('', '━━━━━━━━━━━━━━━━━━')
    const pages = Math.max(1, Math.ceil(Math.max(sesiTotal, totalTotal) / pageSize))
    if (pages > 1) {
        lines.push(`Hal *${page}/${pages}* • total ${Math.max(sesiTotal, totalTotal)} data`)
        if (page < pages) lines.push(`→ Lanjut: .lb afk${scope === 'global' ? ' global' : ''} ${page + 1}`)
    }
    return lines.join('\n')
}

export default {
    name: 'lb',
    aliases: ['leaderboard', 'top'],
    description: 'Leaderboard aktivitas: level/exp/chat/cmd/money/streak + topcmd',
    category: 'information',
    usage: '.lb <kategori> [global] [waktu] [halaman]',
    register: false,

    async execute(ctx) {
        const { args, chat, isGroup, sender, activity, reply } = ctx
        if (!activity) return reply('Fitur statistik belum aktif (restart bot).')

        // .lb help / .lb ? → panduan kategori
        if (/^(help|\?)$/i.test(String(args[0] || '').trim())) return reply(buildLbHelp())

        const parsed = parseLbArgs(args, { defaultScope: isGroup ? 'group' : 'global' })
        const meta = CATEGORY_META[parsed.category] || CATEGORY_META.level

        // ---- Fase-4: kategori afk → tampilan GABUNGAN dua seksi ----
        // (requirement #7: "AFK TERLAMA — SATU SESI" + "AFK TERLAMA — TOTAL"
        // dalam satu output .lb afk; format baris + pagination konsisten).
        if (parsed.category === 'afk') {
            const pageSize = activityCfg.lbPageSize
            const scope = { type: parsed.scope, jid: parsed.scope === 'group' ? chat : null }
            const windowIgnored = parsed.window !== 'all'

            const fetchPage = (page) => ({
                sesi: activity.top({ category: 'afk', scope, limit: pageSize, offset: (page - 1) * pageSize }),
                total: activity.top({ category: 'afktotal', scope, limit: pageSize, offset: (page - 1) * pageSize }),
            })

            const first = fetchPage(parsed.page)
            const pages = Math.max(1, Math.ceil(Math.max(first.sesi.total, first.total.total) / pageSize))
            const page = Math.min(parsed.page, pages)
            const cur = page === parsed.page ? first : fetchPage(page)

            const namesMap = new Map()
            for (const r of [...cur.sesi.rows, ...cur.total.rows]) {
                try {
                    const u = ctx.userRepo?.findByIdentifier?.(r.jid)
                    if (u?.username) { namesMap.set(r.jid, String(u.username)); continue }
                    const pn = getPushName(ctx.db, r.jid)
                    if (pn) namesMap.set(r.jid, pn)
                } catch {}
            }

            const text = buildAfkLbText({
                sesiRows: cur.sesi.rows,
                sesiTotal: first.sesi.total,
                totalRows: cur.total.rows,
                totalTotal: first.total.total,
                page,
                pageSize,
                scope: parsed.scope,
                names: namesMap,
                windowIgnored,
            })

            // self-rank (metrik sesi terlama)
            let footer = ''
            if (sender) {
                const { rank } = activity.rankOf({ userJid: sender, category: 'afk', scope })
                const shown = cur.sesi.rows.some(r => r.jid === sender)
                if (rank && !shown) footer = `\n📍 Posisimu: *#${rank}* (sesi terlama)`
            }

            try {
                await ctx.sock.sendMessage(chat, { text: text + footer }, { quoted: ctx.message })
            } catch (e) {
                // TASK 23 (double message): kirim utama "tidak pasti" (timeout
                // fence — hasil leaderboard sering SUDAH sampai) → JANGAN kirim
                // ulang lewat reply() — itu persis mekanisme ".leaderboard
                // mengirim hasil 2x dengan jeda". Gagal PASTI → fallback tetap.
                if (isSendUncertain(e)) {
                    logger.warn('.lb afk: kirim leaderboard tidak pasti (uncertain) — skip fallback reply (anti duplikat, chat=%s)', chat)
                    return
                }
                await reply(text + footer)
            }
            return
        }

        // kategori yang tidak mendukung window → catat utk catatan kaki
        const windowIgnored = !meta.windowed && parsed.window !== 'all'
        const window = meta.windowed ? parsed.window : 'all'
        const scope = { type: parsed.scope, jid: parsed.scope === 'group' ? chat : null }

        const pageSize = activityCfg.lbPageSize
        const { rows, total } = activity.top({
            category: parsed.category,
            scope,
            window,
            limit: pageSize,
            offset: (parsed.page - 1) * pageSize,
        })

        const pages = Math.max(1, Math.ceil(total / pageSize))
        const page = Math.min(parsed.page, pages)
        const finalRows = page === parsed.page ? rows : activity.top({
            category: parsed.category,
            scope,
            window,
            limit: pageSize,
            offset: (page - 1) * pageSize,
        }).rows

        // Task 36+37: baris leaderboard tampil pakai NAMA TERDAFTAR, fallback
        // PUSH NAME WA (cache lib/names.js) utk yang belum daftar, terakhir
        // @nomor — TANPA mention/tag.
        const namesMap = new Map()
        if (parsed.category !== 'topcmd') {
            for (const r of finalRows) {
                try {
                    const u = ctx.userRepo?.findByIdentifier?.(r.jid)
                    if (u?.username) { namesMap.set(r.jid, String(u.username)); continue }
                    const pn = getPushName(ctx.db, r.jid)
                    if (pn) namesMap.set(r.jid, pn)
                } catch {}
            }
        }

        const text = buildLbText({
            rows: finalRows,
            total,
            page,
            pageSize,
            category: parsed.category,
            scope: parsed.scope,
            window,
            windowIgnored,
            isTopcmd: parsed.category === 'topcmd',
            names: namesMap,
        })

        const mentions = [] // Task 36: tanpa tag — nama terdaftar di teks
        // self-rank: posisi user utk kategori/scope yang sama (kalau tidak tampil di halaman ini)
        let footer = ''
        if (sender && parsed.category !== 'topcmd') {
            const { rank } = activity.rankOf({ userJid: sender, category: parsed.category, scope, window })
            const shown = finalRows.some(r => r.jid === sender)
            if (rank && !shown) footer = `\n📍 Posisimu: *#${rank}*`
        }

        try {
            await ctx.sock.sendMessage(chat, { text: text + footer, mentions }, { quoted: ctx.message })
        } catch (e) {
            // TASK 23 (double message): kirim utama "tidak pasti" (timeout
            // fence — hasil sering SUDAH sampai ke user) → JANGAN kirim ulang
            // lewat reply() (duplikat "hasil 2x dengan jeda"). Gagal PASTI →
            // fallback reply tetap jalan.
            if (isSendUncertain(e)) {
                logger.warn('.lb: kirim leaderboard tidak pasti (uncertain) — skip fallback reply (anti duplikat, chat=%s)', chat)
                return
            }
            await reply(text + footer)
        }
    },
}
