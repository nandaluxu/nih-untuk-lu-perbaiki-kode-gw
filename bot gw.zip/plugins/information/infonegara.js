import axios from 'axios'
import logger from '../../lib/core/logger.js'

/** Timeout API (ms). */
const API_TIMEOUT_MS = 30_000

/**
 * Get info negara via API kyzzz.xyz
 */
async function getCountryInfo(country) {
    try {
        const apiKey = process.env.KYZZZ_API_KEY || ''
        const res = await axios.get(
            `https://api.kyzzz.xyz/api/tools/info-negara?country=${encodeURIComponent(country)}&apikey=${apiKey}`,
            { timeout: API_TIMEOUT_MS }
        )
        return res.data
    } catch (e) {
        logger.error('[infonegara] API error:', e)
        return null
    }
}

/**
 * Format luas area.
 */
function formatArea(squareKilometers, squareMiles) {
    if (!squareKilometers) return 'N/A'
    return `${squareKilometers.toLocaleString('id-ID')} km² (${squareMiles?.toLocaleString('id-ID') || 'N/A'} mi²)`
}

/**
 * Format koordinat.
 */
function formatCoordinates(coords) {
    if (!coords) return 'N/A'
    return `${coords.latitude}, ${coords.longitude}`
}

/**
 * Format response jadi teks WhatsApp yang rapi.
 */
function formatCountryInfo(data) {
    const country = data.result?.data || {}
    const metadata = data.result?.searchMetadata || {}
    
    const lines = [
        `🌍 *INFO NEGARA*\n`,
        `━━━━━━━━━━━━━━━━━━`,
        `\n${country.flag ? `🏳️ *Bendera:* ${country.flag}` : ''}`,
        `📛 *Nama:* ${country.name || 'Unknown'}`,
        `🏛️ *Ibu Kota:* ${country.capital || 'Unknown'}`,
        `📞 *Kode Telepon:* ${country.phoneCode || 'N/A'}`,
        `\n━━━ *📍 GEOGRAFI* ━━━`,
        `🗺️ *Benua:* ${country.continent?.emoji || ''} ${country.continent?.name || 'Unknown'} (${country.continent?.code?.toUpperCase() || 'N/A'})`,
        `📐 *Koordinat:* ${formatCoordinates(country.coordinates)}`,
        `📏 *Luas:* ${formatArea(country.area?.squareKilometers, country.area?.squareMiles)}`,
        `🏝️ *Landlocked:* ${country.landlocked ? 'Ya' : 'Tidak'}`,
        `\n━━━ *🏛️ PEMERINTAHAN* ━━━`,
        `📋 *Bentuk:* ${country.constitutionalForm || 'N/A'}`,
        `🚗 *Lajur Kiri:* ${country.drivingSide === 'left' ? 'Ya (Kiri)' : 'Tidak (Kanan)'}`,
        `\n━━━ *🏷️ IDENTITAS* ━━━`,
        `🌐 *TLD:* ${country.internetTLD || 'N/A'}`,
        `🔢 *ISO Numeric:* ${country.isoCode?.numeric || 'N/A'}`,
        `🔤 *ISO Alpha-2:* ${country.isoCode?.alpha2?.toUpperCase() || 'N/A'}`,
        `🔤 *ISO Alpha-3:* ${country.isoCode?.alpha3?.toUpperCase() || 'N/A'}`,
        `\n━━━ *💬 BAHASA* ━━━`,
        `🗣️ *Native:* ${(country.languages?.native || []).join(', ') || 'N/A'}`,
        `🔤 *Codes:* ${(country.languages?.codes || []).join(', ') || 'N/A'}`,
        `\n━━━ *💰 EKONOMI* ━━━`,
        `💵 *Mata Uang:* ${country.currency || 'N/A'}`,
        `🍺 *Larangan Alkohol:* ${country.alcoholProhibition || 'N/A'}`,
        `\n━━━ *⭐ TERKENAL* ━━━`,
        `🌟 ${country.famousFor || 'N/A'}`,
    ]
    
    // Tambah negara tetangga
    if (country.neighbors?.length) {
        lines.push(`\n━━━ *👥 NEGARA TETANGGA* ━━━`)
        for (const neighbor of country.neighbors) {
            const coords = neighbor.coordinates 
                ? `${neighbor.coordinates.latitude}, ${neighbor.coordinates.longitude}`
                : 'N/A'
            lines.push(`\n• *${neighbor.name}*`)
            lines.push(`  📐 ${coords}`)
        }
    }
    
    // Tambah link maps
    if (country.googleMapsLink) {
        lines.push(`\n━━━━━━━━━━━━━━━━━━`)
        lines.push(`\n🗺️ *Maps:* ${country.googleMapsLink}`)
    }
    
    return lines.join('\n')
}

export default {
    name: 'infonegara',
    aliases: ['negara', 'country', 'countryinfo'],
    description: 'Cek informasi lengkap negara',
    category: 'information',
    usage: '.infonegara <nama negara>',
    register: true,

    async execute(ctx) {
        const { sock, chat, message, args, prefix, command, reply } = ctx
        const input = args.join(' ').trim()
        
        if (!input) {
            return reply(
`🌍 *Info Negara*

Cek informasi lengkap negara.

📌 *Contoh:*
${prefix + command} indonesia
${prefix + command} japan
${prefix + command} united states

✨ *Fitur:*
- Info geografi lengkap
- Bahasa & mata uang
- Negara tetangga
- Link Google Maps
- ISO codes`)
        }
        
        if (input.length < 2) {
            return reply('❌ Minimal 2 karakter.')
        }
        
        await sock.sendMessage(chat, { react: { text: '🔍', key: message.key } }).catch(() => {})
        
        try {
            const data = await getCountryInfo(input)
            
            if (!data?.status || !data?.result?.data) {
                await sock.sendMessage(chat, { react: { text: '❌', key: message.key } }).catch(() => {})
                return reply(`❌ Negara "${input}" tidak ditemukan.`)
            }
            
            const text = formatCountryInfo(data)
            
            // Kirim langsung satu pesan
            await sock.sendMessage(chat, { text }, { quoted: message })
            
            await sock.sendMessage(chat, { react: { text: '✅', key: message.key } }).catch(() => {})
            
        } catch (e) {
            logger.error('[infonegara] Error:', e)
            await sock.sendMessage(chat, { react: { text: '❌', key: message.key } }).catch(() => {})
            
            if (e.code === 'ECONNABORTED') {
                return reply('⏱️ Request timeout. Coba lagi.')
            }
            
            return reply(`❌ Error: ${e.message || 'Gagal mengambil info negara.'}`)
        }
    }
}