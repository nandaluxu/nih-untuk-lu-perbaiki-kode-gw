/**
 * .status — kondisi bot (§14-A).
 *
 *   .status        → versi publik (aman untuk semua user)
 *   .status full   → versi owner (memory, db size, timers, AI queue, dsb.)
 *
 * Data dari: lib/health.js (state kesehatan), activity store, provider
 * manager (AI), process (uptime/memory). Owner-only field jelas dipisah.
 */
import os from 'os'
import path from 'path'
import fs from 'fs'
import logger from '../../lib/core/logger.js'
import { getHealth } from '../../lib/features/health.js'
import { getSendFenceStats } from '../../lib/messaging/send-fence.js'
import { getSendLedgerStats } from '../../lib/messaging/send-ledger.js'
import { getLifecycleSnapshot } from '../../lib/features/connection-lifecycle.js'
import { getEchoGuardStats } from '../../lib/messaging/echo-guard.js'
import { isAutoReadEnabled } from '../../lib/messaging/autoread.js'
import { getReactConfig, getStatusReactorStats } from '../../lib/messaging/auto-status.js'
import { formatCoin } from '../../lib/economy/economy.js'
import { getDedupStats } from '../../lib/messaging/message-dedup.js'

function fmtUptime(ms) {
        const s = Math.floor(ms / 1000)
        const d = Math.floor(s / 86400)
        const h = Math.floor((s % 86400) / 3600)
        const m = Math.floor((s % 3600) / 60)
        if (d) return `${d}h ${h}j ${m}m`
        if (h) return `${h}j ${m}m`
        return `${m}m ${s % 60}d`
}

function fmtBytes(n) {
        if (!Number.isFinite(n)) return '?'
        const units = ['B', 'KB', 'MB', 'GB']
        let i = 0
        while (n >= 1024 && i < units.length - 1) { n /= 1024; i++ }
        return `${n.toFixed(1)}${units[i]}`
}

/** Ukuran total file dalam folder (sinkron, non-rekursif). */
function dirSize(dir) {
        try {
                let total = 0
                for (const f of fs.readdirSync(dir)) {
                        const full = path.join(dir, f)
                        try {
                                const st = fs.statSync(full)
                                if (st.isFile()) total += st.size
                        } catch { /* noop */ }
                }
                return total
        } catch {
                return 0
        }
}

export default {
        name: 'status',
        aliases: ['health'],
        description: 'Kondisi bot (uptime, kesehatan subsystem)',
        category: 'information',
        usage: '.status [full]', // full = owner

        async execute(ctx) {
                        const _pfx = (typeof ctx !== 'undefined' && ctx?.prefix) || ''
                const { pluginLoader } = ctx
                const full = String(ctx.args[0] || '').toLowerCase() === 'full'
                if (full && !ctx.isOwner) {
                        return ctx.reply(`Detail lengkap hanya untuk owner. Pakai ${_pfx}status`)
                }

                const health = getHealth()
                // PATCH BUTTON-PREFIX (fase-9, paritas stickerly fase-8): hint
                // "status full" pakai prefix EFEKTIF chat invokasi
                // (ctx.prefix = parsed.usedPrefix) — prefixManager.get() selalu
                // GLOBAL. pfx kini = _pfx (satu sumber).
                const pfx = ctx.prefix ?? ''
                const lines = []

                lines.push('*BOT STATUS*')
                lines.push(`Uptime : ${fmtUptime(process.uptime() * 1000)}`)
                lines.push(`Overall: *${health.overall()}*`)
                lines.push('')

                if (full) {
                        // ---- Owner: detail teknis ----
                        const mem = process.memoryUsage()
                        lines.push('*Resources (owner)*')
                        lines.push(`Memory  : rss ${fmtBytes(mem.rss)}, heap ${fmtBytes(mem.heapUsed)}/${fmtBytes(mem.heapTotal)}`)
                        lines.push(`Load    : ${os.loadavg().map(x => x.toFixed(2)).join(' / ')} (core ${os.cpus().length})`)
                        lines.push(`Node    : ${process.version}`)
                        lines.push('')

                        lines.push('*Storage*')
                        for (const d of ['store', 'users', 'sessions', 'temp']) {
                                lines.push(`${d.padEnd(10)}: ${fmtBytes(dirSize(process.cwd() + '/' + d))}`)
                        }
                        lines.push('')

                        lines.push('*Plugins*')
                        const registry = pluginLoader?.registry
                        if (registry) {
                                const cats = new Set()
                                for (const [, p] of registry) cats.add(p.category || 'other')
                                lines.push(`Loaded: ${registry.size} (${cats.size} kategori)`)
                        }
                        lines.push('')

                        lines.push('*AI*')
                        const ai = ctx.sock?._aiSystem
                        if (ai?.providerManager) {
                                const pm = ai.providerManager
                                const provs = pm.listProviders()
                                for (const p of provs) {
                                        lines.push(`${p.id.padEnd(12)}: ${p.keys} key, ${p.coolingKeys} cooling, active=${p.active}`)
                                }
                                lines.push(`Semaphore : active ${pm._semaphore.active}/${pm.maxConcurrency}, queue ${pm._semaphore.waiting}/${pm.maxQueue}`)
                        } else {
                                // Phase 1.A (F-01): "tidak aktif" dibedakan dari
                                // "init gagal" — health initState menyimpan
                                // lastError + lastErrorAt (sekali tulis saat
                                // lifecycle init, bukan per pesan). Seksi
                                // Subsystems di atas juga menampilkan
                                // ❌ AI: DOWN — init gagal: ...
                                const aiInit = health.initState('AI')
                                if (aiInit?.phase === 'down') {
                                        lines.push(`AI system DOWN — init gagal${aiInit.lastError ? `: ${aiInit.lastError}` : ''}`)
                                } else {
                                        lines.push('AI system tidak aktif')
                                }
                        }
                        lines.push('')

                        // ---- Send fence (audit execution): trip = koneksi zombie ----
                        lines.push('*Send Fence*')
                        const fs2 = getSendFenceStats(ctx.sock)
                        if (fs2) {
                                lines.push(`Trip total : ${fs2.trips} (terakhir: ${fs2.lastMethod || '-'} ${fs2.lastTripAt ? fmtUptime(Date.now() - fs2.lastTripAt) + ' lalu' : ''})`)
                                for (const [m, n] of Object.entries(fs2.byMethod)) {
                                        lines.push(`${m.padEnd(12)}: ${n} trip`)
                                }
                                if (fs2.trips === 0) lines.push('Bersih — tidak ada kirim yang menggantung')
                        } else {
                                lines.push('Fence belum terpasang (belum ready/reconnect)')
                        }
                        lines.push('')

                        // ---- Message dedup (Task 21): anti replay global ----
                        lines.push('*Message Dedup (anti-replay)*')
                        const dd = getDedupStats()
                        lines.push(`Dilacak   : ${dd.tracked} ID pesan aktif (TTL ${Math.round(dd.ttlMs / 3600000)} jam, cap ${dd.cap.toLocaleString('id-ID')})`)
                        lines.push(`Replay ditangkal : ${dd.blocked}${dd.blocked ? ` (terakhir: ${dd.lastBlockedKey} @ ${String(dd.lastBlockedChat || '').split('@')[0]}, ${fmtUptime(Date.now() - dd.lastBlockedAt)} lalu)` : ''}`)
                        {
                                let upsertN = null
                                let msgN = null
                                try { upsertN = ctx.sock?.ev?.listenerCount?.('messages.upsert') ?? null } catch {}
                                try { msgN = ctx.sock?.ev?.listenerCount?.('message') ?? null } catch {}
                                lines.push(`Listener  : message=${ctx.sock?.ev ? (typeof msgN === 'number' ? msgN : '-') : '-'}${typeof upsertN === 'number' ? `, messages.upsert=${upsertN}` : ''} (harus stabil, bukan menumpuk)`)
                        }
                        lines.push('')

                        // ---- Send ledger + transport retry (Task 23: anti double message) ----
                        lines.push('*Send Ledger (Task 23 — korrelasi kirim)*')
                        const sl = getSendLedgerStats()
                        if (sl) {
                                lines.push(`Kirim total : ${sl.sends.total} (ok ${sl.sends.ok}, uncertain ${sl.sends.uncertain}, gagal ${sl.sends.failed})`)
                                lines.push(`Terakhir    : ${sl.sends.lastMsgId || '-'} @ ${String(sl.sends.lastChat || '-').split('@')[0]}`)
                                if (sl.transport) {
                                        lines.push(`Transport re-send Baileys : ${sl.transport.successfulRetries}${sl.transport.successfulRetries > 0 ? ' ⚠️ (duplikat level transport — BUKAN eksekusi ganda)' : ' — bersih'}`)
                                        lines.push(`Retry cache : pending ${sl.transport.pendingCounters}, cached ${sl.transport.recentCached}, maxRetry ${sl.transport.maxMsgRetryCount}`)
                                } else {
                                        lines.push('Transport observer belum aktif')
                                }
                        }
                        lines.push('')

                        // ---- Ownership progression (Task 23) ----
                        lines.push('*Ownership Data (Task 23)*')
                        lines.push('User DB   : source of truth identitas + economy + progression (level/EXP/streak)')
                        lines.push('Group DB  : source of truth konfigurasi grup (settings + groups/)')
                        lines.push('Activity  : analytics saja (chat/cmd harian + commandNames) — legacy activity.json mati')
                        lines.push('')

                        // ---- Backlog guard (audit fase-2): lifecycle koneksi ----
                        lines.push('*Backlog Guard*')
                        const lc = getLifecycleSnapshot()
                        lines.push(`Online   : ${lc.online ? 'YA' : 'TIDAK'}${lc.onlineAt ? ` (sejak ${fmtUptime(Date.now() - lc.onlineAt)} lalu)` : ''}`)
                        lines.push(`Offline  : ${lc.offlineAt ? fmtUptime(Date.now() - lc.offlineAt) + ' lalu' + (lc.lastReason ? ` (${lc.lastReason})` : '') : '-'}`)
                        lines.push(`Policy   : window replay ${Math.round(lc.backlogWindowMs / 1000)} dtk, grace ${Math.round(lc.graceMs / 1000)} dtk — pesan pra-online di-drop`)
                        lines.push('')

                        // ---- Fase-3: self-processing (echo-guard + autoread + autoreactsw) ----
                        lines.push('*Self & Auto (fase-3)*')
                        const eg = getEchoGuardStats()
                        lines.push(`EchoGuard: ${eg.tracked} ID terlacak (TTL ${Math.round(eg.ttlMs / 60000)} mnt, max ${eg.max}) — fromMe diproses, echo bot dibuang`)
                        lines.push(`AutoRead : ${isAutoReadEnabled(ctx.db) ? '🟢 ON' : '🔴 OFF'} (blue tick pesan live)`)
                        const rsw = getReactConfig(ctx.db)
                        lines.push(`AutoReactSW : ${rsw.enabled ? '🟢 ON' : '🔴 OFF'}${rsw.emoji ? ` (${rsw.emoji})` : ' (emoji acak)'}`)
                        const rs = getStatusReactorStats()
                        if (rs) lines.push(`  react terkirim: ${rs.sent}, gagal: ${rs.errors}, drop queue: ${rs.dropped}`)
                        lines.push('')

                        lines.push('*Economy*')
                        if (ctx.worldBank) {
                                const st = ctx.worldBank.getStatus()
                                const wb = ctx.worldBank.get()
                                lines.push(`World Bank: ${st.status} (${st.pct}%) — ${formatCoin(Number(wb?.balance) || 0)} coin`)
                        }
                }

                lines.push('*Subsystems*')
                for (const [name, st] of Object.entries(health.snapshot())) {
                        const mark = st.status === 'HEALTHY' ? '✅' : st.status === 'DEGRADED' ? '⚠️' : '❌'
                        lines.push(`${mark} ${name}: ${st.status}${st.detail ? ` — ${st.detail}` : ''}`)
                }

                if (!full) {
                        lines.push('')
                        lines.push(`Butuh detail? Owner pakai ${pfx}status full`)
                }

                await ctx.reply(lines.join('\n'))
                logger.debug(`${_pfx}status dipakai (full=%s)`, full)
        },
}
