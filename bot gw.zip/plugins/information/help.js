import config from '../../config/index.js'
import logger from '../../lib/core/logger.js'
import { normalizeUsage } from '../../lib/command/cmd-ref.js'
import { getMenuStyle, sendMenuByStyle } from '../../lib/messaging/menu-style.js'
import { isSendUncertain } from '../../lib/messaging/send-fence.js'
import { findMatches } from '../../lib/command/fuzzy.js'
import { checkAdmin } from '../../lib/protection/permissions.js'

/**
 * Plugin .menu — Task 39.
 *
 * Task 38: menu no-args dikirim via vendor mbuilder (class Button, native
 * flow "mixed") — pola yang dirender benar klien WA modern.
 * Task 39: UI menu kini DIATUR GLOBAL lewat .setmenu (owner) dengan 9 style
 * (list / reply / mixed / mixed_url / image_list / button_card /
 * button_card_lama / NESTED battle-menu / teks) — lihat lib/menu-style.js.
 * FONT BIASA: smallcaps unicode dihapus seluruhnya (permintaan owner);
 * emoji & simbol umum tetap.
 *
 * Fallback berlapis tetap ada: style interaktif gagal → sendInteractive
 * gaya lama (starcore) → teks menu penuh. Style 9 langsung teks.
 */

/**
 * Group plugins by category, filter owner-only / admin-only if needed.
 * Audit fase-2:
 *   - kategori 'hidden' (internal helper yg dipicu tombol, mis. fontdl) tidak
 *     pernah masuk menu — bukan command yang dicari user.
 *   - badge 💎 utk command premium (minRole premium/vip/co-owner) supaya
 *     user tahu command mana bagian nilai Premium sebelum mencoba.
 * Major improvement: command admin grup (plugin.admin) kini HIDDEN bagi
 * pengguna biasa (bukan owner & bukan admin grup chat ini) — sebelumnya
 * hanya diberi badge 👮 tapi tetap terlihat. Permission tetap dijalankan
 * oleh handler (checkAdmin TTL cache) — menu hanya menyembunyikan entri.
 * @param {Map} registry
 * @param {boolean} isOwner
 * @param {boolean} [isAdmin] - admin grup chat invokasi (diabaikan bila owner)
 * @returns {Map<string, Array>}
 */
function buildGroups(registry, isOwner, isAdmin = false) {
        const groups = new Map()

        for (const [, plugin] of registry) {
                if (plugin.owner && !isOwner) continue
                if (plugin.admin && !isOwner && !isAdmin) continue

                const cat = (plugin.category || 'other').toLowerCase()
                if (cat === 'hidden') continue

                if (!groups.has(cat)) {
                        groups.set(cat, [])
                }

                groups.get(cat).push(plugin)
        }

        for (const list of groups.values()) {
                list.sort((a, b) => a.name.localeCompare(b.name))
        }

        return groups
}

/** Badge akses sebuah plugin (dipakai semua format listing menu). */
function accessBadges(plugin) {
        const badges = []
        if (plugin.owner) badges.push('🔒')
        if (plugin.admin) badges.push('👮')
        if (plugin.group) badges.push('💬')
        if (plugin.minRole && ['premium', 'vip', 'co-owner'].includes(plugin.minRole)) badges.push('💎')
        return badges.join('')
}

/**
 * Format full text menu — all categories, all commands.
 */
function formatAllMenu(groups, categories, total, pfx) {
        const lines = [
                `*${config.botName}*`,
                `Prefix: \`${pfx || '(none)'}\` [${pfx ? 'ON' : 'OFF'}]`,
                `Total Fitur: *${total}*`,
                ''
        ]

        for (const cat of categories) {
                lines.push(`═══ *${cat.toUpperCase()}*`)

                for (const plugin of groups.get(cat)) {
                        const trigger = pfx + (plugin.aliases?.[0] || plugin.name)
                        const badge = accessBadges(plugin)
                        const badgeStr = badge ? ` ${badge}` : ''

                        lines.push(`  • ${trigger}${badgeStr}`)
                        lines.push(`    ${plugin.description || 'No description.'}`)
                }

                lines.push('')
        }

        // Legenda badge (audit fase-2 — 💎 premium) di menu teks penuh juga,
        // bukan hanya footer dropdown interaktif.
        lines.push('🔒 Khusus owner · 👮 Admin grup · 💬 Khusus grup · 💎 Premium/VIP')

        return lines.join('\n').trimEnd()
}

/**
 * Format single category menu.
 */
function formatCategory(cat, list, pfx) {
        const lines = [`═══ *${cat.toUpperCase()}*`]

        for (const plugin of list) {
                const trigger = pfx + (plugin.aliases?.[0] || plugin.name)
                const badge = accessBadges(plugin)
                const badgeStr = badge ? ` ${badge}` : ''

                lines.push(`  • ${trigger}${badgeStr}`)
                lines.push(`    ${plugin.description || 'No description.'}`)
                // Task 32 §5: usage kini HIDUP — dinormalisasi ke prefix aktif
                const usage = normalizeUsage(plugin.usage, pfx)
                if (usage) lines.push(`    ⇝ ${usage}`)
        }

        return lines.join('\n')
}

/**
 * Format "category not found" message.
 * Major improvement: saran typo command — pakai findMatches (lib/fuzzy.js
 * resmi, sama dengan koreksi handler) atas SEMUA command yang boleh
 * dilihat user; kandidat diurutkan skor. Hanya aktif bila query cukup
 * panjang (≥3 char) supaya query 1-2 huruf tidak menghasilkan noise.
 */
function formatNotFound(query, categories, pfx, suggestions = []) {
        const lines = [
                `Kategori/command *${query}* tidak ditemukan.`,
                ''
        ]

        if (suggestions.length) {
                lines.push('*Mungkin yang kamu maksud:*')
                for (const s of suggestions) {
                        lines.push(`  • ${pfx}${s}`)
                }
                lines.push('')
        }

        lines.push('*Kategori yang tersedia:*', '')

        for (const cat of categories) {
                lines.push(`  • ${cat}`)
        }

        lines.push(
                '',
                `Ketik *${pfx}menu <kategori>* untuk melihat isi kategori.`,
                `Ketik *${pfx}menu <command>* untuk detail 1 command.`
        )

        return lines.join('\n')
}

/**
 * Task 32 §5 — Detail SATU command: description, usage (dinamis prefix),
 * aliases, permission, cooldown/limit. Dulu usage dead metadata.
 * Major improvement: contoh pemakaian (field plugin.example) kini ikut
 * ditampilkan bila plugin mendefinisikannya — contoh ditulis prefix-aktif.
 */
function formatCommandDetail(plugin, pfx) {
        const lines = [`*${pfx}${plugin.name}*`]
        if (plugin.description) lines.push(plugin.description)
        lines.push('')

        const usage = normalizeUsage(plugin.usage, pfx)
        if (usage) lines.push(`*Usage:* ${usage}`)

        const examples = (Array.isArray(plugin.example) ? plugin.example : (plugin.example ? [plugin.example] : []))
                .map(ex => normalizeUsage(String(ex), pfx))
                .filter(Boolean)
        if (examples.length) {
                lines.push('*Contoh:*')
                for (const ex of examples) lines.push(`  • ${ex}`)
        }

        const aliases = (plugin.aliases || []).map(a => `${pfx}${a}`)
        if (aliases.length) lines.push(`*Alias:* ${aliases.join(', ')}`)

        const perms = []
        if (plugin.owner) perms.push('owner')
        if (plugin.admin) perms.push(plugin.adminPm ? 'admin (PM boleh)' : 'admin grup')
        if (plugin.botAdmin) perms.push('bot admin')
        if (plugin.group) perms.push('grup saja')
        if (plugin.private) perms.push('PM saja')
        if (plugin.register) perms.push('terdaftar')
        if (plugin.minRole) perms.push(`role ≥ ${plugin.minRole}`)
        if (plugin.nsfw) perms.push('nsfw (cek setting grup)')
        lines.push(`*Akses:* ${perms.length ? perms.join(', ') : 'semua user'}`)

        const extras = []
        if (plugin.cooldownMs) extras.push(`cooldown ${Math.round(plugin.cooldownMs / 1000)}s`)
        if (plugin.limit) extras.push('quota harian')
        if (extras.length) lines.push(`*Batasan:* ${extras.join(', ')}`)

        lines.push('', `Kategori: ${plugin.category || 'other'}`)
        return lines.join('\n')
}

/**
 * Build dropdown body text.
 */
function formatDropdownBody(pfx, total) {
        const lines = [
                `☘️ Welcome to *${config.botName}*`,
                '',
                `Prefix: \`${pfx || '(none)'}\` [${pfx ? 'ON' : 'OFF'}]`,
                `Total Fitur: *${total}*`,
                '',
                'Pilih kategori dari dropdown di bawah:'
        ]

        return lines.join('\n')
}

/**
 * Build dropdown footer text.
 */
function formatDropdownFooter(total) {
        return (
                `╼  *Info Bot*\n` +
                `╭╼━┈━━━┈━━━⏬╼\n` +
                `▆ Bot Name : *${config.botName}*\n` +
                `▆ Total Fitur : *${total}*\n` +
                `╰━╼━┈━━━┈━━━┈\n\n` +
                `╼  *Catatan*\n` +
                `╭╼━┈━━━┈━━━⏬╼\n` +
                `▆ 🔒 = Khusus owner\n` +
                `▆ 👮 = Butuh admin grup\n` +
                `▆ 💬 = Khusus grup\n` +
                `▆ 💎 = Premium/VIP\n` +
                `╰━╼━┈━━━┈━━━┈`
        )
}

/**
 * Build the sections/rows for the fallback dropdown (sendInteractive gaya
 * lama). Task 39: font biasa.
 */
function buildDropdownButtons(categories, pfx) {
        const splitIndex = 2
        const firstCats = categories.slice(0, splitIndex)
        const restCats = categories.slice(splitIndex)

        const mainRows = [
                {
                        title: 'Semua menu',
                        description: `➜ ${config.botName}`,
                        id: `${pfx}menu all`
                }
        ]

        for (const cat of firstCats) {
                mainRows.push({
                        title: `Menu ${cat}`,
                        description: `➜ ${config.botName}`,
                        id: `${pfx}menu ${cat}`
                })
        }

        const sections = [
                {
                        title: 'Menu utama',
                        rows: mainRows
                }
        ]

        if (restCats.length > 0) {
                sections.push({
                        title: 'Kategori lainnya',
                        rows: restCats.map(cat => ({
                                title: `Menu ${cat}`,
                                description: `➜ ${config.botName}`,
                                id: `${pfx}menu ${cat}`
                        }))
                })
        }

        return [
                {
                        text: '📋 List Menu',
                        sections
                }
        ]
}

/**
 * Format daftar kategori (dipakai .menucat tanpa argumen).
 */
function formatCategoryList(categories, pfx) {
        const lines = ['*Kategori tersedia:*', '']
        for (const cat of categories) {
                lines.push(`  • ${cat}`)
        }
        lines.push('', `Ketik *${pfx}menu <kategori>* atau buka *${pfx}menu* dan pilih dari tombol.`)
        return lines.join('\n')
}

export default {
        name: 'menu',
        aliases: ['help', 'allmenu', 'menucat'],
        description: 'Tampilkan daftar command',
        category: 'information',
        usage: '.menu / .menu <kategori> / .menu all / .allmenu',
        register: false, // Task 36: discovery — browse menu tanpa akun

        async execute(ctx) {
                const { pluginLoader, sock } = ctx

                // PATCH BUTTON-PREFIX (fase-9, paritas stickerly fase-8): prefix
                // EFEKTIF chat invokasi (ctx.prefix = parsed.usedPrefix) — row id
                // tombol menu ("${pfx}menu <cat>" dsb.) harus hidup di grup
                // ber-prefix sendiri. prefixManager.get() mengabaikan argumen
                // chat → selalu GLOBAL → tombol menu mati di grup ber-prefix
                // sendiri. Parser/PrefixManager/global prefix tidak diubah.
                const pfx = ctx.prefix ?? ''

                // Major improvement: admin grup chat ini? (checkAdmin lib resmi,
                // TTL cache — murah). Owner otomatis lolos filter admin.
                const isAdmin = ctx.isOwner
                        || await checkAdmin(sock, ctx.chat, ctx.sender).catch(() => false)

                const groups = buildGroups(
                        pluginLoader.registry,
                        ctx.isOwner,
                        isAdmin
                )

                const categories = [...groups.keys()].sort()
                const total = [...groups.values()].flat().length
                const q = String(ctx.text || '').trim()

                // --- menu all / .allmenu: tampilkan semua command ---
                if (q.toLowerCase() === 'all' || ctx.rawCommand === 'allmenu') {
                        const text = formatAllMenu(groups, categories, total, pfx)
                        return ctx.reply(text)
                }

                // --- .menucat tanpa argumen → daftar kategori ---
                if (ctx.rawCommand === 'menucat' && !q) {
                        return ctx.reply(formatCategoryList(categories, pfx))
                }

                // --- menu <category>: tampilkan command per kategori ---
                if (q) {
                        const query = q.toLowerCase()
                        const list = groups.get(query)

                        if (!list) {
                                // Task 32 §5: query = nama/alias command → detail command
                                const all = [...groups.values()].flat()
                                const cmd = all.find(p => p.name === query || (p.aliases || []).includes(query))
                                if (cmd) {
                                        if (cmd.owner && !ctx.isOwner) {
                                                // owner command tetap dirahasiakan dari user biasa
                                                return ctx.reply(formatNotFound(query, categories, pfx))
                                        }
                                        return ctx.reply(formatCommandDetail(cmd, pfx))
                                }

                                // Major improvement: saran typo — findMatches (lib/fuzzy
                                // resmi) atas SEMUA command/alias yang boleh dilihat user
                                // (owner+admin command sudah tersaring oleh buildGroups).
                                // Threshold 0.45 + query ≥3 char → saran relevan saja.
                                let suggestions = []
                                if (query.length >= 3) {
                                        const names = []
                                        for (const p of all) {
                                                names.push(p.name)
                                                for (const a of (p.aliases || [])) names.push(a)
                                        }
                                        suggestions = findMatches(query, names, { threshold: 0.45, limit: 3 })
                                                .map(m => m.match)
                                }

                                // Admin command yang disembunyikan dari user biasa
                                // TIDAK ikut disarankan (sudah tidak ada di `names`).
                                return ctx.reply(
                                        formatNotFound(query, categories, pfx, suggestions)
                                )
                        }

                        return ctx.reply(
                                formatCategory(query, list, pfx)
                        )
                }

                // --- menu (no args): INTERACTIVE sesuai style global (.setmenu) ---
                // Style 1..8 via lib/menu-style.js (vendor mbuilder), style 9 =
                // teks. Fallback berlapis: style → sendInteractive gaya lama →
                // teks menu penuh — menu TIDAK PERNAH gagal terkirim.
                const caption = formatDropdownBody(pfx, total)
                const footer = formatDropdownFooter(total)
                const style = getMenuStyle(ctx.db)

                if (style !== 9) {
                        try {
                                await sendMenuByStyle({
                                        style,
                                        sock,
                                        chat: ctx.chat,
                                        caption,
                                        footer,
                                        categories,
                                        groups,
                                        total,
                                        pfx,
                                        quoted: ctx.message,
                                })
                                return
                        } catch (err) {
                                // TASK 23 (double message): kirim menu "tidak pasti"
                                // (timeout — menu MUNGKIN sudah tampil) → BERHENTI di sini.
                                // Melanjutkan ke fallback sendInteractive/teks = menu yang
                                // sama tampil 2x dengan jeda. Gagal PASTI → fallback tetap.
                                if (isSendUncertain(err)) {
                                        logger.warn('.menu: kirim menu tidak pasti (uncertain) — stop fallback (anti duplikat, chat=%s)', ctx.chat)
                                        return
                                }
                                logger.debug('menu style %s gagal → fallback sendInteractive: %s', style, err.message)
                        }

                        try {
                                await sock.sendInteractive(
                                        ctx.chat,
                                        buildDropdownButtons(categories, pfx),
                                        ctx.message,
                                        {
                                                caption,
                                                footer
                                        }
                                )
                                return
                        } catch (err) {
                                if (isSendUncertain(err)) {
                                        logger.warn('.menu: sendInteractive tidak pasti (uncertain) — stop fallback teks (anti duplikat, chat=%s)', ctx.chat)
                                        return
                                }
                                logger.debug(
                                        'sendInteractive gagal, fallback ke text menu: %s',
                                        err.message
                                )
                        }
                }

                const text = formatAllMenu(groups, categories, total, pfx)
                await ctx.reply(text)
        }
}
