// Badge role untuk tampilan profil (konsisten dengan ROLE_HIERARCHY di role-repository)
import { progressBar, expToNext } from '../../lib/economy/leveling.js'
import { regenEnergy } from '../../lib/economy/energy.js'
import { economy as economyConfig } from '../../lib/economy/economy.js'
import { findJob } from '../../lib/economy/jobs.js'
import { formatCoin } from '../../lib/economy/economy.js'
import { progressionOf } from '../../database/user-progression.js'

const ROLE_BADGE = {
        banned: '⛔',
        free: '👤',
        premium: '💎',
        vip: '🌟',
        'co-owner': '🛡️',
        owner: '👑',
}

const fmtNum = (n) => Number(n || 0).toLocaleString('id-ID')

export default {
        name: 'profile',
        aliases: ['me'],
        description: 'Lihat profil & role kamu atau orang lain (max 5)',
        category: 'information',
        usage: '.profile | .profile @tag1 @tag2 | .profile 628xxx 628xxx',
        register: true,

        async execute(ctx) {
                const { args, mentionedJid, resolver, userRepo, sock, message, roleRepo, activity } = ctx
                
                let targets = []
                let rawInput = args.join(' ').trim()

                // Kumpulkan semua mention dari berbagai sumber
                let allMentions = []
                
                // Dari Starcore mentionedJid (biasanya PN)
                if (mentionedJid && mentionedJid.length > 0) {
                        allMentions.push(...mentionedJid)
                }
                
                // Dari contextInfo (biasanya LID)
                const contextInfo = message?.message?.extendedTextMessage?.contextInfo
                if (contextInfo?.mentionedJid) {
                        allMentions.push(...contextInfo.mentionedJid)
                }
                
                // Dari message contextInfo langsung
                if (message?.contextInfo?.mentionedJid) {
                        allMentions.push(...message.contextInfo.mentionedJid)
                }

                // Hapus duplikat JID
                const uniqueMentions = [...new Set(allMentions)]

                if (uniqueMentions.length > 0) {
                        // Proses SEMUA mention (tanpa slice dulu)
                        const results = await Promise.all(
                                uniqueMentions.map(async (targetJid) => {
                                        const user = await this._findUser(ctx, targetJid)
                                        return { targetJid, user }
                                })
                        )

                        // Debug
                        console.log('=== RESULTS ===')
                        results.forEach((r, i) => {
                                console.log(`${i}: ${r.targetJid} -> ${r.user?.username || 'NOT FOUND'}`)
                        })

                        // Filter + deduplikasi berdasarkan user_id
                        const seenUserIds = new Set()
                        
                        for (const { targetJid, user } of results) {
                                if (user && !seenUserIds.has(user.user_id)) {
                                        seenUserIds.add(user.user_id)
                                        targets.push({ targetJid, user })
                                }
                        }
                }
                else if (rawInput) {
                        const nums = rawInput.split(/\s+/).filter(Boolean)
                        
                        const results = await Promise.all(
                                nums.map(async (rawNum) => {
                                        let num = rawNum.replace(/[^0-9]/g, '')
                                        if (!num) return null
                                        if (num.startsWith('0')) num = '62' + num.slice(1)
                                        const targetJid = num + '@s.whatsapp.net'
                                        const user = await this._findUser(ctx, targetJid)
                                        return { targetJid, user }
                                })
                        )

                        const seenUserIds = new Set()
                        
                        for (const result of results) {
                                if (result?.user && !seenUserIds.has(result.user.user_id)) {
                                        seenUserIds.add(result.user.user_id)
                                        targets.push({ targetJid: result.targetJid, user: result.user })
                                }
                        }
                }
                else {
                        if (!ctx.user) return ctx.reply('Kamu belum terdaftar.')
                        targets.push({ targetJid: ctx.sender, user: ctx.user })
                }

                // Batasi max 5 SETELAH deduplikasi
                targets = targets.slice(0, 5)

                if (targets.length === 0) {
                        return ctx.reply('❌ Tidak ada user yang ditemukan atau belum terdaftar.')
                }

                const profileCards = targets.map((t, index) => {
                        const u = t.user
                        const regDate = u.registered_at
                                ? new Date(u.registered_at).toLocaleDateString('id-ID', {
                                        day: 'numeric', month: 'long', year: 'numeric'
                                })
                                : '-'

                        return (
                                `┏━━ ⊑ *PROFILE ${targets.length > 1 ? `#${index + 1}` : ''}* ⊒\n` +
                                `┃\n` +
                                `┃ ⤷ *Nama* : ${u.username}\n` +
                                `┃ ⤷ *Umur* : ${u.age} tahun\n` +
                                `┃ ⤷ *Player ID* : ${u.player_id}\n` +
                                `┃ ⤷ *User ID* : ${u.user_id}\n` +
                                this._formatRoleLine(roleRepo, u) +
                                `┃ ⤷ *Terdaftar* : ${regDate}\n` +
                                this._economyLines({ user: u, economy: ctx.economy, activity, jid: t.targetJid, chat: ctx.chat, isGroup: ctx.isGroup }) +
                                this._activityLines({ activity, user: u, jid: t.targetJid, chat: ctx.chat, isGroup: ctx.isGroup }) +
                                `┃\n` +
                                `╰───────────────`
                        )
                })

                await ctx.reply(profileCards.join('\n\n'))
        },

        /**
         * Baris ECONOMY: money/energy/job/job rank (spec Task 26 §21-22).
         * Best-effort — economy store tidak ada → hanya money & energy.
         * @returns {string} baris siap sambung (terakhir berakhir \n) atau ''
         */
        _economyLines({ user, economy, activity, jid, chat, isGroup }) {
                if (!user) return ''
                try {
                        const lines = []
                        const wallet = Number(user.wallet) || 0
                        const bank = Number(user.bank) || 0
                        const regened = regenEnergy(user)

                        lines.push(`┃ ⤷ *Money* : ${formatCoin(wallet + bank)} coin (wallet ${formatCoin(wallet)} • bank ${formatCoin(bank)})\n`)
                        lines.push(`┃ ⤷ *Energy* : ${regened.energy}/${economyConfig.energy.max}\n`)

                        if (economy && jid) {
                                const st = economy.getJob(jid)
                                if (st?.current) {
                                        const meta = findJob(st.current)
                                        lines.push(`┃ ⤷ *Job* : ${meta ? `${meta.emoji} ${meta.name}` : st.current} Lv. ${st.level} • ${st.exp}/${st.expNeeded} EXP\n`)
                                        if (activity) {
                                                const scope = isGroup ? { type: 'group', jid: chat } : { type: 'global' }
                                                const rk = activity.rankOf({ userJid: jid, category: 'job', scope })
                                                if (rk?.rank) lines.push(`┃ ⤷ *Job Rank* : #${rk.rank}\n`)
                                        }
                                } else {
                                        lines.push(`┃ ⤷ *Job* : Belum dipilih\n`)
                                }
                        }
                        return lines.join('')
                } catch {
                        return ''
                }
        },

        /**
         * Baris Level/EXP/Chat/Command/Rank utk kartu profil (dari ActivityStore).
         * Best-effort: activity tidak ada / user belum punya data → default level 1.
         * @returns {string} baris siap sambung (terakhir berakhir \n) atau ''
         */
        _activityLines({ activity, user, jid, chat, isGroup }) {
                if (!activity || !jid) return ''
                try {
                        const st = activity.getUser(jid)
                        // TASK 23: progression (level/EXP/streak) → USER DB (baris
                        // user) — activity hanya analytics (chat/cmd).
                        const prog = progressionOf(user)
                        const level = prog.level
                        const need = expToNext(level)
                        const cur = prog.exp
                        const pct = need > 0 ? Math.min(100, Math.round((cur / need) * 100)) : 0
                        const bar = progressBar(pct, 8)

                        const lines = [
                                `┃ ⤷ *Level* : ${level} • ${fmtNum(cur)}/${fmtNum(need)} EXP (${pct}%)\n`,
                                `┃    ${bar}\n`,
                                `┃ ⤷ *Chat* : ${fmtNum(st?.chat)}${isGroup ? ` (grup ini: ${fmtNum(activity.getGroupUser(chat, jid)?.chat)})` : ''}\n`,
                                `┃ ⤷ *Command* : ${fmtNum(st?.cmdTotal)}x${prog.streak.count ? ` • 🔥 Streak ${prog.streak.count} hari` : ''}\n`,
                        ]

                        // Rank sesuai scope yang sedang dilihat (grup saat di grup, global saat PM)
                        const scope = isGroup ? { type: 'group', jid: chat } : { type: 'global' }
                        const scopeTag = isGroup ? 'grup' : 'global'
                        const rk = (cat) => {
                                const r = activity.rankOf({ userJid: jid, category: cat, scope })
                                return r.rank ? `#${r.rank}` : null
                        }
                        const rankLv = rk('level')
                        const rankChat = rk('chat')
                        const rankMoney = rk('money')
                        if (rankLv || rankChat || rankMoney) {
                                const parts = []
                                if (rankLv) parts.push(`Level ${rankLv}`)
                                if (rankChat) parts.push(`Chat ${rankChat}`)
                                if (rankMoney) parts.push(`Coin ${rankMoney}`)
                                lines.push(`┃ ⤷ *Rank ${scopeTag}* : ${parts.join(' • ')}\n`)
                        }
                        return lines.join('')
                } catch {
                        return ''
                }
        },

        /**
         * Format baris Role untuk kartu profil.
         * Selalu lewat roleRepo.getRole() (bukan baca user.role mentah) supaya
         * expirasi role tetap dicek + lazy cleanup jalan sama seperti di handler.
         * Lookup via user_id → resolve langsung ke profil, bebas masalah PN/LID.
         */
        _formatRoleLine(roleRepo, user) {
                if (!roleRepo || !user?.user_id) return ''

                const data = roleRepo.getRole(user.user_id)
                const badge = ROLE_BADGE[data.role] || '👤'

                // found=false → tidak ada entry role (profil free / belum pernah di-set)
                if (!data.found || data.role === 'free') {
                        return `┃ ⤷ *Role* : ${badge} Free\n`
                }

                let status = 'permanen'
                if (data.expires_at) {
                        const until = new Date(data.expires_at).toLocaleDateString('id-ID', {
                                day: 'numeric', month: 'long', year: 'numeric',
                                hour: '2-digit', minute: '2-digit'
                        })
                        status = `s/d ${until}`
                }

                const label = data.role.charAt(0).toUpperCase() + data.role.slice(1)
                return `┃ ⤷ *Role* : ${badge} ${label} (${status})\n`
        },

        async _findUser(ctx, targetJid) {
                const { resolver, userRepo, sock } = ctx
                
                try {
                        // Phase 1: resolve identifier via resolver KANONIK
                        // (pn/lid — termasuk vendor fallback), lalu cari profil
                        // lewat rantai kanonik findByIdentifier.
                        const resolved = await resolver.resolveUser(targetJid)
                        const pn = resolved.pn || targetJid
                        const lid = resolved.lid || null

                        return userRepo.findByIdentifier(pn)
                                || (lid ? userRepo.findByIdentifier(lid) : null)
                                || userRepo.findByIdentifier(targetJid)
                } catch (error) {
                        return userRepo?.findByIdentifier?.(targetJid)
                                || userRepo.findByJID(targetJid)
                                || userRepo.findByPN(targetJid)
                }
        }
}