import axios from 'axios'
import logger from '../../lib/core/logger.js'

/** Timeout API (ms). */
const API_TIMEOUT_MS = 30_000

/**
 * Check domain security via API kyzzz.xyz
 */
async function checkDomainSecurity(domain) {
    try {
        const apiKey = process.env.KYZZZ_API_KEY || ''
        const res = await axios.get(
            `https://api.kyzzz.xyz/api/tools/domain-security?domain=${encodeURIComponent(domain)}&apikey=${apiKey}`,
            { timeout: API_TIMEOUT_MS }
        )
        return res.data
    } catch (e) {
        logger.error('[domainsecurity] API error:', e)
        return null
    }
}

/**
 * Format skor dengan progress bar.
 */
function formatScoreBar(score, maxScore) {
    const percentage = maxScore > 0 ? (score / maxScore) * 100 : 0
    const barLength = 10
    const filled = Math.round((percentage / 100) * barLength)
    const empty = barLength - filled
    
    let emoji = '🔴'
    if (percentage >= 80) emoji = '🟢'
    else if (percentage >= 50) emoji = '🟡'
    else if (percentage >= 30) emoji = '🟠'
    
    return `${emoji} ${'█'.repeat(filled)}${'░'.repeat(empty)} ${score}/${maxScore} (${percentage.toFixed(1)}%)`
}

/**
 * Format DNS Security section.
 */
function formatDnsSecurity(dnsSecurity) {
    const lines = []
    lines.push(`\n━━━ *🔒 DNS SECURITY* ━━━`)
    lines.push(formatScoreBar(dnsSecurity.score, dnsSecurity.maxScore))
    
    for (const detail of dnsSecurity.details || []) {
        const icon = detail.passed ? '✅' : '❌'
        lines.push(`\n${icon} *${detail.check}* (+${detail.points} pts)`)
        if (detail.info) {
            lines.push(`   ℹ️ ${detail.info}`)
        }
    }
    
    return lines.join('\n')
}

/**
 * Format Exposed Artifacts section.
 */
function formatExposedArtifacts(exposedArtifacts) {
    const lines = []
    lines.push(`\n━━━ *🔓 EXPOSED ARTIFACTS* ━━━`)
    lines.push(formatScoreBar(exposedArtifacts.score, exposedArtifacts.maxScore))
    
    for (const detail of exposedArtifacts.details || []) {
        const icon = detail.exposed ? '⚠️' : '✅'
        const status = detail.exposed ? 'TERBUKA' : 'Aman'
        lines.push(`\n${icon} *${detail.path}* → ${status}`)
    }
    
    return lines.join('\n')
}

/**
 * Format Domain Trust section.
 */
function formatDomainTrust(domainTrust) {
    const lines = []
    lines.push(`\n━━━ *🌐 DOMAIN TRUST* ━━━`)
    lines.push(formatScoreBar(domainTrust.score, domainTrust.maxScore))
    
    for (const detail of domainTrust.details || []) {
        const icon = detail.passed ? '✅' : '❌'
        
        if (detail.check === 'HTTP Security Headers Audit') {
            lines.push(`\n${icon} *${detail.check}* (${detail.passed ? 'Passed' : 'Failed'})`)
            
            if (detail.headers) {
                lines.push(`   ┌─ *HSTS:* ${detail.headers.strictTransportSecurity || 'N/A'}`)
                lines.push(`   ├─ *CSP:* ${detail.headers.contentSecurityPolicy || 'N/A'}`)
                lines.push(`   ├─ *X-Frame:* ${detail.headers.xFrameOptions || 'N/A'}`)
                lines.push(`   ├─ *X-Content-Type:* ${detail.headers.xContentTypeOptions || 'N/A'}`)
                lines.push(`   ├─ *X-XSS:* ${detail.headers.xXssProtection || 'N/A'}`)
                lines.push(`   ├─ *Referrer:* ${detail.headers.referrerPolicy || 'N/A'}`)
                lines.push(`   ├─ *ACAO:* ${detail.headers.accessControlAllowOrigin || 'N/A'}`)
                lines.push(`   ├─ *Server:* ${detail.headers.serverBanner || 'N/A'}`)
                lines.push(`   └─ *X-Powered-By:* ${detail.headers.xPoweredBy || 'N/A'}`)
            }
        } else if (detail.check === 'XSS & Clickjacking Mitigation') {
            lines.push(`\n${icon} *${detail.check}*`)
            if (detail.info) {
                lines.push(`   ├─ *XSS:* ${detail.info.xssProtection || 'N/A'}`)
                lines.push(`   └─ *Clickjacking:* ${detail.info.clickjackingProtection || 'N/A'}`)
            }
        } else if (detail.check === 'A Record Resolution') {
            lines.push(`\n${icon} *${detail.check}* (+${detail.points} pts)`)
            if (Array.isArray(detail.info)) {
                lines.push(`   ℹ️ ${detail.info.join(', ')}`)
            }
        } else {
            lines.push(`\n${icon} *${detail.check}* (+${detail.points || 0} pts)`)
            if (detail.info) {
                lines.push(`   ℹ️ ${detail.info}`)
            }
        }
    }
    
    return lines.join('\n')
}

/**
 * Format response lengkap jadi teks WhatsApp.
 */
function formatSecurityReport(data) {
    const result = data.result || {}
    const scores = result.scores || {}
    
    // Hitung total skor
    const totalScore = Object.values(scores).reduce((sum, s) => sum + (s.score || 0), 0)
    const totalMax = Object.values(scores).reduce((sum, s) => sum + (s.maxScore || 0), 0)
    const totalPercentage = totalMax > 0 ? (totalScore / totalMax) * 100 : 0
    
    // Tentukan grade
    let grade = 'F'
    let gradeEmoji = '🔴'
    if (totalPercentage >= 90) { grade = 'A'; gradeEmoji = '🟢' }
    else if (totalPercentage >= 80) { grade = 'B'; gradeEmoji = '🟢' }
    else if (totalPercentage >= 70) { grade = 'C'; gradeEmoji = '🟡' }
    else if (totalPercentage >= 60) { grade = 'D'; gradeEmoji = '🟠' }
    
    const lines = [
        `🔒 *DOMAIN SECURITY REPORT*\n`,
        `━━━━━━━━━━━━━━━━━━`,
        `\n🌐 *Domain:* ${result.domain || 'Unknown'}`,
        `📅 *Waktu:* ${result.timestamp ? new Date(result.timestamp).toLocaleString('id-ID') : 'N/A'}`,
        `\n${gradeEmoji} *SKOR TOTAL:* ${totalScore}/${totalMax} (${totalPercentage.toFixed(1)}%)`,
        `🏆 *Grade:* ${grade}`,
    ]
    
    // Format masing-masing section
    if (scores.dnsSecurity) {
        lines.push(formatDnsSecurity(scores.dnsSecurity))
    }
    
    if (scores.exposedArtifacts) {
        lines.push(formatExposedArtifacts(scores.exposedArtifacts))
    }
    
    if (scores.domainTrust) {
        lines.push(formatDomainTrust(scores.domainTrust))
    }
    
    // Tambah rekomendasi
    lines.push(`\n━━━ *💡 REKOMENDASI* ━━━`)
    
    const recommendations = []
    
    if (scores.dnsSecurity) {
        const dns = scores.dnsSecurity.details || []
        const failedDns = dns.filter(d => !d.passed)
        if (failedDns.length) {
            recommendations.push(`• Perbaiki DNS record: ${failedDns.map(d => d.check).join(', ')}`)
        }
    }
    
    if (scores.exposedArtifacts) {
        const artifacts = scores.exposedArtifacts.details || []
        const exposed = artifacts.filter(a => a.exposed)
        if (exposed.length) {
            recommendations.push(`• ⚠️ SEGERA tutup akses file sensitif: ${exposed.map(a => a.path).join(', ')}`)
        }
    }
    
    if (scores.domainTrust) {
        const trust = scores.domainTrust.details || []
        const headersAudit = trust.find(d => d.check === 'HTTP Security Headers Audit')
        if (headersAudit && !headersAudit.passed) {
            recommendations.push(`• Tambahkan security headers (HSTS, CSP, dll)`)
        }
    }
    
    if (!recommendations.length) {
        recommendations.push(`• ✅ Domain sudah cukup aman!`)
    }
    
    lines.push(recommendations.join('\n'))
    
    return lines.join('\n')
}

export default {
    name: 'domainsecurity',
    aliases: ['domainsec', 'cekdomain', 'securitycheck'],
    description: 'Cek keamanan domain (DNS, artifacts, trust)',
    category: 'information',
    usage: '.domainsecurity <domain>',
    register: true,

    async execute(ctx) {
        const { sock, chat, message, args, prefix, command, reply } = ctx
        const input = args.join(' ').trim()
        
        if (!input) {
            return reply(
`🔒 *Domain Security Checker*

Cek keamanan domain lengkap.

📌 *Contoh:*
${prefix + command} google.com
${prefix + command} facebook.com

✨ *Fitur:*
- DNS Security (MX, SPF, DMARC, NS)
- Exposed Artifacts (.env, .git, dll)
- Domain Trust (HTTPS, headers, XSS)
- Skor total + grade
- Rekomendasi perbaikan`)
        }
        
        // Validasi domain sederhana
        if (!/^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(input)) {
            return reply('❌ Format domain tidak valid!\nContoh: google.com')
        }
        
        await sock.sendMessage(chat, { react: { text: '🔍', key: message.key } }).catch(() => {})
        
        try {
            const data = await checkDomainSecurity(input)
            
            if (!data?.status || !data?.result) {
                await sock.sendMessage(chat, { react: { text: '❌', key: message.key } }).catch(() => {})
                return reply('❌ Gagal menganalisis domain.')
            }
            
            const text = formatSecurityReport(data)
            
            // Kirim langsung satu pesan
            await sock.sendMessage(chat, { text }, { quoted: message })
            
            await sock.sendMessage(chat, { react: { text: '✅', key: message.key } }).catch(() => {})
            
        } catch (e) {
            logger.error('[domainsecurity] Error:', e)
            await sock.sendMessage(chat, { react: { text: '❌', key: message.key } }).catch(() => {})
            
            if (e.code === 'ECONNABORTED') {
                return reply('⏱️ Request timeout. Coba lagi.')
            }
            
            return reply(`❌ Error: ${e.message || 'Gagal menganalisis domain.'}`)
        }
    }
}