/**
 * .myid — JID pengirim sendiri, cepat & read-only (major improvement).
 *
 * Versi ringkas .jid khusus DIRI SENDIRI (tanpa resolusi target):
 *   • JID asli (ctx.sender) + bentuk LID bila tersedia (ctx.senderLid);
 *   • JID normalized + tipe (helper resmi lib/identity);
 *   • nama terdaftar di DB sendiri (ctx.user — profil yang sudah di-resolve
 *     dispatch bot.js) + push name sendiri (m.pushName / ctx.pushName).
 *
 * Read-only murni: tidak menulis DB, tidak network request, tidak resolver.
 * Konteks penggunaan: user butuh JID-nya untuk didaftarkan/di-tag admin —
 * tanpa harus memahami argumen .jid.
 */
import { normalizeJid, jidDigits, isLidJid, isPnJid } from '../../lib/identity/index.js'
import { sanitizeName } from '../../lib/features/names.js'

/** Klasifikasi tipe JID via helper resmi identity (paritas .jid/.whois). */
function classify(jid) {
        if (!jid) return 'Tidak tersedia'
        if (isLidJid(jid)) return 'LID (identitas internal WhatsApp)'
        if (isPnJid(jid)) return 'PN (@s.whatsapp.net)'
        return 'Tanpa domain (nomor polos)'
}

export default {
        name: 'myid',
        description: 'Lihat JID & identitas kamu sendiri (asli, normalized, tipe)',
        category: 'information',
        usage: '.myid',
        example: ['.myid'],
        register: false, // basic info — pola .jid/.ping (Task 36)

        async execute(ctx) {
                const { sender, senderLid, message, user } = ctx

                if (!sender) {
                        return ctx.reply('❌ JID pengirim tidak terbaca dari pesan ini.')
                }

                const normalized = normalizeJid(sender) || sender
                const dbName = sanitizeName(user?.username || user?.name || '')
                const pushName = sanitizeName(message?.pushName || ctx.pushName || '')

                const lines = [
                        '╭─❁ *MY ID* ❁',
                        `◦❒ *JID asli:* ${sender}`,
                ]
                if (senderLid && String(senderLid) !== String(sender)) {
                        lines.push(`◦❒ *LID:* ${senderLid}`)
                }
                lines.push(
                        `◦❒ *JID normalized:* ${normalized}`,
                        `◦❒ *Tipe:* ${classify(normalized)}`,
                        `◦❒ *Digits:* ${jidDigits(normalized) || '-'}`,
                        `◦❒ *Nama DB:* ${dbName || 'Tidak terdaftar'}`,
                        `◦❒ *Push Name WA:* ${pushName || 'Tidak tersedia'}`,
                        '╰─❁',
                )

                const mentions = isPnJid(normalized) ? [normalized] : []
                return ctx.reply(lines.join('\n'), { mentions })
        }
}
