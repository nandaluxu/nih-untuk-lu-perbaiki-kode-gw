import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import { isSafePluginPath } from '../../lib/core/validators.js'
import { findPluginsDir, resolvePluginFile } from '../../lib/command/plugin-loader.js'
import { AIRich } from '../../lib/messaging/MessageBuilderV4.7.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
// Location-agnostic (Task 30): benar baik file ini di plugins/ root
// maupun di plugins/owner/ — naik sampai ketemu folder "plugins".
const PLUGINS_DIR = findPluginsDir(__dirname) || path.join(__dirname, '..', 'plugins')

export default {
        name: 'checkplugin',
        description: 'Lihat source code plugin (cari otomatis walau file di subfolder)',
        category: 'owner',
        usage: '.checkplugin nama.js',
        owner: true,

        async execute(ctx) {
                const { sock, chat, message, args, prefix, reply } = ctx
                const filename = args[0]

                if (!filename) {
                        return reply(`Masukkan nama file. Contoh: ${prefix}checkplugin ping.js`)
                }

                if (!isSafePluginPath(filename)) {
                        return reply('Nama file tidak valid. Format: nama.js atau folder/nama.js')
                }

                // Task 30: file bisa di subfolder — "hunt.js" di-resolve ke
                // lokasi aslinya (registry → scan).
                const hits = resolvePluginFile(filename, PLUGINS_DIR, ctx.pluginLoader)
                if (hits.length === 0) {
                        return reply('Plugin tidak ditemukan.')
                }
                if (hits.length > 1) {
                        return reply(`Nama file ambigu (${hits.join(', ')}) — sebutkan foldernya, contoh: ${prefix}checkplugin ${hits[0]}`)
                }
                const target = hits[0]

                const targetPath = path.join(PLUGINS_DIR, target)
                const source = fs.readFileSync(targetPath, 'utf8')
                const stats = fs.statSync(targetPath)
                const fileSize = (stats.size / 1024).toFixed(2)
                const lineCount = source.split('\n').length

                if (!sock?.waUploadToServer) {
                        return reply(`*${target}*\n\n\`\`\`js\n${source}\n\`\`\``)
                }

                try {
                        const aiRich = new AIRich(sock)

                        aiRich.setTitle(`📄 Source Code Plugin`)

                        // Info file
                        aiRich.addText(
                                `📁 *File:* ${target}\n` +
                                `📏 *Baris:* ${lineCount}\n` +
                                `💾 *Ukuran:* ${fileSize} KB`
                        )

                        // Kode dengan syntax highlighting
                        aiRich.addCode('javascript', source)

                        // Kirim ke chat yang sama
                        await aiRich.send(chat, {
                                quoted: message || undefined
                        })

                } catch (error) {
                        console.error('[checkplugin] AIRich gagal:', error?.message || error)
                        await reply(`*${target}*\n\n\`\`\`js\n${source}\n\`\`\``)
                }
        }
}
