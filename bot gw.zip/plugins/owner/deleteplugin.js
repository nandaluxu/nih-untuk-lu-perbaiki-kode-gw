import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import { isSafePluginPath } from '../../lib/core/validators.js'
import { findPluginsDir, resolvePluginFile } from '../../lib/command/plugin-loader.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
// Location-agnostic (Task 30): benar baik file ini di plugins/ root
// maupun di plugins/owner/ — naik sampai ketemu folder "plugins".
const PLUGINS_DIR = findPluginsDir(__dirname) || path.join(__dirname, '..', 'plugins')

export default {
        name: 'deleteplugin',
        description: 'Hapus plugin (cari otomatis walau file di subfolder)',
        category: 'owner',
        usage: '.deleteplugin nama.js',
        owner: true,

        async execute(ctx) {
                        const _pfx = (typeof ctx !== 'undefined' && ctx?.prefix) || ''
                const filename = ctx.args[0]
                if (!filename) {
                        return ctx.reply(`Masukkan nama file. Contoh: ${_pfx}deleteplugin halo.js`)
                }

                if (!isSafePluginPath(filename)) {
                        return ctx.reply('Nama file tidak valid. Format: nama.js atau folder/nama.js')
                }

                // Task 30: file bisa di subfolder — "hunt.js" di-resolve ke
                // lokasi aslinya (registry → scan) sebelum dihapus.
                const hits = resolvePluginFile(filename, PLUGINS_DIR, ctx.pluginLoader)
                if (hits.length === 0) {
                        return ctx.reply('Plugin tidak ditemukan.')
                }
                if (hits.length > 1) {
                        return ctx.reply(`Nama file ambigu (${hits.join(', ')}) — sebutkan foldernya, contoh: ${_pfx}deleteplugin ${hits[0]}`)
                }
                const target = hits[0]

                const targetPath = path.join(PLUGINS_DIR, target)
                try {
                        fs.unlinkSync(targetPath)
                        ctx.reply(`Plugin *${target}* berhasil dihapus.`)
                } catch (error) {
                        ctx.reply(`Gagal menghapus: ${error.message}`)
                }
        }
}
