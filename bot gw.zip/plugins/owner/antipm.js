/**
 * .antipm — Anti Private Message (toggle global, owner only).
 *
 *   .antipm on      → PM dari user non-trusted langsung diblokir
 *   .antipm off     → matikan (bot menerima PM siapa saja)
 *   .antipm status  → status + daftar trust/blocked
 *
 * Engine & persist: lib/antipm.js (gate dipasang di bot.js).
 * Catatan: .block/.unblock jalan terlepas dari toggle ini (blokir WA-level).
 */
import {
    isAntipmOn,
    setAntipm,
    listTrusted,
    listBlockedRecords,
} from '../../lib/features/antipm.js'
import { fmtJid } from '../../lib/command/group-utils.js'

export default {
    name: 'antipm',
    description: 'Anti private message — blokir otomatis PM dari user yang tidak diizinkan',
    category: 'owner',
    usage: '.antipm on|off|status',
    owner: true,

    async execute(ctx) {
			const _pfx = (typeof ctx !== 'undefined' && ctx?.prefix) || ''
        const { args, reply, db, sender } = ctx
        const sub = String(args[0] || '').toLowerCase()

        if (!sub || sub === 'status') {
            const on = isAntipmOn(db)
            const trusted = listTrusted(db)
            const blocked = listBlockedRecords(db)
            let text =
                `🛡️ *Anti PM*\n\n` +
                `Status : *${on ? 'ON' : 'OFF'}*\n` +
                `PM dari user non-trusted akan ${on ? 'DIBLOKIR otomatis' : 'diterima normal'}.\n\n`

            text += `👤 *Trusted* (${trusted.length}):\n`
            text += trusted.length
                ? trusted.slice(0, 20).map((t) => `• ${fmtJid(t.jid || t.digits)}`).join('\n') + '\n'
                : '• (kosong)\n'

            text += `\n🚫 *Catatan blocked* (${blocked.length}):\n`
            text += blocked.length
                ? blocked
                      .slice(0, 20)
                      .map((b) => `• ${fmtJid(b.jid || b.digits)} (${b.source}${b.by ? `, oleh ${b.by}` : ''})`)
                      .join('\n')
                : '• (kosong)'

            text += `\n\n📌 Perintah:\n.antipm on/off\n.trust @tag|nomor\n.untrust @tag|nomor\n.block @tag|nomor\n.unblock @tag|nomor\n.blacklist`
            return reply(text)
        }

        if (sub === 'on' || sub === 'off') {
            const enabled = sub === 'on'
            const entry = setAntipm(db, enabled, sender)
            return reply(
                entry.enabled
                    ? '🛡️ *Anti PM: ON*\nPM dari user yang tidak di-trust akan diblokir otomatis.'
                    : '🛡️ *Anti PM: OFF*\nChat pribadi diterima normal.'
            )
        }

        return reply(`Pakai: *${_pfx}antipm on* / *${_pfx}antipm off* / *${_pfx}antipm status*`)
    },
}
