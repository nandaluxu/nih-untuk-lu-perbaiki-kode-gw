/**
 * .protection — config rate limit & anti-spam (Khusus OWNER).
 *
 * Dua lingkup:
 *   1. GLOBAL  → default semua chat. Persist di global_settings
 *                (protection_enabled, protection_overrides) — pola PrefixManager.
 *   2. CHAT    → override khusus chat/grup ini. Persist di
 *                settings[chat].protection — pola gcnsfw/adminOnly.
 *
 * Prinsip:
 *   - Nilai dibaca LIVE oleh ProtectionManager saat gate (hot-path tetap
 *     in-memory). Write ke store HANYA saat owner mengubah config, BUKAN
 *     per pesan — state rate-limit sendiri tetap tanpa database.
 *   - Concurrency sengaja global (state concurrent per user lintas chat,
 *     menyangkut integritas resource bot — tidak bisa dioverride per chat).
 */
import { parseDurationMs } from '../../lib/core/validators.js'
import { getSharedProtection } from '../../lib/protection/protection.js'

// ---- Definisi path config ----
// display : path yang diketik owner (mis. flood.max)
// target  : lokasi penyimpanan kanonik di objek config (mis. flood.maxCommands)
// kind    : 'int' | 'dur' (durasi: 30s/5m/2h, angka polos = ms) | 'bool' (on/off)
const PATHS = {
        'antispam':         { target: 'antispam.enabled',     kind: 'bool',                label: 'Anti-spam (flood + strike + penalty)' },
        'burst.capacity':  { target: 'burst.capacity',      kind: 'int', min: 1,   max: 100,       label: 'Kapasitas burst (token)' },
        'burst.refill':    { target: 'burst.refill',        kind: 'int', min: 1,   max: 100,       label: 'Refill burst (token)' },
        'burst.interval':  { target: 'burst.interval',      kind: 'dur', min: 250, max: 3_600_000, label: 'Interval refill burst' },
        'flood.window':    { target: 'flood.window',        kind: 'dur', min: 1_000, max: 3_600_000, label: 'Window spam req ke bot (command)' },
        'flood.max':       { target: 'flood.maxCommands',   kind: 'int', min: 2,   max: 500,       label: 'Max command per window (spam req)' },
        'flood.same':      { target: 'flood.maxSameCommand', kind: 'int', min: 2,  max: 500,       label: 'Max command sama per window' },
        'chatflood.window': { target: 'chatFlood.window',   kind: 'dur', min: 1_000, max: 3_600_000, label: 'Window spam chat (non-command)' },
        'chatflood.max':   { target: 'chatFlood.maxMessages', kind: 'int', min: 3, max: 500,       label: 'Max pesan chat per window (spam chat)' },
        'penalty.1':       { target: 'penalties[0]',        kind: 'dur', min: 1_000, max: 86_400_000, label: 'Penalty strike 1' },
        'penalty.2':       { target: 'penalties[1]',        kind: 'dur', min: 1_000, max: 86_400_000, label: 'Penalty strike 2' },
        'penalty.3':       { target: 'penalties[2]',        kind: 'dur', min: 1_000, max: 86_400_000, label: 'Penalty strike 3' },
        'penalty.4':       { target: 'penalties[3]',        kind: 'dur', min: 1_000, max: 86_400_000, label: 'Penalty strike 4+' },
        'penalty.cap':     { target: 'penaltyCap',          kind: 'dur', min: 1_000, max: 86_400_000, label: 'Penalty cap' },
        'strike.decay':    { target: 'strikeDecay',         kind: 'dur', min: 60_000, max: 86_400_000, label: 'Decay strike' },
        'ai.capacity':     { target: 'ai.capacity',         kind: 'int', min: 1,   max: 100,       label: 'Kapasitas AI (token)' },
        'ai.refill':       { target: 'ai.refill',           kind: 'int', min: 1,   max: 100,       label: 'Refill AI (token)' },
        'ai.interval':     { target: 'ai.interval',         kind: 'dur', min: 1_000, max: 3_600_000, label: 'Interval refill AI' },
        'ai.window':       { target: 'ai.window',           kind: 'dur', min: 1_000, max: 3_600_000, label: 'Window flood AI' },
        'ai.max':          { target: 'ai.maxRequests',      kind: 'int', min: 1,   max: 500,       label: 'Max request AI per window' },
        'feedback':        { target: 'feedbackCooldown',    kind: 'dur', min: 1_000, max: 3_600_000, label: 'Feedback suppression' },
        'concurrency':     { target: 'maxUserConcurrency',  kind: 'int', min: 1,   max: 50,        label: 'Max command paralel per user', globalOnly: true },
}

const KEY_ENABLED = 'protection_enabled'
const KEY_OVERRIDES = 'protection_overrides'

// ---- Helpers ----

function fmtMs(ms) {
        if (ms >= 3_600_000) {
                const h = ms / 3_600_000
                return `${Number.isInteger(h) ? h : h.toFixed(1)} jam`
        }
        if (ms >= 60_000) {
                const m = ms / 60_000
                return `${Number.isInteger(m) ? m : m.toFixed(1)} menit`
        }
        if (ms >= 1000) {
                const s = ms / 1000
                return `${Number.isInteger(s) ? s : s.toFixed(1)} detik`
        }
        return `${ms}ms`
}

function parseValue(spec, raw) {
        if (spec.kind === 'bool') {
                const v = String(raw || '').trim().toLowerCase()
                if (['on', 'true', '1', 'enable', 'enabled', 'aktif'].includes(v)) return { value: true }
                if (['off', 'false', '0', 'disable', 'disabled', 'mati'].includes(v)) return { value: false }
                return { error: 'Harus on/off.' }
        }
        if (spec.kind === 'int') {
                if (!/^\d+$/.test(String(raw).trim())) return { error: 'Harus angka bulat (contoh: 8).' }
                const n = parseInt(raw, 10)
                if (n < spec.min || n > spec.max) return { error: `Harus di rentang ${spec.min}-${spec.max}.` }
                return { value: n }
        }
        const ms = parseDurationMs(raw, { bareIsMs: true, min: spec.min, max: spec.max })
        if (ms === null) {
                return { error: `Format durasi tidak valid. Contoh: 30s, 5m, 2h (rentang ${fmtMs(spec.min)}-${fmtMs(spec.max)}).` }
        }
        return { value: ms }
}

/** Baca nilai di lokasi target kanonik ("burst.capacity" / "penalties[0]"). */
function getTarget(obj, target) {
        const m = target.match(/^(.+)\[(\d+)\]$/)
        if (m) {
                const arr = m[1].split('.').reduce((o, k) => (o && o[k] !== undefined ? o[k] : undefined), obj)
                return Array.isArray(arr) ? arr[parseInt(m[2], 10)] : undefined
        }
        return target.split('.').reduce((o, k) => (o && o[k] !== undefined ? o[k] : undefined), obj)
}

/** Set nilai di lokasi target kanonik (membuat objek perantara bila perlu). */
function setTarget(obj, target, value) {
        const m = target.match(/^(.+)\[(\d+)\]$/)
        if (m) {
                const path = m[1]
                const idx = parseInt(m[2], 10)
                const parts = path.split('.')
                let o = obj
                for (let i = 0; i < parts.length - 1; i++) {
                        if (typeof o[parts[i]] !== 'object' || o[parts[i]] === null) o[parts[i]] = {}
                        o = o[parts[i]]
                }
                const key = parts[parts.length - 1]
                if (!Array.isArray(o[key])) o[key] = []
                o[key][idx] = value
                return
        }
        const parts = target.split('.')
        let o = obj
        for (let i = 0; i < parts.length - 1; i++) {
                if (typeof o[parts[i]] !== 'object' || o[parts[i]] === null) o[parts[i]] = {}
                o = o[parts[i]]
        }
        o[parts[parts.length - 1]] = value
}

/** Ambil config chat (buat kalau belum ada) — pola gcnsfw. */
function getChatCfg(ctx) {
        if (!ctx.db.data.settings[ctx.chat]) ctx.db.data.settings[ctx.chat] = {}
        if (!ctx.db.data.settings[ctx.chat].protection) ctx.db.data.settings[ctx.chat].protection = {}
        return ctx.db.data.settings[ctx.chat].protection
}

function saveDb(ctx) {
        // Phase 2 storage (F-12): command ini memutasi settings (per-chat
        // protection) DAN global_settings (enabled/overrides) — tandai kedua
        // domain dirty; flush async atomic + debounce (coalescing menulis
        // ulang domain yang tidak berubah pun tetap aman/idempotent).
        ctx.db.writeDirty?.('settings', 'global_settings')
}

export default {
        name: 'protection',
        aliases: ['prot'],
        description: 'Config rate limit & anti-spam (global + per grup)',
        category: 'owner',
        usage: '.protection | on/off | antispam on/off | chat on/off/reset | set <path> <nilai> | global <path> <nilai> | global reset | paths',
        owner: true,

        async execute(ctx) {
                const protection = getSharedProtection()
                const args = ctx.args
                const sub = (args[0] || '').toLowerCase()

                // ---- .protection / .protection status ----
                if (!sub || sub === 'status') return this._status(ctx, protection)

                // ---- .protection paths ----
                if (sub === 'paths') {
                        return ctx.reply(
                                '*Path config protection:*\n' +
                                this._pathsText() +
                                '\n\nNilai durasi: `30s` / `5m` / `2h` (angka polos = ms), `antispam`: `on/off`.' +
                                '\nContoh: `.protection set burst.capacity 10` atau `.protection global penalty.1 30s`'
                        )
                }

                // ---- .protection on|off (GLOBAL toggle) ----
                if (sub === 'on' || sub === 'off') {
                        const enabled = sub === 'on'
                        protection.setEnabled(enabled)
                        ctx.db.data.global_settings[KEY_ENABLED] = enabled ? '1' : '0'
                        saveDb(ctx)
                        return ctx.reply(`Protection *GLOBAL*: *${enabled ? 'ON' : 'OFF'}* — berlaku untuk semua chat yang tidak punya override sendiri. Selamat restart.`)
                }

                // ---- .protection antispam on|off (GLOBAL toggle anti-spam) ----
                // Anti-spam = flood detection + strike + penalty (command & chat).
                // Rate limit (burst/policy/bucket AI) TETAP jalan saat antispam OFF.
                if (sub === 'antispam' || sub === 'spam') {
                        const action = (args[1] || '').toLowerCase()
                        if (action !== 'on' && action !== 'off') {
                                return ctx.reply(`Anti-spam saat ini: *${protection.opts.antispam.enabled ? 'ON' : 'OFF'}* (global)
Usage: \`.protection antispam on/off\`
Per chat: \`.protection set antispam on/off\``)
                        }
                        const enabled = action === 'on'

                        // persist di global overrides — selamat restart (pola KEY_OVERRIDES)
                        let stored = {}
                        try {
                                stored = JSON.parse(ctx.db.data.global_settings[KEY_OVERRIDES] || '{}')
                        } catch { stored = {} }
                        setTarget(stored, 'antispam.enabled', enabled)
                        ctx.db.data.global_settings[KEY_OVERRIDES] = JSON.stringify(stored)
                        saveDb(ctx)
                        protection.applyOverrides({ antispam: { enabled } })

                        return ctx.reply(
                                enabled
                                        ? 'Anti-spam *GLOBAL*: *ON* — flood command & chat kembali memicu strike + penalty.'
                                        : 'Anti-spam *GLOBAL*: *OFF* — tidak ada strike/penalty. Rate limit (burst, limit per command, bucket AI) tetap berjalan.'
                        )
                }

                // ---- .protection reset / chat on|off|reset (CHAT ini) ----
                if (sub === 'chat' || sub === 'reset') {
                        const action = sub === 'reset' ? 'reset' : (args[1] || '').toLowerCase()

                        if (action === 'reset') {
                                if (ctx.db.data.settings[ctx.chat]?.protection) {
                                        delete ctx.db.data.settings[ctx.chat].protection
                                        saveDb(ctx)
                                }
                                return ctx.reply('Override protection chat ini dihapus — sekarang ikut *global*.')
                        }

                        if (action === 'on' || action === 'off') {
                                const cfg = getChatCfg(ctx)
                                cfg.enabled = action === 'on'
                                saveDb(ctx)
                                return ctx.reply(
                                        action === 'on'
                                                ? 'Protection *ON* khusus di chat ini (meskipun global OFF).'
                                                : 'Protection *OFF* khusus di chat ini (meskipun global ON).'
                                )
                        }

                        return ctx.reply('Usage: `.protection chat on/off/reset`')
                }

                // ---- .protection global reset / global <path> <nilai> ----
                if (sub === 'global') {
                        const action = (args[1] || '').toLowerCase()
                        if (action === 'reset') {
                                delete ctx.db.data.global_settings[KEY_OVERRIDES]
                                saveDb(ctx)
                                protection.resetToDefaults()
                                // enabled kembali mengikuti toggle global tersimpan (jika pernah diset)
                                const saved = ctx.db.data.global_settings[KEY_ENABLED]
                                if (saved !== undefined) protection.setEnabled(saved === '1')
                                return ctx.reply('Config protection *GLOBAL* di-reset ke default (config/protection.js + .env).')
                        }

                        return this._set(ctx, protection, { scope: 'global', path: action, value: args[2] })
                }

                // ---- .protection set <path> <nilai> (CHAT ini) ----
                if (sub === 'set') {
                        return this._set(ctx, protection, { scope: 'chat', path: (args[1] || '').toLowerCase(), value: args[2] })
                }

                return this._status(ctx, protection)
        },

        /** Terapkan perubahan nilai (scope: chat / global). */
        async _set(ctx, protection, { scope, path, value }) {
                const usage = `Usage: \`.protection ${scope === 'global' ? 'global' : 'set'} <path> <nilai>\`\n\nDaftar path: \`.protection paths\``

                if (!path || value === undefined) return ctx.reply(usage)

                const spec = PATHS[path]
                if (!spec) return ctx.reply(`Path *${path}* tidak dikenal.\n\nDaftar path: \`.protection paths\``)
                if (spec.globalOnly && scope === 'chat') {
                        return ctx.reply(`Path *${path}* hanya bisa diset *GLOBAL* (concurrency = integritas resource, bukan preferensi chat):\n\`.protection global ${path} ${value}\``)
                }

                const parsed = parseValue(spec, value)
                if (parsed.error) return ctx.reply(`Nilai tidak valid: ${parsed.error}`)

                const isPenaltyIdx = /^penalties\[\d+\]$/.test(spec.target)

                if (scope === 'chat') {
                        const cfg = getChatCfg(ctx)
                        if (isPenaltyIdx) {
                                // array penalties — mulai dari nilai efektif saat ini
                                const base = Array.isArray(cfg.penalties) ? [...cfg.penalties] : [...protection.opts.penalties]
                                base[parseInt(spec.target.match(/\[(\d+)\]/)[1], 10)] = parsed.value
                                cfg.penalties = base
                        } else {
                                setTarget(cfg, spec.target, parsed.value)
                        }
                        saveDb(ctx)
                        const shown = spec.kind === 'dur' ? fmtMs(parsed.value) : parsed.value
                        return ctx.reply(`*${spec.label}*\nChat ini: *${shown}*\nGlobal: ${this._fmtValue(protection.opts, spec)}`)
                }

                // scope global — persist (global_settings) + apply runtime
                let stored = {}
                try {
                        stored = JSON.parse(ctx.db.data.global_settings[KEY_OVERRIDES] || '{}')
                } catch { stored = {} }

                const patch = {}
                if (isPenaltyIdx) {
                        const base = [...protection.opts.penalties]
                        base[parseInt(spec.target.match(/\[(\d+)\]/)[1], 10)] = parsed.value
                        patch.penalties = base
                } else {
                        setTarget(patch, spec.target, parsed.value)
                }

                setTarget(stored, spec.target, parsed.value)
                ctx.db.data.global_settings[KEY_OVERRIDES] = JSON.stringify(stored)
                saveDb(ctx)
                protection.applyOverrides(patch)

                const shown = spec.kind === 'dur' ? fmtMs(parsed.value) : parsed.value
                return ctx.reply(`*${spec.label}*\nGLOBAL: *${shown}* — langsung aktif + selamat restart.`)
        },

        _fmtValue(source, spec) {
                const v = getTarget(source, spec.target)
                if (v === undefined) return '-'
                if (spec.kind === 'bool') return v ? 'ON' : 'OFF'
                return spec.kind === 'dur' ? fmtMs(v) : String(v)
        },

        _pathsText() {
                return Object.entries(PATHS)
                        .map(([p, s]) => `\u2022 \`${p}\` \u2014 ${s.label}${s.globalOnly ? ' *(global saja)*' : ''}`)
                        .join('\n')
        },

        /** Status ringkas: nilai efektif + tanda override chat ini. */
        async _status(ctx, protection) {
                const o = protection.opts
                const chatCfg = ctx.db?.data?.settings?.[ctx.chat]?.protection || null

                const lines = [
                        '\uD83D\uDEE1 *PROTECTION*',
                        '',
                        `Global: *${o.enabled ? 'ON' : 'OFF'}*`,
                        `Anti-spam: *${o.antispam?.enabled ? 'ON' : 'OFF'}* (flood + strike + penalty)`,
                        `Chat ini: *${!chatCfg
                                ? 'ikut global'
                                : chatCfg.enabled === false
                                        ? 'OFF (dimatikan di sini)'
                                        : chatCfg.enabled === true
                                                ? 'ON (dipaksa di sini)'
                                                : 'ikut global, ada override nilai'}*`,
                        '',
                ]

                const rows = []
                for (const [p, s] of Object.entries(PATHS)) {
                        if (s.globalOnly) {
                                rows.push(`\u2022 ${s.label}: ${this._fmtValue(o, s)} (global)`)
                                continue
                        }
                        const inChat = chatCfg && getTarget(chatCfg, s.target) !== undefined
                        const source = inChat ? chatCfg : o
                        rows.push(`\u2022 ${s.label}: ${this._fmtValue(source, s)}${inChat ? ' \u2190 chat ini' : ''}`)
                }
                lines.push(...rows)

                lines.push(
                        '',
                        '*Perintah:*',
                        '`.protection on/off` \u2014 global (semua protection)',
                        '`.protection antispam on/off` \u2014 global (flood + strike + penalty saja)',
                        '`.protection chat on/off/reset` \u2014 chat ini',
                        '`.protection set <path> <nilai>` \u2014 chat ini',
                        '`.protection global <path> <nilai>` \u2014 global',
                        '`.protection global reset` \u2014 default pabrik',
                        '`.protection paths` \u2014 daftar path',
                )

                await ctx.reply(lines.join('\n'))
        },
}
