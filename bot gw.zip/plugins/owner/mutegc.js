import {
        isGroupMuted,
        muteGroup,
        unmuteGroup,
        listMutedGroups,
        normalizeGroupJid,
} from '../../lib/protection/mutegc.js'

/** Best-effort ambil subject grup (jaringan gagal → null, bukan error). */
async function fetchSubject(sock, jid) {
        try {
                const meta = await sock.groupMetadata(jid)
                return meta?.subject ? String(meta.subject) : null
        } catch {
                return null
        }
}

/** Umur relatif (baru saja / Xm / Xj). */
function sinceLabel(ts) {
        if (!Number.isFinite(ts)) return '-'
        const m = Math.max(0, Math.round((Date.now() - ts) / 60_000))
        if (m < 1) return 'baru saja'
        if (m < 60) return `${m} menit lalu`
        const h = Math.floor(m / 60)
        if (h < 24) return `${h} jam lalu`
        return `${Math.floor(h / 24)} hari lalu`
}

export default {
        name: 'mutegc',
        aliases: ['unmutegc', 'mutegclist', 'gcunmute'],
        description:
                'Mute TOTAL grup (owner): bot tidak memproses pesan non-owner & tidak mengirim '
                + 'notif apa pun ke grup itu — data (aktivitas/EXP/nama) tetap tercatat. Owner tetap bisa memakai bot',
        category: 'owner',
        usage:
                '.mutegc (mute grup ini) | .mutegc <jid-grup> | .mutegc off [jid] | .mutegc list | .mutegc status',
        owner: true,
        register: false,

        async execute(ctx) {
                const raw = String(ctx.rawCommand || ctx.command || 'mutegc').toLowerCase()
                const args = ctx.args || []
                const sub = (args[0] || '').toLowerCase()

                // ---- alias yang berdiri sendiri: unmutegc / mutegclist / gcunmute ----
                // (parse me-resolve alias → command 'mutegc', makanya baca rawCommand)
                if (raw === 'mutegclist') return this._replyList(ctx)
                if (raw === 'unmutegc' || raw === 'gcunmute') {
                        return this._doUnmute(ctx, (args[0] || '').trim())
                }

                // ---- .mutegc list ----
                if (sub === 'list') return this._replyList(ctx)

                // ---- .mutegc status ----
                if (sub === 'status') {
                        if (!ctx.isGroup) return ctx.reply('ℹ️ Jalankan command ini di dalam grup.')
                        return ctx.reply(
                                isGroupMuted(ctx.chat)
                                        ? '🔇 Grup ini SEDANG di-mute — non-owner tidak diproses & tanpa notif apa pun (data aktivitas/EXP tetap tercatat). Owner tetap bisa memakai bot di sini.'
                                        : '✅ Grup ini TIDAK di-mute — bot bekerja normal.',
                        )
                }

                // ---- .mutegc off [jid] ----
                if (sub === 'off' || sub === 'unmute') {
                        return this._doUnmute(ctx, (args[1] || '').trim())
                }

                // ---- .mutegc [on] <jid> — mute grup lain ----
                const candidate = (sub === 'on' || sub === 'mute')
                        ? (args[1] || '').trim()
                        : (args[0] || '').trim()
                if (candidate) {
                        return this._doMute(ctx, candidate)
                }

                // ---- .mutegc tanpa arg: mute grup ini (harus di grup) ----
                if (ctx.isGroup) return this._doMute(ctx, ctx.chat)
                return this._replyList(ctx, '⚠️ Jalankan di dalam grup yang mau di-mute, atau sertakan jid-nya.')
        },

        /** Mute target (jid valid / jid grup ini). */
        async _doMute(ctx, targetInput) {
                const target = normalizeGroupJid(targetInput)
                if (!target) {
                        return ctx.reply(
                                '❌ JID grup tidak valid. Format: `123456789-1234567890@g.us`\n'
                                + `Contoh: ${ctx.cmdRef ? ctx.cmdRef('mutegc') : '.mutegc'} 123456789-1234567890@g.us\n`
                                + 'Link invite tidak bisa dipakai (tidak bisa di-resolve tanpa join).\n'
                                + 'Atau jalankan command ini langsung di dalam grup yang mau di-mute.',
                        )
                }
                const name = await fetchSubject(ctx.sock, target)
                const changed = muteGroup(target, name)
                const label = name ? `*${name}*` : 'grup itu'
                return ctx.reply(
                        (changed ? '🔇 Grup di-*MUTE TOTAL*: ' : '🔇 Grup itu sudah di-mute sebelumnya. Status tetap: ')
                        + label
                        + '\n\n'
                        + 'Bot sekarang *TIDAK MEMPROSES* pesan non-owner di grup ini (tanpa command/AI/moderasi/notifikasi) — '
                        + 'tapi *data tetap tercatat* (aktivitas/EXP/level/nama; perekamannya in-memory, bukan sumber lag).\n'
                        + '👑 Owner tetap bisa memakai bot di sini seperti biasa.\n'
                        + 'Escape: '
                        + (ctx.cmdRef ? ctx.cmdRef('mutegc') : '.mutegc')
                        + ' off di grup ini (atau dari PM dengan jid).',
                )
        },

        /** Unmute target (argumen kosong = grup tempat command dijalankan). */
        async _doUnmute(ctx, targetInput) {
                let target
                if (targetInput) {
                        target = normalizeGroupJid(targetInput)
                        if (!target) {
                                return ctx.reply(
                                        '❌ JID grup tidak valid. Format: `123456789-1234567890@g.us`\n'
                                        + 'Atau jalankan command ini langsung di dalam grup yang mau di-unmute.',
                                )
                        }
                } else if (ctx.isGroup) {
                        target = ctx.chat
                } else {
                        return ctx.reply(
                                        'ℹ️ Jalankan di dalam grup yang mau di-unmute, atau sertakan jid-nya:\n'
                                        + `${ctx.cmdRef ? ctx.cmdRef('mutegc') : '.mutegc'} off <jid-grup>`,
                        )
                }
                const changed = unmuteGroup(target)
                return ctx.reply(
                        changed
                                ? '✅ Grup di-*UNMUTE* — bot kembali memproses grup itu secara normal.'
                                : 'ℹ️ Grup itu memang tidak sedang di-mute.',
                )
        },

        /** Balasan daftar grup mute. */
        _replyList(ctx, prefixNote) {
                const list = listMutedGroups()
                const ref = ctx.cmdRef ? ctx.cmdRef('mutegc') : '.mutegc'
                if (list.length === 0) {
                        return ctx.reply(
                                (prefixNote ? prefixNote + '\n' : '')
                                + '📭 Belum ada grup yang di-mute.\n\n'
                                + `Cara pakai: jalankan ${ref} di dalam grup yang mau di-mute, `
                                + `atau ${ref} <jid-grup> dari chat mana pun.`,
                        )
                }
                const lines = list.map((g, i) => {
                        const label = g.name ? `*${g.name}*` : '`' + g.jid + '`'
                        return `${i + 1}. ${label}\n   mute sejak ${sinceLabel(g.ts)}${g.name ? '\n   `' + g.jid + '`' : ''}`
                })
                return ctx.reply(
                        (prefixNote ? prefixNote + '\n' : '')
                        + `🔇 *Grup di-mute total (${list.length})*\n\n`
                        + lines.join('\n\n')
                        + '\n\nUnmute: ' + ref + ' off (di grup itu) / off <jid> (dari mana pun).',
                )
        },
}
