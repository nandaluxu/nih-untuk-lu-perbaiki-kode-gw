/**
 * .setreply — Ganti style UI balasan bot.
 *
 * Mode:
 *   .setreply              → lihat daftar style (global + chat ini)
 *   .setreply 1|2|3        → set GLOBAL (semua chat)
 *   .setreply grup 1|2|3   → set override UNTUK CHAT INI saja
 *   .setreply grup off     → hapus override → balik ikut global
 *
 * Style tersimpan di DB (reply_style + reply_style_by_chat) dan persist
 * setelah restart.
 */
import {
    getReplyStyle, setReplyStyle,
    getReplyStyleForChat, setReplyStyleForChat, clearReplyStyleForChat,
    hasReplyStyleOverride,
    buildSetreplyMenu, buildSetreplyMenuForChat,
    REPLY_STYLES,
} from '../../lib/messaging/reply-style.js'

export default {
    name: 'setreply',
    description: 'Ganti style UI balasan bot — global atau override per-chat (owner)',
    category: 'owner',
    owner: true,
    usage: '.setreply [grup] 1|2|3  |  .setreply grup off',

    async execute(ctx) {
        const _pfx = (typeof ctx !== 'undefined' && ctx?.prefix) || ''
        const { args, db, chat, isGroup } = ctx

        const a = (args || []).map(x => String(x || '').trim()).filter(Boolean)
        const sub = (a[0] || '').toLowerCase()

        // ---- Tanpa argumen: tampilkan menu ----
        if (!a.length) {
            const currentGlobal = getReplyStyle(db)
            const currentChat = getReplyStyleForChat(db, chat)
            if (isGroup || hasReplyStyleOverride(db, chat)) {
                return ctx.reply(buildSetreplyMenuForChat(currentGlobal, currentChat, chat, _pfx))
            }
            return ctx.reply(buildSetreplyMenu(currentGlobal, _pfx))
        }

        // ---- .setreply grup <1|2|3|off> ----
        if (sub === 'grup' || sub === 'group' || sub === 'chat') {
            const target = (a[1] || '').toLowerCase()

            if (!target) {
                return ctx.reply(
                    `Format: *${_pfx}setreply grup 1|2|3*  atau  *${_pfx}setreply grup off*`
                )
            }

            // Hapus override
            if (target === 'off' || target === 'reset' || target === 'hapus' || target === 'default') {
                const ok = clearReplyStyleForChat(db, chat)
                const globalNow = getReplyStyle(db)
                return ctx.reply(ok
                    ? `✅ Override chat ini dihapus.\nBalik ikut style global *${globalNow} — ${REPLY_STYLES[globalNow]}*.`
                    : `ℹ️ Chat ini memang tidak punya override. Aktif: style global *${globalNow} — ${REPLY_STYLES[globalNow]}*.`)
            }

            const style = Number(target)
            if (!setReplyStyleForChat(db, chat, style)) {
                return ctx.reply(
                    `Style tidak valid: *${target}*.\n` +
                    `Pilihan: *1* · *2* · *3* · atau *off* untuk hapus override.\n` +
                    `Contoh: *${_pfx}setreply grup 2*`
                )
            }
            const globalNow = getReplyStyle(db)
            return ctx.reply(
                `✅ Style *chat ini* di-override ke *${style} — ${REPLY_STYLES[style]}*.\n` +
                `Chat lain tetap ikut style global *${globalNow} — ${REPLY_STYLES[globalNow]}*.`
            )
        }

        // ---- .setreply 1|2|3 → set GLOBAL ----
        const style = Number(sub)
        if (!Number.isInteger(style) || !setReplyStyle(db, style)) {
            return ctx.reply(
                `Style tidak valid: *${sub}*.\n` +
                `• Global  : *${_pfx}setreply 1|2|3*\n` +
                `• Chat ini: *${_pfx}setreply grup 1|2|3*\n` +
                `• Hapus override chat ini: *${_pfx}setreply grup off*`
            )
        }

        return ctx.reply(
            `✅ Style balasan GLOBAL diganti ke *${style} — ${REPLY_STYLES[style]}*.\n` +
            `Pesan ini dikirim pakai style baru (preview).\n` +
            `Chat yang punya override tetap pakai style-nya sendiri.`
        )
    },
}