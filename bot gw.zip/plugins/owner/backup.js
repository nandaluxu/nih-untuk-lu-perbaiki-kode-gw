/**
 * .backup / .restore — backup & recovery store (§14-E, owner-only).
 *
 *   .backup               → buat backup sekarang + daftar arsip
 *   .backup list          → daftar arsip tersedia
 *   .restore <nama>       → tampilkan konfirmasi (langkah 1)
 *   .restore <nama> confirm → jalankan restore (langkah 2 — WAJIB restart)
 *
 * Scheduler harian dipasang di bot.js (rotasi 7 arsip otomatis).
 */
import { createBackup, listBackups, restoreBackup } from '../../lib/features/backup.js'
import { formatCoin } from '../../lib/economy/economy.js'

export default {
        name: 'backup',
        description: 'Backup/restore data store bot',
        category: 'owner',
        usage: '.backup | .backup list | .restore <nama> confirm',
        owner: true,

        async execute(ctx) {
			const _pfx = (typeof ctx !== 'undefined' && ctx?.prefix) || ''
                const sub = String(ctx.args[0] || '').toLowerCase()

                // ---- .restore <nama> [confirm] ----
                if (sub === 'restore') {
                        const name = ctx.args[1]
                        if (!name) {
                                const items = listBackups()
                                if (!items.length) return ctx.reply(`Belum ada backup. Buat dulu dengan ${_pfx}backup`)
                                return ctx.reply(
                                        '*Backup tersedia:*\n' +
                                        items.map(b => `• ${b.name} (${formatCoin(b.sizeBytes)} B)`).join('\n') +
                                        '\n\nRestore: `.restore <nama> confirm`'
                                )
                        }
                        if (String(ctx.args[2] || '').toLowerCase() !== 'confirm') {
                                return ctx.reply(
                                        `⚠️ Restore akan MENIMPA data store/ + users/ dengan isi *${name}*.\n` +
                                        'Jalankan kembali dengan kata *confirm* di akhir untuk melanjutkan.\n' +
                                        'Setelah restore, bot WAJIB di-restart.'
                                )
                        }
                        try {
                                await restoreBackup(name)
                                return ctx.reply(`✅ Backup *${name}* di-restore ke disk.\n🔁 RESTART bot sekarang agar data baru dimuat.`)
                        } catch (e) {
                                return ctx.reply(`❌ Restore gagal: ${e.message}`)
                        }
                }

                // ---- .backup list ----
                if (sub === 'list') {
                        const items = listBackups()
                        if (!items.length) return ctx.reply('Belum ada backup.')
                        return ctx.reply(
                                '*Backup tersedia:*\n' +
                                items.map(b => `• ${b.name} (${formatCoin(b.sizeBytes)} B)`).join('\n')
                        )
                }

                // ---- .backup (buat sekarang) ----
                try {
                        const file = await createBackup()
                        const items = listBackups()
                        await ctx.reply(
                                `✅ Backup dibuat: *${file.split('/').pop()}*\n` +
                                `Total arsip: ${items.length} (rotasi otomatis, tersimpan 7 terbaru).`
                        )
                } catch (e) {
                        await ctx.reply(`❌ Backup gagal: ${e.message}`)
                }
        },
}
