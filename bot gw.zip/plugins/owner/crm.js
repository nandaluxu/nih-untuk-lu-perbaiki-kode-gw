/**
 * plugins/owner/crm.js — .crm (conn relay message) — SALIN STRUKTUR PESAN
 * MENDALAM ke dalam code (Task 51).
 *
 * Fungsi: bongkar struktur RAW pesan WhatsApp (proto content asli) dan
 * susun jadi file .js berisi panggilan sock.relayMessage(jid, payload, {})
 * dengan payload yang bisa langsung dijalankan — Buffer jadi
 * Buffer.from("<base64>","base64"), Long baileys jadi number, nested
 * contextInfo utuh. "Versi conn.relay" bot lain = sock.relayMessage di bot
 * ini (kontrak client sama — tinggal ganti nama variabel socket).
 *
 * 3 MODE (semuanya WAJIB reply ke pesan yang mau dilihat strukturnya):
 *   .crm           → struktur pesan yang di-reply → DOCUMENT .js
 *   .crm --snip    → sama, tapi code ditampilkan LANGSUNG di chat
 *                    (AIRich code block — persis gaya .checkplugin)
 *   .crm --quote   → struktur pesan yang di-QUOTED oleh orang yang kita
 *                    reply (kita reply X, X reply Y → struktur Y yang
 *                    kelihatan; reply chain 2 tingkat) → document .js
 *   --quote + --snip boleh digabung → nested quote tampil inline.
 *
 * Sumber struktur (urut fallback):
 *   1. contextInfo.quotedMessage pada proto pesan sekarang (RAW asli —
 *      paling dalam & paling akurat)
 *   2. quoted.fakeObj (fake WAMessage hasil serialisasi starcore)
 *   3. quoted.message (bentuk lama)
 */
import { AIRich } from '../../lib/messaging/MessageBuilderV4.7.js'

// ---------------------------------------------------------------------------
// Ekstraksi struktur
// ---------------------------------------------------------------------------

/** Cari contextInfo di konten proto (1 tingkat: node tipenya). */
function findContextInfo(content) {
    if (!content || typeof content !== 'object') return null
    if (content.contextInfo) return content.contextInfo
    if (content.messageContextInfo) {
        // wrapper pesan: { messageContextInfo, <typeMessage>: { contextInfo } }
        for (const [k, v] of Object.entries(content)) {
            if (k === 'messageContextInfo' || k === 'senderKeyDistributionMessage') continue
            if (v && typeof v === 'object' && v.contextInfo) return v.contextInfo
        }
        return null
    }
    for (const v of Object.values(content)) {
        if (v && typeof v === 'object' && v.contextInfo) return v.contextInfo
    }
    return null
}

/** Tipe pesan (key konten pertama yang bukan wrapper). */
function messageTypeOf(content) {
    if (!content || typeof content !== 'object') return 'unknown'
    const SKIP = new Set(['messageContextInfo', 'senderKeyDistributionMessage'])
    const key = Object.keys(content).find(k => !SKIP.has(k))
    return key || 'unknown'
}

/** Konten mentah + meta pesan yang di-reply (fallback bertingkat). */
function extractQuoted(m, q) {
    // 1) proto pesan sekarang — contextInfo.quotedMessage (RAW asli)
    const content = m?.msg && typeof m.msg === 'object' ? m.msg : m?.message
    const ci = findContextInfo(content)
    if (ci?.quotedMessage && typeof ci.quotedMessage === 'object' && Object.keys(ci.quotedMessage).length) {
        return {
            content: ci.quotedMessage,
            id: ci.stanzaId || q?.id || null,
            sender: ci.participant || q?.sender || q?.key?.participant || null,
            isBot: q?.isBot, fromMe: q?.fromMe, pushName: q?.pushName || null,
        }
    }
    // 2) starcore quoted.fakeObj — fake WAMessage { key, message }
    const fo = q?.fakeObj
    if (fo && typeof fo === 'object') {
        if (fo.message && typeof fo.message === 'object' && Object.keys(fo.message).length) {
            return {
                content: fo.message,
                id: fo.key?.id || q?.id || null,
                sender: fo.key?.participant || q?.sender || null,
                isBot: q?.isBot, fromMe: q?.fromMe, pushName: q?.pushName || null,
            }
        }
        if (!fo.key && Object.keys(fo).length) {
            // content map langsung (bukan WAMessage wrapper)
            return {
                content: fo,
                id: q?.id || null,
                sender: q?.sender || null,
                isBot: q?.isBot, fromMe: q?.fromMe, pushName: q?.pushName || null,
            }
        }
    }
    // 3) bentuk lama: quoted.message
    if (q?.message && typeof q.message === 'object' && Object.keys(q.message).length) {
        return {
            content: q.message,
            id: q?.id || null,
            sender: q?.sender || null,
            isBot: q?.isBot, fromMe: q?.fromMe, pushName: q?.pushName || null,
        }
    }
    return null
}

/** Konten pesan yang di-QUOTED oleh X (nested, mode --quote). */
function extractNestedQuoted(m, q, quotedX) {
    // 1) dari konten X: contextInfo.quotedMessage
    if (quotedX?.content) {
        const ci = findContextInfo(quotedX.content)
        if (ci?.quotedMessage && typeof ci.quotedMessage === 'object' && Object.keys(ci.quotedMessage).length) {
            return {
                content: ci.quotedMessage,
                id: ci.stanzaId || null,
                sender: ci.participant || null,
            }
        }
    }
    // 2) starcore: quoted.contextInfo — contextInfo milik X dibawa serialisasi
    const ci2 = q?.contextInfo
    if (ci2?.quotedMessage && typeof ci2.quotedMessage === 'object' && Object.keys(ci2.quotedMessage).length) {
        return { content: ci2.quotedMessage, id: ci2.stanzaId || null, sender: ci2.participant || null }
    }
    // 3) fakeObj X → contextInfo → quotedMessage
    const fo = q?.fakeObj
    if (fo && typeof fo === 'object') {
        const xContent = fo.message && typeof fo.message === 'object'
            ? fo.message
            : (!fo.key ? fo : null)
        if (xContent) {
            const ci3 = findContextInfo(xContent)
            if (ci3?.quotedMessage && typeof ci3.quotedMessage === 'object' && Object.keys(ci3.quotedMessage).length) {
                return { content: ci3.quotedMessage, id: ci3.stanzaId || null, sender: ci3.participant || null }
            }
        }
    }
    return null
}

// ---------------------------------------------------------------------------
// Serializer mendalam → code JS (siap jalan)
// ---------------------------------------------------------------------------

/** Long baileys { low, high, unsigned } → number aman / string. */
function longToJs(v) {
    try {
        const big = (BigInt(v.high) << 32n) + BigInt(v.unsigned ? v.low >>> 0 : v.low)
        if (big <= BigInt(Number.MAX_SAFE_INTEGER) && big >= BigInt(Number.MIN_SAFE_INTEGER)) {
            return String(big)
        }
        return JSON.stringify(String(big))
    } catch {
        return JSON.stringify(`${v.low},${v.high}`)
    }
}

const IDENT_RE = /^[A-Za-z_$][A-Za-z0-9_$]*$/

/** Deteksi Long baileys: keys persis { low, high } / { low, high, unsigned }. */
function isLongLike(v) {
    const keys = Object.keys(v)
    if (keys.length < 2 || keys.length > 3) return false
    if (typeof v.low !== 'number' || typeof v.high !== 'number') return false
    if (keys.length === 3 && typeof v.unsigned !== 'boolean') return false
    return keys.every(k => k === 'low' || k === 'high' || k === 'unsigned')
}

// ---------------------------------------------------------------------------
// Task 52 — ANTI "Maximum call stack size exceeded"
// ---------------------------------------------------------------------------
// Keluhan owner: .crm "sering kena maximum call stack size". Struktur pesan
// WA (proto + fakeObj wrapper) bisa memuat RANTAI BERULANG (objek yang
// menunjuk dirinya sendiri lewat contextInfo.quotedMessage → wrapper menunjuk
// balik) → serializer rekursif lama muter tanpa henti → stack habis.
// Tiga pagar (FUNGSI TIDAK BERKURANG — format keluaran pesan normal identik):
//   1. CYCLE  : objek yang muncul lagi di jalur induknya → placeholder
//               "«circular»" (data semacam itu memang mustahil jadi literal).
//   2. DEPTH  : kedalaman sarang > 96 level → dipotong (pesan WA asli tidak
//               pernah sedalam itu; hanya payload buatan/rantai aneh).
//   3. BUDGET : total node yang diserialisasi dibatasi — rantai ALIAS
//               (objek sama muncul berkali-kali di posisi beda) membuat
//               ukuran hasil meledak eksponensial → potong dgn error bersih
//               yang dibalas ramah, bukan crash/stack/hang.
// ---------------------------------------------------------------------------

/** Kedalaman sarang maksimum (pesan asli jauh di bawah ini). */
const SERIALIZE_MAX_DEPTH = 96
/** Total node maksimum per satu serialisasi (anti ledakan alias). */
const SERIALIZE_NODE_BUDGET = 300_000

/** Placeholder objek berulang / terpotong — literal JS valid. */
const CIRCULAR_PLACEHOLDER = '"«circular»"'
const DEPTH_PLACEHOLDER = '"«dipotong: terlalu dalam»"'

function serialize(value, level = 1, seen = new WeakSet(), budget = { left: SERIALIZE_NODE_BUDGET }) {
    const pad = '  '.repeat(level)
    if (value === null) return 'null'
    if (value === undefined) return 'undefined'
    const t = typeof value
    if (t === 'number' || t === 'boolean') return String(value)
    if (t === 'string') return JSON.stringify(value)
    if (t === 'bigint') return `${value}n`
    if (t === 'function') return 'null // (fungsi — tidak tersalin)'
    if (--budget.left < 0) {
        throw new Error('struktur pesan meledak (rantai quote berulang) — terlalu besar buat disalin')
    }
    // Buffer / Uint8Array → base64 (payload tetap bisa dijalankan ulang)
    if (value instanceof Uint8Array) {
        const b64 = Buffer.from(value.buffer, value.byteOffset, value.byteLength).toString('base64')
        return `Buffer.from(${JSON.stringify(b64)}, "base64")`
    }
    if (value instanceof Date) return JSON.stringify(value.toISOString())
    if (level > SERIALIZE_MAX_DEPTH) return DEPTH_PLACEHOLDER
    if (value instanceof Map) {
        if (seen.has(value)) return CIRCULAR_PLACEHOLDER
        seen.add(value)
        try {
            if (!value.size) return 'new Map()'
            const items = [...value.entries()].map(([k, v]) => `${pad}  [${serialize(k, level + 1, seen, budget)}, ${serialize(v, level + 1, seen, budget)}],`)
            return `new Map([\n${items.join('\n')}\n${pad}])`
        } finally { seen.delete(value) }
    }
    if (value instanceof Set) {
        if (seen.has(value)) return CIRCULAR_PLACEHOLDER
        seen.add(value)
        try {
            if (!value.size) return 'new Set()'
            const items = [...value.values()].map(v => `${pad}  ${serialize(v, level + 1, seen, budget)},`)
            return `new Set([\n${items.join('\n')}\n${pad}])`
        } finally { seen.delete(value) }
    }
    // Long baileys { low, high[, unsigned] } → number aman / string
    if (!Array.isArray(value) && isLongLike(value)) {
        return longToJs(value)
    }
    if (Array.isArray(value)) {
        if (seen.has(value)) return CIRCULAR_PLACEHOLDER
        seen.add(value)
        try {
            if (!value.length) return '[]'
            const items = value.map(v => `${pad}  ${serialize(v, level + 1, seen, budget)},`)
            return `[\n${items.join('\n')}\n${pad}]`
        } finally { seen.delete(value) }
    }
    if (t === 'object') {
        if (seen.has(value)) return CIRCULAR_PLACEHOLDER
        seen.add(value)
        try {
            // plain object — urutan key asli dipertahankan (proto field order)
            const entries = Object.entries(value)
            if (!entries.length) return '{}'
            const lines = entries.map(([k, v]) => `${pad}  ${IDENT_RE.test(k) ? k : JSON.stringify(k)}: ${serialize(v, level + 1, seen, budget)},`)
            return `{\n${lines.join('\n')}\n${pad}}`
        } finally { seen.delete(value) }
    }
    return JSON.stringify(String(value))
}

/** Susun file .js lengkap (header meta + panggilan relayMessage siap pakai). */
function buildCrmCode({ payload, type, id, sender, modeLabel, chat, extraNote }) {
    const stamp = new Date().toISOString()
    const meta = [
        `Sumber   : ${type} dari ${sender || '(tidak diketahui)'}`,
        `ID       : ${id || '(tidak diketahui)'}`,
        `Chat     : ${chat}`,
        `Diambil  : ${stamp} (${modeLabel})`,
    ]
    if (extraNote) meta.push(`Catatan  : ${extraNote}`)
    const header = meta.map(l => ` * ${l}`).join('\n')
    return `/**
 * crm — salinan struktur pesan (conn relay message, deep copy)
 *
${header}
 *
 * Payload di bawah = struktur proto ASLI pesan itu (sudah dibersihkan jadi
 * literal JS yang bisa langsung dijalankan). Kirim ulang:
 *   await sock.relayMessage(jid, payload, {})
 * (bot lain yang pakai \`conn\` tinggal ganti \`sock\` → \`conn\`.)
 */
const jid = m.chat // chat tujuan — ganti kalau mau kirim ke chat lain

await sock.relayMessage(
\tjid,
${serialize(payload, 1).replace(/^/gm, '\t')},
\t{}
)
`
}

// ---------------------------------------------------------------------------
// Plugin
// ---------------------------------------------------------------------------

const SNIP_INLINE_LIMIT = 40_000 // > ini → document (code block kegedean)
const CODE_HARD_LIMIT = 512_000

export default {
    name: 'crm',
    aliases: ['connrelay', 'crmsg'],
    description: 'Salin struktur pesan mendalam jadi code relayMessage (reply pesan)',
    category: 'owner',
    usage: '.crm [--snip|--quote] (wajib reply pesan)',
    owner: true,

    async execute(ctx) {
        const { sock, chat, message: m, quoted: q, reply, prefix } = ctx
        const args = (ctx.args || []).map(a => String(a || ''))
        const flags = new Set(args.filter(a => a.startsWith('--')).map(a => a.toLowerCase().replace(/^--/, '')))
        const wantSnip = flags.has('snip')
        const wantQuote = flags.has('quote')
        const badFlags = [...flags].filter(f => f !== 'snip' && f !== 'quote')

        if (!q && !m?.quoted) {
            return reply(
                `🧬 *crm — conn relay message*\n\n` +
                `Wajib *reply* ke pesan yang mau dilihat strukturnya.\n\n` +
                `*${prefix}crm* — struktur pesan yang di-reply → document .js\n` +
                `*${prefix}crm --snip* — code langsung tampil di chat (ala checkplugin)\n` +
                `*${prefix}crm --quote* — struktur pesan yang di-quote orang yang kita reply\n` +
                `*${prefix}crm --quote --snip* — nested quote, tampil inline`)
        }
        if (badFlags.length) {
            return reply(`❌ Flag tidak dikenal: *${badFlags.map(f => '--' + f).join(', ')}*.\nYang tersedia: *--snip*, *--quote*.`)
        }

        try { await m?.react?.('⏳') } catch { /* best effort */ }

        // ---- ekstraksi target ----
        const quotedX = extractQuoted(m, q)
        if (!quotedX) {
            try { await m?.react?.('❌') } catch {}
            return reply('⚠️ Struktur pesan yang di-reply tidak terbaca — coba reply ulang (pesan mungkin terlalu tua / tidak tersedia).')
        }

        let target
        let modeLabel
        if (wantQuote) {
            const nested = extractNestedQuoted(m, q, quotedX)
            if (!nested) {
                try { await m?.react?.('❌') } catch {}
                return reply(
                    `⚠️ Pesan yang kamu reply ini *tidak meng-quote* pesan lain ` +
                    `(bukan balasan) — tidak ada struktur nested yang bisa dilihat.\n\n` +
                    `Pakai *${prefix}crm* (tanpa --quote) untuk struktur pesannya sendiri.`)
            }
            target = nested
            modeLabel = 'nested quote — pesan yang di-quote oleh pesan yang di-reply'
        } else {
            target = quotedX
            modeLabel = 'pesan yang di-reply'
        }

        const type = messageTypeOf(target.content)

        // ---- susun code ----
        let code
        try {
            code = buildCrmCode({
                payload: target.content,
                type,
                id: target.id,
                sender: target.sender,
                modeLabel,
                chat,
            })
        } catch (e) {
            try { await m?.react?.('❌') } catch {}
            return reply(`❌ Gagal menyalin struktur: ${e?.message || e}`)
        }

        if (code.length > CODE_HARD_LIMIT) {
            try { await m?.react?.('❌') } catch {}
            return reply('⚠️ Struktur pesan ini kegedean (>512KB) — kemungkinan pesan media penuh, tidak bisa disalin.')
        }

        const infoText =
            `📦 *Sumber:* ${type} dari ${target.sender ? `@${String(target.sender).split('@')[0]}` : '(tidak diketahui)'}\n` +
            `🆔 *ID:* \`${target.id || '-'}\`\n` +
            `📄 *Baris code:* ${code.split('\n').length} · ${(code.length / 1024).toFixed(1)} KB`

        // ---- kirim ----
        try {
            // --snip: tampil inline (pola checkplugin: AIRich code block);
            // code kegedean utk inline → otomatis jadi document + catatan.
            if (wantSnip && code.length <= SNIP_INLINE_LIMIT) {
                await sendInline(sock, chat, m, code, infoText, type, wantQuote)
            } else {
                const note = wantSnip && code.length > SNIP_INLINE_LIMIT
                        ? ' (kegedean buat inline — dikirim jadi document)'
                        : ''
                await sock.sendMessage(chat, {
                    document: Buffer.from(code, 'utf8'),
                    mimetype: 'text/javascript',
                    fileName: `crm-${type}-${Date.now().toString(36)}.js`,
                    caption: `🧬 *crm${wantQuote ? ' --quote' : ''}* — struktur *${type}*${note}\n\n${infoText}`,
                }, { quoted: m })
            }
            try { await m?.react?.('✅') } catch { /* best effort */ }
        } catch (e) {
            // document/inline gagal → fallback plain text code block
            try {
                await reply(`🧬 *crm* — struktur *${type}* (fallback teks)\n\n${infoText}\n\n\`\`\`js\n${code.slice(0, 3800)}\n\`\`\``)
                try { await m?.react?.('✅') } catch {}
            } catch (e2) {
                try { await m?.react?.('❌') } catch {}
                return reply(`❌ Gagal mengirim struktur: ${e2?.message || e2}`)
            }
        }
    },
}

/** --snip: AIRich code block (pola checkplugin) + fallback plain. */
async function sendInline(sock, chat, m, code, infoText, type, wantQuote) {
    if (!sock?.waUploadToServer) {
        await sock.sendMessage(chat, {
            text: `🧬 *crm${wantQuote ? ' --quote' : ''}* — struktur *${type}*\n\n${infoText}\n\n\`\`\`js\n${code}\n\`\`\``,
        }, { quoted: m })
        return
    }
    try {
        const aiRich = new AIRich(sock)
        aiRich.setTitle(`🧬 CRM — Struktur ${type}`)
        aiRich.addText(infoText)
        aiRich.addCode('javascript', code)
        await aiRich.send(chat, { quoted: m || undefined })
    } catch (e) {
        // AIRich gagal → plain code block (pola checkplugin fallback)
        await sock.sendMessage(chat, {
            text: `🧬 *crm${wantQuote ? ' --quote' : ''}* — struktur *${type}*\n\n${infoText}\n\n\`\`\`js\n${code}\n\`\`\``,
        }, { quoted: m })
    }
}
