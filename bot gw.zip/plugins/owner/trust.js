/**
 * .trust — Izinkan user pakai bot di chat pribadi (owner only).
 *
 *   .trust @tag
 *   .trust 628xxxxxxxxxx
 *   .trust (reply pesan user)
 *
 * User yang di-trust TIDAK diblokir oleh anti PM (.antipm on).
 * Persist: global_settings.antipm.trusted (lib/antipm.js).
 */
import { resolveTargetJid, addTrust, isTrusted } from '../../lib/features/antipm.js'
import { isOwner } from '../../config/index.js'
import { fmtJid } from '../../lib/command/group-utils.js'

export default {
    name: 'trust',
    description: 'Izinkan user pakai bot di chat pribadi (bebas anti PM)',
    category: 'owner',
    usage: '.trust @tag|nomor',
    owner: true,

    async execute(ctx) {
			const _pfx = (typeof ctx !== 'undefined' && ctx?.prefix) || ''
        const { args, mentionedJid, quoted, reply, db, sender } = ctx

        const target = resolveTargetJid({ mentionedJid, args, quoted })
        if (!target) {
            return reply(`❌ Tag user atau tulis nomornya.\nContoh: *${_pfx}trust @tag* atau *${_pfx}trust 628xxxxxxxxxx*`)
        }

        if (isOwner(target)) {
            return reply('ℹ️ Owner selalu diizinkan — tidak perlu di-trust.')
        }

        if (isTrusted(db, [target])) {
            return reply(`ℹ️ ${fmtJid(target)} sudah ada di daftar trust.`)
        }

        addTrust(db, target, sender)
        return reply(
            `✅ *Trusted:* ${fmtJid(target)}\n` +
                `User ini sekarang bisa pakai bot di chat pribadi (bebas anti PM).`
        )
    },
}
