import config from '../../config/index.js'
import logger from '../../lib/core/logger.js'

export default {
	name: 'join',
	aliases: ['joingrup', 'joingroup'],
	description: 'Join grup WhatsApp melalui link invite',
	category: 'owner',
	usage: '.join <link/invite_code>',
	owner: true,

	async execute(ctx) {
		const { sock, text } = ctx

		if (!text) {
			return ctx.reply(
				`⚠️ *Cara penggunaan:*\n` +
				`\`${ctx.prefix}join <link/invite_code>\`\n\n` +
				`*Contoh:*\n` +
				`\`${ctx.prefix}join https://chat.whatsapp.com/ABC123456789\`\n` +
				`atau\n` +
				`\`${ctx.prefix}join ABC123456789\``
			)
		}

		try {
			// Extract invite code from URL if full link is provided
			let inviteCode = text.trim()
			
			// Check if it's a full URL
			const urlMatch = inviteCode.match(
				/(?:https?:\/\/)?chat\.whatsapp\.com\/(?:invite\/)?([a-zA-Z0-9_-]{10,})/
			)
			
			if (urlMatch) {
				inviteCode = urlMatch[1]
			}

			logger.info('Mencoba join grup dengan kode: %s', inviteCode)

			// Get group info from invite code first
			const groupInfo = await sock.groupGetInviteInfo(inviteCode)
			
			if (!groupInfo) {
				return ctx.reply('❌ *Gagal mendapatkan info grup!*\nInvite link tidak valid atau sudah kadaluarsa.')
			}

			// Accept the invite
			const joinedGroup = await sock.groupAcceptInvite(inviteCode)
			
			if (!joinedGroup) {
				return ctx.reply('❌ *Gagal join grup!*\nBot tidak dapat bergabung dengan grup tersebut.')
			}

			// Get fresh metadata
			const metadata = await sock.groupMetadata(joinedGroup)
			
			const successMessage = [
				'✅ *Berhasil Join Grup!*',
				'',
				`📛 *Nama Grup:* ${metadata.subject || 'Unknown'}`,
				`👥 *Total Member:* ${metadata.participants?.length || 0}`,
				`🆔 *Group ID:* \`${joinedGroup}\``,
				'',
				`🔗 *Invite Code:* \`${inviteCode}\``,
				'',
				'Bot telah aktif di grup tersebut! 🎉'
			].join('\n')

			await ctx.reply(successMessage)

			// Send greeting message to the group
			try {
				await sock.sendMessage(joinedGroup, {
					text: [
						`👋 *${config.botName} Telah Bergabung!*`,
						'',
						`Terima kasih telah mengundang bot ini ke grup *${metadata.subject}*.`,
						'',
						`Ketik \`${ctx.prefix}menu\` untuk melihat daftar command yang tersedia.`,
						'',
						'Happy chatting! 🎉'
					].join('\n')
				})
			} catch (greetingErr) {
				logger.warn('Gagal mengirim pesan ke grup: %s', greetingErr.message)
			}

		} catch (err) {
			logger.error('Error saat join grup: %s', err.message)
			
			let errorMessage = '❌ *Gagal join grup!*\n'
			
			if (err.message.includes('invite')) {
				errorMessage += 'Invite link tidak valid atau sudah kadaluarsa.'
			} else if (err.message.includes('full')) {
				errorMessage += 'Grup sudah penuh (maksimal 1024 member).'
			} else if (err.message.includes('banned')) {
				errorMessage += 'Bot di-ban dari grup tersebut.'
			} else if (err.message.includes('rate')) {
				errorMessage += 'Terlalu banyak request. Coba lagi nanti.'
			} else {
				errorMessage += `Error: ${err.message}`
			}

			await ctx.reply(errorMessage)
		}
	}
}