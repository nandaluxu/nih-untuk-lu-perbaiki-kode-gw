import { getReactConfig, setReactConfig } from '../../lib/messaging/auto-status.js'

export default {
        name: 'autoreactsw',
        aliases: ['areactsw', 'reactsw', 'autoreactstatus'],
        description: 'Bot otomatis react status WhatsApp kontak (story)',
        category: 'owner',
        usage: '.autoreactsw on [emoji] / off / emoji <emoji>',
        owner: true,
        register: false,

        async execute(ctx) {
                const _pfx = (typeof ctx !== 'undefined' && ctx?.prefix) || '.'
                const sub = (ctx.args[0] || '').toLowerCase()
                const cfg = getReactConfig(ctx.db)

                if (sub === 'on') {
                        const custom = ctx.args[1]
                        setReactConfig(ctx.db, { enabled: true, emoji: custom || undefined })
                        return ctx.reply(
                                `✅ Auto-react status *diaktifkan*${custom ? ` dengan emoji *${custom}*` : ' (emoji acak per status)'}.` +
                                `\n\nStatus baru kontak (max 5 menit setelah tayang) otomatis direact.`
                        )
                }

                if (sub === 'off') {
                        setReactConfig(ctx.db, { enabled: false })
                        return ctx.reply('✅ Auto-react status *dimatikan*.')
                }

                if (sub === 'emoji') {
                        const emoji = ctx.args[1]
                        if (!emoji) {
                                return ctx.reply(`Format: ${_pfx}autoreactsw emoji <emoji>\nContoh: ${_pfx}autoreactsw emoji 🔥`)
                        }
                        setReactConfig(ctx.db, { enabled: cfg.enabled, emoji })
                        return ctx.reply(`Emoji react status disimpan: *${emoji}* (mode acak OFF).`)
                }

                if (sub === 'random') {
                        setReactConfig(ctx.db, { emoji: null })
                        return ctx.reply('Emoji react status kembali *acak* per status.')
                }

                return ctx.reply(
                        [
                                '*Auto React Status*',
                                '',
                                `Status: ${cfg.enabled ? '🟢 ON' : '🔴 OFF'}`,
                                `Emoji: ${cfg.emoji ? cfg.emoji : 'acak (❤️ 😂 😮 😢 👍 🔥 …)'}`,
                                '',
                                `*Perintah:*`,
                                `${_pfx}autoreactsw on → aktifkan (emoji acak)`,
                                `${_pfx}autoreactsw on 🔥 → aktifkan dengan emoji tetap`,
                                `${_pfx}autoreactsw off → matikan`,
                                `${_pfx}autoreactsw emoji 😭 → ganti emoji tetap`,
                                `${_pfx}autoreactsw random → kembali acak`,
                        ].join('\n')
                )
        }
}
