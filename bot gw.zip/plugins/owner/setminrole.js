import { ROLE_HIERARCHY, RoleRepository } from '../../database/role-repository.js'

export default {
	name: 'setminrole',
	description: 'Lihat minRole command (dibaca dari source plugin)',
	category: 'owner',
	usage: '.setminrole <cmd> | .setminrole all',
	owner: true,

	async execute(ctx) {
			const _pfx = (typeof ctx !== 'undefined' && ctx?.prefix) || ''
		const { args, pluginLoader } = ctx
		const cmdName = (args[0] || '').toLowerCase()

		if (!cmdName) {
			return ctx.reply(`Format: ${_pfx}setminrole <cmd> | ${_pfx}setminrole all`)
		}

		// minRole plugin TIDAK disimpan di database.
		// Source of truth = metadata plugin di source file, ikut hot-reload.
		// Cara ubah: edit minRole di file plugin → hot reload otomatis menerapkan.
		if (cmdName === 'all') {
			const rows = []
			for (const [name, plugin] of pluginLoader.registry) {
				const mr = RoleRepository.normalizeMinRole(plugin.minRole, name)
				if (mr !== 'free') {
					rows.push(`• ${name} → *${mr}*`)
				}
			}
			if (rows.length === 0) {
				return ctx.reply('Tidak ada plugin dengan minRole di atas free.')
			}
			return ctx.reply(`*minRole plugin (dari source plugin):*\n\n${rows.join('\n')}\n\n_Ubah via edit file plugin — hot reload otomatis menerapkan._`)
		}

		const plugin = pluginLoader.registry.get(cmdName)
		if (!plugin) {
			return ctx.reply('Command tidak ditemukan: ' + cmdName)
		}

		const minRole = RoleRepository.normalizeMinRole(plugin.minRole, plugin.name)
		await ctx.reply(`minRole *${cmdName}*: *${minRole}*

_Source of truth:_ file plugin \`${plugin.name}\` (metadata minRole).
_Ubah: edit minRole di file plugin → hot reload otomatis menerapkan, tanpa restart._
_Role valid: ${ROLE_HIERARCHY.join(', ')}_)
`)
	}
}
