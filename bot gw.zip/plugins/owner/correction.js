export default {
	name: 'correction',
	description: 'Atur command correction (global)',
	category: 'owner',
	usage: '.correction on|off|mode message|button',
	owner: true,

	async execute(ctx) {
		const { args, prefixManager } = ctx
		const sub = (args[0] || '').toLowerCase()

		if (sub === 'on') {
			prefixManager.setCorrectionEnabled(true)
			return ctx.reply('Command correction diaktifkan (global).')
		}

		if (sub === 'off') {
			prefixManager.setCorrectionEnabled(false)
			return ctx.reply('Command correction dimatikan (global).')
		}

		if (sub === 'mode') {
			const mode = (args[1] || '').toLowerCase()
			if (!['message', 'button'].includes(mode)) {
				return ctx.reply('Mode tidak valid. Gunakan: message atau button.')
			}
			prefixManager.setCorrectionMode(mode)
			return ctx.reply(`Correction mode diubah ke: ${mode} (global)`)
		}

		const cfg = prefixManager.getCorrection()
		await ctx.reply([
			'*Correction Config (Global)*',
			'',
			`Status: ${cfg.enabled ? 'ON' : 'OFF'}`,
			`Mode: ${cfg.mode}`
		].join('\n'))
	}
}
