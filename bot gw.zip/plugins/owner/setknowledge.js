/**
 * plugins/owner/setknowledge.js — .setknow (owner) — AI WORLD KNOWLEDGE.
 *
 * Kelola pengetahuan dunia yang diketahui SEMUA karakter AI (engine anime
 * characters + rikka). Fakta disuntik ke pesan pertama session AI sebagai
 * info internal (urutan: fakta karakter → fakta grup ini → fakta global).
 * Penyimpanan: domain `ai_world` di JsonStore yang sudah ada (pola ai_char).
 *
 *   .setknow                          → status: jumlah fakta per scope + cara pakai
 *   .setknow global <teks>            → fakta untuk SEMUA karakter di semua chat
 *   .setknow group <teks>             → fakta khusus CHAT INI (di mana command dijalankan)
 *   .setknow <karakter> <teks>        → fakta khusus satu karakter (miku/rikka/rem/…)
 *   .setknow list [global|group|<karakter>]  → lihat daftar fakta (nomor = urutan hapus)
 *   .setknow del <scope> <nomor>      → hapus fakta (scope: global|group|<karakter>)
 *
 * Contoh:
 *   .setknow global Bot ini bernama Nanda Bot, grup utama suka rame tengah malam.
 *   .setknow group Di grup ini ada tradisi foto bareng tiap Jumat.
 *   .setknow miku Miku suka banget dengerin cerita tentang konser.
 *   .setknow list miku
 *   .setknow del miku 2
 *
 * Batas (lib/ai-characters/world-knowledge.js): maks 25 fakta per scope
 * (paling lama dibuang otomatis), teks maks 300 karakter per fakta.
 */
import { getCharacters } from '../../lib/ai-characters/engine.js'
import { matchCharacter } from '../../lib/ai-characters/relationship.js'
import {
    addWorldFact, deleteWorldFact, listWorldFacts, countWorldFacts,
    WORLD_FACTS_CAP, WORLD_FACT_MAX_CHARS,
} from '../../lib/ai-characters/world-knowledge.js'

/** Parse argumen → { scope, key, label } (null bila scope tidak dikenal). */
async function resolveScope(ctx, word) {
    const w = String(word || '').toLowerCase().trim()
    if (w === 'global') return { scope: 'global', key: null, label: 'Global (semua karakter, semua chat)' }
    if (w === 'group' || w === 'grup' || w === 'chat') return { scope: 'group', key: ctx.chat, label: `Chat ini (${ctx.chat})` }
    if (!w) return null
    const chars = await getCharacters()
    const char = matchCharacter(chars, w)
    if (char) return { scope: 'char', key: char.id, label: `Karakter ${char.name}` }
    return null
}

/** Teks daftar fakta satu scope (dipakai .setknow list). */
function formatFacts(label, facts) {
    if (!facts.length) return `📭 ${label}: (kosong)`
    const lines = facts.map((f, i) => `${i + 1}. ${f.text}`)
    return `📒 *${label}* (${facts.length}):\n${lines.join('\n')}`
}

export default {
    name: 'setknowledge',
    aliases: ['setknow', 'worldknow', 'setworld'],
    description: 'Kelola pengetahuan dunia AI (global / grup / per karakter)',
    category: 'owner',
    owner: true,
    usage: '.setknow <global|group|<karakter>> <teks> — lihat .setknow list',

    async execute(ctx) {
        const { args, reply, db, chat } = ctx
        const _pfx = (typeof ctx !== 'undefined' && ctx?.prefix) || '.'
        const words = (args || []).map(a => String(a || '').trim()).filter(Boolean)

        // ---- tanpa argumen: status ----
        if (!words.length) {
            const c = countWorldFacts(db)
            const chars = await getCharacters()
            return reply(
                `🧠 *AI WORLD KNOWLEDGE* — pengetahuan dunia karakter AI (owner)\n\n` +
                `Fakta tersimpan: *${c.total}*\n` +
                `• Global (semua karakter): ${c.global} fakta\n` +
                `• Semua grup/chat: ${c.groups} fakta\n` +
                `• Semua karakter: ${c.chars} fakta\n\n` +
                `*Cara pakai:*\n` +
                `${_pfx}setknow global <teks> — semua karakter tahu\n` +
                `${_pfx}setknow group <teks> — khusus chat ini\n` +
                `${_pfx}setknow <karakter> <teks> — khusus 1 karakter (${['rikka', ...chars.map(x => x.id)].slice(0, 10).join(', ')}…)\n` +
                `${_pfx}setknow list [scope] — lihat daftar\n` +
                `${_pfx}setknow del <scope> <nomor> — hapus\n\n` +
                `Fakta disuntik ke otak AI sebagai info internal saat user mulai chat baru (maks ${WORLD_FACTS_CAP}/scope, ${WORLD_FACT_MAX_CHARS} char/fakta).`
            )
        }

        // ---- list [scope] ----
        if (words[0].toLowerCase() === 'list' || words[0].toLowerCase() === 'lihat') {
            const target = words[1]
            if (!target) {
                // semua scope relevan: global + chat ini
                const parts = [
                    formatFacts('Global', listWorldFacts(db, 'global', null)),
                    formatFacts(`Chat ini (${chat})`, listWorldFacts(db, 'group', chat)),
                ]
                return reply(parts.join('\n\n') + `\n\nDetail per karakter: ${_pfx}setknow list <karakter>`)
            }
            const sc = await resolveScope(ctx, target)
            if (!sc) return reply(`❌ Scope *${target}* tidak dikenal.\nGunakan: global · group · <nama karakter>`)
            return reply(formatFacts(sc.label, listWorldFacts(db, sc.scope, sc.key)))
        }

        // ---- del <scope> <nomor> ----
        if (words[0].toLowerCase() === 'del' || words[0].toLowerCase() === 'hapus') {
            const sc = await resolveScope(ctx, words[1])
            if (!sc) return reply(`❌ Format: *${_pfx}setknow del <global|group|<karakter>> <nomor>*\nContoh: *${_pfx}setknow del miku 2*`)
            const r = deleteWorldFact(db, sc.scope, sc.key, words[2])
            if (!r.ok) return reply(`❌ ${r.message}`)
            return reply(`🗑️ Fakta #${words[2]} dihapus dari *${sc.label}*.\nSisa: ${r.count} fakta.`)
        }

        // ---- tambah fakta: <scope> <teks> ----
        const sc = await resolveScope(ctx, words[0])
        if (!sc) {
            const chars = await getCharacters()
            return reply(
                `❌ Scope *${words[0]}* tidak dikenal.\n\n` +
                `Gunakan:\n${_pfx}setknow global <teks>\n${_pfx}setknow group <teks>\n${_pfx}setknow <karakter> <teks>\n\n` +
                `Karakter tersedia: ${['rikka', ...chars.map(x => x.id)].join(', ') || '(kosong)'}`
            )
        }
        const text = words.slice(1).join(' ')
        if (!text) return reply(`Teks fakta-nya apa?\nContoh: *${_pfx}setknow ${words[0].toLowerCase()} Nanda Bot punya grup rame tiap malam.*`)
        const r = addWorldFact(db, sc.scope, sc.key, text)
        if (!r.ok) return reply(`❌ ${r.message}`)
        return reply(
            `✅ Fakta disimpan ke *${sc.label}* (total ${r.count}).\n` +
            `『 ${text.slice(0, 200)}${text.length > 200 ? '…' : ''} 』\n` +
            `Karakter AI akan otomatis tahu fakta ini di percakapan baru.`
        )
    },
}
