export default {
    name: 'testcarousel',
    description: 'Test carousel message',
    category: 'owner',
    usage: '.testcarousel',
    owner: true,

    async execute(ctx) {
        const { sock, chat, message } = ctx
        
        try {
            await sock.sendCarousel(chat, [
                {
                    media: 'https://picsum.photos/600/600',
                    caption: 'Test Carousel 1',
                    footer: 'Test',
                    nativeFlow: [{
                        text: 'Open',
                        url: 'https://example.com'
                    }]
                },
                {
                    media: 'https://picsum.photos/601/600',
                    caption: 'Test Carousel 2',
                    footer: 'Test',
                    nativeFlow: [{
                        text: 'Open',
                        url: 'https://example.com'
                    }]
                },
                {
                    media: 'https://picsum.photos/602/600',
                    caption: 'Test Carousel 3',
                    footer: 'Test',
                    nativeFlow: [{
                        text: 'Open',
                        url: 'https://example.com'
                    }]
                },
                {
                    media: 'https://picsum.photos/603/600',
                    caption: 'Test Carousel 4',
                    footer: 'Test',
                    nativeFlow: [{
                        text: 'Open',
                        url: 'https://example.com'
                    }]
                }
            ], message, {
                text: 'Carousel test',
                footer: 'Starcore'
            })
            
            await ctx.reply('✅ Carousel berhasil dikirim!')
        } catch (error) {
            console.error('Error sending carousel:', error)
            await ctx.reply('❌ Gagal mengirim carousel: ' + error.message)
        }
    }
}