/**
 * .workset — pengaturan runtime fitur .work (KHUSUS OWNER, berdampak global).
 *
 *   .workset                    → panel setelan + bantuan
 *   .workset mode fast|full     → UI sederhana (langsung hasil) / animasi lama
 *   .workset delay <min> <max>  → jeda per update progress, satuan DETIK
 *                                 (mis. ".workset delay 1 5" = 1-5 detik)
 *   .workset steps <min> <max>  → jumlah step progress (mis. 5 8)
 *   .workset reset              → kembalikan default config/economy.js
 *
 * Tersimpan di db (global_settings) — BUKAN env — sehingga tetap berlaku
 * setelah restart dan bisa diubah kapan saja tanpa edit file.
 * Mode fast TIDAK mengubah mesin: event, grade, peluang & upah persis sama,
 * hanya presentasi progress dimatikan (langsung info "sedang bekerja" → hasil).
 */
import { getWorkSettings, setWorkSettings, resetWorkSettings } from '../../lib/work/work-settings.js'

/** "1000" → "1", "4500" → "4.5" (detik, ringkas). */
function fmtSec(ms) {
    const s = ms / 1000
    return Number.isInteger(s) ? String(s) : String(Math.round(s * 10) / 10)
}

function buildPanel(s) {
    return [
        '🛠️ *WORK SETTINGS* (global — semua user)',
        '━━━━━━━━━━━━━━━━━━━━',
        `🎛️ Mode UI : *${s.mode === 'fast' ? 'FAST — sederhana, langsung hasil' : 'FULL — progress animasi'}*`,
        `⏱️ Jeda/step : *${fmtSec(s.minDelayMs)}-${fmtSec(s.maxDelayMs)} detik*`,
        `📊 Jumlah step : *${s.minSteps}-${s.maxSteps}*`,
        '',
        'Ubah:',
        '• *.workset mode fast* / *.workset mode full*',
        '• *.workset delay <min> <max>* — detik (0.2-60)',
        '• *.workset steps <min> <max>* — jumlah (1-25)',
        '• *.workset reset* — default config',
    ].join('\n')
}

export default {
    name: 'workset',
    description: 'Pengaturan .work: mode UI fast/full + kecepatan & jumlah progress (owner)',
    category: 'owner',
    owner: true,
    usage: '.workset [mode fast|full | delay min max | steps min max | reset]',

    async execute(ctx) {
			const _pfx = (typeof ctx !== 'undefined' && ctx?.prefix) || ''
        const { args, db } = ctx
        const sub = String(args?.[0] || '').trim().toLowerCase()

        // ---- panel ----
        if (!sub) {
            return ctx.reply(buildPanel(getWorkSettings(db)))
        }

        // ---- reset ----
        if (sub === 'reset') {
            const s = resetWorkSettings(db)
            return ctx.reply(`✅ Setelan ${_pfx}work direset ke default config.\n\n${buildPanel(s)}`)
        }

        // ---- mode UI ----
        if (sub === 'mode') {
            const mode = String(args?.[1] || '').trim().toLowerCase()
            if (mode !== 'fast' && mode !== 'full') {
                return ctx.reply(
                    `❌ Pakai: *${_pfx}workset mode fast* (UI sederhana — langsung hasil) ` +
                    `atau *${_pfx}workset mode full* (progress animasi).`
                )
            }
            const r = setWorkSettings(db, { mode })
            if (!r.ok) return ctx.reply(`❌ ${r.error}`)
            return ctx.reply(mode === 'fast'
                ? `✅ Mode *FAST* aktif — ${_pfx}work kini: info "sedang bekerja" → langsung kartu hasil sederhana.`
                : `✅ Mode *FULL* aktif — ${_pfx}work kini pakai progress animasi (bar + event + 99% menyelesaikan pekerjaan).`
            )
        }

        // ---- delay (detik) / steps ----
        if (sub === 'delay' || sub === 'steps') {
            const a = Number(args?.[1])
            const b = Number(args?.[2])
            if (!Number.isFinite(a) || !Number.isFinite(b)) {
                return ctx.reply(sub === 'delay'
                    ? `❌ Format: *${_pfx}workset delay <min> <max>* (detik). Contoh: *${_pfx}workset delay 1 5*`
                    : `❌ Format: *${_pfx}workset steps <min> <max>*. Contoh: *${_pfx}workset steps 5 8*`
                )
            }
            const patch = sub === 'delay'
                ? { minDelayMs: Math.round(a * 1000), maxDelayMs: Math.round(b * 1000) }
                : { minSteps: Math.round(a), maxSteps: Math.round(b) }
            const r = setWorkSettings(db, patch)
            if (!r.ok) return ctx.reply(`❌ ${r.error}`)
            const s = r.settings
            return ctx.reply(sub === 'delay'
                ? `✅ Jeda progress: *${fmtSec(s.minDelayMs)}-${fmtSec(s.maxDelayMs)} detik* per update.`
                : `✅ Jumlah step progress: *${s.minSteps}-${s.maxSteps}*.`
            )
        }

        return ctx.reply(`Sub-command tidak dikenal: *${sub}*.\n\n${buildPanel(getWorkSettings(db))}`)
    },
}
