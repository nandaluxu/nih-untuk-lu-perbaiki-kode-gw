/**
 * .stats — command analytics (§14-F, owner-only).
 *
 *   .stats commands       → top command + success/fail/rate-limit + latency
 *   .stats recent         → 15 event eksekusi terakhir
 *   .stats economy        → audit log economy terakhir (dari EconomyService)
 *
 * Data dari lib/cmd-stats.js (bounded in-memory) + store.economy_log.
 */
import { getCommandStats } from '../../lib/command/cmd-stats.js'

export default {
        name: 'stats',
        description: 'Statistik pemakaian command & audit economy',
        category: 'owner',
        usage: '.stats [commands|recent|economy]',
        owner: true,

        async execute(ctx) {
                const sub = String(ctx.args[0] || 'commands').toLowerCase()

                if (sub === 'economy') {
                        const log = Array.isArray(ctx.db?.data?.economy_log) ? ctx.db.data.economy_log : []
                        if (!log.length) return ctx.reply('Audit log economy kosong.')
                        const lines = ['*Economy audit log* (terbaru dulu, maks 20)']
                        for (const e of log.slice(-20).reverse()) {
                                lines.push(
                                        `• ${e.ts.slice(5, 16)} [${e.txId}] ${e.action} ${e.actor}` +
                                        `${e.amount != null ? ` amt=${e.amount}` : ''}` +
                                        `${e.before != null ? ` (${e.before}→${e.after})` : ''}` +
                                        `${e.target ? ` → ${e.target}` : ''}`
                                )
                        }
                        return ctx.reply(lines.join('\n'))
                }

                if (sub === 'recent') {
                        const events = getCommandStats().recent(15).reverse()
                        if (!events.length) return ctx.reply('Belum ada event command.')
                        const lines = ['*Event terakhir*']
                        for (const e of events) {
                                lines.push(`• ${e.ok ? '✅' : '❌'} ${e.command} — ${e.ms}ms${e.reason ? ` (${e.reason})` : ''}`)
                        }
                        return ctx.reply(lines.join('\n'))
                }

                // default: commands
                const rows = getCommandStats().top(15)
                if (!rows.length) {
                        return ctx.reply('Statistik kosong — belum ada command dieksekusi sejak restart.')
                }
                const lines = ['*Top command* (sejak restart)']
                lines.push('```')
                lines.push('cmd           total  ok  fail  r-lim  avg')
                lines.push('──────────────────────────────────────────')
                for (const r of rows) {
                        lines.push(
                                r.command.padEnd(13).slice(0, 13) +
                                String(r.total).padStart(5) +
                                String(r.success).padStart(5) +
                                String(r.fail).padStart(5) +
                                String(r.rejected).padStart(6) +
                                String(r.avgMs + 'ms').padStart(7)
                        )
                }
                lines.push('```')
                await ctx.reply(lines.join('\n'))
        },
}
