/**
 * .untrust — Cabut izin chat pribadi (owner only).
 *
 *   .untrust @tag
 *   .untrust 628xxxxxxxxxx
 *   .untrust (reply pesan user)
 *
 * CATATAN: plugin terpisah dari .trust — parser me-resolve alias ke nama
 * kanonik, jadi cabang "untrust" TIDAK BISA hidup di plugin trust
 * (pelajaran dari bug .unmute).
 */
import { resolveTargetJid, removeTrust, isTrusted } from '../../lib/features/antipm.js'
import { fmtJid } from '../../lib/command/group-utils.js'

export default {
    name: 'untrust',
    description: 'Cabut izin chat pribadi user',
    category: 'owner',
    usage: '.untrust @tag|nomor',
    owner: true,

    async execute(ctx) {
			const _pfx = (typeof ctx !== 'undefined' && ctx?.prefix) || ''
        const { args, mentionedJid, quoted, reply, db } = ctx

        const target = resolveTargetJid({ mentionedJid, args, quoted })
        if (!target) {
            return reply(`❌ Tag user atau tulis nomornya.\nContoh: *${_pfx}untrust @tag* atau *${_pfx}untrust 628xxxxxxxxxx*`)
        }

        if (!isTrusted(db, [target])) {
            return reply(`ℹ️ ${fmtJid(target)} tidak ada di daftar trust.`)
        }

        removeTrust(db, target)
        return reply(`✅ *Trust dicabut:* ${fmtJid(target)}\nKalau anti PM ON, PM dari user ini akan diblokir.`)
    },
}
