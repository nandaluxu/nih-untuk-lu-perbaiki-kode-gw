/**
 * .unblock — Buka blokir user (owner only).
 *
 *   .unblock @tag
 *   .unblock 628xxxxxxxxxx
 *   .unblock (reply pesan user)
 *
 * Aksi: sock.updateBlockStatus(jid, 'unblock') + hapus catatan db.
 */
import { resolveTargetJid, removeBlockedRecord, addTrust } from '../../lib/features/antipm.js'
import { fmtJid } from '../../lib/command/group-utils.js'

export default {
    name: 'unblock',
    description: 'Buka blokir user (WA unblock + hapus catatan db)',
    category: 'owner',
    usage: '.unblock @tag|nomor',
    owner: true,

    async execute(ctx) {
			const _pfx = (typeof ctx !== 'undefined' && ctx?.prefix) || ''
        const { sock, args, mentionedJid, quoted, reply, db, sender } = ctx

        const target = resolveTargetJid({ mentionedJid, args, quoted })
        if (!target) {
            return reply(`❌ Tag user atau tulis nomornya.\nContoh: *${_pfx}unblock @tag* atau *${_pfx}unblock 628xxxxxxxxxx*`)
        }

        try {
            await sock.updateBlockStatus(target, 'unblock')
        } catch (e) {
            return reply(`❌ Gagal membuka blokir di WhatsApp: ${e?.message || e}`)
        }

        const removed = removeBlockedRecord(db, target)
        // buka blokir → user belum tentu bisa PM kalau antipm ON; tambah trust
        // supaya langsung diperbolehkan (kalau antipm off, trust tidak berpengaruh)
        if (db.data.global_settings?.antipm?.enabled) {
            addTrust(db, target, sender)
        }

        return reply(
            `✅ *Blokir dibuka:* ${fmtJid(target)}` +
                (removed ? '\nCatatan db dihapus.' : '\n(Tidak ada catatan db sebelumnya)') +
                (db.data.global_settings?.antipm?.enabled ? '\nUser otomatis di-trust (anti PM aktif).' : '')
        )
    },
}
