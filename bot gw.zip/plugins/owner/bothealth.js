/**
 * .bothealth — ringkasan kesehatan bot untuk OWNER (major improvement).
 *
 * Berbeda dari .status (versi publik + .status full):
 *   • kini owner-only (tidak bisa dipakai user biasa sama sekali);
 *   • fokus metrik operasional: uptime, memory, jumlah plugin, status
 *     koneksi, JUMLAH ERROR + LATENCY rata-rata per command (cmd-stats),
 *     semua dalam satu tampilan ringkas.
 *
 * Sumber data — seluruhnya infrastruktur RESMI yang sudah ada:
 *   • process.uptime()/memoryUsage() (Node builtin);
 *   • lib/health.js getHealth() (subsystem: DATABASE/AI/WHATSAPP/...);
 *   • lib/connection-lifecycle.js getLifecycleSnapshot() (online/offline);
 *   • lib/cmd-stats.js getCommandStats() (fail/latency — bounded memory);
 *   • pluginLoader.registry.size (jumlah plugin termuat).
 *
 * TIDAK menampilkan: credential, API key, environment variable, isi
 * session, path file, konfigurasi secret. Semua angka metrik saja.
 */
import os from 'os'
import { getHealth } from '../../lib/features/health.js'
import { getCommandStats } from '../../lib/command/cmd-stats.js'
import { getLifecycleSnapshot } from '../../lib/features/connection-lifecycle.js'
import { getSendFenceStats } from '../../lib/messaging/send-fence.js'

function fmtUptime(ms) {
        const s = Math.floor(ms / 1000)
        const d = Math.floor(s / 86400)
        const h = Math.floor((s % 86400) / 3600)
        const m = Math.floor((s % 3600) / 60)
        if (d) return `${d} hari ${h} jam ${m} mnt`
        if (h) return `${h} jam ${m} mnt`
        return `${m} mnt ${s % 60} dtk`
}

function fmtBytes(n) {
        if (!Number.isFinite(n)) return '?'
        const units = ['B', 'KB', 'MB', 'GB']
        let i = 0
        while (n >= 1024 && i < units.length - 1) { n /= 1024; i++ }
        return `${n.toFixed(1)}${units[i]}`
}

export default {
        name: 'bothealth',
        aliases: ['botstats'],
        description: 'Kesehatan bot (uptime, memory, error, latency) — owner only',
        category: 'owner',
        usage: '.bothealth',
        example: ['.bothealth'],
        owner: true,

        async execute(ctx) {
                const { pluginLoader } = ctx

                const health = getHealth()
                const lc = getLifecycleSnapshot()
                const stats = getCommandStats()

                // ---- Command stats: total/fail/error + latency agregat ----
                const top = stats.top(1000)
                const totalCalls = top.reduce((a, r) => a + r.total, 0)
                const totalFail = top.reduce((a, r) => a + r.fail + r.rejected, 0)
                const totalMs = top.reduce((a, r) => a + r.avgMs * r.total, 0)
                const avgLatency = totalCalls ? Math.round(totalMs / totalCalls) : null
                const failRate = totalCalls ? ((totalFail / totalCalls) * 100).toFixed(1) : '0.0'
                const worst = [...top].sort((a, b) => (b.fail / Math.max(1, b.total)) - (a.fail / Math.max(1, a.total)) || b.fail - a.fail)[0] || null

                // ---- Send fence: trip = koneksi zombie ----
                const fence = (() => { try { return getSendFenceStats(ctx.sock) } catch { return null } })()

                const mem = process.memoryUsage()
                const lines = []

                lines.push('🩺 *BOT HEALTH* (owner)')
                lines.push('━━━━━━━━━━━━━━━━━━')

                // Uptime & resources
                lines.push(`⏱️ Uptime: *${fmtUptime(process.uptime() * 1000)}*`)
                lines.push(`🧠 Memory: rss *${fmtBytes(mem.rss)}* • heap ${fmtBytes(mem.heapUsed)}/${fmtBytes(mem.heapTotal)}`)
                lines.push(`⚙️ Load: ${os.loadavg().map(x => x.toFixed(2)).join(' / ')} (${os.cpus().length} core) • Node ${process.version}`)

                // Plugins
                const registry = pluginLoader?.registry
                if (registry) {
                        const cats = new Set()
                        for (const [, p] of registry) cats.add(p.category || 'other')
                        lines.push(`🧩 Plugin: *${registry.size}* (${cats.size} kategori)`)
                }

                // Koneksi
                lines.push(`📡 Koneksi: ${lc.online ? '🟢 ONLINE' : '🔴 OFFLINE'}${lc.onlineAt ? ` — ${fmtUptime(Date.now() - lc.onlineAt)} sejak online` : ''}`)
                if (lc.offlineAt) {
                        lines.push(`   ⚠️ Offline terakhir: ${fmtUptime(Date.now() - lc.offlineAt)} lalu${lc.lastReason ? ` (${lc.lastReason})` : ''}`)
                }
                if (fence) {
                        lines.push(`🚧 Send fence: ${fence.trips} trip${fence.trips ? ' ⚠️ (kirim sempat menggantung)' : ' — bersih'}`)
                }

                // Eksekusi & error
                lines.push('')
                lines.push('*Eksekusi (sejak restart):*')
                lines.push(`📊 Total: ${totalCalls.toLocaleString('id-ID')} • Gagal/reject: ${totalFail.toLocaleString('id-ID')} (${failRate}%)`)
                if (avgLatency != null) lines.push(`⚡ Latency rata-rata: *${avgLatency}ms*`)
                if (worst && worst.fail > 0) {
                        lines.push(`🔺 Paling sering gagal: ${worst.command} (${worst.fail}/${worst.total})`)
                }

                // Subsystem health (ringkas)
                lines.push('')
                lines.push('*Subsystem:*')
                for (const [name, st] of Object.entries(health.snapshot())) {
                        const mark = st.status === 'HEALTHY' ? '✅' : st.status === 'DEGRADED' ? '⚠️' : '❌'
                        lines.push(`${mark} ${name}${st.detail ? ` — ${st.detail}` : ''}`)
                }

                return ctx.reply(lines.join('\n'))
        }
}
