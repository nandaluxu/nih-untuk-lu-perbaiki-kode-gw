/**
 * .selfmode — lockdown: bot HANYA bisa dipakai owner + co-owner.
 *
 * SEJARAH JUJUR (Task 18): versi lama command ini (plugins_archive/selfmode.js)
 * hanya men-toggle SELF= di .env — flag yang konsumennya cuma filter fromMe di
 * handler. "selfmode on" TIDAK pernah merestrict user lain, walau balasannya
 * mengklaim "Hanya owner & co-owner yang bisa menggunakan command". Setelah
 * fase-3 (fromMe selalu diproses), flag itu mati total → command jadi dead
 * toggle → sempat di-tombstone. Implementasi BARU ini benar-benar melakukan
 * apa yang diklaimnya:
 *
 *   ON  → pesan non-privileged (bukan owner / co-owner) diabaikan total oleh
 *         bot: tidak ada command, AI, game, moderasi, read receipt, dan tidak
 *         ada pesan keluar apa pun. Data statistik tetap tercatat senyap
 *         (pola light path mutegc). Persist di global_settings → selamat
 *         restart (tidak lagi nulis file .env saat runtime).
 *   OFF → semua kembali normal.
 *
 * Gate di bot.js (setelah gate mutegc). Penentuan privileged di
 * lib/selfmode.js — rantai resolve identik dengan handler.js supaya
 * co-owner tidak pernah salah diabaikan (LID↔PN, role repo, fromMe).
 */
import { isSelfModeOn, setSelfMode } from '../../lib/features/selfmode.js'

export default {
        name: 'selfmode',
        description: 'Lockdown bot: hanya owner & co-owner yang bisa memakai bot',
        category: 'owner',
        usage: '.selfmode on|off|status',
        owner: true,

        async execute(ctx) {
                const { args, reply, prefix } = ctx
                const action = (args[0] || '').toLowerCase()

                if (action === 'on') {
                        setSelfMode(true)
                        return reply(
                                '🔒 *Self mode DI AKTIFKAN.*\n' +
                                'Hanya *owner* & *co-owner* yang bisa memakai bot.\n' +
                                'Pesan user lain diabaikan total (statistik tetap dicatat senyap).\n' +
                                `Matikan dengan: ${prefix}selfmode off`
                        )
                }

                if (action === 'off') {
                        setSelfMode(false)
                        return reply(
                                '🔓 *Self mode DI NONAKTIFKAN.*\n' +
                                'Semua user kembali bisa memakai bot.'
                        )
                }

                // tanpa argumen / 'status' → tampilkan status
                const on = isSelfModeOn()
                return reply(
                        `Self mode: ${on ? '🔒 AKTIF — hanya owner & co-owner' : '🔓 MATI — semua user bisa memakai bot'}\n` +
                        `Format: ${prefix}selfmode on|off`
                )
        }
}
