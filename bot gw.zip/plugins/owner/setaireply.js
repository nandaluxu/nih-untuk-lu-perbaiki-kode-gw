import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import {
    AI_CHAR_STYLES, getCharacters, getAiCharStyle, setAiCharStyle,
    getAiCharStyleForChat, setAiCharStyleForChat, listChatOverrides,
    isCharDisabled, setCharDisabled, rescanCharacters,
} from '../../lib/ai-characters/engine.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
const TEMPLATE_FILE = path.join(__dirname, 'CONTOH-WAIFU.txt')

const SCOPE_LOCAL = new Set(['group', 'grup', 'here', 'chat', 'local'])

export default {
    name: 'setaireply',
    aliases: ['setaichar', 'setanimeai'],
    description: 'Atur style balasan & karakter AI anime — universal (owner)',
    category: 'owner',
    owner: true,
    usage: '.setaireply [1-6 [group] | reset group | listchat | on/off <nama> | rescan | contoh | lupa <nama>]',

    async execute(ctx) {
        const { args, reply, db, sock, chat, message: m } = ctx
        const _pfx = (typeof ctx !== 'undefined' && ctx?.prefix) || '.'
        const argList = (args || []).map(a => String(a || '').trim()).filter(Boolean)
        const requested = argList[0]

        if (!requested) {
            const chars = await getCharacters(true)
            return reply(buildStatus(db, _pfx, chars, chat))
        }

        if (requested.toLowerCase() === 'rescan') {
            const chars = await rescanCharacters()
            return reply(`🔄 Scan ulang selesai — *${chars.length}* karakter aktif:\n` +
                    (chars.map(c => `• ${c.id} — ${c.character.displayName}`).join('\n') || '(kosong)'))
        }

        if (requested.toLowerCase() === 'contoh' || requested.toLowerCase() === 'template') {
            let tpl
            try { tpl = fs.readFileSync(TEMPLATE_FILE, 'utf8') } catch { /* file hilang → fallback teks */ }
            if (tpl) {
                await sock.sendMessage(chat, {
                    document: Buffer.from(tpl, 'utf8'),
                    mimetype: 'text/javascript',
                    fileName: 'waifu-baru.js',
                    caption: `📘 *TEMPLATE WAIFU BARU* — tinggal 4 langkah:\n` +
                            `1. Download file ini, edit bagian yang ada tanda // ← GANTI\n` +
                            `2. Nama file = nama karakter (huruf kecil, tanpa spasi)\n` +
                            `3. Salin isinya ke chat, lalu reply pesan itu: *${_pfx}addplugin aianime/<nama>.js*\n` +
                            `4. Selesai — langsung bisa di-chat tanpa restart (atau ${_pfx}setaireply rescan)`,
                }, { quoted: m }).catch(() => {})
                return reply(`📘 Template dikirim ✓\nAtau ketik manual — format minimal:\n\`\`\`\nexport default {\n  name: 'namaWaifu',\n  aliases: ['panggilanLain'],\n  character: {\n    displayName: 'Nama Lengkap',\n    images: ['https://link-gambar.jpg'],\n    prompt: 'Kamu adalah … (kepribadian & cara bicara)',\n  },\n}\n\`\`\`\nTaruh di plugins/aianime/ → kebaca otomatis.`)
            }
        }

        if (requested.toLowerCase() === 'lupa' || requested.toLowerCase() === 'forget') {
            const name = argList[1]
            if (!name) {
                return reply(`Format: *${_pfx}setaireply lupa <nama karakter>*\nContoh: *${_pfx}setaireply lupa miku* (hapus ingatannya di chat ini)`)
            }
            const c = await getCharacters(true).then(cs => cs.find(x => x.id === name.toLowerCase()))
            if (!c) return reply(`❌ Karakter *${name}* tidak ditemukan.`)
            try {
                const map = db?.data?.ai_char?.memory
                if (map && typeof map === 'object') {
                    const key = `${chat}|${c.id}`
                    delete map[key]
                    db.writeDirty?.('ai_char')
                    return reply(`🧹 Ingatan *${c.character.displayName}* di chat ini dihapus — dia mulai bersih lagi.`)
                }
            } catch { /* db aneh → jatuh ke jawaban standar */ }
            return reply(`ℹ️ *${c.character.displayName}* tidak punya ingatan tersimpan di chat ini.`)
        }

        if (requested.toLowerCase() === 'listchat' || requested.toLowerCase() === 'listoverride' || requested.toLowerCase() === 'listoverrides') {
            const map = listChatOverrides(db)
            const entries = Object.entries(map)
            if (!entries.length) {
                return reply(`📋 Belum ada chat yang punya style khusus.\nSemua chat pakai style *global* (${getAiCharStyle(db)} — ${AI_CHAR_STYLES[getAiCharStyle(db)]}).`)
            }
            const lines = entries.map(([jid, s]) =>
                `• ${jid}\n  → *${s}* (${AI_CHAR_STYLES[s] || '?'})`)
            return reply(
                `📋 *Chat dengan style override* (${entries.length}):\n` +
                lines.join('\n') +
                `\n\nHapus override 1 chat: kirim *${_pfx}setaireply reset group* di chat itu.`)
        }

        const style = Number(requested)
        if (Number.isInteger(style)) {
            const scope = String(argList[1] || '').toLowerCase()
            const isLocal = SCOPE_LOCAL.has(scope)

            if (isLocal) {
                if (!setAiCharStyleForChat(db, chat, style)) {
                    return reply(
                        `Style tidak valid: *${requested}*.\n` +
                        `Pilihan: ${Object.keys(AI_CHAR_STYLES).map(n => `*${n}* (${AI_CHAR_STYLES[n]})`).join(' · ')}.\n` +
                        `Contoh: *${_pfx}setaireply 3 group*`)
                }
                return reply(
                    `✅ Style balasan di chat *ini* diganti ke *${style} — ${AI_CHAR_STYLES[style]}*.\n` +
                    `Chat lain tetap pakai setting masing-masing (atau global *${getAiCharStyle(db)}*).\n` +
                    `Hapus override: *${_pfx}setaireply reset group*`)
            }

            if (!setAiCharStyle(db, style)) {
                return reply(
                        `Style tidak valid: *${requested}*.\n` +
                        `Pilihan: ${Object.keys(AI_CHAR_STYLES).map(n => `*${n}* (${AI_CHAR_STYLES[n]})`).join(' · ')}.\n` +
                        `Contoh: *${_pfx}setaireply 2* (global) atau *${_pfx}setaireply 3 group* (chat ini)`)
            }
            return reply(
                    `✅ Style balasan AI anime diganti ke *${style} — ${AI_CHAR_STYLES[style]}* (global, semua karakter).\n` +
                    `Mau khusus chat ini saja? Pakai *${_pfx}setaireply ${style} group*.\n` +
                    (style === 2 ? 'Preview card kadang cuma muncul di sebagian HP — gagal kirim otomatis jadi teks biasa.\n' : '') +
                    (style === 4 ? 'Balasan AI tampil sebagai kartu katalog (orderMessage) + gambar karakter — reply balasannya untuk lanjut chat.\n' : '') +
                    (style === 5 ? 'Balasan AI dikirim sebagai gambar karakter + caption teks biasa.\n' : '') +
                    (style === 6 ? 'Balasan AI tampil sebagai kartu KATALOG PRODUK (pola crm "My Bini") — gambar karakter ter-upload ke server WA + jawaban AI jadi deskripsi kartu. Reply balasannya untuk lanjut chat.\n' : '') +
                    `Coba chat sama karakternya buat liat hasilnya.`)
        }

        const action = requested.toLowerCase()
        if (action === 'on' || action === 'off') {
            const name = argList[1]
            if (!name) {
                return reply(`Format: *${_pfx}setaireply ${action} <nama karakter>*\nContoh: *${_pfx}setaireply off miku*`)
            }
            const ok = await setCharDisabled(db, name, action === 'off')
            if (!ok) {
                const chars = await getCharacters(true)
                return reply(`❌ Karakter *${name}* tidak ditemukan.\n` +
                        `Yang ada: ${chars.map(c => c.id).join(', ') || '(kosong)'}`)
            }
            return reply(action === 'off'
                    ? `😴 Karakter *${name}* dimatikan — trigger & reply-nya diabaikan.`
                    : `✅ Karakter *${name}* diaktifkan lagi.`)
        }

        if (action === 'reset') {
            const scope = String(argList[1] || '').toLowerCase()
            if (SCOPE_LOCAL.has(scope)) {
                const had = getAiCharStyleForChat(db, chat) !== getAiCharStyle(db)
                setAiCharStyleForChat(db, chat, null)
                const g = getAiCharStyle(db)
                return reply(had
                    ? `↩️ Override style chat ini dihapus — balik pakai style *global* (*${g} — ${AI_CHAR_STYLES[g]}*).`
                    : `ℹ️ Chat ini memang tidak punya override — tetap pakai style *global* (*${g} — ${AI_CHAR_STYLES[g]}*).`)
            }
            return reply(`Format: *${_pfx}setaireply reset group* — hapus style khusus chat ini (balik ke global).`)
        }

        return reply(`Argumen tidak dikenal: *${requested}*.\n\n` +
                buildStatus(db, _pfx, await getCharacters(true), chat))
    },
}

function buildStatus(db, pfx, chars, chat) {
    const globalStyle = getAiCharStyle(db)
    const hereStyle = chat ? getAiCharStyleForChat(db, chat) : globalStyle
    const overridden = chat ? hereStyle !== globalStyle : false

    const styleLines = Object.entries(AI_CHAR_STYLES)
            .map(([n, label]) => {
                const marks = []
                if (Number(n) === globalStyle) marks.push('🌐 global')
                if (overridden && Number(n) === hereStyle) marks.push('✅ chat ini')
                else if (!overridden && Number(n) === globalStyle) marks.push('✅ aktif')
                return `• *${n}* — ${label}${marks.length ? ' — ' + marks.join(', ') : ''}`
            })

    const charLines = chars.length
            ? chars.map(c => {
                    const hasMem = (() => {
                        try {
                            const map = db?.data?.ai_char?.memory
                            if (!map || typeof map !== 'object') return false
                            return Object.keys(map).some(k => k.endsWith(`|${c.id}`) && map[k]?.summary)
                        } catch { return false }
                    })()
                    return `• *${c.id}* — ${c.character.displayName}${isCharDisabled(db, c.id) ? ' 😴 (off)' : ' ✅'}${hasMem ? ' 🧠 (punya ingatan)' : ''}`
            }).join('\n')
            : '(belum ada — taruh 1 file .js per karakter di plugins/aianime/)'

    const overrideLine = overridden
            ? `\n⚠️ Chat ini punya override sendiri: *${hereStyle} — ${AI_CHAR_STYLES[hereStyle]}* (global *${globalStyle}*).\n`
            : ''

    return (
            `🤖 *AI ANIME CHARACTERS* — pengaturan (owner)\n\n` +
            `*Style balasan:*\n${styleLines.join('\n')}\n` +
            overrideLine +
            `\n*Karakter* (${chars.length}):\n${charLines}\n\n` +
            `Ganti global (semua chat): *${pfx}setaireply 2*\n` +
            `Ganti KHUSUS chat ini: *${pfx}setaireply 3 group*\n` +
            `Hapus override chat ini: *${pfx}setaireply reset group*\n` +
            `Lihat daftar override: *${pfx}setaireply listchat*\n` +
            `On/off karakter: *${pfx}setaireply off miku*\n` +
            `Nambah waifu: *${pfx}setaireply contoh* (template siap edit)\n` +
            `Hapus ingatan karakter di chat ini: *${pfx}setaireply lupa miku*\n` +
            `Cara chat: sebut nama karakter di awal pesan, *.nama <chat>*, atau reply pesan AI untuk lanjut sesi.`
    )
}