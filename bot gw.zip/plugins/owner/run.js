/**
 * plugins/owner/run.js — .run (Task 53): JALANKAN kode JS dari document
 * yang di-reply, langsung di dalam bot.
 *
 * Keluhan/asal: hasil .crm berupa file .js berisi panggilan
 * sock.relayMessage(jid, payload, {}) — owner harus copy-paste manual ke
 * console/VPS buat nyobain. Sekarang: cukup REPLY document .js-nya dan
 * ketik .run — kodenya dieksekusi di process bot yang sama.
 *
 * Sumber kode (urutan):
 *   1. documentMessage yang di-reply (.js / .txt / apapun — isinya dibaca
 *      sebagai teks; fileName ditampilkan sebagai info)
 *   2. teks pesan yang di-reply (kode diketik/kopi langsung di chat)
 *
 * Sandbox eksekusi — variabel yang tersedia di kode:
 *   sock / conn — socket baileys (sama; bot lain pakai conn → ganti nama)
 *   m           — pesan owner (m.chat = chat tujuan, persis template crm:
 *                 "const jid = m.chat; await sock.relayMessage(jid, …)")
 *   db, ctx     — store & context command (reply() tersedia via ctx)
 *   await       — top-level await boleh (AsyncFunction)
 * Timeout 60s (fence) — kode macet → dibatalkan + lapor, tidak gantung bot.
 * console.log/warn/error DI DALAM kode ditangkap & dilaporkan di balasan.
 * Owner-only (metadata owner:true — gate handler), maks 512KB.
 *
 * Contoh pakai:
 *   .crm (reply pesan katalog)  → dapet document crm-productMessage-xxx.js
 *   .run  (reply document itu)  → payload crm dikirim ulang ke chat ini
 */
import { extractQuotedRawMessage, findMediaInContainer, downloadMediaContent } from '../../lib/media/media.js'
import { withTimeout } from '../../lib/core/async-utils.js'
import logger from '../../lib/core/logger.js'

/** Fence total eksekusi kode (env RUN_TIMEOUT_MS utk test). */
const RUN_TIMEOUT_MS = (() => {
        const n = Number(process.env.RUN_TIMEOUT_MS)
        return Number.isFinite(n) && n > 0 ? n : 60_000
})()
/** Maks ukuran kode. */
const CODE_MAX_BYTES = 512_000

export default {
        name: 'run',
        aliases: ['runjs', 'evaldoc'],
        description: 'Jalankan kode JS dari document/teks yang di-reply (owner)',
        category: 'owner',
        owner: true,
        usage: '.run (reply document .js atau pesan berisi kode)',

        async execute(ctx) {
                const { sock, chat, message: m, quoted: q, reply, db } = ctx
                const _pfx = ctx?.prefix || '.'

                if (!q && !m?.quoted) {
                        return reply(
                                `▶️ *run — eksekusi kode JS*\n\n` +
                                `Reply *document .js* (mis. hasil *${_pfx}crm*) atau pesan berisi kode, lalu ketik *${_pfx}run*.\n\n` +
                                `Variabel yang tersedia di kode:\n` +
                                `• *sock* / *conn* — socket bot\n` +
                                `• *m* — pesan kamu (*m.chat* = chat tujuan)\n` +
                                `• *db*, *ctx* — database & context\n` +
                                `• *await* boleh · timeout 60s`)
                }

                try { await m?.react?.('⏳') } catch { /* best effort */ }

                // ---- 1) ambil kode: document > teks ----
                let code = null
                let fileName = null
                const container = extractQuotedRawMessage(m, q)
                const found = container ? findMediaInContainer(container) : null
                if (found) {
                        fileName = found.content?.fileName || null
                        const buf = await downloadMediaContent(found.content, found.type)
                        if (buf) code = buf.toString('utf8')
                }
                if (!code) {
                        // fallback: teks pesan yang di-reply (kodenya diketik di chat)
                        code = (typeof q?.text === 'string' && q.text)
                                || q?.message?.conversation
                                || q?.message?.extendedTextMessage?.text
                                || m?.quoted?.text
                                || null
                }

                code = String(code || '').trim()
                if (!code) {
                        try { await m?.react?.('❌') } catch {}
                        return reply('⚠️ Pesan yang di-reply tidak berisi kode (bukan document/teks). Reply document .js hasil crm atau pesan berisi kode, lalu .run lagi.')
                }
                if (Buffer.byteLength(code, 'utf8') > CODE_MAX_BYTES) {
                        try { await m?.react?.('❌') } catch {}
                        return reply(`⚠️ Kode kegedean (>512KB) — tidak dieksekusi.`)
                }

                // ---- 2) tangkap console selama eksekusi ----
                const logs = []
                const pushLog = (prefix, args) => {
                        const line = args.map(a => {
                                if (typeof a === 'string') return a
                                try { return JSON.stringify(a) } catch { return String(a) }
                        }).join(' ')
                        logs.push(`${prefix}${line}`.slice(0, 400))
                        if (logs.length > 40) logs.shift()
                }
                const origLog = console.log, origWarn = console.warn, origErr = console.error
                console.log = (...a) => pushLog('', a)
                console.warn = (...a) => pushLog('⚠️ ', a)
                console.error = (...a) => pushLog('❌ ', a)

                // ---- 3) eksekusi (AsyncFunction = top-level await boleh) ----
                const t0 = Date.now()
                let result, error, timedOut = false
                try {
                        const AsyncFunction = Object.getPrototypeOf(async function () {}).constructor
                        const fn = new AsyncFunction('sock', 'conn', 'm', 'db', 'ctx', code)
                        result = await withTimeout(
                                fn(sock, sock, m, db, ctx),
                                RUN_TIMEOUT_MS,
                                'run-command',
                        )
                } catch (e) {
                        if (e?.timeout || String(e?.message || e).includes('run-command')) timedOut = true
                        error = e
                } finally {
                        console.log = origLog
                        console.warn = origWarn
                        console.error = origErr
                }
                const ms = Date.now() - t0

                // ---- 4) lapor ----
                const header = `▶️ *run* — ${fileName ? `*${fileName}*` : 'kode dari chat'} · ${ms}ms`

                if (timedOut) {
                        try { await m?.react?.('❌') } catch {}
                        return reply(`${header}\n⏱️ Kode macet lebih dari 60 detik — dibatalkan paksa.\n${logsBlock(logs)}`)
                }
                if (error) {
                        try { await m?.react?.('❌') } catch {}
                        logger.warn('[run] eksekusi gagal: %s', error?.stack || error?.message || error)
                        return reply(`${header}\n❌ *Error:*\n\`\`\`\n${String(error?.stack || error?.message || error).slice(0, 1200)}\n\`\`\`${logsBlock(logs)}`)
                }

                try { await m?.react?.('✅') } catch { /* best effort */ }
                const resultBlock = result === undefined
                        ? ''
                        : `\n📤 *Hasil:*\n\`\`\`\n${fmtResult(result)}\n\`\`\``
                return reply(`${header}\n✅ Berhasil dieksekusi.${resultBlock}${logsBlock(logs)}`)
        },
}

/** Blok log console hasil tangkapan (bila ada). */
function logsBlock(logs) {
        if (!logs.length) return ''
        return `\n🖥️ *Console:*\n\`\`\`\n${logs.join('\n').slice(0, 1500)}\n\`\`\``
}

/** Format nilai hasil supaya aman ditampilkan. */
function fmtResult(result) {
        try {
                if (typeof result === 'string') return result.slice(0, 1500)
                if (result && typeof result === 'object') {
                        // WAMessage hasil relay → tampil ringkas
                        if (result.key?.id) {
                                return JSON.stringify({ key: result.key, messageTypes: Object.keys(result.message || {}) }, null, 1).slice(0, 1500)
                        }
                        return JSON.stringify(result, null, 1).slice(0, 1500)
                }
                return String(result).slice(0, 1500)
        } catch {
                return String(result).slice(0, 1500)
        }
}
