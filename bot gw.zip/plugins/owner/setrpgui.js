/**
 * .setrpgui — Ganti template UI RPG (KHUSUS OWNER, berlaku GLOBAL).
 *
 * Task 28 — pola mengikuti .setmenu: owner menyetel SEKALI, berdampak ke
 * SEMUA user & chat; tersimpan di db (global_settings.rpg_ui) dan tetap
 * ada setelah restart.
 *
 *   .setrpgui        → lihat daftar 5 template + yang aktif
 *   .setrpgui 1..5   → ganti template (lihat lib/rpg-ui.js)
 *
 * Setelah ganti, PREVIEW tampilan combat dikirim langsung pakai template
 * barunya (best-effort — bila render gagal, bot otomatis jatuh ke fallback
 * teks dan pesan konfirmasi tetap menyampaikan bahwa fallback terjadi).
 */
import {
    getRpgUi, setRpgUi, buildSetrpguiMenu,
    RPG_UIS, isValidRpgUi,
} from '../../lib/features/rpg-ui.js'
import { sendCombatView, clearCombatEditTarget } from '../../rpg/ui.js'
import { startCombat } from '../../rpg/systems/combat.js'
import logger from '../../lib/core/logger.js'

/** Player contoh untuk preview (read-only — tidak pernah disimpan). */
function previewPlayer() {
    return {
        uid: '__rpgui_preview__',
        name: 'Petualang Contoh',
        level: 5,
        locationId: 'aldoria_forest',
        classId: 'mage',
        skills: { unlocked: ['stab', 'fireball'], mantras: {}, mastery: {} },
        inventory: { stacks: { bread: 2 }, instances: [] },
        equipment: {},
        skillPoints: 1,
        hp: 93,
        mana: 25,
        energy: 60,
    }
}

/**
 * Session contoh (2 musuh — showcase menu multi-target: selection Attack
 * per musuh + skill single-target dengan header mana; read-only, tidak
 * pernah didaftarkan ke SessionManager).
 */
function previewSession(player) {
    return startCombat(player, ['young_wolf', 'young_wolf'], { origin: 'hunt' })
}

function previewText(session) {
    const intro = (session?.units?.enemies || []).map(e => `${e.emoji} *${e.name}* Lv${e.level} muncul!`)
    const a = session?.units?.allies?.[0]
    const status = session
        ? [
            '⚔️ *Giliranmu!* (Ronde 1)',
            '',
            ...session.units.enemies.map((e, i) => `${i + 1}. ${e.emoji} ${e.name} — ❤️ ${e.hp}/${e.maxHp}`),
            '',
            a ? `🧑 Petualang Contoh — ❤️ ${a.hp}/${a.maxHp} · ✨ ${a.mana}/${a.maxMana}` : '',
        ].filter(Boolean).join('\n')
        : ''
    // Guide "Ketik:" tidak ditaruh di sini — ui.js otomatis menambahkannya
    // hanya untuk template teks (UI 1/3); template tombol pakai battle menu.
    return ['⚔️ *COMBAT DIMULAI!*', ...intro, '', status].filter(Boolean).join('\n')
}

export default {
    name: 'setrpgui',
    description: 'Ganti template UI RPG GLOBAL — 5 pilihan tampilan (owner)',
    category: 'owner',
    owner: true,
    usage: '.setrpgui 1|2|3|4|5 (.setrpgui = lihat daftar)',

    async execute(ctx) {
        const { args, db } = ctx
        const pfx = ctx.prefix ?? '.'
        const requested = (args || []).map(a => String(a || '').trim()).filter(Boolean)[0]

        // ---- Tanpa argumen: daftar template + yang aktif ----
        if (!requested) {
            return ctx.reply(buildSetrpguiMenu(getRpgUi(db), pfx))
        }

        // ---- Validasi nomor template ----
        const ui = Number(requested)
        if (!isValidRpgUi(ui) || !setRpgUi(db, ui)) {
            return ctx.reply(
                `Template tidak valid: *${requested}*.\n` +
                `Pilihan: *1* s.d. *5* — ketik *${pfx}setrpgui* tanpa argumen untuk daftar lengkap.`
            )
        }

        // ---- Preview pakai template baru (best-effort) ----
        let previewNote = ''
        try {
            const player = previewPlayer()
            const session = previewSession(player)
            await sendCombatView({
                sock: ctx.sock,
                chat: ctx.chat,
                m: ctx.message,
                player,
                session,
                text: previewText(session),
                phase: 'intro',
                pfx,
                db,
            })
            previewNote = '\nPreview di atas dikirim pakai template barunya.'
        } catch (e) {
            logger.debug('setrpgui preview gagal (ui %s): %s', ui, e.message)
            previewNote = '\n⚠️ Preview gagal dirender di chat ini — RPG tetap memakai template ini dengan fallback teks bila perlu.'
        } finally {
            clearCombatEditTarget('__rpgui_preview__')
        }

        return ctx.reply(
            `✅ Template UI RPG GLOBAL diganti ke *${ui} — ${RPG_UIS[ui]}*.${previewNote}\n` +
            `Semua pesan RPG (semua user & chat) sekarang tampil dengan template ini — persist setelah restart.`
        )
    },
}
