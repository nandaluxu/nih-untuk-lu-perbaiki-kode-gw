/**
 * .plugincheck — diagnostics plugin (§14-C, owner-only).
 *
 * Memeriksa registry + source file plugin:
 *  - duplicate command/alias antar plugin
 *  - unknown metadata (re-run validator loader terhadap registry hidup)
 *  - description/usage kosong
 *  - alias tidak valid (bukan a-z0-9-_)
 *  - cross-plugin import (plugin meng-import plugin lain = rapuh)
 *  - kecurigaan hardcoded prefix ('.command' di source, command resmi)
 *
 * Source code TIDAK dikirim ke chat — hanya ringkasan + nama file.
 */
import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import { unknownMetaKeys, findPluginsDir, listPluginFiles } from '../../lib/command/plugin-loader.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
// Location-agnostic (Task 30) + scan REKURSIF subfolder kategori
const PLUGINS_DIR = findPluginsDir(__dirname) || path.join(process.cwd(), 'plugins')

export default {
        name: 'plugincheck',
        description: 'Diagnostics kesehatan plugin system',
        category: 'owner',
        usage: '.plugincheck',
        owner: true,

        async execute(ctx) {
                const registry = ctx.pluginLoader?.registry
                if (!registry) return ctx.reply('Plugin loader tidak tersedia.')

                const problems = []
                const warn = []

                // ---- 1. Duplikat command/alias ----
                const owner = new Map() // nama/alias → plugin pertama pemiliknya
                for (const [name, p] of registry) {
                        const keys = [name, ...(p.aliases || [])]
                        for (const k of keys) {
                                if (owner.has(k) && owner.get(k).name !== name) {
                                        problems.push(`Duplikat "${k}": ${owner.get(k).name} vs ${name}`)
                                } else {
                                        owner.set(k, p)
                                }
                        }
                }

                // ---- 2. Metadata + kualitas per plugin ----
                for (const [name, p] of registry) {
                        const unknown = unknownMetaKeys(p)
                        if (unknown.length) problems.push(`${name}: metadata tidak dikenal [${unknown.join(', ')}]`)
                        if (!p.description) warn.push(`${name}: tanpa description`)
                        if (!p.category) warn.push(`${name}: tanpa category`)
                        for (const a of (p.aliases || [])) {
                                if (!/^[a-z0-9_-]+$/.test(a)) problems.push(`${name}: alias invalid "${a}"`)
                        }
                }

                // ---- 3. Scan source (REKURSIF Task 30): cross-import + hardcoded prefix ----
                let files = []
                try { files = listPluginFiles(PLUGINS_DIR) } catch { /* noop */ }
                const names = new Set([...registry.keys()])
                const crossImports = []
                const hardPrefix = []
                for (const f of files) {
                        let src = ''
                        try { src = fs.readFileSync(path.join(PLUGINS_DIR, f), 'utf8') } catch { continue }
                        const thisName = path.basename(f, '.js')
                        for (const m of src.matchAll(/from\s+['"]\.\.?\/plugins\/([\w-]+)\.js['"]/g)) {
                                crossImports.push(`${thisName} → ${m[1]}`)
                        }
                        for (const n of names) {
                                if (n === thisName) continue
                                const re = new RegExp("['\"`]([^'\"`$]{0,24})\\." + n + "\\b", 'g')
                                let count = 0
                                for (const m of src.matchAll(re)) {
                                        // hanya string; '$' atau '{' sebelum dot = interpolasi — skip
                                        const before = m[1]
                                        if (before.includes('{') || before.endsWith('$')) continue
                                        count++
                                }
                                if (count > 0) hardPrefix.push(`${f}: '${n}' ×${count}`)
                        }
                }

                const lines = ['*PLUGIN CHECK*']
                lines.push(`Registry: ${registry.size} plugin, ${files.length} file`)
                lines.push('')
                lines.push(`❌ *Masalah (${problems.length}):*`)
                lines.push(problems.length ? problems.map(x => `• ${x}`).join('\n') : '• Bersih ✅')
                lines.push('')
                if (crossImports.length) {
                        lines.push(`⚠️ *Cross-plugin import (${crossImports.length}):*`)
                        lines.push(crossImports.slice(0, 10).map(x => `• ${x}`).join('\n'))
                        lines.push('')
                }
                if (hardPrefix.length) {
                        lines.push(`⚠️ *Kecurigaan hardcoded prefix (${hardPrefix.length} file):*`)
                        lines.push(hardPrefix.slice(0, 15).map(x => `• ${x}`).join('\n'))
                        lines.push('')
                }
                lines.push(`ℹ️ *Catatan (${warn.length}):*`)
                lines.push(warn.length ? warn.slice(0, 10).map(x => `• ${x}`).join('\n') : '• Bersih ✅')

                await ctx.reply(lines.join('\n').slice(0, 3500))
        },
}
