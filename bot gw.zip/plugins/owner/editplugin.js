import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import { isSafePluginPath, isValidJavaScript } from '../../lib/core/validators.js'
import { findPluginsDir, resolvePluginFile } from '../../lib/command/plugin-loader.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
// Location-agnostic (Task 30): benar baik file ini di plugins/ root
// maupun di plugins/owner/ — naik sampai ketemu folder "plugins".
const PLUGINS_DIR = findPluginsDir(__dirname) || path.join(__dirname, '..', 'plugins')

function getQuotedText(quoted) {
        if (!quoted) return null
        if (typeof quoted.text === 'string') return quoted.text
        const msg = quoted.message
        if (!msg) return null
        return msg.conversation
                || msg.extendedTextMessage?.text
                || null
}

export default {
        name: 'editplugin',
        description: 'Edit plugin via reply source code baru (cari otomatis walau file di subfolder)',
        category: 'owner',
        usage: '.editplugin nama.js (reply source code)',
        owner: true,

        async execute(ctx) {
                        const _pfx = (typeof ctx !== 'undefined' && ctx?.prefix) || ''
                const filename = ctx.args[0]
                if (!filename) {
                        return ctx.reply(`Masukkan nama file. Contoh: ${_pfx}editplugin halo.js`)
                }

                if (!isSafePluginPath(filename)) {
                        return ctx.reply('Nama file tidak valid. Format: nama.js atau folder/nama.js')
                }

                const source = getQuotedText(ctx.quoted)
                if (!source) {
                        return ctx.reply('Reply pesan yang berisi source code plugin baru.')
                }

                const check = await isValidJavaScript(source)
                if (!check.valid) {
                        return ctx.reply(`Syntax error:\n${check.error}`)
                }

                // Task 30: file bisa di subfolder — "hunt.js" di-resolve ke
                // lokasi aslinya (registry → scan) sebelum ditulis.
                const hits = resolvePluginFile(filename, PLUGINS_DIR, ctx.pluginLoader)
                if (hits.length === 0) {
                        return ctx.reply(`Plugin tidak ditemukan. Gunakan ${_pfx}addplugin untuk menambah.`)
                }
                if (hits.length > 1) {
                        return ctx.reply(`Nama file ambigu (${hits.join(', ')}) — sebutkan foldernya, contoh: ${_pfx}editplugin ${hits[0]}`)
                }
                const target = hits[0]

                const targetPath = path.join(PLUGINS_DIR, target)
                const tmpPath = targetPath + '.tmp'
                try {
                        fs.writeFileSync(tmpPath, source, 'utf8')
                        fs.renameSync(tmpPath, targetPath)
                        ctx.reply(`Plugin *${target}* berhasil diupdate.`)
                } catch (error) {
                        try { fs.unlinkSync(tmpPath) } catch {}
                        ctx.reply(`Gagal mengupdate: ${error.message}`)
                }
        }
}
