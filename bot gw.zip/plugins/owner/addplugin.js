import fs from 'fs'
import path from 'path'
import { fileURLToPath } from 'url'
import { isSafePluginPath, isValidJavaScript } from '../../lib/core/validators.js'
import { findPluginsDir } from '../../lib/command/plugin-loader.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))
// Location-agnostic (Task 30): benar baik file ini di plugins/ root
// maupun di plugins/owner/ — naik sampai ketemu folder "plugins".
const PLUGINS_DIR = findPluginsDir(__dirname) || path.join(__dirname, '..', 'plugins')

function getQuotedText(quoted) {
        // starcore convenience
        if (!quoted) return null
        if (typeof quoted.text === 'string') return quoted.text
        // baileys raw
        const msg = quoted.message
        if (!msg) return null
        return msg.conversation
                || msg.extendedTextMessage?.text
                || null
}

export default {
        name: 'addplugin',
        description: 'Tambah plugin baru via reply source code (boleh subfolder: rpg/baru.js)',
        category: 'owner',
        usage: '.addplugin nama.js | .addplugin rpg/nama.js (reply source code)',
        owner: true,

        async execute(ctx) {
                        const _pfx = (typeof ctx !== 'undefined' && ctx?.prefix) || ''
                const filename = ctx.args[0]
                if (!filename) {
                        return ctx.reply(`Masukkan nama file. Contoh: ${_pfx}addplugin halo.js atau ${_pfx}addplugin rpg/halo.js`)
                }

                if (!isSafePluginPath(filename)) {
                        return ctx.reply('Nama file tidak valid atau mengandung path traversal. Format: nama.js atau folder/nama.js')
                }

                const source = getQuotedText(ctx.quoted)
                if (!source) {
                        return ctx.reply('Reply pesan yang berisi source code plugin.')
                }

                const check = await isValidJavaScript(source)
                if (!check.valid) {
                        return ctx.reply(`Syntax error:\n${check.error}`)
                }

                const targetPath = path.join(PLUGINS_DIR, filename)
                if (fs.existsSync(targetPath)) {
                        return ctx.reply(`Plugin sudah ada. Gunakan ${_pfx}editplugin untuk mengubah.`)
                }

                try {
                        // Subfolder belum ada → dibuat otomatis (Task 30)
                        fs.mkdirSync(path.dirname(targetPath), { recursive: true })
                        fs.writeFileSync(targetPath, source, 'utf8')
                        ctx.reply(`Plugin *${filename}* berhasil ditambahkan${filename.includes('/') ? ' (folder dibuat otomatis)' : ''}.`)
                } catch (error) {
                        ctx.reply(`Gagal menulis file: ${error.message}`)
                }
        }
}
