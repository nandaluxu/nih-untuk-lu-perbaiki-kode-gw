/**
 * .block — Blokir user dari bot (owner only).
 *
 *   .block @tag [alasan]
 *   .block 628xxxxxxxxxx [alasan]
 *   .block (reply pesan user)
 *
 * Aksi: sock.updateBlockStatus(jid, 'block') + catat ke db (global_settings).
 * Jalan TERLEPAS dari toggle .antipm (blokir di level WhatsApp).
 */
import {
    resolveTargetJid,
    addBlockedRecord,
    isBlockedRecord,
    removeTrust,
    getAntipmState,
} from '../../lib/features/antipm.js'
import { jidDigits } from '../../lib/identity/index.js'
import { isOwner } from '../../config/index.js'
import { fmtJid } from '../../lib/command/group-utils.js'

export default {
    name: 'block',
    description: 'Blokir user dari bot (WA block + catatan db)',
    category: 'owner',
    usage: '.block @tag|nomor [alasan]',
    owner: true,

    async execute(ctx) {
			const _pfx = (typeof ctx !== 'undefined' && ctx?.prefix) || ''
        const { sock, args, mentionedJid, quoted, reply, db, sender } = ctx

        const target = resolveTargetJid({ mentionedJid, args, quoted })
        if (!target) {
            return reply(`❌ Tag user atau tulis nomornya.\nContoh: *${_pfx}block @tag* atau *${_pfx}block 628xxxxxxxxxx*`)
        }

        // Lindungi owner & user yang di-trust dari keblokir tak sengaja
        if (isOwner(target)) {
            return reply('❌ Tidak bisa memblokir owner bot.')
        }
        const digits = jidDigits(target)
        if (digits && getAntipmState(db).trusted[digits]) {
            return reply(`❌ User ini ada di daftar trust. Hapus dulu dengan *${_pfx}untrust*.`)
        }

        const restArgs = (mentionedJid?.length ? args.slice(1) : args.slice(0)).filter(Boolean)
        // buang token nomor murni dari sisa args (sisanya = alasan)
        const reason =
            restArgs
                .filter((t) => !/^\+?\d{5,15}$/.test(String(t).trim()))
                .join(' ')
                .trim() || null

        try {
            await sock.updateBlockStatus(target, 'block')
        } catch (e) {
            return reply(`❌ Gagal memblokir di WhatsApp: ${e?.message || e}`)
        }

        const entry = addBlockedRecord(db, target, { by: sender, reason, source: 'manual' })
        // blokir → trust otomatis dicabut
        removeTrust(db, target)

        const existed = isBlockedRecord(db, [target])
        let text = `🚫 *Diblokir:* ${fmtJid(target)}\n` +
            `Sumber: ${existed?.source === 'antipm' ? 'anti PM' : 'manual'}`
        if (entry.reason) text += `\nAlasan: ${entry.reason}`
        return reply(text)
    },
}
