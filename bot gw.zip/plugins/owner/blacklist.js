/**
 * .blacklist — Daftar user yang diblokir (owner only).
 *
 * Sumber: fetchBlocklist() WhatsApp (sumber kebenaran) + catatan db
 * (blokir manual via .block / otomatis via anti PM).
 */
import { listBlockedRecords } from '../../lib/features/antipm.js'
import { fmtJid } from '../../lib/command/group-utils.js'

export default {
    name: 'blacklist',
    aliases: ['blocklist'],
    description: 'Daftar user yang diblokir dari bot',
    category: 'owner',
    usage: '.blacklist',
    owner: true,

    async execute(ctx) {
        const { sock, reply, db } = ctx

        let waList = []
        try {
            const blocked = await sock.fetchBlocklist()
            if (Array.isArray(blocked)) waList = blocked
        } catch {
            // fetch gagal → tetap tampilkan catatan db
        }

        const records = listBlockedRecords(db)

        let text = `🚫 *Blacklist Bot*\n\n`
        text += `*Blokir WhatsApp* (${waList.length}):\n`
        text += waList.length
            ? waList.slice(0, 50).map((j) => `• ${fmtJid(j)}`).join('\n') + '\n'
            : '• (kosong)\n'

        text += `\n*Catatan db* (${records.length}):\n`
        text += records.length
            ? records
                  .slice(0, 50)
                  .map(
                      (b) =>
                          `• ${fmtJid(b.jid || b.digits)} — ${b.source}` +
                          (b.reason ? ` (${b.reason})` : '') +
                          (b.at ? ` · ${String(b.at).slice(0, 10)}` : '')
                  )
                  .join('\n')
            : '• (kosong)'

        return reply(text)
    },
}
