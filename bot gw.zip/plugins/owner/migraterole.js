export default {
    name: 'migraterole',
    aliases: ['migrasirole'],
    description: 'Migrasi & bersihkan data role legacy dari store.json ke user profile',
    category: 'owner',
    usage: '.migraterole',
    owner: true,

    async execute(ctx) {
			const _pfx = (typeof ctx !== 'undefined' && ctx?.prefix) || ''
        const { roleRepo } = ctx

        if (!roleRepo || typeof roleRepo.migrateLegacyRoles !== 'function') {
            return ctx.reply('❌ RoleRepository tidak tersedia di context.')
        }

        // Idempotent: aman dijalankan kapan saja.
        // - Entry legacy yang punya profil  → dipindah ke user profile (users/*.json)
        // - Entry yang sudah punya role     → skip (tidak ditimpa)
        // - Entry tanpa profil              → didrop dari store.json, dibackup dulu
        // - Key roles & plugin_min_roles    → dihapus dari store.json
        const r = roleRepo.migrateLegacyRoles()

        let msg = '🔄 *MIGRASI ROLE LEGACY*\n\n'

        if (r.total === 0 && r.pluginMinRolesRemoved === 0) {
            msg += '✅ store.json sudah bersih — tidak ada data role legacy yang perlu dimigrasi.\n\n'
        } else {
            msg += `📦 Entry legacy ditemukan : *${r.total}*\n`
            msg += `✅ Dipindah ke profil : *${r.migrated}*\n`
            msg += `⏭️ Skip (profil sudah punya role) : *${r.skippedHasRole}*\n`
            msg += `⏰ Expired (dibuang) : *${r.expired}*\n`
            msg += `🗑️ Tanpa profil (didrop) : *${r.droppedNoProfile}*\n`
            msg += `🧹 plugin_min_roles dihapus : *${r.pluginMinRolesRemoved}*\n\n`
        }

        if (r.backupFile) {
            msg += `💾 Backup : ${r.backupFile}\n\n`
        }

        msg += '📌 Role sekarang *HANYA* tersimpan di user profile (users/*.json)\n'
        msg += '📌 store.json tidak lagi dipakai untuk role — fallback legacy sudah dimatikan\n'
        msg += `📌 Cek role user: ${_pfx}profile`

        await ctx.reply(msg)
    }
}
