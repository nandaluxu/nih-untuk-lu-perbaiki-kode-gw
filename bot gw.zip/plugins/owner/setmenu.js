/**
 * .setmenu — Ganti style UI menu bot (KHUSUS OWNER, berlaku GLOBAL).
 *
 * Task 39 — pola mengikuti .setreply: owner menyetel SEKALI, berdampak ke
 * SEMUA user & chat; tersimpan di db (global_settings.menu_style) dan tetap
 * ada setelah restart.
 *
 * Task 29 — style 8 kini NESTED (battle-menu style: tombol kategori →
 * command + gambar, pola testbutton owner); style lama "Teks" pindah ke 9.
 *
 *   .setmenu        → lihat daftar 9 style + yang aktif
 *   .setmenu 1..9   → ganti style (daftar lihat lib/menu-style.js)
 *
 * Setelah ganti, PREVIEW menu dikirim langsung pakai style barunya
 * (best-effort — bila style gagal dirender, bot otomatis jatuh ke fallback
 * dan pesan konfirmasi tetap menyampaikan bahwa fallback terjadi).
 */
import {
    getMenuStyle, setMenuStyle, buildSetmenuMenu, sendMenuByStyle,
    MENU_STYLES, isValidMenuStyle,
} from '../../lib/messaging/menu-style.js'
import config from '../../config/index.js'
import logger from '../../lib/core/logger.js'

export default {
    name: 'setmenu',
    description: 'Ganti style UI menu GLOBAL — 9 pilihan tampilan (owner)',
    category: 'owner',
    owner: true,
    usage: '.setmenu 1|2|3|4|5|6|7|8|9 (.setmenu = lihat daftar)',

    async execute(ctx) {
        const { args, db } = ctx

        // PATCH BUTTON-PREFIX (fase-9, paritas stickerly fase-8): prefix EFEKTIF
        // chat invokasi (ctx.prefix = parsed.usedPrefix) — preview menu yang
        // dikirim setmenu membawa tombol "${pfx}allmenu/..." lewat
        // sendMenuByStyle; prefixManager.get() mengabaikan argumen chat →
        // selalu GLOBAL → tombol preview mati di grup ber-prefix sendiri.
        const pfx = ctx.prefix ?? ''
        const requested = (args || []).map(a => String(a || '').trim()).filter(Boolean)[0]

        // ---- Tanpa argumen: daftar style + yang aktif ----
        if (!requested) {
            const current = getMenuStyle(db)
            return ctx.reply(buildSetmenuMenu(current, pfx))
        }

        // ---- Validasi nomor style ----
        const style = Number(requested)
        if (!isValidMenuStyle(style) || !setMenuStyle(db, style)) {
            return ctx.reply(
                `Style tidak valid: *${requested}*.\n` +
                `Pilihan: *1* s.d. *9* — ketik *${pfx}setmenu* tanpa argumen untuk daftar lengkap.`
            )
        }

        // ---- Preview pakai style baru (best-effort) ----
        // Bangun isi menu dari registry yang sama dengan .menu; bila render
        // gagal (mis. upload thumbnail ditolak), jangan gagalkan konfirmasi.
        // Style 9 = teks — tak ada yang di-preview lewat jalur interaktif.
        let previewNote = ''
        if (style !== 9) {
            try {
                const groups = new Map()
                for (const [, plugin] of ctx.pluginLoader.registry) {
                    if (plugin.owner && !ctx.isOwner) continue
                    const cat = (plugin.category || 'other').toLowerCase()
                    if (!groups.has(cat)) groups.set(cat, [])
                    groups.get(cat).push(plugin)
                }
                for (const list of groups.values()) list.sort((a, b) => a.name.localeCompare(b.name))
                const categories = [...groups.keys()].sort()
                const total = [...groups.values()].flat().length

                await sendMenuByStyle({
                    style,
                    sock: ctx.sock,
                    chat: ctx.chat,
                    caption:
                        `☘️ Preview *${config.botName}* — style ${style}\n` +
                        `Total Fitur: *${total}*`,
                    footer: `${MENU_STYLES[style]} • atur via ${pfx}setmenu`,
                    categories,
                    groups,
                    total,
                    pfx,
                    quoted: ctx.message,
                })
                previewNote = '\nPreview di atas dikirim pakai style barunya.'
            } catch (e) {
                logger.debug('setmenu preview gagal (style %s): %s', style, e.message)
                previewNote = '\n⚠️ Preview style gagal dirender di chat ini — menu tetap pakai fallback teks bila terjadi terus.'
            }
        }

        return ctx.reply(
            `✅ Style menu GLOBAL diganti ke *${style} — ${MENU_STYLES[style]}*.${previewNote}\n` +
            `Semua .menu (semua user & chat) sekarang tampil dengan style ini — persist setelah restart.`
        )
    },
}
