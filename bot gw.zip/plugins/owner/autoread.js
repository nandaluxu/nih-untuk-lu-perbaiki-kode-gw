import { isAutoReadEnabled, setAutoRead } from '../../lib/messaging/autoread.js'

export default {
        name: 'autoread',
        aliases: ['aread'],
        description: 'Bot otomatis menandai pesan masuk sudah dibaca (blue tick)',
        category: 'owner',
        usage: '.autoread on/off',
        owner: true,
        register: false,

        async execute(ctx) {
                const _pfx = (typeof ctx !== 'undefined' && ctx?.prefix) || '.'
                const action = (ctx.args[0] || '').toLowerCase()

                if (action === 'on' || action === 'off') {
                        const enabled = action === 'on'
                        setAutoRead(ctx.db, enabled)
                        return ctx.reply(
                                `✅ Auto-read *${enabled ? 'diaktifkan' : 'dimatikan'}*.` +
                                (enabled
                                        ? '\n\nSemua pesan masuk (live) otomatis ditandai dibaca.\nCatatan: centang biru ke lawan chat hanya muncul jika privacy "read receipts" akun = Everyone.'
                                        : '')
                        )
                }

                const enabled = isAutoReadEnabled(ctx.db)
                return ctx.reply(
                        [
                                '*Auto Read Status*',
                                '',
                                `Status: ${enabled ? '🟢 ON' : '🔴 OFF'}`,
                                `Setting: ${_pfx}autoread on|off`,
                        ].join('\n')
                )
        }
}
