import { ROLE_HIERARCHY, ROLE_CONFIG } from '../../database/role-repository.js'
import { fmtJid } from '../../lib/command/group-utils.js'

export default {
    name: 'setrole',
    description: 'Atur role user',
    category: 'owner',
    usage: '.setrole @user <role> [durasi]',
    owner: true,

    async execute(ctx) {
			const _pfx = (typeof ctx !== 'undefined' && ctx?.prefix) || ''
        const { args, mentionedJid, roleRepo } = ctx
        const target = mentionedJid?.[0]
        if (!target) return ctx.reply('Tag user yang ingin diatur role-nya.')

        let role, durationRaw

        if (mentionedJid?.length) {
            const last = (args[args.length - 1] || '').toLowerCase()
            const prev = args.length >= 2 ? (args[args.length - 2] || '').toLowerCase() : ''

            if (ROLE_HIERARCHY.includes(last)) {
                role = last
                durationRaw = /^\d+$/.test(prev) ? prev : null
            } else if (ROLE_HIERARCHY.includes(prev)) {
                // Kasus: .setrole @user vip 30 (tanpa nama panjang)
                role = prev
                durationRaw = /^\d+$/.test(last) ? last : null
            }
        } else {
            role = (args[0] || '').toLowerCase()
            durationRaw = args[1]
        }

        if (!role || !ROLE_HIERARCHY.includes(role)) {
            return ctx.reply('Role tidak valid.\nRole: ' + ROLE_HIERARCHY.join(', '))
        }

        const durationDays = durationRaw ? parseInt(durationRaw) : null
        const effectiveDays = (durationDays && durationDays > 0) ? durationDays : null

        // Role ditulis ke user profile target (resolve PN/LID otomatis oleh RoleRepository).
        // User yang belum terdaftar tidak punya profil → ditolak.
        const ok = roleRepo.setRole(target, role, effectiveDays)
        if (!ok) {
                return ctx.reply(`❌ Tidak bisa mengatur role: user belum terdaftar / tidak ditemukan.\nMinta user daftar dulu dengan ${_pfx}daftar nama.umur`)
        }

        const num = fmtJid(target)
        let msg = `✅ Role *${num}* diubah ke *${role}*`
        if (effectiveDays) {
            msg += ` selama *${effectiveDays} hari*`
        } else {
            msg += ' (permanen)'
        }

        const conf = ROLE_CONFIG[role]
        if (conf) {
            msg += '\n\nℹ️ *Info role:*\n'
            msg += '• Cooldown: ' + (conf.bypassCooldown ? 'bypass' : conf.cooldownMultiplier === 1 ? 'normal' : (1/conf.cooldownMultiplier).toFixed(1) + 'x lebih cepat')
            msg += '\n• Typing delay: ' + (conf.bypassDelay ? 'bypass' : conf.typingDelay ? conf.typingDelay/1000 + ' detik' : 'tanpa delay')
        }

        await ctx.reply(msg)
    }
}