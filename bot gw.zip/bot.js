import './lib/protection/vendor-patch.js'
import path from 'path'
import { fileURLToPath } from 'url'
import pino from 'pino'

import { Client, setGlobalConfig } from '@itsliaaa/starcore'

import config, { isOwner } from './config/index.js'
import logger from './lib/core/logger.js'
import { getDatabase } from './database/database.js'
import { getUserFileStore } from './database/user-file-store.js'
import { UserRepository } from './database/user-repository.js'
import { IdentifierRepository } from './database/identifier-repository.js'
import { SettingsRepository } from './database/settings-repository.js'
import { WorldBankRepository } from './database/world-bank-repository.js'
import { InventoryRepository } from './database/inventory-repository.js'
import { RoleRepository, ROLE_HIERARCHY } from './database/role-repository.js'
import { getGroupFileStore } from './database/group-file-store.js'
import { IdentityResolver, normalizeJid, jidEquals } from './lib/identity/index.js'
import { PrefixManager } from './lib/command/prefix-manager.js'
import { isBotEcho, isBotAccountMessage } from './lib/messaging/echo-guard.js'
import { createAutoReader, isAutoReadEnabled } from './lib/messaging/autoread.js'
import { getReactConfig, shouldReactStatus, sendStatusReaction, pickStatusEmoji } from './lib/messaging/auto-status.js'
import { PluginLoader } from './lib/command/plugin-loader.js'
import { getSharedProtection, resolveChatScope } from './lib/protection/protection.js'
import { AutoDeleteManager } from './lib/messaging/autodelete.js'
import { parse } from './lib/command/command-parser.js'
import { dispatchCommand } from './handler.js'
import { ActivityStore } from './database/activity-store.js'
import { migrateProgressionFromActivityOnce, applyMessageProgression, aggregateProgression } from './database/user-progression.js'
import { EconomyStore } from './database/economy-store.js'
import { activity as activityCfg } from './config/activity.js'
import { WorldBank } from './lib/world-bank.js'
import { initAiSystemGuarded, checkAiTrigger, isAiCandidate } from './ai/index.js'
import { getActiveMute, runMessageGuard } from './lib/protection/message-guard.js'
import { vanishMessage } from './lib/messaging/vanish.js'
import { MAX_WARN } from './lib/protection/warn-core.js'
import { sendStyledReply, installGlobalReplyStyle } from './lib/messaging/reply-style.js'
import { renderReplyMsg } from './lib/messaging/messages.js'
import { cmdRef } from './lib/command/cmd-ref.js'
import { handleAutoDownload } from './lib/features/autodl.js'
import { handleAntipmGate } from './lib/features/antipm.js'
import { isStaleCommand, isStaleForAi, messageAgeMs } from './lib/features/stale-guard.js'
import { classifyMessage } from './lib/features/connection-lifecycle.js'
import { getGameSessions } from './lib/game/session-manager.js'
import { handleGameNumberReply } from './lib/game/reply-move.js'
import { handleTebakHeroReply } from './lib/game/tebak-mlbb.js'
import { handleQuizReply } from './lib/game/quiz.js'
import { handleAnimeGameGuess } from './lib/game/tebak-anime.js'
import { handleBombInput } from './lib/game/bomb-game.js'
import { handleKataInput } from './lib/game/kata-game.js'
import { handleAkinatorReply } from './lib/game/akinator-engine.js'
import { handleAiCharTrigger, normalizeMentions, migrateAiRelData } from './lib/ai-characters/engine.js'
import { AfkService, extractMentions, extractQuotedTargets, messageTimestampMs, buildAfkMentionReply, buildAfkSummary } from './lib/features/afk.js'
import { recordPushName } from './lib/features/names.js'
import { createBackup, BACKUP_KEEP } from './lib/features/backup.js'
import { isGroupMuted, grantSendAllowance, initMuteGc } from './lib/protection/mutegc.js'
import { initSelfMode, isSelfModeOn, isPrivilegedSender } from './lib/features/selfmode.js'
import { buildLine } from './lib/features/build.js'
import { initRpg, handleRpgInput } from './rpg/index.js'
import { setRpgUiDbSource } from './lib/features/rpg-ui.js'
import { initJjc } from './lib/jjc.js'
import { createPipelineContext, setCommandInfo, beginPipelineTrace, runMiddleware } from './lib/pipeline/index.js'
import { stopChain, isChainStopped } from './lib/pipeline/middleware.js'
import { runStartupCheck } from './lib/bot/startup-check.js'
import { logStaleDrop, logBacklogDrop } from './lib/bot/log-throttle.js'
import { wireConnect, wireReady, wireMessage } from './lib/bot/events.js'
import { shutdownAll } from './lib/bot/shutdown.js'
import { fenceMessageReply } from './lib/messaging/send-fence.js'
import { LimitService, setLimitService } from './lib/command/limit-service.js'

const __dirname = path.dirname(fileURLToPath(import.meta.url))

function fmtJidShort(jid) {
    return jid ? String(jid).split('@')[0] : jid
}

runStartupCheck()

const FFMPEG_CONCURRENCY = (() => {
    const n = Number.parseInt(process.env.FFMPEG_CONCURRENCY || '', 10)
    return Number.isFinite(n) && n > 0 ? n : 1
})()

try {
    setGlobalConfig({ logger: pino({ level: config.logLevel }), ffmpegConcurrency: FFMPEG_CONCURRENCY })
    logger.info('Starcore: ffmpegConcurrency=%d (encode paralel)', FFMPEG_CONCURRENCY)
} catch (e) {
    logger.warn('setGlobalConfig skipped: %s', e.message)
}

const db = getDatabase()
const ufs = getUserFileStore()

// ============================================================================
// LIMIT SERVICE — override configDir agar baca dari /home/container/config/limits
// (default kode baca dari lib/config/limits — path berbeda)
// ============================================================================
try {
    const limitConfigDir = path.join(__dirname, 'config', 'limits')
    setLimitService(new LimitService({ db, configDir: limitConfigDir }))
    logger.info('LimitService: configDir = %s', limitConfigDir)
} catch (e) {
    logger.warn('LimitService override gagal (pakai default): %s', e?.message || e)
}
// ============================================================================

setRpgUiDbSource(db)

const groupFileStore = getGroupFileStore()

const idRepo = new IdentifierRepository(db)
const userRepo = new UserRepository(ufs, { idRepo })
const settingsRepo = new SettingsRepository(db)
const worldBankRepo = new WorldBankRepository(db)
const inventoryRepo = new InventoryRepository(ufs)
const roleRepo = new RoleRepository(db, userRepo, idRepo)

migrateProgressionFromActivityOnce({ ufs })

// ============================================================================
// MIGRASI AI_REL — bersihkan data lama yang melanggar aturan baru
// ============================================================================
try {
    const migrationSummary = migrateAiRelData(db)
    if (migrationSummary.total > 0) {
        logger.info(
            '[ai-partner] migrasi ai_rel selesai: %d klaim dibersihkan (menikah=%d, tunangan=%d, pacar=%d)',
            migrationSummary.total,
            migrationSummary.menikah,
            migrationSummary.tunangan,
            migrationSummary.pacar,
        )
    } else {
        logger.info('[ai-partner] data ai_rel sudah rapi — tidak ada yang perlu dimigrasi')
    }
} catch (e) {
    logger.warn('[ai-partner] migrasi ai_rel gagal (dilewati): %s', e?.message || e)
}
// ============================================================================

const activity = new ActivityStore().load()
activity.setMoneyProvider((jids) => {
    const map = new Map()
    for (const jid of jids || []) {
        const u = userRepo.findByIdentifier(jid)
        if (u) map.set(jid, (Number(u.wallet) || 0) + (Number(u.bank) || 0))
    }
    return map
})
activity.setProgressionProvider((jids) => aggregateProgression(ufs, jids))

const economyStore = new EconomyStore().load()
activity.setEconomyProvider((jids, scope) => economyStore.aggregate(jids, scope))

const afkService = new AfkService({ db, userRepo })
activity.setAfkProvider((jids) => afkService.aggregateForLb(jids))

const identity = new IdentityResolver(null, idRepo, userRepo)
activity.setIdentityResolver((jid) => identity.lidToPn(jid))

roleRepo.migrateLegacyRoles()

const prefixManager = new PrefixManager(settingsRepo)
const pluginLoader = new PluginLoader()
const worldBank = WorldBank.init(worldBankRepo)

const protection = getSharedProtection()
const savedProtectionEnabled = settingsRepo.getGlobal('protection_enabled', null)
if (savedProtectionEnabled !== null) protection.setEnabled(savedProtectionEnabled === '1')
const savedProtectionOverrides = settingsRepo.getGlobal('protection_overrides', null)
if (savedProtectionOverrides) {
    try {
        protection.applyOverrides(JSON.parse(savedProtectionOverrides))
    } catch (e) {
        logger.warn('Config protection global korup, diabaikan: %s', e.message)
    }
}

initMuteGc(settingsRepo)
initSelfMode(settingsRepo)

const rpgSystem = initRpg()
const jjcService = initJjc()

const autoDelete = new AutoDeleteManager({
    getConfig: (chat) => db.data?.settings?.[chat]?.autodelete || null,
})

const pluginFolder = path.join(__dirname, 'plugins')
await pluginLoader.loadAll(pluginFolder)
pluginLoader.watch(pluginFolder)

const aiConfig = {
    groqKeys: (process.env.GROQ_API_KEY || '').split(',').map(k => k.trim()).filter(Boolean),
    geminiKeys: (process.env.GEMINI_API_KEY || '').split(',').map(k => k.trim()).filter(Boolean),
    openrouterKeys: (process.env.OPENROUTER_API_KEY || '').split(',').map(k => k.trim()).filter(Boolean),
}
const aiSystem = initAiSystemGuarded(db, aiConfig)

function resolveUserRole({ m, ownerFlag }) {
    if (ownerFlag) return { name: 'owner', data: null, ownerOverride: true }
    try {
        let rd = m.sender ? roleRepo.getRole(m.sender) : null
        if (!rd?.found && m.senderLid) rd = roleRepo.getRole(m.senderLid)
        if (rd?.found && ROLE_HIERARCHY.includes(rd.role)) {
            return { name: rd.role, data: rd, ownerOverride: false }
        }
    } catch { /* fallback free */ }
    return { name: 'free', data: null, ownerOverride: false }
}

export class Bot {
    static _backupTimer = null

    constructor() {
        this.client = null
        this.resolver = null
        this.store = null
        this.aiSystem = aiSystem
        this.protection = getSharedProtection()
    }

    async start() {
        logger.info('Memulai bot: %s', config.botName)

        const clientOptions = {
            auth: {
                name: config.sessionName,
                pairingCode: config.usePairingCode,
                phoneNumber: config.pairingNumber,
            },
            messageIdPrefix: 'BOT',
            updatePresence: true,
            autoFollowNewsletter: false,
        }

        clientOptions.isBotMessageId = (id) => typeof id === 'string' && id.startsWith('BOT')

        this.client = new Client(clientOptions)

        wireConnect(this)
        wireReady(this, {
            identity,
            jjcService,
            afkService,
            autoDelete,
            config,
            db,
        })
        wireMessage(this)

        if (!Bot._backupTimer) {
            const DAY = 24 * 60 * 60 * 1000
            const firstDelay = 60 * 60 * 1000
            const run = async () => {
                try { await createBackup() } catch (e) { logger.warn('Backup terjadwal gagal: %s', e.message) }
            }
            Bot._backupTimer = setTimeout(async () => {
                await run()
                Bot._backupTimer = setInterval(run, DAY)
                Bot._backupTimer.unref?.()
            }, firstDelay)
            Bot._backupTimer.unref?.()
            logger.info('Backup scheduler aktif (harian, keep %d)', BACKUP_KEEP)
        }
    }

    async _handleMessage(starcoreCtx) {
        const m = starcoreCtx.m
        if (!m?.chat) return

        const sock = this.client.sock

        const pipeTrace = beginPipelineTrace(m, {
            chat: m.chat,
            isGroup: m.isGroup,
            execId: m.__execId || null,
        })
        const pipe = createPipelineContext({
            message: m,
            sock,
            raw: starcoreCtx,
            identityAuthority: identity,
            trace: pipeTrace,
        })

        const statusBroadcastGate = async (ctx, next) => {
            if (m.chat === 'status@broadcast') {
                const sv = classifyMessage(m)
                if (sv.backlog) return stopChain(ctx)
                const reactCfg = getReactConfig(db)
                if (reactCfg.enabled && shouldReactStatus(m, reactCfg)) {
                    sendStatusReaction(sock, m, pickStatusEmoji(reactCfg.emoji)).catch(() => {})
                }
                return stopChain(ctx)
            }
            return next()
        }

        const echoGate = async (ctx, next) => {
            if (m.fromMe && isBotEcho(m)) return stopChain(ctx)
            pipeTrace.stage('echo-guard')
            return next()
        }

        let earlyGatesPassed = false
        await runMiddleware([statusBroadcastGate, echoGate], pipe, async () => {
            earlyGatesPassed = true
        })
        if (!earlyGatesPassed || isChainStopped(pipe)) return

        const globalPrefixCfg = prefixManager.get()
        let prefixConfig = globalPrefixCfg
        if (m.isGroup) {
            const groupPrefix = groupFileStore.getPrefix(m.chat)
            if (groupPrefix) prefixConfig = { enabled: true, prefix: groupPrefix }
        }
        pipe.prefixConfig = prefixConfig

        let mutegcOwner = false
        const mutegcGate = async (ctx, next) => {
            if (m.isGroup && isGroupMuted(m.chat)) {
                let gateOwner = m.fromMe || isOwner(m.sender) || false
                if (!gateOwner && m.senderLid) {
                    try {
                        const prof = identity.resolveProfile({ senderLid: m.senderLid })
                        if (prof?.pn && isOwner(prof.pn)) gateOwner = true
                    } catch {}
                }
                if (gateOwner) {
                    mutegcOwner = true
                    grantSendAllowance(m.chat, 120_000)
                } else {
                    const lightVerdict = classifyMessage(m)
                    if (lightVerdict.backlog) return stopChain(ctx)

                    if (!isBotAccountMessage(m)) {
                        const afkBody = starcoreCtx.body || m.text || ''
                        const afkParsed = afkBody
                            ? parse(afkBody, prefixConfig, pluginLoader.registry)
                            : null
                        const isAfkFamily = afkParsed?.isCommand
                            && (afkParsed.command === 'afk' || afkParsed.command === 'afkmail')
                        if (!isAfkFamily) {
                            try {
                                afkService.handleReturn({
                                    sender: m.sender,
                                    senderLid: m.senderLid,
                                    endedAt: messageTimestampMs(m),
                                })
                            } catch {}
                        }
                    }

                    {
                        const nameJid = identity.toCanonical(m.sender || m.senderLid)
                        if (nameJid && !m.fromMe && m.pushName) {
                            try { recordPushName(db, nameJid, m.pushName) } catch {}
                        }
                    }

                    const lightJid = m.sender || m.senderLid
                    if (lightJid && !m.fromMe) {
                        try {
                            activity.recordMessage({
                                userJid: lightJid,
                                groupJid: m.isGroup ? m.chat : null,
                            })
                        } catch (e) {
                            logger.warn('Activity record (mutegc light) gagal: %s', e.message)
                        }
                        try {
                            const pUser = identity.resolveProfile({ sender: m.sender, senderLid: m.senderLid })
                            if (pUser) applyMessageProgression(pUser, ufs)
                        } catch {}
                    }
                    return stopChain(ctx)
                }
            }
            return next()
        }
        let mutegcGatePassed = false
        await runMiddleware([mutegcGate], pipe, async () => {
            mutegcGatePassed = true
        })
        if (!mutegcGatePassed || isChainStopped(pipe)) return

        const selfmodeGate = async (ctx, next) => {
            if (isSelfModeOn()
                && !isPrivilegedSender({ m, isOwnerFn: isOwner, userRepo, roleRepo })) {
                const smVerdict = classifyMessage(m)
                if (smVerdict.backlog) return stopChain(ctx)

                if (!isBotAccountMessage(m)) {
                    const smAfkBody = starcoreCtx.body || m.text || ''
                    const smAfkParsed = smAfkBody
                        ? parse(smAfkBody, prefixConfig, pluginLoader.registry)
                        : null
                    const smIsAfkFamily = smAfkParsed?.isCommand
                        && (smAfkParsed.command === 'afk' || smAfkParsed.command === 'afkmail')
                    if (!smIsAfkFamily) {
                        try {
                            afkService.handleReturn({
                                sender: m.sender,
                                senderLid: m.senderLid,
                                endedAt: messageTimestampMs(m),
                            })
                        } catch {}
                    }
                }

                {
                    const smNameJid = identity.toCanonical(m.sender || m.senderLid)
                    if (smNameJid && !m.fromMe && m.pushName) {
                        try { recordPushName(db, smNameJid, m.pushName) } catch {}
                    }
                }

                const smLightJid = m.sender || m.senderLid
                if (smLightJid && !m.fromMe) {
                    try {
                        activity.recordMessage({
                            userJid: smLightJid,
                            groupJid: m.isGroup ? m.chat : null,
                        })
                    } catch (e) {
                        logger.warn('Activity record (selfmode light) gagal: %s', e.message)
                    }
                    try {
                        const pUser = identity.resolveProfile({ sender: m.sender, senderLid: m.senderLid })
                        if (pUser) applyMessageProgression(pUser, ufs)
                    } catch {}
                }
                return stopChain(ctx)
            }
            return next()
        }
        let selfmodeGatePassed = false
        await runMiddleware([selfmodeGate], pipe, async () => {
            selfmodeGatePassed = true
        })
        if (!selfmodeGatePassed || isChainStopped(pipe)) return

        const resolverReadyGate = async (ctx, next) => {
            if (!this.resolver) return stopChain(ctx)
            return next()
        }
        let resolverReadyPassed = false
        await runMiddleware([resolverReadyGate], pipe, async () => {
            resolverReadyPassed = true
        })
        if (!resolverReadyPassed || isChainStopped(pipe)) return

        fenceMessageReply(m, 60_000)

        const backlogGate = async (ctx, next) => {
            const backlogVerdict = classifyMessage(m)
            if (backlogVerdict.backlog) {
                logBacklogDrop(m, backlogVerdict)
                return stopChain(ctx)
            }
            return next()
        }
        let backlogGatePassed = false
        await runMiddleware([backlogGate], pipe, async () => {
            backlogGatePassed = true
        })
        if (!backlogGatePassed || isChainStopped(pipe)) return

        if (!m.fromMe && isAutoReadEnabled(db)) {
            if (!this._autoReader || this._autoReader.sock !== sock) {
                this._autoReader = createAutoReader(sock)
            }
            this._autoReader.read(m)
        }
        pipeTrace.stage('backlog-guard')

        if (!isBotAccountMessage(m)) {
            const afkBody = starcoreCtx.body || m.text || ''
            const afkParsed = parse(afkBody, prefixConfig, pluginLoader.registry)
            const isAfkFamilyCmd = afkParsed.isCommand
                && (afkParsed.command === 'afk' || afkParsed.command === 'afkmail')
            if (!isAfkFamilyCmd) {
                const ended = afkService.handleReturn({
                    sender: m.sender,
                    senderLid: m.senderLid,
                    endedAt: messageTimestampMs(m),
                })
                if (ended) {
                    const text = buildAfkSummary({
                        record: ended.record,
                        durationMs: ended.durationMs,
                        mailStats: ended.mailStats,
                    })
                    await sock.sendMessage(m.chat, { text }, { quoted: m }).catch(() => {})
                }
            }
        }

        const muteGate = async (ctx, next) => {
            if (!mutegcOwner && m.isGroup && getActiveMute(db, m.chat, m.sender)) {
                await vanishMessage(sock, m.chat, m.key?.id).catch(() => {})
                return stopChain(ctx)
            }
            return next()
        }
        let muteGatePassed = false
        await runMiddleware([muteGate], pipe, async () => {
            muteGatePassed = true
        })
        if (!muteGatePassed || isChainStopped(pipe)) return

        const antipmGate = async (ctx, next) => {
            if (m.isPrivate && !m.fromMe) {
                const pmBlocked = await handleAntipmGate({ sock, m, db, isOwnerFn: isOwner })
                if (pmBlocked) return stopChain(ctx)
            }
            return next()
        }
        let antipmGatePassed = false
        await runMiddleware([antipmGate], pipe, async () => {
            antipmGatePassed = true
        })
        if (!antipmGatePassed || isChainStopped(pipe)) return

        {
            const nameJid = identity.toCanonical(m.sender || m.senderLid)
            if (nameJid && !m.fromMe && m.pushName) {
                try { recordPushName(db, nameJid, m.pushName) } catch {}
            }
        }

        const isInteractive = !!(
            m.message?.listResponseMessage
            || m.message?.buttonsResponseMessage
            || m.message?.interactiveResponseMessage
        )

        let body = starcoreCtx.body || m.text || ''

        if (!isBotAccountMessage(m)) {
            const afkBotJid = normalizeJid(sock?.user?.id)
            const notBotTarget = (j) => !(afkBotJid && jidEquals(j, afkBotJid))
            const afkMentions = extractMentions(m).filter(notBotTarget)
            const afkReplyTargets = extractQuotedTargets(m).filter(notBotTarget)
            if (afkMentions.length > 0 || afkReplyTargets.length > 0) {
                const afkResult = await afkService.processMentions({
                    sock,
                    m,
                    body,
                    mentions: afkMentions,
                    replyTargets: afkReplyTargets,
                    now: messageTimestampMs(m, Date.now()),
                    resolver: this.resolver,
                })
                if (afkResult.responses.length > 0 && !isStaleForAi(m)) {
                    await sock.sendMessage(m.chat, {
                        text: buildAfkMentionReply(afkResult.responses),
                    }, { quoted: m }).catch(() => {})
                }
            }
        }

        if (!isBotAccountMessage(m)) {
            try {
                if (await jjcService.handleMessage({ m, sock })) return
            } catch (e) {
                logger.warn('JJC hook gagal: %s', e.message)
            }
        }

        if (!body || isInteractive) {
            const listId = m.message?.listResponseMessage?.singleSelectReply?.selectedRowId
            if (listId) body = listId

            const btnId = m.message?.buttonsResponseMessage?.selectedButtonId
            if (btnId) {
                body = btnId
            } else {
                const btnText = m.message?.buttonsResponseMessage?.selectedDisplayText
                if (btnText && !body) body = btnText
            }

            const paramsStr = m.message?.interactiveResponseMessage
                ?.nativeFlowResponseMessage?.paramsJson
            if (paramsStr) {
                try {
                    const params = JSON.parse(paramsStr)
                    if (params.id) body = params.id
                } catch {}
            }
        }

        const bodyGate = async (ctx, next) => {
            if (!body) return stopChain(ctx)
            return next()
        }
        let bodyGatePassed = false
        await runMiddleware([bodyGate], pipe, async () => {
            bodyGatePassed = true
        })
        if (!bodyGatePassed || isChainStopped(pipe)) return
        pipe.body = body
        pipeTrace.stage('body-gate')

        const parsed = parse(body, prefixConfig, pluginLoader.registry)
        const isCommandMsg = parsed.isCommand && Boolean(parsed.command)
        setCommandInfo(pipe, parsed)
        pipeTrace.stage('parse-command')

        const staleGate = async (ctx, next) => {
            if (isStaleCommand(m, parsed)) {
                logStaleDrop(parsed.command, messageAgeMs(m), m)
                return stopChain(ctx)
            }
            return next()
        }
        let staleGatePassed = false
        await runMiddleware([staleGate], pipe, async () => {
            staleGatePassed = true
        })
        if (!staleGatePassed || isChainStopped(pipe)) return

        const antilinkGate = async (ctx, next) => {
            if (!mutegcOwner && m.isGroup) {
                const guardPlugin = isCommandMsg ? (pluginLoader.registry.get(parsed.command) || null) : null
                const verdict = await runMessageGuard({
                    sock,
                    m,
                    body,
                    db,
                    resolver: this.resolver,
                    isValidCommand: Boolean(guardPlugin),
                    command: guardPlugin?.name || null,
                })
                if (verdict?.handled) {
                    if (verdict.rule === 'antilink') {
                        const { key, matched, warn } = verdict.detail
                        const display = '@' + fmtJidShort(key)
                        let text
                        if (warn?.kicked) {
                            text = `🔴 ${display} kena warn *${warn.count}/${MAX_WARN}* — link terlarang *(${matched})* → *DIKICK* dari grup.`
                        } else if (warn?.kickError) {
                            text = `⚠️ ${display} kena warn *${warn.count}/${MAX_WARN}* — link terlarang *(${matched})*.\n` +
                                `❌ Gagal kick: bot harus jadi admin grup.`
                        } else {
                            text = `⚠️ ${display} kena warn *${warn.count}/${MAX_WARN}* — link terlarang *(${matched})*.\n` +
                                `Sisa *${MAX_WARN - warn.count}* warn sebelum auto kick.`
                        }
                        await sock.sendMessage(m.chat, { text, mentions: key ? [key] : [] }).catch(() => {})
                    }
                    return stopChain(ctx)
                }
            }
            return next()
        }
        let antilinkGatePassed = false
        await runMiddleware([antilinkGate], pipe, async () => {
            antilinkGatePassed = true
        })
        if (!antilinkGatePassed || isChainStopped(pipe)) return

        const chatProtectionGate = async (ctx, next) => {
            if (!isCommandMsg) {
                const chatScope = resolveChatScope({
                    quoted: m.quoted,
                    aiRefs: db.data?.ai?.message_refs,
                    chatId: m.chat,
                })
                const chatVerdict = this.protection.gateChat({
                    userKey: m.sender || m.senderLid || m.chat,
                    isOwner: isOwner(m.sender) || m.fromMe || false,
                    chatConfig: db.data?.settings?.[m.chat]?.protection || null,
                    scope: chatScope,
                })
                if (!chatVerdict.ok) {
                    if (chatVerdict.reply) {
                        await m.reply(chatVerdict.reply).catch(() => {})
                    }
                    return stopChain(ctx)
                }
            }
            return next()
        }
        let chatProtectionGatePassed = false
        await runMiddleware([chatProtectionGate], pipe, async () => {
            chatProtectionGatePassed = true
        })
        if (!chatProtectionGatePassed || isChainStopped(pipe)) return
        pipeTrace.stage('protection')

        const activityJid = m.sender || m.senderLid
        if (activityJid && !m.fromMe) {
            try {
                activity.recordMessage({
                    userJid: activityJid,
                    groupJid: m.isGroup ? m.chat : null,
                })
            } catch (e) {
                logger.warn('Activity record gagal: %s', e.message)
            }
            try {
                const pUser = identity.resolveProfile({ sender: m.sender, senderLid: m.senderLid })
                const prog = pUser ? applyMessageProgression(pUser, ufs) : null
                if (prog?.leveledUp && activityCfg.levelUpNotify && !isGroupMuted(m.chat)) {
                    const text =
                        `🎉 *LEVEL UP!* 🎉\n` +
                        `Selamat @${fmtJidShort(activityJid)}, kamu naik ke *Level ${prog.level}*!` +
                        (prog.levelsGained > 1 ? ` (+${prog.levelsGained} level)` : '')
                    await sock.sendMessage(m.chat, {
                        text,
                        mentions: [activityJid],
                    }).catch(() => {})
                }
            } catch (e) {
                logger.warn('Progression record gagal: %s', e.message)
            }
        }
        pipeTrace.stage('activity-progression')

        const isFromMe = (() => { try { return m.fromMe } catch { return false } })()
        if (!isCommandMsg && !isFromMe) {
            try {
                if (await handleRpgInput({
                    m, body, sock, chat: m.chat,
                    db,
                    pfx: (typeof prefixConfig?.prefix === 'string' && prefixConfig.prefix)
                        ? prefixConfig.prefix
                        : '.',
                })) return
            } catch (e) {
                logger.warn('RPG input hook gagal: %s', e.message)
            }
        }

        if (!isCommandMsg && !isFromMe && !isInteractive) {
            try {
                if (await handleGameNumberReply({ m, body, sock, db })) return
            } catch (e) {
                logger.warn('Game reply hook gagal: %s', e.message)
            }
        }

        if (!isCommandMsg && !isInteractive) {
            try {
                if (await handleTebakHeroReply({ m, body, sock, db, activity, userRepo })) return
            } catch (e) {
                logger.warn('TebakHero reply hook gagal: %s', e.message)
            }
            try {
                if (await handleQuizReply({ m, body, sock, db, activity, userRepo })) return
            } catch (e) {
                logger.warn('Quiz reply hook gagal: %s', e.message)
            }
            try {
                if (await handleAnimeGameGuess({ m, body, sock, db, activity, userRepo })) return
            } catch (e) {
                logger.warn('TebakAnime guess hook gagal: %s', e.message)
            }
            try {
                if (await handleBombInput({ m, body, sock, db, userRepo })) return
            } catch (e) {
                logger.warn('Bom input hook gagal: %s', e.message)
            }
            try {
                if (await handleKataInput({ m, body, sock, db, userRepo })) return
            } catch (e) {
                logger.warn('Kata input hook gagal: %s', e.message)
            }
            try {
                if (await handleAkinatorReply({ m, body, sock, userRepo })) return
            } catch (e) {
                logger.warn('Akinator reply hook gagal: %s', e.message)
            }
        }
        pipeTrace.stage('game-hooks')

        if (!isCommandMsg && !isInteractive) {
            try {
                const aiOwnerFlag = isOwner(m.sender) || m.fromMe || false
                const aiRoleData = resolveUserRole({ m, ownerFlag: aiOwnerFlag })
                if (await handleAiCharTrigger({
                    m, body, sock, db,
                    botName: config.botName,
                    userRepo,
                    isOwner: aiOwnerFlag,
                    role: aiRoleData.name,
                })) return
            } catch (e) {
                logger.warn('AI char trigger hook gagal: %s', e.message)
            }
        }

        if (this.aiSystem && !isFromMe && !isInteractive) {
            if (m.isGroup && m.sender && !isCommandMsg && !isInteractive) {
                this.aiSystem.contextManager.add(m.chat, m.sender, normalizeMentions(body, m, db, userRepo))
            }

            const aiStale = isStaleForAi(m)

            if (!aiStale && isAiCandidate(this.aiSystem, m, userRepo)) {
                const aiVerdict = this.protection.allowAi(
                    m.sender || m.senderLid || m.chat,
                    isOwner(m.sender) || m.fromMe || false,
                    db.data?.settings?.[m.chat]?.protection || null,
                )
                if (!aiVerdict.ok) {
                    if (aiVerdict.reply) {
                        await m.reply(aiVerdict.reply).catch(() => {})
                    }
                    return
                }
            }

            if (!aiStale) {
                const rikkaOwnerFlag = isOwner(m.sender) || false
                const rikkaRoleData = resolveUserRole({ m, ownerFlag: rikkaOwnerFlag })
                const aiHandled = await checkAiTrigger(this.aiSystem, m, sock, userRepo, {
                    isOwner: rikkaOwnerFlag,
                    role: rikkaRoleData.name,
                })
                if (aiHandled) return
            }
        }
        pipeTrace.stage('ai-routing')

        if (!isCommandMsg && !isInteractive && !isFromMe) {
            const dlHandled = await handleAutoDownload({ sock, m, body, db })
            if (dlHandled) return
        }

        const commandGate = async (ctx, next) => {
            if (!isCommandMsg) return stopChain(ctx)
            return next()
        }
        let commandGatePassed = false
        await runMiddleware([commandGate], pipe, async () => {
            commandGatePassed = true
        })
        if (!commandGatePassed || isChainStopped(pipe)) return
        pipeTrace.stage('dispatch')

        let user = null
        if (m.sender) {
            user = identity.resolveProfile({ sender: m.sender, senderLid: m.senderLid })
        }

        let ownerFlag = isOwner(m.sender) || m.fromMe || false
        if (!ownerFlag && m.senderLid && !isOwner(m.sender)) {
            try {
                const prof = identity.resolveProfile({ senderLid: m.senderLid })
                if (prof?.pn && isOwner(prof.pn)) ownerFlag = true
            } catch {}
        }

        const roleResolved = resolveUserRole({ m, ownerFlag })

        const activePlugin = pluginLoader.registry.get(parsed.command) || null

        const ctx = {
            message: m,
            chat: m.chat,
            sender: m.sender,
            senderLid: m.senderLid,
            isGroup: m.isGroup,
            isPrivate: m.isPrivate,
            isOwner: ownerFlag,
            fromMe: m.fromMe,

            command: parsed.command,
            rawCommand: parsed.rawCommand || parsed.command || null,
            args: parsed.args,
            rawArgs: parsed.rawArgs,
            text: parsed.args.join(' '),
            prefix: parsed.usedPrefix,
            isCommand: true,
            pushName: m.pushName || null,

            pipeline: pipe,

            quoted: m.quoted || null,
            mentionedJid: m.mentionedJid || [],

            sock,
            config,
            resolver: this.resolver,
            prefixManager,
            pluginLoader,
            userRepo,
            idRepo,
            inventoryRepo,
            worldBank,
            db,
            roleRepo,
            user,
            activity,
            economy: economyStore,
            afk: afkService,
            rpg: rpgSystem,

            role: roleResolved.name,
            userRole: roleResolved.name,
            roleData: roleResolved.data,

            plugin: activePlugin,

            cmdRef(command) {
                const p = prefixConfig?.enabled ? (prefixConfig.prefix || '') : ''
                return cmdRef(p, command)
            },
            reply(text, options = {}) {
                return sendStyledReply({
                    db,
                    sock,
                    m,
                    text: String(text),
                    opts: options,
                    botName: config.botName,
                })
            },
            send(jid, content, options = {}) {
                return sock.sendMessage(jid, content, { quoted: m, ...options })
            },
            resolveUser(identifier) {
                return this.resolver.resolveUser(identifier)
            },
        }

        ctx.replyMsg = (key, extraVars = {}) => {
            const text = renderReplyMsg(ctx, key, extraVars)
            if (text === null) {
                return ctx.reply(`[missing message: ${key}]`)
            }
            return ctx.reply(text)
        }

        await dispatchCommand(ctx, {
            sock,
            config,
            resolver: this.resolver,
            prefixManager,
            pluginLoader,
            store: this.store,
            roleRepo,
            protection: this.protection,
            activity,
        })
    }

    stop() {
        shutdownAll({
            bot: this,
            pluginLoader,
            autoDelete,
            ufs,
            activity,
            economyStore,
        })
    }
}